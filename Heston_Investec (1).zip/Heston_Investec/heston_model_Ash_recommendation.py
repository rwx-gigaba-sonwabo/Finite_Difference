"""
===============================================================================
 THE HESTON MODEL: A PRACTICAL APPROACH  --  Python edition
===============================================================================

A Python translation of:

    Nimalin Moodley (2005), "The Heston Model: A Practical Approach with
    Matlab Code", BSc Honours project, University of the Witwatersrand.

Every piece of theory from the paper lives in this file, next to the code
that implements it. The comments walk through each step so you can read the
file from top to bottom like the paper itself.

HOW THE FILE IS ORGANISED (mirrors the paper)
---------------------------------------------
  PART 0  Imports and a small parameter container
  PART 1  Chapter I   - the model, what the parameters do, PDE, risk-neutral
                        measure                                  (paper 1.1-1.3)
  PART 2  Appendix A.1 - Monte Carlo simulation of the price density
  PART 3  Chapter 2.1 - the closed-form solution for a European call
  PART 4  Chapter 2.3 - numerical integration (quadrature) rules
  PART 5  Chapter 2.2 - Fast Fourier Transform (Carr & Madan) pricing
  PART 6  Appendix A.2 - Black-Scholes implied volatility, smiles and surfaces
  PART 7  Chapter 3   - calibration: the problem, the objective, and five
                        optimisers (lsqnonlin, regularisation, Solver,
                        Simulated Annealing, Adaptive Simulated Annealing)
  PART 8  Plots that reproduce the paper's figures
  PART 9  A runnable walk-through (main)

HOW TO RUN
----------
    python heston_model.py            # quick tour, about a minute
    python heston_model.py --plots    # also saves the paper's figures as PNGs
    python heston_model.py --full     # longer, more thorough global calibration

Requires: numpy, scipy (and matplotlib for --plots).

MATLAB -> PYTHON MAP
--------------------
    HestonCallQuad          -> heston_call_quad()
    HestonP                 -> heston_P()
    HestonPIntegrand        -> heston_P_integrand()
    Hestf                   -> heston_f()
    HestonCallFft           -> heston_call_fft()
    HestonCallFftTimeValue  -> heston_call_fft_time_value()
    quad  (adaptive Simpson)       -> adaptive_simpson()
    quadl (adaptive Gauss-Lobatto) -> adaptive_gauss_lobatto()
    blsimpv                 -> bs_implied_vol()
    HestonLsCalibration     -> calibrate_lsqnonlin()   (scipy least_squares, 'trf')
    HestonDifferences       -> heston_differences()
    Excel Solver            -> calibrate_local_solver() (scipy SLSQP)
    HestonASACalibration    -> calibrate_asa()          (ASA written out in Python)
    HestonCostFunc          -> heston_cost_func()
    VolSmile.m, HestonVolSmileVolVol.m -> plot_* functions in PART 8

WHERE THE PYTHON DIFFERS FROM THE MATLAB (and why)
--------------------------------------------------
  1. HestonCallFft has a typo: the Simpson weights use (-i).^j where the paper
     says (-1)^j. The Python uses (-1)^j as in equation (2.13).
  2. HestonCallFftTimeValue: the Carr-Madan out-of-the-money formula assumes
     the spot is scaled to 1. The Python prices with S0 = 1 and strike K/S0,
     then multiplies by S0, so it works for any spot.
  3. In HestonLsCalibration the `options` (MaxFunEvals = 20000) are created
     but never passed to lsqnonlin. The Python passes them.
  4. The original closed form (paper eq. 2.1-2.2) gives wrong prices when the
     complex log crosses its branch cut, which happens for large kappa/sigma or
     long maturities (the "little Heston trap", Albrecher et al. 2007). It can
     also overflow to NaN. The default here is `formulation="stable"`, which
     is algebraically the same function but numerically safe. Pass
     `formulation="paper"` to reproduce the MATLAB numbers exactly.
     This matters: with formulation="paper" this file reproduces the paper's
     20 October results (S = 148.32, 77.36, 88.62 vs the paper's 148.32,
     77.38, 88.58), but Monte Carlo confirms the "stable" prices are the
     correct ones. At the paper's calibrated 20 October parameters the true
     S(Omega) is much higher (see the note in 3.3 below).
  7. HestonCallFft undoes the damping with exp(-alpha*log(strike)) at every
     grid point; the Python uses exp(-alpha*k_u) per grid point, as in (2.13).
     They agree at the grid point that is read off.
  8. Typos in the paper's equations, corrected here: (1.5) should discount
     with e^{-r(T-t)}; in C(T-t, phi) "r phi i r" should be "r phi i tau" and
     "e^{dr}" should be "e^{d tau}" (the MATLAB code has them right).
  5. MATLAB's quadl nudges off a non-finite endpoint. The Heston integrand is
     0/0 at phi = 0, so the Python starts at phi = 1e-8.
  6. Ingber's ASA (C code via asamin) is not available in Python. PART 7
     writes out the core ASA algorithm and also offers scipy's
     dual_annealing, a closely related generalised annealing method.
"""

# =============================================================================
# PART 0 -- IMPORTS AND A PARAMETER CONTAINER
# =============================================================================
from __future__ import annotations

import argparse
import math
import time
from dataclasses import dataclass, asdict

import numpy as np
from scipy import optimize, stats

# Short-hand for the imaginary unit. MATLAB uses `i`; in Python it is `1j`.
I = 1j


@dataclass
class HestonParams:
    """
    The five Heston parameters estimated in calibration (paper 3.1).

    kappa : rate of mean reversion of the variance
    theta : long-run mean (level) of the variance
    sigma : volatility of volatility
    rho   : correlation between the two Brownian motions
    v0    : today's (initial) variance, V_0

    Note: these are VARIANCE quantities. A volatility of 20% is a variance of
    0.2^2 = 0.04, which is why theta = 0.04 appears so often in the paper.
    """
    kappa: float
    theta: float
    sigma: float
    rho: float
    v0: float

    def as_array(self) -> np.ndarray:
        return np.array([self.kappa, self.theta, self.sigma, self.rho, self.v0])

    @classmethod
    def from_array(cls, x) -> "HestonParams":
        return cls(*[float(v) for v in x])

    def feller(self) -> float:
        """2*kappa*theta - sigma^2. Positive means the variance stays above 0."""
        return 2 * self.kappa * self.theta - self.sigma ** 2

    def __str__(self) -> str:
        return ("kappa={kappa:.4f} theta={theta:.4f} sigma={sigma:.4f} "
                "rho={rho:.4f} v0={v0:.4f}".format(**asdict(self)))


# =============================================================================
# PART 1 -- CHAPTER I: A BRIEF OVERVIEW OF THE MODEL
# =============================================================================
#
# 1.1  THE HESTON MODEL
# ---------------------
# Heston (1993) proposed:
#
#     dS_t = mu * S_t dt + sqrt(V_t) * S_t dW1_t                       (1.1)
#     dV_t = kappa * (theta - V_t) dt + sigma * sqrt(V_t) dW2_t        (1.2)
#     dW1_t dW2_t = rho dt                                             (1.3)
#
#   * S_t is the asset price and V_t its instantaneous VARIANCE.
#   * W1 and W2 are Brownian motions with correlation rho.
#   * V_t is a square-root, mean-reverting (CIR) process (Cox, Ingersoll &
#     Ross 1985): it is pulled towards the long-run mean theta at speed kappa.
#   * sigma is the "volatility of volatility".
#   * All parameters (mu, kappa, theta, sigma, rho) are constant in time and
#     state.
#
# 1.2  MOTIVATION: WHAT EACH PARAMETER DOES
# -----------------------------------------
# Real log-returns are not normal. They have fat tails and a high peak
# (leptokurtic), and equity returns are negatively correlated with volatility
# (the "leverage effect"). Black-Scholes-Merton (BSM) cannot capture any of
# this; Heston can.
#
#   rho  -> SKEWNESS.
#           rho > 0: volatility rises when the price rises, so the right tail
#           spreads and the left tail is squeezed (fat right tail).
#           rho < 0: volatility rises when the price falls, so the left tail
#           is fat. This is the usual equity case.
#           Because skew changes, the implied volatility smile tilts too
#           (Figures 1.1 to 1.4, reproduced in PART 8).
#
#   sigma -> KURTOSIS (peakedness / tail weight).
#           sigma = 0 makes variance deterministic, so returns are normal.
#           Larger sigma fattens BOTH tails. On the implied volatility curve,
#           a larger sigma makes the smile/skew more pronounced
#           (Figures 1.5 to 1.8). Intuition: more volatile volatility means a
#           greater chance of extreme moves, so put writers charge more and
#           call writers less for a given strike.
#
#   kappa -> VOLATILITY CLUSTERING. It controls how quickly a shock to
#           variance dies out. Large moves tend to be followed by large moves
#           (Cont 2001).
#
# Heston also has a closed-form price for European options for ANY rho,
# which makes it much more tractable than most stochastic volatility models
# (Hull-White, for example, only has closed forms for special rho).
#
# 1.3  PRICING OPTIONS
# --------------------
# In BSM the only source of randomness is the traded asset, so the market is
# complete and every claim can be hedged. In Heston there are TWO sources of
# randomness (S and V) but only S is traded. Volatility is not a traded
# asset, so the market is INCOMPLETE.
#
# 1.3.1  PDE approach
#   Any option value U(S, V, t) must satisfy
#
#     1/2 V S^2 U_SS + rho sigma V S U_SV + 1/2 sigma^2 V U_VV + r S U_S
#       + { kappa[theta - V] - Lambda(S,V,t) sigma sqrt(V) } U_V
#       - r U + U_t = 0                                                (1.4)
#
#   Lambda is the market price of volatility risk. Heston assumes it is
#   proportional to sqrt(V):  Lambda = k sqrt(V), so
#       Lambda * sigma * sqrt(V) = k sigma V =: lambda * V   (lambda constant)
#   lambda is almost impossible to estimate directly, but it turns out we
#   never need to (see below and 3.1).
#
# 1.3.2  Risk-neutral approach
#   Price = expected discounted payoff under an equivalent martingale
#   measure (EMM) Q:
#       Option value = E^Q_t[ e^{-r(T-t)} H(T) ]                       (1.5)
#   (The paper prints e^{+r(T-t)}; discounting needs the minus sign.)
#
#   Girsanov's theorem moves us from the real-world measure P to Q:
#       dW~1 = dW1 + vartheta_t dt,   vartheta_t = (mu - r)/sqrt(V_t)  (1.6, 1.9)
#       dW~2 = dW2 + Lambda dt                                         (1.7)
#   with the Radon-Nikodym derivative dQ/dP given by (1.8).
#
#   Under Q the dynamics become
#       dS_t = r S_t dt + sqrt(V_t) S_t dW~1_t                         (1.10)
#       dV_t = kappa*(theta* - V_t) dt + sigma sqrt(V_t) dW~2_t        (1.11)
#       dW~1 dW~2 = rho dt                                             (1.12)
#   where
#       kappa* = kappa + lambda,      theta* = kappa*theta/(kappa + lambda)
#
#   KEY RESULT: under Q, lambda disappears into kappa* and theta*. Because
#   the EMM is not unique (it depends on Lambda), different lambdas give
#   different prices. We side-step this by calibrating kappa* and theta*
#   straight to market prices. Everything below uses risk-neutral
#   parameters, i.e. lambda = 0.


def risk_neutral_params(kappa: float, theta: float, lam: float) -> tuple[float, float]:
    """
    Convert real-world (kappa, theta) plus the volatility risk premium lambda
    to the risk-neutral (kappa*, theta*) of equations (1.10)-(1.11).

        kappa* = kappa + lambda
        theta* = kappa * theta / (kappa + lambda)

    Note kappa* * theta* = kappa * theta: the "a" term in the closed form is
    unchanged. This is why
        OptionValue_P(kappa, theta, sigma, v0, rho, lambda)
          = OptionValue_Q(kappa*, theta*, sigma, v0, rho, 0)          (paper 3.2)
    """
    kappa_star = kappa + lam
    theta_star = kappa * theta / (kappa + lam)
    return kappa_star, theta_star


# =============================================================================
# PART 2 -- APPENDIX A.1: MONTE CARLO SIMULATION OF THE PRICE DENSITY
# =============================================================================
#
# Discretise (1.10)-(1.11) with Euler-Maruyama over a step dt:
#
#   S_t = S_{t-1} + r S_{t-1} dt + sqrt(V_{t-1}) S_{t-1} sqrt(dt) Z1
#   V_t = V_{t-1} + kappa(theta - V_{t-1}) dt + sigma sqrt(V_{t-1}) sqrt(dt) Z2
#
# Z1 and Z2 are standard normals with correlation rho. We build them from two
# INDEPENDENT standard normals phi1, phi2 with the Cholesky decomposition of
# the 2x2 correlation matrix [[1, rho], [rho, 1]]:
#
#   Z1 = phi1
#   Z2 = rho * phi1 + sqrt(1 - rho^2) * phi2
#
# Check: Var(Z2) = rho^2 + (1 - rho^2) = 1 and Cov(Z1, Z2) = rho.
#
# A NOTE ON THE ORIGINAL MATLAB
# The paper's code takes ONE time step, and in the price update it uses the
# NEW variance V_t rather than V_{t-1}:
#     S = S0 + r*S0*dt + S0*sqrt(V)*Z1*sqrt(dt)      (V already updated)
# That is what makes rho show up in Figure 1.1: V_t contains Z1 through Z2,
# so the price shock is scaled by a variance correlated with itself. With a
# true single Euler step (using V_0), S would be exactly normal and rho would
# have no effect. `scheme="paper"` reproduces the MATLAB exactly;
# `scheme="euler"` is a proper multi-step Euler scheme (full truncation) for
# anyone who wants a genuine Heston terminal distribution.


def simulate_terminal_prices(
    s0: float, v0: float, r: float, kappa: float, theta: float,
    sigma: float, rho: float, dt: float, n_paths: int,
    n_steps: int = 1, scheme: str = "paper", seed: int | None = 0,
) -> np.ndarray:
    """
    Simulate S at the end of `n_steps` steps of size `dt`.

    scheme="paper" : exactly the Appendix A.1 MATLAB (use n_steps=1).
    scheme="euler" : standard Euler-Maruyama with full truncation
                     (negative variance floored at 0 inside drift/diffusion).
    """
    rng = np.random.default_rng(seed)
    S = np.full(n_paths, s0, dtype=float)
    V = np.full(n_paths, v0, dtype=float)
    sqdt = math.sqrt(dt)

    for _ in range(n_steps):
        # Step 1: two independent standard normals per path.
        phi1 = rng.standard_normal(n_paths)
        phi2 = rng.standard_normal(n_paths)
        # Step 2: Cholesky to correlate them.
        z1 = phi1
        z2 = rho * phi1 + math.sqrt(1.0 - rho ** 2) * phi2

        if scheme == "paper":
            # Step 3a (MATLAB): update V first ...
            V_new = V + kappa * (theta - V) * dt + sigma * np.sqrt(V) * z2 * sqdt
            V_new = np.abs(V_new)            # "prevents negative volatilities"
            # ... then use the NEW V in the price step.
            S = S + r * S * dt + S * np.sqrt(V_new) * z1 * sqdt
            V = V_new
        elif scheme == "euler":
            # Step 3b: textbook Euler using start-of-step values.
            Vp = np.maximum(V, 0.0)          # full truncation
            S = S + r * S * dt + np.sqrt(Vp) * S * sqdt * z1
            V = V + kappa * (theta - Vp) * dt + sigma * np.sqrt(Vp) * sqdt * z2
        else:
            raise ValueError("scheme must be 'paper' or 'euler'")
    return S


def mc_call_price(s0, K, T, r, p: HestonParams, n_paths=200_000, n_steps=200, seed=1):
    """Monte Carlo European call: discounted average of max(S_T - K, 0)."""
    ST = simulate_terminal_prices(s0, p.v0, r, p.kappa, p.theta, p.sigma, p.rho,
                                  dt=T / n_steps, n_paths=n_paths,
                                  n_steps=n_steps, scheme="euler", seed=seed)
    payoff = np.maximum(ST - K, 0.0)
    disc = math.exp(-r * T)
    price = disc * payoff.mean()
    stderr = disc * payoff.std(ddof=1) / math.sqrt(n_paths)
    return price, stderr


# =============================================================================
# PART 3 -- CHAPTER 2.1: THE CLOSED-FORM SOLUTION
# =============================================================================
#
# For a European call on a non-dividend-paying asset:
#
#   C(S_t, V_t, t, T) = S_t * P1 - K e^{-r(T-t)} * P2                  (2.1)
#
# P1 and P2 are probabilities that the option ends in the money, each under a
# different measure (P2 under Q; P1 under the measure that uses the stock as
# numeraire). This is the same shape as BSM's S N(d1) - K e^{-rT} N(d2).
# They are recovered from characteristic functions f_j by Fourier inversion:
#
#   P_j = 1/2 + 1/pi * Integral_0^inf Re[ e^{-i phi ln K} f_j(x, V_t, T, phi)
#                                         / (i phi) ] d phi            (2.2)
#
# with tau = T - t, x = ln S_t and, for j = 1, 2:
#
#   f_j = exp{ C(tau, phi) + D(tau, phi) V_t + i phi x }
#   C   = r phi i tau + a/sigma^2 [ (b_j - rho sigma phi i + d) tau
#                                   - 2 ln( (1 - g e^{d tau}) / (1 - g) ) ]
#   D   = (b_j - rho sigma phi i + d)/sigma^2 * (1 - e^{d tau})/(1 - g e^{d tau})
#   g   = (b_j - rho sigma phi i + d) / (b_j - rho sigma phi i - d)
#   d   = sqrt( (rho sigma phi i - b_j)^2 - sigma^2 (2 u_j phi i - phi^2) )
#
#   u1 = 1/2,  u2 = -1/2,  a = kappa theta,
#   b1 = kappa + lambda - rho sigma,  b2 = kappa + lambda
#
# Under the EMM Q (lambda = 0): a = kappa* theta*, b1 = kappa* - rho sigma,
# b2 = kappa*. lambda is gone.
#
# The only hard part is the integral in (2.2): it has no closed form, so we
# approximate it numerically (PART 4).
#
# "Stable" formulation: replacing d with -d leaves f_j mathematically
# unchanged but keeps the complex logarithm on its principal branch, which
# avoids the "little Heston trap" (Albrecher, Mayer, Schoutens & Tistaert
# 2007). With g2 = 1/g:
#   C = r phi i tau + a/sigma^2 [ (b - rho sigma phi i - d) tau
#                                 - 2 ln( (1 - g2 e^{-d tau}) / (1 - g2) ) ]
#   D = (b - rho sigma phi i - d)/sigma^2 * (1 - e^{-d tau})/(1 - g2 e^{-d tau})


def heston_f(phi, kappa, theta, sigma, rho, v0, r, T, s0, j, lam=0.0,
             formulation="stable"):
    """
    MATLAB `Hestf`: the characteristic function f_j of equation (2.2).
    `phi` may be a scalar or numpy array (vectorised).
    """
    phi = np.asarray(phi, dtype=complex)

    # Step 1: pick u_j and b_j for P1 (j=1) or P2 (j=2).
    if j == 1:
        u = 0.5
        b = kappa + lam - rho * sigma
    else:
        u = -0.5
        b = kappa + lam

    # Step 2: the constants.
    a = kappa * theta
    x = np.log(s0)

    # Step 3: d, the square root that appears throughout.
    d = np.sqrt((rho * sigma * phi * I - b) ** 2
                - sigma ** 2 * (2 * u * phi * I - phi ** 2))

    bm = b - rho * sigma * phi * I          # shorthand: b_j - rho sigma phi i

    if formulation == "paper":
        # Step 4a: Heston's original form, exactly as in the paper/MATLAB.
        g = (bm + d) / (bm - d)
        C = (r * phi * I * T
             + a / sigma ** 2 * ((bm + d) * T
                                 - 2 * np.log((1 - g * np.exp(d * T)) / (1 - g))))
        D = (bm + d) / sigma ** 2 * ((1 - np.exp(d * T)) / (1 - g * np.exp(d * T)))
    elif formulation == "stable":
        # Step 4b: same function, rewritten to avoid branch-cut jumps.
        g2 = (bm - d) / (bm + d)
        e = np.exp(-d * T)
        C = (r * phi * I * T
             + a / sigma ** 2 * ((bm - d) * T
                                 - 2 * np.log((1 - g2 * e) / (1 - g2))))
        D = (bm - d) / sigma ** 2 * ((1 - e) / (1 - g2 * e))
    else:
        raise ValueError("formulation must be 'paper' or 'stable'")

    # Step 5: assemble f_j = exp(C + D V0 + i phi x).
    return np.exp(C + D * v0 + I * phi * x)


def heston_P_integrand(phi, kappa, theta, sigma, rho, v0, r, T, s0, K, j,
                       formulation="stable"):
    """
    MATLAB `HestonPIntegrand`: Re[ e^{-i phi ln K} f_j / (i phi) ].
    This is the function plotted in Figure 2.2. It decays to zero quickly,
    which is why the infinite integral can be cut off at phi = 100.
    """
    phi = np.asarray(phi, dtype=float)
    f = heston_f(phi, kappa, theta, sigma, rho, v0, r, T, s0, j,
                 formulation=formulation)
    return np.real(np.exp(-I * phi * np.log(K)) * f / (I * phi))


# The upper limit that replaces infinity in (2.2). The paper: "I have chosen
# b = 100 to be prudent." The lower limit is nudged off 0 (0/0 there).
PHI_MIN, PHI_MAX = 1e-8, 100.0


def heston_P(kappa, theta, sigma, rho, v0, r, T, s0, K, j,
             method="lobatto", tol=1e-6, formulation="stable"):
    """
    MATLAB `HestonP`: P_j = 1/2 + (1/pi) * Integral_0^100 integrand d phi.

    method: "lobatto"  -> adaptive Gauss-Lobatto (MATLAB quadl), the paper's choice
            "simpson"  -> adaptive Simpson       (MATLAB quad)
            "legendre" -> fixed 128-node Gauss-Legendre (fast; used for calibration)
            "scipy"    -> scipy.integrate.quad (QUADPACK), as an independent check
    """
    func = lambda ph: heston_P_integrand(ph, kappa, theta, sigma, rho, v0, r, T,
                                         s0, K, j, formulation)
    if method == "lobatto":
        integral = adaptive_gauss_lobatto(func, PHI_MIN, PHI_MAX, tol)
    elif method == "simpson":
        integral = adaptive_simpson(func, PHI_MIN, PHI_MAX, tol)
    elif method == "legendre":
        integral = gauss_legendre(func, PHI_MIN, PHI_MAX, n=128)
    elif method == "scipy":
        from scipy.integrate import quad
        integral = quad(lambda ph: float(func(ph)), PHI_MIN, PHI_MAX,
                        limit=200, epsabs=tol)[0]
    else:
        raise ValueError(method)
    return 0.5 + integral / math.pi


def heston_call_quad(kappa, theta, sigma, rho, v0, r, T, s0, K,
                     method="lobatto", tol=1e-6, formulation="stable"):
    """
    MATLAB `HestonCallQuad`: equation (2.1),
        C = S0 * P1 - K e^{-rT} * P2.
    Argument order matches the MATLAB: (kappa, theta, sigma, rho, v0, r, T, s0, K).
    """
    P1 = heston_P(kappa, theta, sigma, rho, v0, r, T, s0, K, 1, method, tol, formulation)
    P2 = heston_P(kappa, theta, sigma, rho, v0, r, T, s0, K, 2, method, tol, formulation)
    return s0 * P1 - K * math.exp(-r * T) * P2


# ---- Vectorised pricer for many options at once (speed for calibration) ----
# Calibration prices dozens of options thousands of times. Pricing them one
# by one with a Python-level adaptive rule is slow, so this version evaluates
# every option on the same 128 Gauss-Legendre nodes in one numpy call. It is
# the same formula (2.1)-(2.2) with a fixed quadrature rule; PART 9 checks
# that it matches the adaptive Lobatto answer.
_GL_NODES, _GL_WEIGHTS = np.polynomial.legendre.leggauss(128)


def heston_call_vectorised(p: HestonParams, s0, K, T, r, formulation="stable"):
    K = np.atleast_1d(np.asarray(K, float))[:, None]    # shape (m, 1)
    T = np.atleast_1d(np.asarray(T, float))[:, None]
    r = np.atleast_1d(np.asarray(r, float))[:, None]
    s0 = np.atleast_1d(np.asarray(s0, float))[:, None]
    # Map Legendre nodes from [-1, 1] to [PHI_MIN, PHI_MAX] (linear change of
    # variables, see 2.3.2).
    half = 0.5 * (PHI_MAX - PHI_MIN)
    phi = (PHI_MIN + PHI_MAX) / 2 + half * _GL_NODES[None, :]   # shape (1, n)
    w = half * _GL_WEIGHTS[None, :]
    P = []
    for j in (1, 2):
        f = heston_f(phi, p.kappa, p.theta, p.sigma, p.rho, p.v0, r, T, s0, j,
                     formulation=formulation)
        integrand = np.real(np.exp(-I * phi * np.log(K)) * f / (I * phi))
        P.append(0.5 + (integrand * w).sum(axis=1) / math.pi)
    call = s0[:, 0] * P[0] - K[:, 0] * np.exp(-r[:, 0] * T[:, 0]) * P[1]
    return call


# =============================================================================
# PART 4 -- CHAPTER 2.3: NUMERICAL INTEGRATION (QUADRATURE RULES)
# =============================================================================
#
# 2.3.1  ADAPTIVE SIMPSON'S RULE  (Cheney & Kincaid 1999)
# ------------------------------
# Basic Simpson over [a, a+2h]:
#     Int f  ~  h/3 [ f(a) + 4 f(a+h) + f(a+2h) ]                      (2.15)
#
# Error, by Taylor expansion:
#   Expand f(a+h), f(a+2h) about a and plug into the RHS of (2.15):
#     RHS = 2h f + 2h^2 f' + 4/3 h^3 f'' + 2/3 h^4 f''' + 20/(3*4!) h^5 f'''' + ...  (2.16)
#   Let F(x) = Int_a^x f. By the Fundamental Theorem of Calculus
#   F^{(n+1)} = f^{(n)} and F(a) = 0, so
#     Int_a^{a+2h} f = F(a+2h)
#                    = 2h f + 2h^2 f' + 4/3 h^3 f'' + 2/3 h^4 f''' + 2^5/5! h^5 f'''' + ... (2.17)
#   Subtracting (2.16) from (2.17):
#     Error = -(h^5 / 90) f''''(xi) = O(h^5),  xi in (a, a+2h)
#
# General form on [a, b]:
#     Int_a^b f ~ (b-a)/6 [ f(a) + 4 f((a+b)/2) + f(b) ]
#     Error = -(1/90) ((b-a)/2)^5 f''''(xi)
#
# ADAPTIVE: compare one Simpson estimate S on [a,b] with the sum S2 of the two
# half-interval estimates. Because the error scales like h^5, halving h cuts
# it by 2^4 = 16, so |S2 - S| / 15 estimates the error of S2. If that is
# below the tolerance, accept (with Richardson correction S2 + (S2 - S)/15);
# otherwise split and recurse, giving each half half the tolerance. Where the
# function is smooth the intervals stay wide; where it wiggles they shrink.
# MATLAB's quad(@fun, a, b) does this with a default tolerance of 1e-6.


def simpson_basic(f, a, b):
    """Basic Simpson rule on [a, b] (the general form above)."""
    m = 0.5 * (a + b)
    return (b - a) / 6.0 * (f(a) + 4.0 * f(m) + f(b))


def adaptive_simpson(f, a, b, tol=1e-6, max_depth=50):
    """Recursive adaptive Simpson (equivalent in spirit to MATLAB quad)."""
    def _rec(a, b, fa, fm, fb, whole, tol, depth):
        m = 0.5 * (a + b)
        lm, rm = 0.5 * (a + m), 0.5 * (m + b)
        flm, frm = float(f(lm)), float(f(rm))
        left = (m - a) / 6.0 * (fa + 4 * flm + fm)
        right = (b - m) / 6.0 * (fm + 4 * frm + fb)
        delta = left + right - whole
        if not math.isfinite(delta):
            return float("nan")                          # bad integrand: stop, don't recurse
        if depth <= 0 or abs(delta) <= 15.0 * tol:
            return left + right + delta / 15.0          # Richardson extrapolation
        return (_rec(a, m, fa, flm, fm, left, tol / 2, depth - 1)
                + _rec(m, b, fm, frm, fb, right, tol / 2, depth - 1))

    fa, fb, fm = float(f(a)), float(f(b)), float(f(0.5 * (a + b)))
    whole = (b - a) / 6.0 * (fa + 4 * fm + fb)
    return _rec(a, b, fa, fm, fb, whole, tol, max_depth)


# 2.3.2  ADAPTIVE GAUSSIAN QUADRATURE RULES
# ----------------------------------------
# A Gaussian rule approximates
#     Int_a^b f(x) dx  ~  Sum_{i=0}^{n} A_i f(x_i)                      (2.18)
# with weights  A_i = Int_a^b l_i(x) dx,
#     l_i(x) = Prod_{j != i} (x - x_j)/(x_i - x_j)   (Lagrange basis polynomials).
#
# The nodes x_i are the zeros of a polynomial p_{n+1} orthogonal to all
# lower powers: Int_a^b x^k p(x) dx = 0 for 0 <= k <= n. The usual choice is
# the LEGENDRE polynomials on [-1, 1] (standardised so p_n(1) = 1); any [a, b]
# maps linearly onto [-1, 1]. With n+1 well-chosen nodes the rule is exact
# for polynomials of degree 2n+1, which is why Gaussian rules are so accurate.
# (Figure 2.1 of the paper shows Lagrange interpolating polynomials through
# 2, 3, 4, 5 points: a polynomial of order n-1 through n points.)
#
# GAUSS-LOBATTO is a Gaussian rule whose nodes also include both endpoints
# and are symmetric about 0. Its error is
#     Error = - n (n-1)^3 2^{2n-1} ((n-2)!)^4 / ((2n-1) ((2n-2)!)^3) f^{(2n-2)}(xi)
# MATLAB's quadl uses the adaptive Gauss-Lobatto algorithm of Gander &
# Gautschi (1998), "Adaptive quadrature - revisited". It is written out below:
#   * a 4-point Gauss-Lobatto rule (exact to degree 5) and its 7-point Kronrod
#     extension (exact to degree 9) are computed on each interval;
#   * if they agree to within the tolerance (measured relative to a rough
#     estimate of the whole integral), accept; otherwise split the interval
#     into 6 pieces at the Lobatto nodes and recurse.
#
# 2.3.4  WHICH RULE?  Gander & Gautschi: for very small tolerances quadl beats
# quad on efficiency (fewer recursive steps) and reliability (the requested
# tolerance is actually achieved). Option pricing needs tight tolerances, so
# the paper uses quadl, i.e. adaptive_gauss_lobatto here.


def adaptive_gauss_lobatto(f, a, b, tol=1e-6):
    """Gander & Gautschi (1998) adaptlob, the algorithm behind MATLAB quadl."""
    eps = np.finfo(float).eps
    alpha, beta = math.sqrt(2.0 / 3.0), 1.0 / math.sqrt(5.0)
    x1, x2, x3 = 0.942882415695480, 0.641853342345781, 0.236383199662150

    # Step 1: rough global estimate using a 13-point Kronrod rule on [a, b].
    m, h = 0.5 * (a + b), 0.5 * (b - a)
    x = np.array([a, m - x1 * h, m - alpha * h, m - x2 * h, m - beta * h,
                  m - x3 * h, m, m + x3 * h, m + beta * h, m + x2 * h,
                  m + alpha * h, m + x1 * h, b])
    y = np.asarray(f(x), float)
    fa, fb = y[0], y[12]
    i2 = (h / 6) * (y[0] + y[12] + 5 * (y[4] + y[8]))
    i1 = (h / 1470) * (77 * (y[0] + y[12]) + 432 * (y[2] + y[10])
                       + 625 * (y[4] + y[8]) + 672 * y[6])
    is_ = h * (0.0158271919734802 * (y[0] + y[12]) + 0.0942738402188500 * (y[1] + y[11])
               + 0.155071987336585 * (y[2] + y[10]) + 0.188821573960182 * (y[3] + y[9])
               + 0.199773405226859 * (y[4] + y[8]) + 0.224926465333340 * (y[5] + y[7])
               + 0.242611071901408 * y[6])
    # Step 2: turn the tolerance into a "significance" scale `is_`. Adding a
    # difference smaller than tol*|integral| to is_ then leaves it unchanged
    # in floating point, which is the stopping test below.
    s = 1.0 if is_ == 0 else math.copysign(1.0, is_)
    erri1, erri2 = abs(i1 - is_), abs(i2 - is_)
    R = erri1 / erri2 if erri2 != 0 else 1.0
    if 0 < R < 1:
        tol = tol / R
    is_ = s * abs(is_) * tol / eps
    if is_ == 0:
        is_ = b - a

    # Step 3: recursive step on each subinterval.
    def _step(a, b, fa, fb, depth):
        h, m = 0.5 * (b - a), 0.5 * (a + b)
        mll, ml, mr, mrr = m - alpha * h, m - beta * h, m + beta * h, m + alpha * h
        y = np.asarray(f(np.array([mll, ml, m, mr, mrr])), float)
        fmll, fml, fm, fmr, fmrr = y
        i2 = (h / 6) * (fa + fb + 5 * (fml + fmr))                    # 4-pt Lobatto
        i1 = (h / 1470) * (77 * (fa + fb) + 432 * (fmll + fmrr)
                           + 625 * (fml + fmr) + 672 * fm)              # 7-pt Kronrod
        if not (math.isfinite(i1) and math.isfinite(i2)):
            return float("nan")          # NaN/inf integrand (e.g. overflow): stop here
        # Stop when (a) the two rules agree to working precision relative to
        # the whole integral, (b) the interval can't be split further, or
        # (c) a depth cap is hit (6-way splitting grows very fast).
        if (is_ + (i1 - i2) == is_) or (mll <= a) or (b <= mrr) or depth > 12:
            return i1
        return (_step(a, mll, fa, fmll, depth + 1) + _step(mll, ml, fmll, fml, depth + 1)
                + _step(ml, m, fml, fm, depth + 1) + _step(m, mr, fm, fmr, depth + 1)
                + _step(mr, mrr, fmr, fmrr, depth + 1) + _step(mrr, b, fmrr, fb, depth + 1))

    return _step(a, b, fa, fb, 0)


def gauss_legendre(f, a, b, n=128):
    """Fixed n-point Gauss-Legendre rule on [a, b] (equation 2.18)."""
    x, w = np.polynomial.legendre.leggauss(n)
    xm, xr = 0.5 * (a + b), 0.5 * (b - a)
    return xr * np.sum(w * f(xm + xr * x))


# =============================================================================
# PART 5 -- CHAPTER 2.2: FAST FOURIER TRANSFORM (Carr & Madan 1999)
# =============================================================================
#
# Definition 2.1 (Fourier transform pair):
#     F{f}(phi)  = Int e^{i phi x} f(x) dx = F(phi)                     (2.3)
#     F^-1{F}(x) = 1/(2 pi) Int e^{-i phi x} F(phi) d phi = f(x)        (2.4)
# If f is the risk-neutral density of the log-price, F is its characteristic
# function, E[e^{i phi X}]. (The characteristic function exists even when X
# has no density.)
#
# The FFT computes sums of the form
#     w(k) = Sum_{j=1}^{N} e^{-i 2pi/N (j-1)(k-1)} x(j)                 (2.5)
# in O(N log N) instead of O(N^2) operations.
#
# Setting up the call as a Fourier integral. Let x_T = ln S_T, k = ln K:
#     C_T(k) = e^{-rT} Int_k^inf (e^{x} - e^{k}) f_T(x) dx              (2.6)
# C_T(k) is not square-integrable (it tends to S0 as k -> -inf), so Carr and
# Madan damp it:
#     c_T(k) = e^{alpha k} C_T(k),   alpha > 0 (the "dampening factor") (2.7)
# Transform, invert, and use the fact that C_T is real so only half the
# frequency axis is needed:
#     C_T(k) = e^{-alpha k}/pi Int_0^inf e^{-i phi k} Fc_T(phi) d phi   (2.10-2.12)
# Substituting (2.6)-(2.7) into (2.8) and swapping the order of integration:
#     Fc_T(phi) = e^{-rT} FC_T(phi - (alpha+1) i)
#                 / (alpha^2 + alpha - phi^2 + i (2 alpha + 1) phi)
# where FC_T is the characteristic function of x_T under Q (Hong 2004):
#
#     FC_T(phi) = exp(A + B + C)
#     A = i phi (x0 + r T)
#     B = 2 zeta (1 - e^{-psi T}) V0 / (2 psi - (psi - gamma)(1 - e^{-psi T}))
#     C = -kappa theta / sigma^2 [ 2 log( (2psi - (psi-gamma)(1-e^{-psi T})) / (2 psi) )
#                                  + (psi - gamma) T ]
#     zeta  = -1/2 (phi^2 + i phi)
#     psi   = sqrt(gamma^2 - 2 sigma^2 zeta)
#     gamma = kappa - rho sigma phi i
#
# Discretising the integral with Simpson weights gives (Carr & Madan):
#     C_T(k_u) ~ e^{-alpha k_u}/pi Sum_{j=1}^N e^{-i 2pi/N (j-1)(u-1)}
#                e^{i b v_j} Fc_T(v_j) eta/3 (3 + (-1)^j - delta_{j-1})  (2.13)
# with
#     v_j = eta (j-1),  eta = c/N,  c = 600,  N = 4096,  b = pi/eta,
#     k_u = -b + 2b/N (u-1)   (the log-strike grid)
# These values of c and N balance speed against accuracy. The sum is exactly
# the FFT form (2.5), so one fft call prices all N log-strikes at once.
#
# Choosing alpha: we need E[S_T^{alpha+1}] < infinity, i.e.
#     FC_T(-(alpha+1) i) < infinity                                     (2.14)
# The price depends on alpha (Figure 2.3) and the right alpha depends on the
# parameters in a non-obvious way. That is the FFT's weak spot. The paper's
# conclusion: FFT is about 2000x faster (4097 strikes in 0.14s vs 282s by
# quadrature), but quadrature is the primary tool unless a safe alpha is known.
# (Cross-check: with the Simpson-weight typo fixed, for kappa=2, theta=0.04,
# sigma=0.5, rho=-0.5, r=5%, S0=100, K=70, T=1 the FFT price is 33.909 for every
# alpha from 0.5 to 5, equal to quadrature. The MATLAB (-i) weights give
# 33.90-34.25 depending on alpha. So part of the alpha sensitivity the paper
# reports may come from that typo. Very small alpha still fails; see Fig 2.3.)


def heston_char_func(u, kappa, theta, sigma, rho, v0, r, T, s0):
    """Characteristic function of ln S_T under Q, in Hong's (2004) form."""
    u = np.asarray(u, dtype=complex)
    zeta = -0.5 * (u ** 2 + I * u)
    gamma = kappa - rho * sigma * u * I
    psi = np.sqrt(gamma ** 2 - 2 * sigma ** 2 * zeta)
    emt = 1 - np.exp(-psi * T)
    A = I * u * (np.log(s0) + r * T)
    B = v0 * (2 * zeta * emt) / (2 * psi - (psi - gamma) * emt)
    C = -kappa * theta / sigma ** 2 * (2 * np.log((2 * psi - (psi - gamma) * emt)
                                                  / (2 * psi)) + (psi - gamma) * T)
    return np.exp(A + B + C)


def _fft_grid(N=4096, c=600.0):
    eta = c / N                      # spacing of the integration grid in phi
    b = math.pi / eta                # half-width of the log-strike grid
    u = np.arange(N) * eta           # v_j = eta (j-1)
    lam = 2 * b / N                  # spacing of the log-strike grid
    k = -b + lam * np.arange(N)      # k_u = -b + 2b/N (u-1)
    # Simpson weights (3 + (-1)^j - delta_{j-1}) / 3 for j = 1..N.
    # (The MATLAB has (-i).^j here, a typo; the paper's formula is (-1)^j.)
    j = np.arange(1, N + 1)
    simpson = (3 + (-1.0) ** j - (j == 1)) / 3.0
    return eta, b, u, lam, k, simpson


def heston_call_fft(kappa, theta, sigma, rho, r, v0, s0, strike, T,
                    alpha=1.25, N=4096, c=600.0, interpolate=True, return_grid=False):
    """
    MATLAB `HestonCallFft`: in-the-money / at-the-money calls by FFT,
    equation (2.13). Argument order matches the MATLAB:
    (kappa, theta, sigma, rho, r, v0, s0, strike, T).

    interpolate=True  : linear interpolation between grid log-strikes
    interpolate=False : pick the nearest grid point (MATLAB `round(position)`)
    """
    eta, b, u, lam, k, simpson = _fft_grid(N, c)

    # Step 1: evaluate the characteristic function at the shifted point
    #         v = u - (alpha+1) i.
    v = u - (alpha + 1) * I
    cf = heston_char_func(v, kappa, theta, sigma, rho, v0, r, T, s0)

    # Step 2: the damped call's transform Fc_T(u).
    modified_cf = cf * math.exp(-r * T) / (alpha ** 2 + alpha - u ** 2
                                           + I * (2 * alpha + 1) * u)

    # Step 3: build the FFT input x(j) = e^{i b v_j} Fc_T(v_j) eta w_j.
    fft_input = np.exp(I * b * u) * modified_cf * eta * simpson

    # Step 4: one FFT gives the (damped) integral at every log-strike k_u.
    payoff = np.real(np.fft.fft(fft_input))

    # Step 5: undo the damping, e^{-alpha k}/pi.
    call_grid = np.exp(-alpha * k) * payoff / math.pi
    if return_grid:
        return np.exp(k), call_grid

    # Step 6: read off the requested strike.
    position = (np.log(strike) - k[0]) / lam          # 0-based grid index
    if interpolate:
        return float(np.interp(np.log(strike), k, call_grid))
    return float(call_grid[int(round(position))])


# Out-of-the-money FFT (Carr's "time value" version). An OTM option has no
# intrinsic value, so Carr & Madan transform the time value instead:
#
#   C_T(k_u) ~ 1/(pi sinh(alpha k_u)) Sum_j e^{-i 2pi/N (j-1)(u-1)} e^{i b v_j}
#              gamma_T(v_j) eta/3 (3 + (-1)^j - delta_{j-1})
#   gamma_T(v) = [ varphi_T(v - i alpha) - varphi_T(v + i alpha) ] / 2
#   varphi_T(v) = e^{-rT} [ 1/(1 + i v) - e^{rT}/(i v) - FC_T(v - i)/(v^2 - i v) ]
#
# This formula is derived with the spot normalised to S0 = 1, so the function
# below prices with S0 = 1 and strike K/S0, then scales by S0.


def heston_call_fft_time_value(kappa, theta, sigma, rho, r, v0, s0, strike, T,
                               alpha=1.25, N=4096, c=600.0, interpolate=True):
    """MATLAB `HestonCallFftTimeValue`: out-of-the-money calls by FFT."""
    eta, b, u, lam, k, simpson = _fft_grid(N, c)
    K_norm = strike / s0                              # normalise spot to 1

    def varphi(w):
        cf = heston_char_func(w - I, kappa, theta, sigma, rho, v0, r, T, 1.0)
        return math.exp(-r * T) * (1 / (1 + I * w) - math.exp(r * T) / (I * w)
                                   - cf / (w ** 2 - I * w))

    # gamma_T(v) = (varphi(v - i alpha) - varphi(v + i alpha)) / 2
    combo = (varphi(u - I * alpha) - varphi(u + I * alpha)) / 2
    fft_input = np.exp(I * b * u) * combo * eta * simpson
    payoff = np.real(np.fft.fft(fft_input))
    with np.errstate(divide="ignore", invalid="ignore"):
        call_grid = payoff / math.pi / np.sinh(alpha * k)   # blows up at k = 0 (ATM)
    if interpolate:
        val = float(np.interp(np.log(K_norm), k, call_grid))
    else:
        val = float(call_grid[int(round((np.log(K_norm) - k[0]) / lam))])
    return s0 * val


# =============================================================================
# PART 6 -- APPENDIX A.2: IMPLIED VOLATILITY, SMILES AND SURFACES
# =============================================================================
#
# Price European calls with Heston at a grid of strikes and maturities, then
# find the BSM volatility that reproduces each price. Plotting that implied
# volatility against strike/maturity gives the smiles and surfaces of
# Figures 1.2-1.4 and 1.6-1.8. MATLAB's blsimpv does the inversion; here
# we write BSM out and solve with Brent's method.


def bs_call(s0, K, T, r, vol):
    """Black-Scholes-Merton European call."""
    if vol <= 0 or T <= 0:
        return max(s0 - K * math.exp(-r * T), 0.0)
    d1 = (math.log(s0 / K) + (r + 0.5 * vol ** 2) * T) / (vol * math.sqrt(T))
    d2 = d1 - vol * math.sqrt(T)
    return s0 * stats.norm.cdf(d1) - K * math.exp(-r * T) * stats.norm.cdf(d2)


def bs_implied_vol(s0, K, r, T, price, lo=1e-6, hi=5.0):
    """MATLAB blsimpv(S0, K, r, T, price): solve bs_call(vol) = price for vol."""
    intrinsic = max(s0 - K * math.exp(-r * T), 0.0)
    if price <= intrinsic + 1e-12 or price >= s0:
        return float("nan")                       # no BSM vol can match
    return optimize.brentq(lambda v: bs_call(s0, K, T, r, v) - price, lo, hi,
                           xtol=1e-10)


def heston_implied_vol_surface(p: HestonParams, r=0.01, s0=1.0,
                               strikes=None, mats=None, method="legendre"):
    """
    VolSmile.m: Heston prices -> BSM implied vols on a strike x maturity grid.
    Returns (strikes, mats, vol_matrix[mats, strikes]).
    """
    strikes = np.linspace(0.8, 1.2, 11) if strikes is None else strikes
    mats = np.linspace(0.3, 3, 11) if mats is None else mats
    vols = np.empty((len(mats), len(strikes)))
    for a, T in enumerate(mats):
        for b_, K in enumerate(strikes):
            price = heston_call_quad(p.kappa, p.theta, p.sigma, p.rho, p.v0,
                                     r, T, s0, K, method=method)
            vols[a, b_] = bs_implied_vol(s0, K, r, T, price)
    return strikes, mats, vols


# =============================================================================
# PART 7 -- CHAPTER 3: CALIBRATION
# =============================================================================
#
# 3.1  THE CALIBRATION PROBLEM
# ----------------------------
# Heston has six parameters: kappa, theta, sigma, V0, rho, lambda. Implied
# parameters (those that reproduce option prices) differ from time-series
# estimates (Bakshi, Cao & Chen 1997), so we cannot simply estimate them from
# history. Instead we solve an INVERSE problem: find the parameters that make
# model prices match market prices.
#
#   min_Omega S(Omega) = min_Omega Sum_{i=1}^N w_i [ C_i^Omega(K_i,T_i) - C_i^M(K_i,T_i) ]^2   (3.1)
#
#   Omega      : parameter vector
#   C^Omega    : model price;  C^M : market (mid) price
#   w_i        : weights
#
# Working under the EMM Q removes lambda, leaving FIVE parameters:
#   OptionValue_P(kappa, theta, sigma, V0, rho, lambda)
#     = OptionValue_Q(kappa*, theta*, sigma, V0, rho, 0)
# (A side benefit: we never have to estimate the market price of vol risk.)
#
# ACCEPTANCE CRITERION. Use mid prices, but accept any Omega0 with
#   Sum w_i [C_i^Omega0 - C_i^M]^2  <=  Sum w_i [bid_i - ask_i]^2       (3.2)
# i.e. the model need only land, on average, inside the bid-offer spread.
# Fitting more tightly than that is spurious precision.
#
# WEIGHTS. w_i = 1/|bid_i - ask_i|: wide spread -> less certainty about the
# true price -> less weight. (Cont 2005 suggests implied vols instead.)
#
# CONSTRAINT. Keep the variance away from zero (Feller-type condition,
# Mikhailov & Nogel 2003):  2 kappa theta > sigma^2.
#
# WHY IT IS HARD. S(Omega) is neither convex nor structured (Figure 3.1):
#   * gradient-based methods can stall on flat or non-differentiable regions;
#   * a global minimum is hard to find and optimiser-dependent;
#   * the minimum need not be unique.
# The last two make it ILL-POSED: calibration is an inverse, ill-posed problem.
#
# A caveat of your own: a pricer with the branch-cut problem (formulation
# "paper") adds FALSE valleys to S(Omega) at large kappa/sigma. An optimiser
# will happily find them. Always calibrate with a stable pricer.

# Market data from the paper (end of A.4.1): vanilla calls on Anglo American,
# LSE. Columns: r-q, T, S0, K, mid, bid, offer.
# Note r-q (rate minus dividend yield) is passed as "r" to the pricer, as in
# the paper. That also discounts at r-q rather than r, a simplification the
# paper accepts.
OPTION_DATA = np.array([
    [0.022685, 0.126027, 1544.50, 1000.00, 559.00, 553.00, 565.00],
    [0.022685, 0.126027, 1544.50, 1050.00, 509.50, 503.50, 515.50],
    [0.022685, 0.126027, 1544.50, 1100.00, 460.00, 454.00, 466.00],
    [0.022685, 0.126027, 1544.50, 1150.00, 411.00, 405.00, 417.00],
    [0.022685, 0.126027, 1544.50, 1200.00, 362.50, 356.50, 368.50],
    [0.022342, 0.375342, 1544.50, 1200.00, 386.00, 378.50, 393.50],
    [0.022685, 0.126027, 1544.50, 1250.00, 315.00, 309.00, 321.00],
    [0.022342, 0.375342, 1544.50, 1250.00, 345.50, 338.00, 353.00],
    [0.022685, 0.126027, 1544.50, 1300.00, 269.50, 263.50, 275.50],
    [0.022342, 0.375342, 1544.50, 1300.00, 300.50, 293.00, 308.00],
    [0.022685, 0.126027, 1544.50, 1350.00, 223.00, 217.00, 229.00],
    [0.022342, 0.375342, 1544.50, 1350.00, 259.00, 251.50, 266.50],
    [0.021947, 0.627397, 1544.50, 1350.00, 281.00, 272.00, 290.00],
    [0.022685, 0.126027, 1544.50, 1400.00, 179.00, 176.00, 182.00],
    [0.022342, 0.375342, 1544.50, 1400.00, 221.00, 213.50, 228.50],
    [0.021947, 0.627397, 1544.50, 1400.00, 244.00, 235.00, 253.00],
    [0.022685, 0.126027, 1544.50, 1450.00, 140.00, 136.00, 144.00],
    [0.022342, 0.375342, 1544.50, 1450.00, 180.00, 174.00, 186.00],
    [0.021947, 0.627397, 1544.50, 1450.00, 207.50, 198.50, 216.50],
    [0.022685, 0.126027, 1544.50, 1500.00, 105.00, 102.00, 108.00],
    [0.022342, 0.375342, 1544.50, 1500.00, 149.50, 145.00, 154.00],
    [0.021947, 0.627397, 1544.50, 1500.00, 173.00, 166.00, 180.00],
    [0.022685, 0.126027, 1544.50, 1600.00,  56.50,  51.50,  61.50],
    [0.022342, 0.375342, 1544.50, 1600.00,  96.00,  92.00, 100.00],
    [0.021947, 0.627397, 1544.50, 1600.00, 121.00, 114.00, 128.00],
    [0.022685, 0.126027, 1544.50, 1700.00,  23.50,  20.50,  26.50],
    [0.022342, 0.375342, 1544.50, 1700.00,  57.25,  51.00,  63.50],
    [0.021947, 0.627397, 1544.50, 1700.00,  81.50,  77.00,  86.00],
    [0.022685, 0.126027, 1544.50, 1800.00,  10.00,   7.00,  13.00],
    [0.022342, 0.375342, 1544.50, 1800.00,  32.50,  28.00,  37.00],
    [0.021947, 0.627397, 1544.50, 1800.00,  50.50,  44.50,  56.50],
    [0.022685, 0.126027, 1544.50, 1900.00,   4.50,   2.00,   7.00],
    [0.022342, 0.375342, 1544.50, 1900.00,  18.25,  14.50,  22.00],
    [0.021947, 0.627397, 1544.50, 1900.00,  35.50,  29.50,  41.50],
])

# Parameter bounds used throughout: [kappa, theta, sigma, rho, v0]
LB = np.array([1e-4, 1e-4, 1e-4, -1.0, 1e-4])
UB = np.array([20.0, 1.0, 5.0, 0.0, 1.0])


class CalibrationProblem:
    """
    Holds the market data and everything the optimisers need:
    model prices, weighted residuals, S(Omega), the constraint, the
    acceptance threshold of (3.2), and the "PossibleSolutions" trick (3.4).
    """

    def __init__(self, data=OPTION_DATA, formulation="stable", pricer="vectorised"):
        # pricer="vectorised": fast fixed Gauss-Legendre (use for optimising)
        # pricer="lobatto"   : one-by-one adaptive Gauss-Lobatto, as in the MATLAB
        self.pricer = pricer
        self.r, self.T, self.S0, self.K, self.mid, self.bid, self.ask = data.T
        self.spread = np.abs(self.bid - self.ask)
        self.w = 1.0 / self.spread                   # w_i = 1/|bid - ask|
        self.formulation = formulation
        self.n_evals = 0                             # MATLAB NoOfIterations
        self.path = []                               # MATLAB ObjectiveFunc
        self.possible_solutions = []                 # MATLAB PossibleSolutions
        # RHS of (3.2): Sum w_i (bid_i - ask_i)^2  (= Sum |spread_i|).
        self.sum_bid_offer = float(np.sum(self.w * self.spread ** 2))

    # ---- model prices and residuals ----------------------------------------
    def model_prices(self, p: HestonParams):
        if self.pricer == "lobatto":
            return np.array([heston_call_quad(p.kappa, p.theta, p.sigma, p.rho, p.v0,
                                              r, T, s0, K, formulation=self.formulation)
                             for r, T, s0, K in zip(self.r, self.T, self.S0, self.K)])
        return heston_call_vectorised(p, self.S0, self.K, self.T, self.r,
                                      formulation=self.formulation)

    def residuals(self, p: HestonParams):
        """
        MATLAB HestonDifferences core: (C^M - C^Omega) / sqrt(|bid - ask|).
        Squaring and summing gives exactly S(Omega) with w_i = 1/|bid-ask|,
        which is the form least-squares solvers want.
        """
        return (self.mid - self.model_prices(p)) / np.sqrt(self.spread)

    def S(self, p: HestonParams) -> float:
        """The objective S(Omega) of (3.1)."""
        val = float(np.sum(self.residuals(p) ** 2))
        self._record(p, val)
        return val

    def _record(self, p, val):
        self.n_evals += 1
        self.path.append(val)
        # 3.4 trick: store every parameter set that satisfies (3.2).
        # Collected over many days, these sets can be compared to look for a
        # stationary region of parameters that always fits within the spread.
        if val <= self.sum_bid_offer:
            self.possible_solutions.append(p.as_array())

    @staticmethod
    def feasible(p: HestonParams) -> bool:
        """The constraint 2 kappa theta > sigma^2, plus a valid correlation."""
        return p.feller() > 0 and -1 <= p.rho <= 1

    def accept(self, p: HestonParams) -> bool:
        """Acceptance criterion (3.2)."""
        return float(np.sum(self.residuals(p) ** 2)) <= self.sum_bid_offer

    def reset(self):
        self.n_evals, self.path, self.possible_solutions = 0, [], []


# -----------------------------------------------------------------------------
# 3.2.2  MATLAB's lsqnonlin  -> scipy.optimize.least_squares(method="trf")
# -----------------------------------------------------------------------------
# lsqnonlin(fun, x0, lb, ub) minimises the sum of squares of the vector
# function `fun` subject to bounds, using an interior-reflective Newton
# (trust-region reflective) method (Coleman & Li 1994, 1996). scipy's
# least_squares with method="trf" is the same family of algorithm.
# It is a LOCAL optimiser: the answer depends on x0. If the result passes
# (3.2) we accept it; otherwise we restart from a different x0. It needs at
# least five market prices (as many equations as unknowns).
#
# Note: the upper bound 20 applies to 2 kappa theta - sigma^2, not to kappa,
# so kappa itself is effectively unbounded (the paper's x0 implies kappa = 81).
#
# The constraint trick. lsqnonlin only handles box bounds, not
# 2 kappa theta > sigma^2. So the paper optimises over
#     input = [2 kappa theta - sigma^2, theta, sigma, rho, v0]
# with the first entry bounded below by 0. The constraint is then just a
# bound, and kappa is recovered as
#     kappa = (input1 + sigma^2) / (2 theta).

def _from_feller_coords(x) -> HestonParams:
    feller, theta, sigma, rho, v0 = x
    kappa = (feller + sigma ** 2) / (2 * theta)
    return HestonParams(kappa, theta, sigma, rho, v0)


def _to_feller_coords(p: HestonParams) -> np.ndarray:
    return np.array([p.feller(), p.theta, p.sigma, p.rho, p.v0])


def heston_differences(x, prob: CalibrationProblem):
    """MATLAB HestonDifferences: vector of weighted price errors."""
    p = _from_feller_coords(x)
    res = prob.residuals(p)
    prob._record(p, float(np.sum(res ** 2)))
    return res


def calibrate_lsqnonlin(prob: CalibrationProblem, x0=None, max_nfev=20000,
                        regularisation=0.0, omega0=None):
    """
    MATLAB HestonLsCalibration.m.

    x0 is in "Feller coordinates" [2 kappa theta - sigma^2, theta, sigma, rho, v0],
    exactly as in the paper. The paper's starting point is
        x0 = [6.5482, 0.0731, 2.3012, -0.4176, 0.1838]
    with bounds lb = [0 0 0 -1 0], ub = [20 1 5 0 1].

    regularisation > 0 turns on the 3.2.1 penalty (see below).
    """
    x0 = np.array([6.5482, 0.0731, 2.3012, -0.4176, 0.1838]) if x0 is None else np.asarray(x0)
    lb = np.array([0.0, 1e-4, 1e-4, -1.0, 1e-4])
    ub = np.array([20.0, 1.0, 5.0, 0.0, 1.0])
    x0 = np.clip(x0, lb + 1e-10, ub - 1e-10)

    # ---------------------------------------------------------------------
    # 3.2.1  REGULARISATION (Chiarella, Craddock & El-Hassan 2000)
    # Add a penalty alpha * p(Omega) so the problem becomes (closer to)
    # convex:
    #   Sum w_i [C^Omega - C^M]^2 + alpha p(Omega)                     (3.3)
    # "Don't try to solve the given problem; solve a nearby one whose
    # solution is close to yours." Mikhailov & Nogel suggest
    #   alpha p(Omega) = ||Omega - Omega0||^2
    # with Omega0 an initial estimate, which makes the method local and
    # dependent on Omega0. The regularisation parameter alpha must also be
    # chosen (Cont 2005). In least-squares form the penalty is extra
    # residuals sqrt(alpha) * (Omega - Omega0).
    # ---------------------------------------------------------------------
    omega0 = x0.copy() if omega0 is None else np.asarray(omega0)

    def fun(x):
        res = heston_differences(x, prob)
        if regularisation > 0:
            res = np.concatenate([res, math.sqrt(regularisation) * (x - omega0)])
        return res

    t0 = time.perf_counter()
    sol = optimize.least_squares(fun, x0, bounds=(lb, ub), method="trf",
                                 max_nfev=max_nfev, x_scale="jac")
    elapsed = time.perf_counter() - t0
    # Convert back from Feller coordinates (the MATLAB `Solution = ...` line).
    p = _from_feller_coords(sol.x)
    return p, elapsed


# -----------------------------------------------------------------------------
# 3.2.3  EXCEL'S SOLVER  -> scipy.optimize.minimize(method="SLSQP")
# -----------------------------------------------------------------------------
# Solver uses Generalised Reduced Gradient (GRG), a local, gradient-based,
# constrained optimiser: very sensitive to the starting point, so use it only
# when you already have a good guess. Its appeal is that everyone has Excel;
# its weakness is poor handling of very small numbers (e.g. when checking
# 2 kappa theta > sigma^2), which can make results suspect.
# The nearest scipy equivalent is SLSQP (Sequential Least Squares
# Programming), also a local gradient-based method with explicit constraints.

def calibrate_local_solver(prob: CalibrationProblem, p0: HestonParams):
    def obj(x):
        return prob.S(HestonParams.from_array(x))

    cons = [{"type": "ineq", "fun": lambda x: 2 * x[0] * x[1] - x[2] ** 2 - 1e-8}]
    t0 = time.perf_counter()
    sol = optimize.minimize(obj, p0.as_array(), method="SLSQP",
                            bounds=list(zip(LB, UB)), constraints=cons,
                            options={"maxiter": 500, "ftol": 1e-10})
    return HestonParams.from_array(sol.x), time.perf_counter() - t0


# -----------------------------------------------------------------------------
# 3.2.4  SIMULATED ANNEALING (SA)
# -----------------------------------------------------------------------------
# A probability-based, non-linear optimiser inspired by annealing (heating
# and cooling metal so its atoms settle into a low-energy structure).
# Metropolis et al. (1953) invented the algorithm; Kirkpatrick, Gelatt &
# Vecchi (1983) applied it to optimisation. Its strengths: it copes with
# arbitrary nonlinearities, discontinuities, noise and constraints; it is
# short to code; and it statistically guarantees finding an optimum.
#
# The algorithm:
#   1. Evaluate the objective at the initial parameters.
#   2. Generate a random nearby parameter set.
#   3. If the objective is lower, ACCEPT it. Otherwise accept it anyway with
#      probability exp(-delta_f / T_k), where delta_f is the increase and
#      T_k is the "temperature" at iteration k.
#   4. Lower the temperature and repeat until a stopping condition (usually
#      a minimum temperature).
#
# Accepting some uphill moves stops it getting stuck in a local minimum.
# Picture a bouncing ball over a landscape: when hot it bounces between any
# valleys; as it cools it loses energy and settles into the deepest one
# nearby. The optimiser only needs objective VALUES, not gradients: the
# objective is a black box that also reports whether a point is feasible
# (here: 2 kappa theta > sigma^2). The temperature schedule, step sizes and
# so on form the "annealing scheme"; tuning it is something of an art.

def heston_cost_func(x, prob: CalibrationProblem):
    """
    MATLAB HestonCostFunc: returns (cost, flag).
    flag = 0 if the constraint is violated (the optimiser must reject the
    point), else 1.
    """
    p = HestonParams.from_array(x)
    if not prob.feasible(p):
        return 0.0, 0
    return prob.S(p), 1


def simulated_annealing(prob, x0, lb=LB, ub=UB, T0=None, cooling=0.95,
                        moves_per_temp=50, T_min_ratio=1e-6, step=0.1, seed=0,
                        max_evals=20000):
    """Plain SA, exactly the four steps above."""
    rng = np.random.default_rng(seed)
    x = np.asarray(x0, float)
    f, flag = heston_cost_func(x, prob)                       # step 1
    if not flag:
        raise ValueError("initial point violates 2*kappa*theta > sigma^2")
    best_x, best_f = x.copy(), f
    T = T0 if T0 is not None else max(f, 1.0)                 # start hot
    T_end = T * T_min_ratio
    evals = 0
    while T > T_end and evals < max_evals:
        for _ in range(moves_per_temp):
            # step 2: random neighbour, step size shrinking with temperature
            scale = step * (ub - lb) * max(math.sqrt(T / (T_end / T_min_ratio)), 0.01)
            cand = np.clip(x + scale * rng.standard_normal(x.size), lb, ub)
            fc, flag = heston_cost_func(cand, prob)
            evals += 1
            if not flag:
                continue                                      # infeasible: reject
            delta = fc - f
            # step 3: Metropolis acceptance rule
            if delta < 0 or rng.random() < math.exp(-delta / T):
                x, f = cand, fc
                if f < best_f:
                    best_x, best_f = x.copy(), f
        T *= cooling                                          # step 4: cool down
    return HestonParams.from_array(best_x)


# -----------------------------------------------------------------------------
# 3.2.5  ADAPTIVE SIMULATED ANNEALING (ASA)  (Ingber 1993, 1995)
# -----------------------------------------------------------------------------
# ASA is SA that adapts its own annealing scheme from statistics of its
# progress, which removes much of the hand tuning. Ingber proves it is a
# global optimiser. The paper runs Ingber's C code through the MATLAB gateway
# `asamin` (Sakata). Here the core ASA algorithm is written out:
#
#   * EACH parameter i has its own generating temperature
#         T_i(k) = T_i0 exp(-c_i k^{1/D})       (D = number of parameters)
#     This schedule is exponentially fast yet keeps the global-convergence
#     guarantee (plain Boltzmann annealing needs T ~ 1/log k, which is far
#     slower).
#   * New points come from Ingber's heavy-tailed generating distribution:
#         u ~ U(0,1)
#         y_i = sign(u - 1/2) T_i [ (1 + 1/T_i)^{|2u - 1|} - 1 ]  in [-1, 1]
#         x_i' = x_i + y_i (ub_i - lb_i)       (resample if out of bounds)
#     Mostly small steps, occasionally very long jumps, which lets it keep
#     exploring the whole space (the oscillation in Figure 3.3).
#   * A separate ACCEPTANCE temperature T_cost(k), with the same kind of
#     schedule, is used in the Metropolis test exp(-delta_f / T_cost). Its
#     starting value is set from the spread of costs in an initial sample.
#   * Full ASA also periodically "re-anneals" (rescales T_i by how sensitive
#     the cost is to each parameter). That refinement is omitted here for
#     brevity; the defaults work reasonably without it.
#
# Why ASA is slow for Heston: each cost evaluation prices every option, and
# ASA searches the WHOLE space rather than settling quickly. The paper's runs
# took 3.5-4.7 hours (on a 2005 laptop, with adaptive quadrature). Here the
# vectorised pricer makes it minutes.

def calibrate_asa(prob, x0, lb=LB, ub=UB, max_evals=20000, T0_gen=1.0,
                  T_final_gen=1e-8, seed=0, verbose=False):
    rng = np.random.default_rng(seed)
    D = len(x0)
    x = np.asarray(x0, float)
    f, flag = heston_cost_func(x, prob)
    if not flag:
        raise ValueError("initial point violates 2*kappa*theta > sigma^2")
    best_x, best_f = x.copy(), f

    # Initial acceptance temperature: typical cost differences in a sample.
    sample = []
    while len(sample) < 20:
        cand = lb + rng.random(D) * (ub - lb)
        fc, ok = heston_cost_func(cand, prob)
        if ok:
            sample.append(fc)
    T0_cost = float(np.std(sample)) or 1.0

    # Choose c so the generating temperature reaches T_final at max_evals.
    c = -math.log(T_final_gen / T0_gen) / max_evals ** (1.0 / D)

    for k in range(1, max_evals + 1):
        decay = math.exp(-c * k ** (1.0 / D))
        T_gen = T0_gen * decay
        T_cost = T0_cost * decay

        # Generate a candidate with Ingber's distribution, one coordinate at a time.
        cand = x.copy()
        for i in range(D):
            for _ in range(100):                       # resample until in bounds
                u = rng.random()
                y = math.copysign(1.0, u - 0.5) * T_gen * ((1 + 1 / T_gen) ** abs(2 * u - 1) - 1)
                xi = x[i] + y * (ub[i] - lb[i])
                if lb[i] <= xi <= ub[i]:
                    cand[i] = xi
                    break

        fc, ok = heston_cost_func(cand, prob)
        if not ok:
            continue
        delta = fc - f
        if delta < 0 or rng.random() < math.exp(-delta / max(T_cost, 1e-300)):
            x, f = cand, fc
            if f < best_f:
                best_x, best_f = x.copy(), f
                if verbose:
                    print(f"   ASA k={k:6d}  S={best_f:10.3f}")
    return HestonParams.from_array(best_x)


def calibrate_dual_annealing(prob, x0, maxiter=300, seed=0):
    """
    scipy's dual_annealing (generalised simulated annealing, Tsallis & Stariolo)
    plus a local polish: a ready-made global annealer close in spirit to ASA.
    Infeasible points get a large penalty because it has no "flag" mechanism.
    """
    def obj(x):
        cost, ok = heston_cost_func(x, prob)
        return cost if ok else 1e10
    sol = optimize.dual_annealing(obj, list(zip(LB, UB)), x0=np.asarray(x0),
                                  maxiter=maxiter, seed=seed)
    return HestonParams.from_array(sol.x)


# 3.3-3.4  RESULTS AND WHICH METHOD TO USE (paper's findings)
# ----------------------------------------------------------
#   11 Oct 2005   kappa    theta   sigma   rho      v0     S(Omega)  time
#   initial       3        0.05    0.5     -0.5     0.15   386.10
#   lsqnonlin     4.0481   0.0487  0.6066  -0.8061  0.1450  87.50    63 s
#   ASA          21.3108   0.1034  2.0099  -0.4998  0.1583  81.80   4.7 h
#   Solver        5.7369   0.0579  0.8141  -0.7478  0.1568  78.10   10 min
#
#   20 Oct 2005
#   initial       5        0.057   0.7     -0.75    0.16   148.32
#   lsqnonlin    15.096    0.1604  2.0859  -0.7416  0.1469  88.58    6 min
#   ASA          10        0.1072  1.4189  -0.8236  0.1829  77.38   3.5 h
#   Solver        7.3284   0.0745  1.0227  -0.7670  0.1938  89.88   20 min
#
# CROSS-CHECK NOTE (from running this file). The data listed in A.4.1 is the
# 20 October set: with formulation="paper" it reproduces that day's initial
# S = 148.32 exactly, and S = 77.36 / 88.62 for the ASA / lsqnonlin answers
# (paper: 77.38 / 88.58). With the correct, stable pricer those two parameter
# sets actually give S = 228.2 and 1281.9, because at kappa = 10-15 and
# sigma = 1.4-2.1 the original formula is on the wrong branch. Monte Carlo
# (400k paths) agrees with the stable pricer (e.g. T = 0.627, K = 1450:
# stable 246.58, MC 247.05 +/- 0.97, paper formula 202.32). Correctly priced,
# the best fit found here is S ~ 94.6 at kappa ~ 7.3, sigma ~ 1.02 (see main()).
# The paper's qualitative conclusions about the methods still hold.
#
# * ASA gives the lowest S(Omega) on average but is by far the slowest,
#   because it keeps searching the whole space (Figure 3.3) while lsqnonlin
#   drops quickly into a local minimum (Figure 3.2).
# * Local methods are fine only when the answer is close to the start.
# * PRACTICAL RECIPE: if yesterday's global fit (ASA) exists and markets are
#   calm, today's parameters should be nearby, so use the fast local method
#   from yesterday's answer. After a crash or big move, rerun ASA.
# * Parameters are NOT stationary (Mikhailov & Nogel 2003), hence daily
#   recalibration. The PossibleSolutions trick (CalibrationProblem._record)
#   collects every set satisfying (3.2), which could be compared across days
#   to look for a stationary region.
#
# 3.5  OTHER METHODS (not implemented, as in the paper)
#   * Shu & Zhang (2004): two-step indirect inference. Estimate the asset
#     dynamics from time series by simulation, then least squares for the rest.
#   * Johnson & Lee (2004): ensemble method. Weight an ensemble of parameter
#     sets (one matrix inversion) so it reproduces market prices exactly.
#   * Genetic algorithms, which Ingber (1993) notes are much slower than ASA.
#
# CONCLUSION (paper): Heston is a model, not reality. Calibrate carefully but
# don't over-fit to a model that can't explain everything. Used with its
# assumptions understood, it is a powerful tool.


# =============================================================================
# PART 8 -- REPRODUCING THE PAPER'S FIGURES
# =============================================================================

def plot_figures(outdir=".", prob=None, calibrated=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from pathlib import Path
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)

    def density(ax, samples, lo, hi, label, bins=100):
        counts, edges = np.histogram(samples, bins=bins, range=(lo, hi))
        ax.plot(0.5 * (edges[1:] + edges[:-1]), counts / len(samples), label=label)

    # Figure 1.1: effect of rho on skewness (A.1 parameters, one step).
    fig, ax = plt.subplots()
    for rho in (0.9, 0.0, -0.9):
        S = simulate_terminal_prices(10, 0.01, 0, 2, 0.01, 0.1, rho, 0.02,
                                     1_000_000, n_steps=1, scheme="paper")
        density(ax, S, 9, 11, f"rho = {rho}")
    ax.set_title("Figure 1.1: effect of rho on skewness"); ax.legend()
    fig.savefig(out / "fig1_1_rho_skew.png", dpi=120); plt.close(fig)

    # Figure 1.5: effect of sigma on kurtosis. rho = 0; to make sigma's
    # effect visible in a single step we use a larger dt than Figure 1.1.
    fig, ax = plt.subplots()
    for sig in (0.0, 0.1, 0.25):
        S = simulate_terminal_prices(10, 0.01, 0, 2, 0.01, sig, 0.0, 0.5,
                                     1_000_000, n_steps=1, scheme="paper")
        density(ax, S, 8, 12, f"sigma = {sig}")
    ax.set_title("Figure 1.5: effect of sigma on kurtosis"); ax.legend()
    fig.savefig(out / "fig1_5_sigma_kurtosis.png", dpi=120); plt.close(fig)

    # Figures 1.2-1.4: implied vol surfaces for rho = 0.5, 0, -0.5.
    for n, rho in zip((2, 3, 4), (0.5, 0.0, -0.5)):
        p = HestonParams(2, 0.04, 0.1, rho, 0.04)
        K, M, V = heston_implied_vol_surface(p)
        KK, MM = np.meshgrid(K, M)
        fig = plt.figure(); ax = fig.add_subplot(projection="3d")
        ax.plot_surface(MM, KK, V, cmap="viridis")
        ax.set_xlabel("Maturity (years)"); ax.set_ylabel("Strike")
        ax.set_zlabel("Implied volatility"); ax.set_title(f"Figure 1.{n}: rho = {rho}")
        fig.savefig(out / f"fig1_{n}_surface_rho_{rho}.png", dpi=120); plt.close(fig)

    # Figures 1.6-1.8: smiles for sigma = 0.1..0.4, T = 1 (HestonVolSmileVolVol.m).
    strikes = np.linspace(0.8, 1.2, 11)
    for n, rho in zip((6, 7, 8), (0.5, 0.0, -0.5)):
        fig, ax = plt.subplots()
        for sig in (0.1, 0.2, 0.3, 0.4):
            vols = [bs_implied_vol(1, K, 0.01, 1,
                                   heston_call_quad(2, 0.04, sig, rho, 0.04, 0.01, 1, 1, K,
                                                    method="legendre"))
                    for K in strikes]
            ax.plot(strikes, vols, label=f"sigma = {sig}")
        ax.set_xlabel("Strike"); ax.set_ylabel("Implied volatility")
        ax.set_title(f"Figure 1.{n}: rho = {rho}"); ax.legend()
        fig.savefig(out / f"fig1_{n}_smile_rho_{rho}.png", dpi=120); plt.close(fig)

    # Figure 2.2: the integrand of (2.19) decays fast (so 100 is a safe cutoff).
    phi = np.linspace(0.01, 100, 2000)
    cases = [(0.1, 100, 1 / 12), (0.1, 100, 1.0), (0.1, 50, 1 / 12),
             (0.1, 150, 1 / 12), (0.9, 100, 1 / 12)]
    fig, axes = plt.subplots(3, 2, figsize=(10, 9))
    for ax, (sig, K, T) in zip(axes.flat, cases):
        ax.plot(phi, heston_P_integrand(phi, 2, 0.04, sig, -0.5, 0.05, 0.1, T, 100, K, 1))
        ax.set_title(f"sigma={sig}, K={K}, T={T:.3g}"); ax.set_xlabel("phi")
    axes.flat[-1].axis("off")
    fig.suptitle("Figure 2.2: integrand of (2.19)"); fig.tight_layout()
    fig.savefig(out / "fig2_2_integrand.png", dpi=120); plt.close(fig)

    # Figure 2.3: FFT price depends on alpha.
    alphas = np.linspace(0.05, 5, 100)
    prices = [heston_call_fft(2, 0.04, 0.5, -0.5, 0.05, 0.04, 100, 70, 1, alpha=a)
              for a in alphas]
    fig, ax = plt.subplots(); ax.plot(alphas, prices)
    ax.set_xlabel("alpha"); ax.set_ylabel("price")
    ax.set_title("Figure 2.3: FFT price vs alpha")
    fig.savefig(out / "fig2_3_alpha.png", dpi=120); plt.close(fig)

    # Figure 3.1: S(Omega) as a function of kappa and sigma (others fixed).
    if prob is not None and calibrated is not None:
        ks, ss = np.linspace(0.5, 15, 40), np.linspace(0.05, 10, 40)
        Z = np.array([[float(np.sum(prob.residuals(HestonParams(
            k, calibrated.theta, s, calibrated.rho, calibrated.v0)) ** 2))
            for s in ss] for k in ks])
        KK, SS = np.meshgrid(ss, ks)
        fig = plt.figure(); ax = fig.add_subplot(projection="3d")
        ax.plot_surface(SS, KK, Z, cmap="viridis")
        ax.set_xlabel("kappa"); ax.set_ylabel("sigma"); ax.set_zlabel("S(Omega)")
        ax.set_title("Figure 3.1: error surface")
        fig.savefig(out / "fig3_1_error_surface.png", dpi=120); plt.close(fig)
    print(f"   figures saved to {out.resolve()}")


# =============================================================================
# PART 9 -- WALK-THROUGH
# =============================================================================

def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[2])
    ap.add_argument("--plots", action="store_true", help="save the paper's figures")
    ap.add_argument("--full", action="store_true", help="longer global calibration")
    ap.add_argument("--outdir", default="heston_figures")
    args = ap.parse_args()

    print("=" * 78)
    print("STEP 1  Risk-neutral parameters (1.3.2)")
    ks, ts = risk_neutral_params(kappa=2.0, theta=0.04, lam=0.5)
    print(f"   kappa=2, theta=0.04, lambda=0.5  ->  kappa*={ks:.3f}, theta*={ts:.4f}"
          f"  (kappa*theta preserved: {2*0.04:.3f} = {ks*ts:.3f})")

    print("=" * 78)
    print("STEP 2  Price one call five ways (2.1-2.4)")
    kappa, theta, sigma, rho, v0, r, T, s0, K = 2, 0.04, 0.3, -0.5, 0.04, 0.01, 1.0, 100, 100
    p = HestonParams(kappa, theta, sigma, rho, v0)
    rows = []
    for name, fn in [
        ("Gauss-Lobatto (quadl)", lambda: heston_call_quad(kappa, theta, sigma, rho, v0, r, T, s0, K, "lobatto")),
        ("Adaptive Simpson (quad)", lambda: heston_call_quad(kappa, theta, sigma, rho, v0, r, T, s0, K, "simpson")),
        ("Gauss-Legendre 128", lambda: heston_call_quad(kappa, theta, sigma, rho, v0, r, T, s0, K, "legendre")),
        ("scipy quad (check)", lambda: heston_call_quad(kappa, theta, sigma, rho, v0, r, T, s0, K, "scipy")),
        ("FFT (Carr-Madan)", lambda: heston_call_fft(kappa, theta, sigma, rho, r, v0, s0, K, T)),
    ]:
        t0 = time.perf_counter(); val = fn(); dt = time.perf_counter() - t0
        rows.append((name, val, dt))
    for name, val, dt in rows:
        print(f"   {name:26s} {val:12.6f}   {dt*1000:8.2f} ms")
    otm_K = 130
    print(f"   OTM K={otm_K}: quadl {heston_call_quad(kappa, theta, sigma, rho, v0, r, T, s0, otm_K):.6f}"
          f"  | FFT time-value {heston_call_fft_time_value(kappa, theta, sigma, rho, r, v0, s0, otm_K, T):.6f}")
    mc, se = mc_call_price(s0, K, T, r, p)
    print(f"   Monte Carlo (Euler, 200 steps): {mc:.4f} +/- {1.96*se:.4f} (95%)")

    print("=" * 78)
    print("STEP 3  FFT speed advantage (2.4): all 4096 strikes in one go")
    t0 = time.perf_counter()
    strikes_grid, calls_grid = heston_call_fft(kappa, theta, sigma, rho, r, v0, s0, K, T,
                                               return_grid=True)
    print(f"   {len(calls_grid)} prices in {1000*(time.perf_counter()-t0):.1f} ms")

    print("=" * 78)
    print("STEP 4  Implied vol smile, T=1, rho=-0.5 (A.2)")
    for Kx in (0.8, 0.9, 1.0, 1.1, 1.2):
        pr = heston_call_quad(2, 0.04, 0.4, -0.5, 0.04, 0.01, 1, 1, Kx)
        print(f"   K={Kx:.1f}  price={pr:.5f}  implied vol={bs_implied_vol(1, Kx, 0.01, 1, pr):.4f}")

    print("=" * 78)
    print("STEP 5  Calibration to Anglo American calls (Chapter 3)")
    prob = CalibrationProblem()
    print(f"   {len(prob.mid)} options; acceptance threshold (3.2) = {prob.sum_bid_offer:.2f}")

    # Check the fast pricer against the adaptive-Lobatto pricer on the data.
    test = HestonParams(3, 0.05, 0.5, -0.5, 0.15)
    fast = prob.model_prices(test)
    slow = np.array([heston_call_quad(test.kappa, test.theta, test.sigma, test.rho, test.v0,
                                      rr, TT, SS, KK) for rr, TT, SS, KK in
                     zip(prob.r, prob.T, prob.S0, prob.K)])
    print(f"   vectorised vs quadl max price diff: {np.max(np.abs(fast-slow)):.2e}")
    oct20 = HestonParams(5, 0.057, 0.7, -0.75, 0.16)   # paper's 20 Oct initial estimate
    prob_paper = CalibrationProblem(formulation="paper", pricer="lobatto")  # = MATLAB
    print(f"   S at paper's 20 Oct initial estimate: {prob_paper.S(oct20):.2f} with the paper's"
          f" formula (paper: 148.32), {prob.S(oct20):.2f} with the stable formula")
    asa20 = HestonParams(10, 0.1072, 1.4189, -0.8236, 0.1829)
    print(f"   S at paper's 20 Oct ASA answer:       {prob_paper.S(asa20):.2f} with the paper's"
          f" formula (paper: 77.38), {prob.S(asa20):.2f} correctly priced")

    results = {}
    prob.reset()
    p_ls, t_ls = calibrate_lsqnonlin(prob)
    results["lsqnonlin (trf)"] = (p_ls, t_ls, prob.n_evals)
    lsq_path = list(prob.path)

    prob.reset()
    p_sv, t_sv = calibrate_local_solver(prob, test)
    results["Solver-like (SLSQP)"] = (p_sv, t_sv, prob.n_evals)

    prob.reset()
    t0 = time.perf_counter()
    p_reg, _ = calibrate_lsqnonlin(prob, x0=_to_feller_coords(test), regularisation=1.0)
    results["Regularised lsq (a=1)"] = (p_reg, time.perf_counter() - t0, prob.n_evals)

    n_asa = 60000 if args.full else 8000
    prob.reset()
    t0 = time.perf_counter()
    p_asa = calibrate_asa(prob, test.as_array(), max_evals=n_asa)
    results["ASA"] = (p_asa, time.perf_counter() - t0, prob.n_evals)
    asa_path = list(prob.path)
    n_possible = len(prob.possible_solutions)

    prob.reset()
    t0 = time.perf_counter()
    p_da = calibrate_dual_annealing(prob, test.as_array(), maxiter=300 if args.full else 60)
    results["dual_annealing"] = (p_da, time.perf_counter() - t0, prob.n_evals)

    print(f"\n   {'method':24s} {'kappa':>8s} {'theta':>7s} {'sigma':>7s} {'rho':>7s} "
          f"{'v0':>7s} {'S(Om)':>8s} {'(3.2)?':>6s} {'time':>7s}")
    for name, (pp, tt, ne) in results.items():
        S_val = float(np.sum(prob.residuals(pp) ** 2))
        print(f"   {name:24s} {pp.kappa:8.4f} {pp.theta:7.4f} {pp.sigma:7.4f} {pp.rho:7.4f} "
              f"{pp.v0:7.4f} {S_val:8.2f} {'yes' if S_val <= prob.sum_bid_offer else 'no':>6s} "
              f"{tt:6.1f}s")
    print(f"\n   ASA stored {n_possible} parameter sets satisfying (3.2) (PossibleSolutions).")

    if args.plots:
        print("=" * 78)
        print("STEP 6  Figures")
        plot_figures(args.outdir, prob, p_ls)
        import matplotlib.pyplot as plt
        for fname, path, title in [("fig3_2_lsqnonlin_path.png", lsq_path, "Figure 3.2: lsqnonlin"),
                                   ("fig3_3_asa_path.png", asa_path, "Figure 3.3: ASA")]:
            fig, ax = plt.subplots(); ax.plot(path)
            ax.set_xlabel("Iteration"); ax.set_ylabel("Objective function"); ax.set_title(title)
            fig.savefig(f"{args.outdir}/{fname}", dpi=120); plt.close(fig)


if __name__ == "__main__":
    main()
