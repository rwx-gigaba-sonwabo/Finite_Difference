"""
Monte Carlo simulation of a calibrated Heston model.

Simulates daily (or any frequency) paths of S and V, stores them, plots them,
and prices European or path-dependent payoffs from the stored paths.

    Schemes : "qe"    - Andersen (2008) quadratic-exponential (default, accurate)
              "euler" - log-Euler with full truncation
    Pricing : mc_price(paths, payoff)  with any payoff(S_window, t_window) -> per-path payoff
              built-ins: european_call/put, asian_call/put, barrier, lookback_call/put

Usage
    python heston_monte_carlo.py --params heston_params.json --T 1 --paths 20000 --plot
    python heston_monte_carlo.py --kappa 2 --theta 0.04 --sigma 0.5 --rho -0.7 --v0 0.04 \
        --S0 100 --r 0.05 --q 0.0 --T 1 --save-csv paths.csv --start-date 2026-10-01

Memory: S and V are stored as (n_paths, n_steps + 1) float64 arrays, i.e.
16 bytes per path per day (100k paths x 1y of days is about 400 MB).
"""
from __future__ import annotations

import argparse
import math
import os
from dataclasses import dataclass

import numpy as np

from heston_calibration import HestonParams, load_params, heston_call, heston_put


# =============================================================================
# SIMULATED PATHS
# =============================================================================
@dataclass
class HestonPaths:
    params: HestonParams
    S0: float
    r: float
    q: float
    t: np.ndarray               # (n_steps + 1,) times in years, t[0] = 0
    S: np.ndarray               # (n_paths, n_steps + 1) stock prices
    V: np.ndarray | None        # (n_paths, n_steps + 1) variances
    antithetic: bool = False    # paths i and i + n/2 are antithetic pairs
    dates: np.ndarray | None = None

    @property
    def n_paths(self):
        return self.S.shape[0]

    @property
    def dt(self):
        return self.t[1] - self.t[0]

    def index(self, T) -> int:
        i = int(round(T / self.dt))
        if not 0 <= i < len(self.t):
            raise ValueError(f"T={T} is outside the simulated horizon {self.t[-1]:.4f}")
        return i

    # ---- storage ------------------------------------------------------------
    def save_npz(self, path):
        np.savez_compressed(path, t=self.t, S=self.S, V=self.V if self.V is not None else np.empty(0),
                            params=self.params.as_array(), S0=self.S0, r=self.r, q=self.q,
                            antithetic=self.antithetic,
                            dates=self.dates.astype(str) if self.dates is not None else np.empty(0))
        print(f"Saved {self.n_paths} paths to {path}")

    @classmethod
    def load_npz(cls, path) -> "HestonPaths":
        d = np.load(path)
        return cls(HestonParams.from_array(d["params"]), float(d["S0"]), float(d["r"]),
                   float(d["q"]), d["t"], d["S"], d["V"] if d["V"].size else None,
                   bool(d["antithetic"]),
                   d["dates"].astype("datetime64[D]") if d["dates"].size else None)

    def to_csv(self, path, max_paths=1000, variance=False):
        """Rows = days, columns = date (if any), t, path_0 .. path_n."""
        X = (self.V if variance else self.S)[:max_paths].T
        cols = (["date"] if self.dates is not None else []) + ["t"] + \
               [f"path_{i}" for i in range(X.shape[1])]
        with open(path, "w") as fh:
            fh.write(",".join(cols) + "\n")
            for k in range(X.shape[0]):
                lead = ([str(self.dates[k])] if self.dates is not None else []) + [f"{self.t[k]:.6f}"]
                fh.write(",".join(lead + [f"{v:.6f}" for v in X[k]]) + "\n")
        print(f"Wrote {X.shape[1]} {'variance' if variance else 'price'} paths to {path}")

    # ---- plots --------------------------------------------------------------
    def plot(self, n_show=50, save=None):
        import matplotlib.pyplot as plt
        x = self.dates if self.dates is not None else self.t
        fig, axes = plt.subplots(1, 3 if self.V is not None else 2, figsize=(16, 5))

        ax = axes[0]
        ax.plot(x, self.S[:n_show].T, lw=0.6, alpha=0.6)
        lo, med, hi = np.percentile(self.S, [5, 50, 95], axis=0)
        ax.plot(x, med, "k", lw=2, label="median")
        ax.fill_between(x, lo, hi, color="grey", alpha=0.25, label="5-95%")
        ax.set_title(f"Stock price ({n_show} of {self.n_paths} paths)")
        ax.set_ylabel("S"); ax.legend()

        if self.V is not None:
            ax = axes[1]
            ax.plot(x, 100 * np.sqrt(np.maximum(self.V[:n_show].T, 0)), lw=0.6, alpha=0.6)
            ax.axhline(100 * math.sqrt(self.params.theta), color="k", ls="--",
                       label="sqrt(theta)")
            ax.set_title("Instantaneous vol sqrt(V)"); ax.set_ylabel("%"); ax.legend()

        ax = axes[-1]
        ax.hist(self.S[:, -1], bins=100, density=True, color="steelblue")
        ax.axvline(self.S0 * math.exp((self.r - self.q) * self.t[-1]), color="k", ls="--",
                   label="forward")
        ax.set_title(f"S at T={self.t[-1]:.2f}"); ax.legend()
        for a in axes[:-1]:
            a.tick_params(axis="x", rotation=30)
        fig.tight_layout()
        if save:
            fig.savefig(save, dpi=120)
        plt.show()


# =============================================================================
# SIMULATION
# =============================================================================
def _qe_variance(V, p: HestonParams, dt, Zv, U, psi_c=1.5):
    """Andersen QE step for the CIR variance."""
    ekd = math.exp(-p.kappa * dt)
    m = p.theta + (V - p.theta) * ekd
    s2 = (V * p.sigma ** 2 * ekd * (1 - ekd) / p.kappa
          + p.theta * p.sigma ** 2 * (1 - ekd) ** 2 / (2 * p.kappa))
    psi = s2 / np.maximum(m ** 2, 1e-300)
    out = np.empty_like(V)

    quad_ = psi <= psi_c                                   # quadratic branch
    inv = 2.0 / psi[quad_]
    b2 = inv - 1 + np.sqrt(inv) * np.sqrt(inv - 1)
    out[quad_] = m[quad_] / (1 + b2) * (np.sqrt(b2) + Zv[quad_]) ** 2

    exp_ = ~quad_                                          # exponential branch
    pr = (psi[exp_] - 1) / (psi[exp_] + 1)
    beta = (1 - pr) / m[exp_]
    u = U[exp_]
    out[exp_] = np.where(u <= pr, 0.0,
                         np.log((1 - pr) / np.maximum(1 - u, 1e-300)) / beta)
    return out


def simulate(params: HestonParams, S0, T, r=0.0, q=0.0, n_paths=10000, steps_per_year=252,
             scheme="qe", antithetic=True, seed=None, start_date=None,
             store_variance=True) -> HestonPaths:
    """
    Simulate Heston paths under Q on a grid of `steps_per_year` steps per year
    (252 = trading days). start_date ('YYYY-MM-DD') labels steps with business days.
    """
    p = params
    n_steps = max(1, int(round(T * steps_per_year)))
    dt = T / n_steps
    if antithetic and n_paths % 2:
        n_paths += 1
    half = n_paths // 2 if antithetic else n_paths
    rng = np.random.default_rng(seed)

    lnS = np.full(n_paths, math.log(S0))
    V = np.full(n_paths, p.v0)
    S_out = np.empty((n_paths, n_steps + 1)); S_out[:, 0] = S0
    V_out = np.empty((n_paths, n_steps + 1)) if store_variance else None
    if store_variance:
        V_out[:, 0] = p.v0

    mirror = (lambda z: np.concatenate([z, -z])) if antithetic else (lambda z: z)
    sqrt_1mr2 = math.sqrt(1 - p.rho ** 2)

    if scheme == "qe":
        # ln S step with gamma1 = gamma2 = 1/2 (Andersen 2008, eq. 33)
        K0 = -p.rho * p.kappa * p.theta * dt / p.sigma
        K1 = 0.5 * dt * (p.kappa * p.rho / p.sigma - 0.5) - p.rho / p.sigma
        K2 = 0.5 * dt * (p.kappa * p.rho / p.sigma - 0.5) + p.rho / p.sigma
        K3 = 0.5 * dt * (1 - p.rho ** 2)

    for k in range(1, n_steps + 1):
        if scheme == "qe":
            Zv, Zs = mirror(rng.standard_normal(half)), mirror(rng.standard_normal(half))
            Uh = rng.random(half)
            U = np.concatenate([Uh, 1 - Uh]) if antithetic else Uh
            V_new = _qe_variance(V, p, dt, Zv, U)
            lnS += ((r - q) * dt + K0 + K1 * V + K2 * V_new
                    + np.sqrt(np.maximum(K3 * (V + V_new), 0)) * Zs)
            V = V_new
        elif scheme == "euler":
            Z1, Z2 = mirror(rng.standard_normal(half)), mirror(rng.standard_normal(half))
            Zv = p.rho * Z1 + sqrt_1mr2 * Z2
            Vp = np.maximum(V, 0.0)                         # full truncation
            lnS += (r - q - 0.5 * Vp) * dt + np.sqrt(Vp * dt) * Z1
            V = V + p.kappa * (p.theta - Vp) * dt + p.sigma * np.sqrt(Vp * dt) * Zv
        else:
            raise ValueError("scheme must be 'qe' or 'euler'")
        S_out[:, k] = np.exp(lnS)
        if store_variance:
            V_out[:, k] = np.maximum(V, 0.0)

    dates = None
    if start_date is not None:
        dates = np.busday_offset(np.datetime64(start_date, "D"), np.arange(n_steps + 1),
                                 roll="forward")
    return HestonPaths(p, float(S0), float(r), float(q), np.linspace(0, T, n_steps + 1),
                       S_out, V_out, antithetic, dates)


# =============================================================================
# PRICING FROM PATHS
# =============================================================================
def mc_price(paths: HestonPaths, payoff, T=None) -> tuple[float, float]:
    """
    Discounted MC price and standard error. `payoff(S, t)` gets the paths up
    to expiry T (S shape (n_paths, i+1), t shape (i+1,)) and returns one
    payoff per path, paid at T.
    """
    i = len(paths.t) - 1 if T is None else paths.index(T)
    pay = np.asarray(payoff(paths.S[:, :i + 1], paths.t[:i + 1]), float)
    if paths.antithetic:                       # average pairs -> independent samples
        h = paths.n_paths // 2
        pay = 0.5 * (pay[:h] + pay[h:])
    disc = math.exp(-paths.r * paths.t[i])
    return disc * pay.mean(), disc * pay.std(ddof=1) / math.sqrt(pay.size)


# ---- payoff builders (each returns payoff(S, t) -> array) -----------------
def european_call(K):
    return lambda S, t: np.maximum(S[:, -1] - K, 0.0)


def european_put(K):
    return lambda S, t: np.maximum(K - S[:, -1], 0.0)


def _average(S, kind):
    X = S[:, 1:]                               # monitoring dates exclude t = 0
    return X.mean(axis=1) if kind == "arithmetic" else np.exp(np.log(X).mean(axis=1))


def asian_call(K, kind="arithmetic"):
    return lambda S, t: np.maximum(_average(S, kind) - K, 0.0)


def asian_put(K, kind="arithmetic"):
    return lambda S, t: np.maximum(K - _average(S, kind), 0.0)


def barrier(K, B, kind="up-and-out", option="call", rebate=0.0):
    """Discretely monitored (each simulated step) knock-in / knock-out."""
    def payoff(S, t):
        vanilla = np.maximum(S[:, -1] - K, 0) if option == "call" else np.maximum(K - S[:, -1], 0)
        hit = (S.max(axis=1) >= B) if kind.startswith("up") else (S.min(axis=1) <= B)
        alive = ~hit if kind.endswith("out") else hit
        return np.where(alive, vanilla, rebate if kind.endswith("out") else 0.0)
    return payoff


def lookback_call(K=None):
    """Floating strike (K=None): S_T - min S.  Fixed strike: max(max S - K, 0)."""
    if K is None:
        return lambda S, t: S[:, -1] - S.min(axis=1)
    return lambda S, t: np.maximum(S.max(axis=1) - K, 0.0)


def lookback_put(K=None):
    """Floating strike (K=None): max S - S_T.  Fixed strike: max(K - min S, 0)."""
    if K is None:
        return lambda S, t: S.max(axis=1) - S[:, -1]
    return lambda S, t: np.maximum(K - S.min(axis=1), 0.0)


def compare_european(paths: HestonPaths, strikes, T=None, integration="legendre"):
    """MC European prices vs the closed form, as a check on the simulation."""
    T = paths.t[-1] if T is None else paths.t[paths.index(T)]
    print(f"\nEuropean check at T={T:.4f}  ({paths.n_paths} paths)")
    print(f"{'K':>10} {'type':>5} {'MC':>12} {'+/- 2se':>10} {'closed form':>12} {'diff/se':>8}")
    for K in strikes:
        for name, pf, cf in (("call", european_call, heston_call), ("put", european_put, heston_put)):
            mc, se = mc_price(paths, pf(K), T)
            exact = float(cf(paths.params, paths.S0, K, T, paths.r, paths.q, integration=integration)[0])
            print(f"{K:10.2f} {name:>5} {mc:12.4f} {2 * se:10.4f} {exact:12.4f} {(mc - exact) / se:8.2f}")


# =============================================================================
# RUN
# =============================================================================
def main():
    ap = argparse.ArgumentParser(description="Monte Carlo of a calibrated Heston model")
    ap.add_argument("--params", default="heston_params.json", help="JSON from heston_calibration.py")
    for name in ("kappa", "theta", "sigma", "rho", "v0", "S0", "r", "q"):
        ap.add_argument(f"--{name}", type=float, help="override / specify manually")
    ap.add_argument("--T", type=float, default=1.0, help="horizon in years")
    ap.add_argument("--paths", type=int, default=20000)
    ap.add_argument("--steps-per-year", type=int, default=252)
    ap.add_argument("--scheme", choices=["qe", "euler"], default="qe")
    ap.add_argument("--no-antithetic", action="store_true")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--start-date", help="YYYY-MM-DD, labels steps with business days")
    ap.add_argument("--save-npz", help="store all paths (S, V, t, params) to .npz")
    ap.add_argument("--save-csv", help="store price paths (rows = days) to .csv")
    ap.add_argument("--plot", action="store_true")
    args = ap.parse_args()

    # Parameters: calibration JSON, then any command-line overrides.
    meta = {"S0": 100.0, "r": 0.0, "q": 0.0}
    if os.path.exists(args.params):
        p, meta = load_params(args.params)
        print(f"Loaded {args.params}")
    else:
        p = HestonParams(2.0, 0.04, 0.5, -0.7, 0.04)
        print(f"{args.params} not found; using example parameters (override with --kappa etc.)")
    for name in ("kappa", "theta", "sigma", "rho", "v0"):
        if getattr(args, name) is not None:
            setattr(p, name, getattr(args, name))
    S0 = args.S0 if args.S0 is not None else meta.get("S0") or 100.0
    r = args.r if args.r is not None else meta.get("r") or 0.0
    q = args.q if args.q is not None else meta.get("q") or 0.0
    print(f"Params: {p}\nS0={S0}  r={r}  q={q}  T={args.T}  scheme={args.scheme}")

    paths = simulate(p, S0, args.T, r, q, n_paths=args.paths, steps_per_year=args.steps_per_year,
                     scheme=args.scheme, antithetic=not args.no_antithetic, seed=args.seed,
                     start_date=args.start_date)
    print(f"Simulated {paths.n_paths} paths x {len(paths.t) - 1} steps")

    compare_european(paths, S0 * np.array([0.9, 1.0, 1.1]))

    K = S0
    print(f"\nPath-dependent examples (K = {K:.2f}, T = {args.T})")
    examples = {
        "Asian arithmetic call": asian_call(K),
        "Asian geometric call": asian_call(K, "geometric"),
        f"Up-and-out call (B={1.3 * S0:.1f})": barrier(K, 1.3 * S0, "up-and-out", "call"),
        f"Down-and-in put (B={0.8 * S0:.1f})": barrier(K, 0.8 * S0, "down-and-in", "put"),
        "Lookback call (floating)": lookback_call(),
        "Lookback put (floating)": lookback_put(),
    }
    for name, pf in examples.items():
        v, se = mc_price(paths, pf)
        print(f"   {name:32s} {v:10.4f}  (se {se:.4f})")

    if args.save_npz:
        paths.save_npz(args.save_npz)
    if args.save_csv:
        paths.to_csv(args.save_csv)
    if args.plot:
        paths.plot()


if __name__ == "__main__":
    main()
