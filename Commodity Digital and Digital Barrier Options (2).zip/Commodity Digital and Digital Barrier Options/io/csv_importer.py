"""
CSV importers for building ScenarioCubes from external simulation data.

Supported CSV formats
---------------------

Curve factors (e.g. yield curves):

    tenor, scenario, 2025-07-28, 2026-07-28, ...
    0.027, 0, 0.0734, 0.0687, ...
    0.027, 1, 0.0725, 0.0742, ...

Scalar factors (e.g. FX spot rates):

    scenario, 2025-07-28, 2026-07-28, ...
    0, 14.50, 14.75, ...
    1, 14.60, 14.80, ...

Surface factors (e.g. vol surfaces):

    tenor, strike, scenario, 2025-07-28, 2026-07-28, ...
    0.5, 0.90, 0, 0.15, 0.14, ...
    0.5, 0.90, 1, 0.16, 0.15, ...
"""

from __future__ import annotations

import csv
from datetime import date
from pathlib import Path

import numpy as np

from market_data.scenario_cube import ScenarioCubeBuilder


def load_curve_csv(
    filepath: str | Path,
) -> tuple[np.ndarray, list[date], np.ndarray]:
    """
    Load a curve factor from CSV.

    Expected CSV format::

        tenor, scenario, 2025-07-28, 2026-07-28, ...
        0.027, 0, 0.0734, 0.0687, ...
        0.027, 1, 0.0725, 0.0742, ...

    Parameters
    ----------
    filepath : path to the CSV file.

    Returns
    -------
    tenors : np.ndarray, shape (n_tenors,)
    dates : list[date], simulation dates parsed from column headers.
    data : np.ndarray, shape (n_paths, n_times, n_tenors)
    """
    with open(filepath, newline="") as f:
        reader = csv.reader(f)
        header = [h.strip() for h in next(reader)]
        rows = [[v.strip() for v in row] for row in reader]

    date_cols = header[2:]
    dates = [date.fromisoformat(c) for c in date_cols]

    raw = np.array([[float(v) for v in row] for row in rows], dtype=np.float64)
    tenor_vals = raw[:, 0]
    scenario_vals = raw[:, 1].astype(int)
    rate_vals = raw[:, 2:]

    tenors = np.unique(tenor_vals)
    scenarios = np.unique(scenario_vals)
    n_tenors = len(tenors)
    n_paths = len(scenarios)
    n_times = len(dates)

    tenor_index = {t: i for i, t in enumerate(tenors)}
    scenario_index = {s: i for i, s in enumerate(scenarios)}

    data = np.empty((n_paths, n_times, n_tenors), dtype=np.float64)

    for row_idx in range(len(raw)):
        t_idx = tenor_index[tenor_vals[row_idx]]
        s_idx = scenario_index[scenario_vals[row_idx]]
        data[s_idx, :, t_idx] = rate_vals[row_idx]

    return tenors, dates, data


def load_scalar_csv(
    filepath: str | Path,
) -> tuple[list[date], np.ndarray]:
    """
    Load a scalar factor from CSV.

    Expected CSV format::

        scenario, 2025-07-28, 2026-07-28, ...
        0, 14.50, 14.75, ...
        1, 14.60, 14.80, ...

    Parameters
    ----------
    filepath : path to the CSV file.

    Returns
    -------
    dates : list[date], simulation dates parsed from column headers.
    data : np.ndarray, shape (n_paths, n_times)
    """
    with open(filepath, newline="") as f:
        reader = csv.reader(f)
        header = [h.strip() for h in next(reader)]
        rows = [[v.strip() for v in row] for row in reader]

    date_cols = header[1:]
    dates = [date.fromisoformat(c) for c in date_cols]

    raw = np.array([[float(v) for v in row] for row in rows], dtype=np.float64)
    scenario_vals = raw[:, 0].astype(int)
    value_data = raw[:, 1:]

    order = np.argsort(scenario_vals)
    data = value_data[order].astype(np.float64)

    return dates, data


def load_surface_csv(
    filepath: str | Path,
) -> tuple[np.ndarray, np.ndarray, list[date], np.ndarray]:
    """
    Load a surface factor from CSV.

    Expected CSV format::

        tenor, strike, scenario, 2025-07-28, 2026-07-28, ...
        0.5, 0.90, 0, 0.15, 0.14, ...
        0.5, 0.90, 1, 0.16, 0.15, ...

    Parameters
    ----------
    filepath : path to the CSV file.

    Returns
    -------
    tenors : np.ndarray, shape (n_tenors,)
    strikes : np.ndarray, shape (n_strikes,)
    dates : list[date], simulation dates parsed from column headers.
    data : np.ndarray, shape (n_paths, n_times, n_tenors, n_strikes)
    """
    with open(filepath, newline="") as f:
        reader = csv.reader(f)
        header = [h.strip() for h in next(reader)]
        rows = [[v.strip() for v in row] for row in reader]

    date_cols = header[3:]
    dates = [date.fromisoformat(c) for c in date_cols]

    raw = np.array([[float(v) for v in row] for row in rows], dtype=np.float64)
    tenor_vals = raw[:, 0]
    strike_vals = raw[:, 1]
    scenario_vals = raw[:, 2].astype(int)
    value_data = raw[:, 3:]

    tenors = np.unique(tenor_vals)
    strikes = np.unique(strike_vals)
    scenarios = np.unique(scenario_vals)
    n_tenors = len(tenors)
    n_strikes = len(strikes)
    n_paths = len(scenarios)
    n_times = len(dates)

    tenor_index = {t: i for i, t in enumerate(tenors)}
    strike_index = {k: i for i, k in enumerate(strikes)}
    scenario_index = {s: i for i, s in enumerate(scenarios)}

    data = np.empty((n_paths, n_times, n_tenors, n_strikes), dtype=np.float64)

    for row_idx in range(len(raw)):
        t_idx = tenor_index[tenor_vals[row_idx]]
        k_idx = strike_index[strike_vals[row_idx]]
        s_idx = scenario_index[scenario_vals[row_idx]]
        data[s_idx, :, t_idx, k_idx] = value_data[row_idx]

    return tenors, strikes, dates, data


def build_cube_from_csvs(
    valuation_date: date,
    curve_csvs: dict[str, str | Path] | None = None,
    scalar_csvs: dict[str, str | Path] | None = None,
    surface_csvs: dict[str, str | Path] | None = None,
) -> ScenarioCubeBuilder:
    """
    Build a ScenarioCubeBuilder from multiple CSV files.

    All CSVs must share the same simulation dates and number of scenarios.

    Parameters
    ----------
    valuation_date : reference date for the simulation.
    curve_csvs : factor name -> CSV path for curve factors.
    scalar_csvs : factor name -> CSV path for scalar factors.
    surface_csvs : factor name -> CSV path for surface factors.

    Returns
    -------
    ScenarioCubeBuilder with all factors added. Call ``.build()`` to get
    the immutable ScenarioCube.
    """
    curve_csvs = curve_csvs or {}
    scalar_csvs = scalar_csvs or {}
    surface_csvs = surface_csvs or {}

    if not curve_csvs and not scalar_csvs and not surface_csvs:
        raise ValueError("At least one CSV file must be provided")

    n_paths: int | None = None

    def _check_paths(name: str, paths: int):
        nonlocal n_paths
        if n_paths is None:
            n_paths = paths
        elif paths != n_paths:
            raise ValueError(
                f"Number of scenarios in '{name}' ({paths}) does not "
                f"match previously loaded factors ({n_paths})"
            )

    loaded_curves: dict[str, tuple[np.ndarray, list[date], np.ndarray]] = {}
    loaded_scalars: dict[str, tuple[list[date], np.ndarray]] = {}
    loaded_surfaces: dict[str, tuple[np.ndarray, np.ndarray, list[date], np.ndarray]] = {}

    for name, path in curve_csvs.items():
        tenors, dates, data = load_curve_csv(path)
        _check_paths(name, data.shape[0])
        loaded_curves[name] = (tenors, dates, data)

    for name, path in scalar_csvs.items():
        dates, data = load_scalar_csv(path)
        _check_paths(name, data.shape[0])
        loaded_scalars[name] = (dates, data)

    for name, path in surface_csvs.items():
        tenors, strikes, dates, data = load_surface_csv(path)
        _check_paths(name, data.shape[0])
        loaded_surfaces[name] = (tenors, strikes, dates, data)

    builder = ScenarioCubeBuilder(
        n_paths=n_paths,
        valuation_date=valuation_date,
    )

    for name, (tenors, dates, data) in loaded_curves.items():
        builder.add_curve_factor(name, data, tenors, dates=tuple(dates))

    for name, (dates, data) in loaded_scalars.items():
        builder.add_factor(name, data, dates=tuple(dates))

    for name, (tenors, strikes, dates, data) in loaded_surfaces.items():
        builder.add_surface_factor(name, data, tenors, strikes, dates=tuple(dates))

    return builder
