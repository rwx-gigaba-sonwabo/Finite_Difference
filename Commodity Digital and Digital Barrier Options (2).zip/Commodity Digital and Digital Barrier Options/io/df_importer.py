"""
DataFrame importers for building ScenarioCubes from pandas DataFrames.

Mirrors :mod:`csv_importer` but accepts in-memory DataFrames instead of
file paths.  The expected column layouts are identical to the CSV formats:

Curve factors (e.g. yield curves)::

    tenor | scenario | 2025-07-28 | 2026-07-28 | ...
    0.027 |        0 |     0.0734 |     0.0687 | ...
    0.027 |        1 |     0.0725 |     0.0742 | ...

Scalar factors (e.g. FX spot rates)::

    scenario | 2025-07-28 | 2026-07-28 | ...
           0 |      14.50 |      14.75 | ...
           1 |      14.60 |      14.80 | ...

Surface factors (e.g. vol surfaces)::

    tenor | strike | scenario | 2025-07-28 | 2026-07-28 | ...
      0.5 |   0.90 |        0 |       0.15 |       0.14 | ...
      0.5 |   0.90 |        1 |       0.16 |       0.15 | ...
"""

from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from market_data.scenario_cube import ScenarioCubeBuilder


def load_curve_df(
    df: pd.DataFrame,
) -> tuple[np.ndarray, list[date], np.ndarray]:
    """
    Load a curve factor from a DataFrame.

    Expected columns: ``tenor, scenario, <date1>, <date2>, ...``

    Date columns can be strings (``"2025-07-28"``) or ``datetime.date``
    objects.

    Parameters
    ----------
    df : DataFrame with the curve data.

    Returns
    -------
    tenors : np.ndarray, shape (n_tenors,)
    dates : list[date], simulation dates parsed from column headers.
    data : np.ndarray, shape (n_paths, n_times, n_tenors)
    """
    cols = list(df.columns)
    date_cols = cols[2:]
    dates = [_parse_date(c) for c in date_cols]

    tenor_vals = df.iloc[:, 0].to_numpy(dtype=np.float64)
    scenario_vals = df.iloc[:, 1].to_numpy(dtype=int)
    rate_vals = df.iloc[:, 2:].to_numpy(dtype=np.float64)

    tenors = np.unique(tenor_vals)
    scenarios = np.unique(scenario_vals)
    n_tenors = len(tenors)
    n_paths = len(scenarios)
    n_times = len(dates)

    tenor_index = {t: i for i, t in enumerate(tenors)}
    scenario_index = {s: i for i, s in enumerate(scenarios)}

    data = np.empty((n_paths, n_times, n_tenors), dtype=np.float64)

    for row_idx in range(len(df)):
        t_idx = tenor_index[tenor_vals[row_idx]]
        s_idx = scenario_index[scenario_vals[row_idx]]
        data[s_idx, :, t_idx] = rate_vals[row_idx]

    return tenors, dates, data


def load_scalar_df(
    df: pd.DataFrame,
) -> tuple[list[date], np.ndarray]:
    """
    Load a scalar factor from a DataFrame.

    Expected columns: ``scenario, <date1>, <date2>, ...``

    Parameters
    ----------
    df : DataFrame with the scalar data.

    Returns
    -------
    dates : list[date], simulation dates parsed from column headers.
    data : np.ndarray, shape (n_paths, n_times)
    """
    cols = list(df.columns)
    date_cols = cols[1:]
    dates = [_parse_date(c) for c in date_cols]

    scenario_vals = df.iloc[:, 0].to_numpy(dtype=int)
    value_data = df.iloc[:, 1:].to_numpy(dtype=np.float64)

    order = np.argsort(scenario_vals)
    data = value_data[order].astype(np.float64)

    return dates, data


def load_surface_df(
    df: pd.DataFrame,
) -> tuple[np.ndarray, np.ndarray, list[date], np.ndarray]:
    """
    Load a surface factor from a DataFrame.

    Expected columns: ``tenor, strike, scenario, <date1>, <date2>, ...``

    Parameters
    ----------
    df : DataFrame with the surface data.

    Returns
    -------
    tenors : np.ndarray, shape (n_tenors,)
    strikes : np.ndarray, shape (n_strikes,)
    dates : list[date], simulation dates parsed from column headers.
    data : np.ndarray, shape (n_paths, n_times, n_tenors, n_strikes)
    """
    cols = list(df.columns)
    date_cols = cols[3:]
    dates = [_parse_date(c) for c in date_cols]

    tenor_vals = df.iloc[:, 0].to_numpy(dtype=np.float64)
    strike_vals = df.iloc[:, 1].to_numpy(dtype=np.float64)
    scenario_vals = df.iloc[:, 2].to_numpy(dtype=int)
    value_data = df.iloc[:, 3:].to_numpy(dtype=np.float64)

    tenors = np.unique(tenor_vals)
    strikes = np.unique(strike_vals)
    scenarios = np.unique(scenario_vals)
    n_tenors = len(tenors)
    n_strikes = len(strikes)
    n_paths = len(scenarios)
    n_times = len(dates)

    tenor_index = {t: i for i, t in enumerate(tenors)}
    strike_index = {k: i for i, k in enumerate(strikes)}
    scenario_index = {s: i for i, s in enumerate(scenarios)}

    data = np.empty((n_paths, n_times, n_tenors, n_strikes), dtype=np.float64)

    for row_idx in range(len(df)):
        t_idx = tenor_index[tenor_vals[row_idx]]
        k_idx = strike_index[strike_vals[row_idx]]
        s_idx = scenario_index[scenario_vals[row_idx]]
        data[s_idx, :, t_idx, k_idx] = value_data[row_idx]

    return tenors, strikes, dates, data


def build_cube_from_dataframes(
    valuation_date: date,
    curve_dfs: dict[str, pd.DataFrame] | None = None,
    scalar_dfs: dict[str, pd.DataFrame] | None = None,
    surface_dfs: dict[str, pd.DataFrame] | None = None,
) -> ScenarioCubeBuilder:
    """
    Build a ScenarioCubeBuilder from pandas DataFrames.

    All DataFrames must share the same number of scenarios.

    Parameters
    ----------
    valuation_date : reference date for the simulation.
    curve_dfs : factor name -> DataFrame for curve factors.
    scalar_dfs : factor name -> DataFrame for scalar factors.
    surface_dfs : factor name -> DataFrame for surface factors.

    Returns
    -------
    ScenarioCubeBuilder with all factors added. Call ``.build()`` to get
    the immutable ScenarioCube.
    """
    curve_dfs = curve_dfs or {}
    scalar_dfs = scalar_dfs or {}
    surface_dfs = surface_dfs or {}

    if not curve_dfs and not scalar_dfs and not surface_dfs:
        raise ValueError("At least one DataFrame must be provided")

    n_paths: int | None = None

    def _check_paths(name: str, paths: int):
        nonlocal n_paths
        if n_paths is None:
            n_paths = paths
        elif paths != n_paths:
            raise ValueError(
                f"Number of scenarios in '{name}' ({paths}) does not "
                f"match previously loaded factors ({n_paths})"
            )

    loaded_curves: dict[str, tuple[np.ndarray, list[date], np.ndarray]] = {}
    loaded_scalars: dict[str, tuple[list[date], np.ndarray]] = {}
    loaded_surfaces: dict[str, tuple[np.ndarray, np.ndarray, list[date], np.ndarray]] = {}

    for name, df in curve_dfs.items():
        tenors, dates, data = load_curve_df(df)
        _check_paths(name, data.shape[0])
        loaded_curves[name] = (tenors, dates, data)

    for name, df in scalar_dfs.items():
        dates, data = load_scalar_df(df)
        _check_paths(name, data.shape[0])
        loaded_scalars[name] = (dates, data)

    for name, df in surface_dfs.items():
        tenors, strikes, dates, data = load_surface_df(df)
        _check_paths(name, data.shape[0])
        loaded_surfaces[name] = (tenors, strikes, dates, data)

    builder = ScenarioCubeBuilder(
        n_paths=n_paths,
        valuation_date=valuation_date,
    )

    for name, (tenors, dates, data) in loaded_curves.items():
        builder.add_curve_factor(name, data, tenors, dates=tuple(dates))

    for name, (dates, data) in loaded_scalars.items():
        builder.add_factor(name, data, dates=tuple(dates))

    for name, (tenors, strikes, dates, data) in loaded_surfaces.items():
        builder.add_surface_factor(name, data, tenors, strikes, dates=tuple(dates))

    return builder


def extract_simulation_dates_from_curve_df(df: pd.DataFrame) -> tuple[date, ...]:
    """
    Extract simulation dates from a curve DataFrame's column headers.

    Expects the same layout as ``load_curve_df``:
    ``tenor, scenario, <date1>, <date2>, ...``

    Parameters
    ----------
    df : DataFrame with curve data (any factor from curve_dfs).

    Returns
    -------
    tuple[date, ...]
        Simulation dates, ready to pass to
        ``generate_static_curve_scenarios``.
    """
    return tuple(_parse_date(c) for c in df.columns[2:])


def _parse_date(value) -> date:
    """Convert a column header to a ``datetime.date``.

    Accepts ``str``, ``datetime.date``, ``pd.Timestamp``, or
    ``np.datetime64``.
    """
    if isinstance(value, pd.Timestamp):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, np.datetime64):
        return pd.Timestamp(value).date()
    return date.fromisoformat(str(value).strip())
