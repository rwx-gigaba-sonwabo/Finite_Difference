"""CSV exporter for exposure profiles."""

from __future__ import annotations

import csv
from pathlib import Path

from pricing.exposure_profile import ExposureProfile


def export_exposure_profile(
    profile: ExposureProfile,
    path: str | Path,
    pfe_alpha: float = 0.95,
) -> None:
    """Write EE, ENE and PFE to a CSV file.

    Parameters
    ----------
    profile : ExposureProfile
        The computed exposure profile.
    path : str or Path
        Destination CSV file path.
    pfe_alpha : float, optional
        Confidence level for PFE (default 0.95).
    """
    ee = profile.epe
    ene = profile.ene
    pfe = profile.pfe(pfe_alpha)

    pfe_label = f"pfe_{int(pfe_alpha * 100)}"

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["date", "ee", "ene", pfe_label])
        for i, d in enumerate(profile.dates):
            writer.writerow([d.isoformat(), ee[i], ene[i], pfe[i]])
