import numpy as np
from datetime import date, timedelta

from utils.ql_helpers import to_ql_date


EXCEL_EPOCH = date(1899, 12, 30)  # standard Python/Excel-compatible origin


def excel_serial_to_date(serial: float | int) -> date:
    """
    Convert an Excel serial date to a Python date.

    Assumes the standard Excel/Windows serial convention.
    """
    return EXCEL_EPOCH + timedelta(days=int(round(float(serial))))


def excel_serials_to_year_fracs(
    serials: np.ndarray,
    value_date: date,
    day_counter,
) -> np.ndarray:
    """
    Convert Excel serial pillar dates into year fractions from value_date.
    """
    serials = np.asarray(serials, dtype=np.float64)

    curve_dates = [excel_serial_to_date(s) for s in serials]

    return np.array(
        [
            float(day_counter.yearFraction(
                to_ql_date(value_date),
                to_ql_date(d),
            ))
            for d in curve_dates
        ],
        dtype=np.float64,
    )


def linear_interpolator(year_fracs: np.ndarray, rates: np.ndarray):
    """
    Vectorised linear interpolation with flat extrapolation.

    Factory signature: (year_fracs, rates) -> callable.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Sorted pillar year fractions.
    rates : np.ndarray, shape (n_paths, n_tenors)
        Zero rates at each pillar per path.

    Returns
    -------
    callable
        t -> (n_paths,) for scalar t,
        t -> (n_paths, n_queries) for array t.
    """
    def interp(t):
        t_scalar = np.isscalar(t)
        t_arr = np.atleast_1d(np.asarray(t, dtype=np.float64))

        idx = np.searchsorted(year_fracs, t_arr, side="right") - 1
        idx = np.clip(idx, 0, len(year_fracs) - 2)

        dt = np.diff(year_fracs)
        dr = np.diff(rates, axis=1)

        rates_left = rates[:, idx]
        t_left = year_fracs[idx]
        dt_seg = dt[idx]
        dr_seg = dr[:, idx]

        frac = (t_arr - t_left) / dt_seg
        result = rates_left + dr_seg * frac[np.newaxis, :]

        # flat extrapolation beyond boundaries
        below = t_arr[np.newaxis, :] <= year_fracs[0]
        above = t_arr[np.newaxis, :] >= year_fracs[-1]
        result = np.where(below, rates[:, :1], result)
        result = np.where(above, rates[:, -1:], result)

        if t_scalar:
            return result[:, 0]
        return result

    return interp


def get_forward_price_from_slice(
    curve_serial_tenors: np.ndarray,
    curve_values: np.ndarray,
    value_date: date,
    target_date: date,
    day_counter,
    right_extrapolation: str = "linear",
    left_extrapolation: str = "flat",
    _precomputed_tenors_yf: np.ndarray | None = None,
) -> np.ndarray:
    """
    Get the applicable forward price from a CurveSlice whose tenors are
    Excel serial dates.

    Interpolation is performed in year-fraction space relative to value_date.

    Pass ``_precomputed_tenors_yf`` (result of
    ``excel_serials_to_year_fracs(curve_serial_tenors, value_date, dc)``)
    to skip recomputing the conversion on every call when pricing inside a loop.
    """
    x = (
        _precomputed_tenors_yf
        if _precomputed_tenors_yf is not None
        else excel_serials_to_year_fracs(
            serials=curve_serial_tenors,
            value_date=value_date,
            day_counter=day_counter,
        )
    )  # shape (n_tenors,)

    p = np.atleast_2d(np.asarray(curve_values, dtype=np.float64))  # (n_paths, n_tenors)

    if x.ndim != 1:
        raise ValueError("Converted tenor grid must be 1D.")
    if p.shape[1] != x.size:
        raise ValueError(
            f"curve_values must have shape (n_paths, {x.size}), got {p.shape}."
        )
    if x.size == 0:
        raise ValueError("Forward curve has no pillars.")
    if x.size == 1:
        return p[:, 0]
    if not np.all(np.diff(x) > 0):
        raise ValueError(
            "Converted year-fraction tenors must be strictly increasing."
        )

    target_t = float(day_counter.yearFraction(
        to_ql_date(value_date),
        to_ql_date(target_date),
    ))

    exact_idx = np.where(np.isclose(x, target_t, rtol=1e-10, atol=1e-12))[0]
    if exact_idx.size > 0:
        return p[:, exact_idx[0]]

    if target_t < x[0]:
        if left_extrapolation == "flat":
            return p[:, 0]
        elif left_extrapolation == "linear":
            slope = (p[:, 1] - p[:, 0]) / (x[1] - x[0])
            return p[:, 0] + slope * (target_t - x[0])
        else:
            raise ValueError("left_extrapolation must be 'flat' or 'linear'.")

    if target_t > x[-1]:
        if right_extrapolation == "flat":
            return p[:, -1]
        elif right_extrapolation == "linear":
            slope = (p[:, -1] - p[:, -2]) / (x[-1] - x[-2])
            return p[:, -1] + slope * (target_t - x[-1])
        else:
            raise ValueError("right_extrapolation must be 'flat' or 'linear'.")

    idx_right = np.searchsorted(x, target_t, side="right")
    idx_left = idx_right - 1

    x0, x1 = x[idx_left], x[idx_right]
    p0, p1 = p[:, idx_left], p[:, idx_right]

    w = (target_t - x0) / (x1 - x0)
    return p0 + w * (p1 - p0)


def forward_price_interpolator(year_fracs: np.ndarray, prices: np.ndarray):
    """
    Vectorised linear interpolation for commodity forward price curves.

    Applies flat left-extrapolation (below the shortest tenor) and
    **linear** right-extrapolation (beyond the last tenor), using the
    slope of the final pillar segment to project forward prices into
    maturities not covered by quoted futures contracts.

    Factory signature: (year_fracs, prices) -> callable.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Sorted pillar year fractions (must have at least 2 elements for
        linear right-extrapolation; falls back to flat if only 1 pillar).
    prices : np.ndarray, shape (n_paths, n_tenors)
        Futures prices (e.g. USD/barrel) at each pillar per path.

    Returns
    -------
    callable
        t -> (n_paths,) for scalar t,
        t -> (n_paths, n_queries) for array t.
    """
    x = np.asarray(year_fracs, dtype=np.float64)   # (n_tenors,)
    p = np.atleast_2d(np.asarray(prices, dtype=np.float64))  # (n_paths, n_tenors)

    # Slope of the final segment used for right-side linear extrapolation.
    # Falls back to zero (flat) when only one pillar is available.
    if len(x) >= 2:
        dx_last = x[-1] - x[-2]                            # scalar
        dp_last = (p[:, -1:] - p[:, -2:-1]) / dx_last      # (n_paths, 1)
    else:
        dp_last = np.zeros_like(p[:, :1])                  # (n_paths, 1)

    def interp(t):
        t_scalar = np.isscalar(t)
        t_arr = np.atleast_1d(np.asarray(t, dtype=np.float64))

        # Linear interpolation (clamp index so we never exceed the last
        # interior segment; extrapolation is handled explicitly below).
        idx = np.searchsorted(x, t_arr, side="right") - 1
        idx = np.clip(idx, 0, len(x) - 2)

        dx = np.diff(x)          # (n_tenors-1,)
        dp = np.diff(p, axis=1)  # (n_paths, n_tenors-1)

        p_left = p[:, idx]        # (n_paths, n_queries)
        x_left = x[idx]           # (n_queries,)
        dx_seg = dx[idx]          # (n_queries,)
        dp_seg = dp[:, idx]       # (n_paths, n_queries)

        frac = (t_arr - x_left) / dx_seg
        result = p_left + dp_seg * frac[np.newaxis, :]

        # Flat left-extrapolation: below the shortest pillar keep first price
        below = t_arr[np.newaxis, :] <= x[0]
        result = np.where(below, p[:, :1], result)

        # Linear right-extrapolation: beyond the last pillar project forward
        above = t_arr[np.newaxis, :] > x[-1]
        if above.any():
            extrap = p[:, -1:] + dp_last * (t_arr[np.newaxis, :] - x[-1])
            result = np.where(above, extrap, result)

        if t_scalar:
            return result[:, 0]
        return result

    return interp


def linear_rt_interp(year_fracs: np.ndarray, rates: np.ndarray):
    """
    Vectorised linear interpolation in (r * t) space with flat extrapolation.

    Interpolates linearly on the product r*t, then converts back to rate space.

    Factory signature: (year_fracs, rates) -> callable.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Sorted pillar year fractions.
    rates : np.ndarray, shape (n_paths, n_tenors)
        Zero rates at each pillar per path.

    Returns
    -------
    callable
        t -> (n_paths,) for scalar t,
        t -> (n_paths, n_queries) for array t.
    """
    x = np.asarray(year_fracs, dtype=np.float64)
    r = np.asarray(rates, dtype=np.float64)
    rt = r * x[np.newaxis, :]  # (n_paths, n_tenors)

    def interp(t):
        t_scalar = np.isscalar(t)
        t_arr = np.atleast_1d(np.asarray(t, dtype=np.float64))

        idx = np.searchsorted(x, t_arr, side="right") - 1
        idx = np.clip(idx, 0, len(x) - 2)

        x_left = x[idx]
        x_right = x[idx + 1]
        rt_left = rt[:, idx]
        rt_right = rt[:, idx + 1]

        frac = (t_arr - x_left) / (x_right - x_left)
        rt_interp = rt_left + (rt_right - rt_left) * frac[np.newaxis, :]

        tau = t_arr[np.newaxis, :]
        safe_tau = np.where(tau == 0.0, 1.0, tau)
        result = np.where(tau == 0.0, r[:, :1], rt_interp / safe_tau)

        # flat extrapolation beyond boundaries
        below = t_arr[np.newaxis, :] <= x[0]
        above = t_arr[np.newaxis, :] >= x[-1]
        result = np.where(below, r[:, :1], result)
        result = np.where(above, r[:, -1:], result)

        if t_scalar:
            return result[:, 0]
        return result

    return interp


def reciprocal_time_interp(year_fracs: np.ndarray, rates: np.ndarray):
    """
    Vectorised linear interpolation in (1/t) space with flat extrapolation.

    Interpolates rates linearly as a function of 1/t (reciprocal time).

    Factory signature: (year_fracs, rates) -> callable.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Sorted pillar year fractions (must be > 0).
    rates : np.ndarray, shape (n_paths, n_tenors)
        Rates at each pillar per path.

    Returns
    -------
    callable
        t -> (n_paths,) for scalar t,
        t -> (n_paths, n_queries) for array t.
    """
    x = np.asarray(year_fracs, dtype=np.float64)
    r = np.asarray(rates, dtype=np.float64)
    inv_x = 1.0 / x  # (n_tenors,) — sorted descending since x is ascending

    def interp(t):
        t_scalar = np.isscalar(t)
        t_arr = np.atleast_1d(np.asarray(t, dtype=np.float64))

        # Flat extrapolation for t <= 0
        safe_t = np.where(t_arr > 0, t_arr, x[0])
        inv_t = 1.0 / safe_t  # (n_queries,)

        # inv_x is descending, so flip for searchsorted
        inv_x_asc = inv_x[::-1]
        r_flipped = r[:, ::-1]

        idx = np.searchsorted(inv_x_asc, inv_t, side="right") - 1
        idx = np.clip(idx, 0, len(inv_x_asc) - 2)

        x_left = inv_x_asc[idx]
        x_right = inv_x_asc[idx + 1]
        r_left = r_flipped[:, idx]
        r_right = r_flipped[:, idx + 1]

        frac = (inv_t - x_left) / (x_right - x_left)
        result = r_left + (r_right - r_left) * frac[np.newaxis, :]

        # flat extrapolation beyond boundaries (in 1/t space)
        below = inv_t[np.newaxis, :] <= inv_x_asc[0]
        above = inv_t[np.newaxis, :] >= inv_x_asc[-1]
        result = np.where(below, r_flipped[:, :1], result)
        result = np.where(above, r_flipped[:, -1:], result)

        # Handle t <= 0: use rate at shortest tenor
        zero_mask = t_arr[np.newaxis, :] <= 0
        result = np.where(zero_mask, r[:, :1], result)

        if t_scalar:
            return result[:, 0]
        return result

    return interp


def hermite_rt_interp(year_fracs: np.ndarray, rates: np.ndarray):
    """
    Vectorised Hermite RT interpolation in (r * t) space with flat
    extrapolation.

    Factory signature: (year_fracs, rates) -> callable.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Sorted pillar year fractions.
    rates : np.ndarray, shape (n_paths, n_tenors)
        Zero rates at each pillar per path.

    Returns
    -------
    callable
        t -> (n_paths,) for scalar t,
        t -> (n_paths, n_queries) for array t.
    """
    x = np.asarray(year_fracs, dtype=np.float64)    # (n_tenors,)
    r = np.asarray(rates, dtype=np.float64)          # (n_paths, n_tenors)
    n = len(x)
    rt = r * x[np.newaxis, :]                        # (n_paths, n_tenors)

    # Hermite derivatives for each path: shape (n_paths, n_tenors)
    rp = np.zeros_like(rt)

    # Interior knots
    for i in range(1, n - 1):
        dx1 = x[i] - x[i - 1]
        dx2 = x[i + 1] - x[i]
        if dx1 == 0 or dx2 == 0:
            continue
        rp[:, i] = (
            (rt[:, i + 1] - rt[:, i]) * dx1 / dx2
            + (rt[:, i] - rt[:, i - 1]) * dx2 / dx1
        ) / (x[i + 1] - x[i - 1])

    # Boundary knots
    if n >= 3:
        t1, t2, t3 = x[0], x[1], x[2]
        rp[:, 0] = (
            (rt[:, 1] - rt[:, 0]) * (t3 + t2 - 2 * t1) / (t2 - t1)
            - (rt[:, 2] - rt[:, 1]) * (t2 - t1) / (t3 - t2)
        ) / (t3 - t1)

        tn, tn1, tn2 = x[-1], x[-2], x[-3]
        rp[:, -1] = -(
            (rt[:, -2] - rt[:, -3]) * (tn - tn1) / (tn1 - tn2)
            - (rt[:, -1] - rt[:, -2]) * (2 * tn - tn1 - tn2) / (tn - tn1)
        ) / (tn - tn2)

    def interp(t):
        t_scalar = np.isscalar(t)
        t_arr = np.atleast_1d(np.asarray(t, dtype=np.float64))  # (n_queries,)

        idx = np.searchsorted(x, t_arr, side="right") - 1
        idx = np.clip(idx, 0, n - 2)

        t1 = x[idx]                       # (n_queries,)
        t2 = x[idx + 1]                   # (n_queries,)
        h = t2 - t1                        # (n_queries,)
        m = (t_arr - t1) / h               # (n_queries,)

        # Gather knot values per path: (n_paths, n_queries)
        rt1 = rt[:, idx]
        rt2 = rt[:, idx + 1]
        rp1 = rp[:, idx]
        rp2 = rp[:, idx + 1]

        # Hermite basis (broadcast m as (1, n_queries))
        m = m[np.newaxis, :]
        h = h[np.newaxis, :]
        rt_interp = (
            (1 - m) ** 2 * (1 + 2 * m) * rt1
            + m ** 2 * (3 - 2 * m) * rt2
            + (1 - m) ** 2 * m * h * rp1
            + m ** 2 * (m - 1) * h * rp2
        )  # (n_paths, n_queries)

        # Convert back from r*t space to rate space
        tau = t_arr[np.newaxis, :]         # (1, n_queries)
        result = np.where(tau == 0.0, r[:, :1], rt_interp / tau)

        # Flat extrapolation beyond boundaries
        below = t_arr[np.newaxis, :] <= x[0]
        above = t_arr[np.newaxis, :] >= x[-1]
        result = np.where(below, r[:, :1], result)
        result = np.where(above, r[:, -1:], result)

        if t_scalar:
            return result[:, 0]
        return result

    return interp


def stitched_linear_rt_hermite_rt_interp(
    year_fracs: np.ndarray,
    rates: np.ndarray,
    stitch_years: float = 1.5,
):
    """
    Blended interpolation in r*t space: linear-RT for short tenors,
    Hermite-RT for long tenors.

    The regime boundary is the last pillar whose year fraction does not
    exceed *stitch_years* (default 1.5 = 18 months).  Anchoring at an
    actual pillar guarantees continuity at the join.

    Factory signature: (year_fracs, rates[, stitch_years]) -> callable.
    Compatible with YieldCurve: pass as ``interpolator=mixed_linear_rt_hermite_rt_interp``
    to use the default 1.5-year stitch, or wrap via
    ``lambda yf, r: stitched_linear_rt_hermite_rt_interp(yf, r, stitch_years=2.0)``
    for a custom stitch.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Sorted pillar year fractions.
    rates : np.ndarray, shape (n_paths, n_tenors)
        Zero rates at each pillar per path.
    stitch_years : float
        Approximate stitch point in years (default 1.5).  The actual
        boundary is snapped to the nearest pillar at or below this value.

    Returns
    -------
    callable
        t -> (n_paths,) for scalar t,
        t -> (n_paths, n_queries) for array t.
    """
    x = np.asarray(year_fracs, dtype=np.float64)   # (n_tenors,)
    r = np.asarray(rates, dtype=np.float64)         # (n_paths, n_tenors)
    n = len(x)
    rt = r * x[np.newaxis, :]                       # (n_paths, n_tenors)

    # Stitch index: last pillar whose year-frac <= stitch_years.
    # Using the pillar (not the raw float) guarantees continuity.
    stitch_idx = max(int(np.searchsorted(x, stitch_years, side="right")) - 1, 0)

    # ------------------------------------------------------------------ #
    # Hermite derivatives on the FULL curve (all pillars).                #
    # Using all pillars for derivative estimation gives accurate slopes   #
    # at the stitch knot and at the last short-end pillar.                #
    # ------------------------------------------------------------------ #
    rp = np.zeros_like(rt)

    for i in range(1, n - 1):
        dx1 = x[i] - x[i - 1]
        dx2 = x[i + 1] - x[i]
        if dx1 == 0 or dx2 == 0:
            continue
        rp[:, i] = (
            (rt[:, i + 1] - rt[:, i]) * dx1 / dx2
            + (rt[:, i] - rt[:, i - 1]) * dx2 / dx1
        ) / (x[i + 1] - x[i - 1])

    if n >= 3:
        t1, t2, t3 = x[0], x[1], x[2]
        rp[:, 0] = (
            (rt[:, 1] - rt[:, 0]) * (t3 + t2 - 2 * t1) / (t2 - t1)
            - (rt[:, 2] - rt[:, 1]) * (t2 - t1) / (t3 - t2)
        ) / (t3 - t1)

        tn, tn1, tn2 = x[-1], x[-2], x[-3]
        rp[:, -1] = -(
            (rt[:, -2] - rt[:, -3]) * (tn - tn1) / (tn1 - tn2)
            - (rt[:, -1] - rt[:, -2]) * (2 * tn - tn1 - tn2) / (tn - tn1)
        ) / (tn - tn2)

    def interp(t):
        t_scalar = np.isscalar(t)
        t_arr = np.atleast_1d(np.asarray(t, dtype=np.float64))
        n_paths = r.shape[0]
        result = np.empty((n_paths, len(t_arr)))

        # Boundary snapped to actual pillar — guarantees no discontinuity.
        left_mask = t_arr <= x[stitch_idx]
        right_mask = ~left_mask

        # Short end: linear on r*t
        if left_mask.any():
            tq = t_arr[left_mask]
            idx = np.searchsorted(x, tq, side="right") - 1
            idx = np.clip(idx, 0, n - 2)

            x_l = x[idx]
            x_r = x[idx + 1]
            rt_l = rt[:, idx]
            rt_r = rt[:, idx + 1]
            frac = (tq - x_l) / (x_r - x_l)
            rt_q = rt_l + (rt_r - rt_l) * frac[np.newaxis, :]
            tau = tq[np.newaxis, :]
            safe_tau = np.where(tau == 0.0, 1.0, tau)
            result[:, left_mask] = np.where(tau == 0.0, r[:, :1], rt_q / safe_tau)

        # Long end: Hermite on r*t 
        if right_mask.any():
            tq = t_arr[right_mask]
            idx = np.searchsorted(x, tq, side="right") - 1
            # Clip to [stitch_idx, n-2]: never borrow a left-regime segment.
            idx = np.clip(idx, stitch_idx, n - 2)

            t1 = x[idx]
            t2 = x[idx + 1]
            h = t2 - t1
            m = (tq - t1) / h

            rt1 = rt[:, idx]
            rt2 = rt[:, idx + 1]
            rp1 = rp[:, idx]
            rp2 = rp[:, idx + 1]

            m = m[np.newaxis, :]
            h = h[np.newaxis, :]
            rt_q = (
                (1 - m) ** 2 * (1 + 2 * m) * rt1
                + m ** 2 * (3 - 2 * m) * rt2
                + (1 - m) ** 2 * m * h * rp1
                + m ** 2 * (m - 1) * h * rp2
            )
            tau = tq[np.newaxis, :]
            safe_tau = np.where(tau == 0.0, 1.0, tau)
            result[:, right_mask] = np.where(tau == 0.0, r[:, :1], rt_q / safe_tau)

        # Flat extrapolation beyond pillar boundaries
        below = t_arr[np.newaxis, :] <= x[0]
        above = t_arr[np.newaxis, :] >= x[-1]
        result = np.where(below, r[:, :1], result)
        result = np.where(above, r[:, -1:], result)

        if t_scalar:
            return result[:, 0]
        return result

    return interp
