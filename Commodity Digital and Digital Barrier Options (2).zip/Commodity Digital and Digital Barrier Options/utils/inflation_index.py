from __future__ import annotations

import calendar
from datetime import date, datetime
from typing import Callable, Dict, Optional, Tuple

import pandas as pd
from dateutil.relativedelta import relativedelta


class InflationIndex:
    """
    Historical CPI index handler with BESA 4/3-month bracketing and optional
    forward projection from a discount-factor callable.

    The BESA rule maps any calendar date d to CPI via:
        - Let j  = first of month, lag_months before d (default 4).
        - Let j1 = j + 1 month.
        - If d.day == 1: CPI(d) = monthly_cpi[j].
        - Otherwise:     CPI(d) = monthly_cpi[j] + fraction * (monthly_cpi[j1] - monthly_cpi[j])
          where fraction = (d.day - 1) / days_in_month(d).

    Forward projection (optional):
        If a discount-factor callable is supplied, monthly CPI values beyond
        the last historical fixing are projected using implied inflation ratios:
            CPI_next = CPI_prev * df(prev_date) / df(next_date)

    Parameters
    ----------
    value_date : date
        Anchor date used as the starting point for forward projection.
    curve_anchor_date : date
        Reference date for the discount-factor callable (e.g. today's date when
        the inflation curve was bootstrapped).
    monthly_cpi : pd.DataFrame
        Historical monthly CPI data.  Must contain one date column and one
        value column (column names are auto-resolved).
    df_func : callable or None
        Signature ``(d: date) -> float``.  Returns the discount factor from
        ``curve_anchor_date`` to ``d``.  Required when ``extend_cpi > 0``.
    extend_cpi : int
        Number of months of projected CPI fixings to pre-compute beyond the
        last historical fixing.  Set to 0 to disable projection entirely.
    date_col : str
        Name of the date column in ``monthly_cpi`` (case-insensitive fallback).
    value_col : str
        Name of the value column in ``monthly_cpi`` (case-insensitive fallback).
    lag_months : int
        CPI publication lag in months (default 4, BESA convention).
    """

    def __init__(
        self,
        value_date: date,
        curve_anchor_date: date,
        monthly_cpi: pd.DataFrame,
        df_func: Optional[Callable[[date], float]] = None,
        extend_cpi: int = 96,
        date_col: str = "Date",
        value_col: str = "Value",
        lag_months: int = 4,
    ):
        self.value_date = value_date
        self.curve_anchor_date = curve_anchor_date
        self.df_func = df_func
        self.extend_cpi = int(extend_cpi)
        self.lag_months = lag_months

        self._monthly_cpi: Dict[date, float] = self._df_to_fixing_map(
            monthly_cpi=monthly_cpi,
            date_col=date_col,
            value_col=value_col,
        )

        if self.extend_cpi > 0 and self.df_func is not None:
            self._monthly_cpi = dict(self.extend_historical_cpi(self.extend_cpi))

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _first_of_month(d: date) -> date:
        return date(d.year, d.month, 1)

    @staticmethod
    def _shift_months(d: date, months: int) -> date:
        """Shift a first-of-month date by ``months`` months."""
        y, m = divmod(d.month - 1 + months, 12)
        return date(d.year + y, m + 1, 1)

    @staticmethod
    def _coerce_to_date(x) -> date:
        if isinstance(x, date) and not isinstance(x, datetime):
            return x
        if isinstance(x, datetime):
            return x.date()
        return pd.to_datetime(x).date()

    @staticmethod
    def _resolve_column(df: pd.DataFrame, preferred: str) -> str:
        if preferred in df.columns:
            return preferred
        lower_map = {c.lower(): c for c in df.columns}
        if preferred.lower() in lower_map:
            return lower_map[preferred.lower()]
        fallbacks = {
            "date":  ["date", "Date", "DATE", "fixing_date", "FixingDate"],
            "value": ["value", "Value", "VALUE", "cpi", "CPI", "fixing", "Fixing"],
        }
        for cand in fallbacks.get(preferred.lower(), []):
            if cand in df.columns:
                return cand
        raise KeyError(
            f"Could not find a '{preferred}' column in monthly_cpi. "
            f"Available columns: {list(df.columns)}"
        )

    # ------------------------------------------------------------------
    # Internal data loading
    # ------------------------------------------------------------------

    def _df_to_fixing_map(
        self,
        monthly_cpi: pd.DataFrame,
        date_col: str,
        value_col: str,
    ) -> Dict[date, float]:
        if not isinstance(monthly_cpi, pd.DataFrame):
            raise TypeError("monthly_cpi must be a pandas DataFrame.")

        dcol = self._resolve_column(monthly_cpi, date_col)
        vcol = self._resolve_column(monthly_cpi, value_col)

        df = monthly_cpi[[dcol, vcol]].copy()
        df[dcol] = df[dcol].apply(self._coerce_to_date)
        df[vcol] = pd.to_numeric(df[vcol], errors="raise")
        # Normalise to first-of-month
        df[dcol] = df[dcol].apply(self._first_of_month)
        # Keep last if duplicates on same month
        df = df.sort_values(dcol).drop_duplicates(subset=[dcol], keep="last")

        fixings: Dict[date, float] = dict(zip(df[dcol].tolist(), df[vcol].tolist()))
        if not fixings:
            raise ValueError("monthly_cpi is empty after processing.")
        return fixings

    # ------------------------------------------------------------------
    # BESA bracketing
    # ------------------------------------------------------------------

    def _bracket(self, d: date) -> Tuple[date, date]:
        """Return the BESA (j, j1) bracket dates for payment date d."""
        first = self._first_of_month(d)
        j = self._shift_months(first, -self.lag_months)
        j1 = self._shift_months(j, 1)
        if d.day == 1:
            return j, j
        return j, j1

    # ------------------------------------------------------------------
    # Forward projection
    # ------------------------------------------------------------------

    def extend_historical_cpi(self, months: int) -> Dict[date, float]:
        """
        Project first-of-month CPI fixings ``months`` ahead using
        discount-factor ratios implied by ``df_func``.

        Returns a dict containing both historical and projected fixings.
        Raises ``ValueError`` if ``df_func`` is not set.
        """
        if self.df_func is None:
            raise ValueError(
                "df_func is required to project CPI forward. "
                "Pass a callable (date -> float) discount-factor function."
            )
        months = int(months)
        if months <= 0:
            return dict(self._monthly_cpi)

        fixings: Dict[date, float] = dict(self._monthly_cpi)

        prev_date = self._first_of_month(max(fixings.keys()))
        prev_cpi = float(fixings[prev_date])

        num_ext_yrs, _ = divmod(self.extend_cpi, 12)

        first_prev_reset = self._shift_months(self.curve_anchor_date, -13)
        prev_date_resets = [
            first_prev_reset + relativedelta(years=i) for i in range(num_ext_yrs)
        ]

        fixing_df = 1.0
        fixing_reset_cpi = 1.0
        value_date = self.value_date

        for i in range(1, months + 1):
            next_date = self._shift_months(prev_date, i)

            if next_date in prev_date_resets:
                value_date = next_date
                next_carry_date = self._shift_months(self.value_date, i)
                fixing_df = self.df_func(value_date)
                next_df = self.df_func(next_carry_date)
                prev_cpi = fixing_reset_cpi
            elif value_date in prev_date_resets:
                next_carry_date = self._shift_months(self.value_date, i)
                next_df = self.df_func(next_carry_date)
            else:
                next_carry_date = value_date + relativedelta(months=i)
                next_df = self.df_func(next_carry_date)

            next_cpi = prev_cpi * (fixing_df / next_df)
            fixings[next_date] = float(next_cpi)
            fixing_reset_cpi = next_cpi

        return fixings

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def cpi_value(self, d: date) -> float:
        """
        Return the published CPI level for date ``d`` using the BESA
        4/3-month bracket rule with linear intra-month interpolation.

        If the required bracket dates are beyond the stored fixings, the
        projection is extended automatically (requires ``df_func``).
        """
        j, j1 = self._bracket(d)

        # Extend if bracket dates exceed known fixings
        latest = max(self._monthly_cpi.keys())
        if j > latest or j1 > latest:
            target = max(j, j1)
            months_to_add = (
                (target.year - latest.year) * 12 + (target.month - latest.month)
            )
            if months_to_add > 0:
                self._monthly_cpi = dict(self.extend_historical_cpi(months_to_add))

        cpi_j = self._monthly_cpi[j]
        cpi_j1 = self._monthly_cpi[j1]

        if j == j1:
            return cpi_j

        D = calendar.monthrange(d.year, d.month)[1]
        fraction = (d.day - 1) / D
        return cpi_j + fraction * (cpi_j1 - cpi_j)
