import numpy as np


def convert_to_year_fracs(dates: np.ndarray, valuation_date: np.datetime64, day_count: str = "ACT/365") -> np.ndarray:
    """Convert an array of dates to year fractions relative to a valuation date.

    Parameters
    ----------
    dates : np.ndarray
        Array of numpy datetime64 values.
    valuation_date : np.datetime64
        The reference date from which year fractions are measured.
    day_count : str
        Day count convention. Supported: "ACT/365", "ACT/360".

    Returns
    -------
    np.ndarray
        Array of year fractions (float64).
    """
    dates = np.asarray(dates, dtype="datetime64[D]")
    valuation_date = np.datetime64(valuation_date, "D")

    day_counts = (dates - valuation_date).astype("timedelta64[D]").astype(np.float64)

    dc = day_count.upper().replace(" ", "")

    if dc == "ACT/365":
        return day_counts / 365.0
    elif dc == "ACT/360":
        return day_counts / 360.0
    else:
        raise ValueError(f"Unsupported day count convention: {day_count!r}. Use 'ACT/365' or 'ACT/360'.")
