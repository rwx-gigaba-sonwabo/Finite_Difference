from __future__ import annotations

from datetime import date

import QuantLib as ql


# ---------------------------------------------------------------------------
# Date conversion
# ---------------------------------------------------------------------------

def to_ql_date(d: date) -> ql.Date:
    return ql.Date(d.day, d.month, d.year)


def from_ql_date(d: ql.Date) -> date:
    return date(d.year(), d.month(), d.dayOfMonth())


# ---------------------------------------------------------------------------
# Look-up tables
# ---------------------------------------------------------------------------

CALENDARS: dict[str, ql.Calendar] = {
    "ZAR": ql.SouthAfrica(),
    "TARGET": ql.TARGET(),
    "USD": ql.UnitedStates(ql.UnitedStates.GovernmentBond),
    "GBP": ql.UnitedKingdom(),
    # Commodity exchange calendars (use USD holiday set as default approximation)
    "ICE": ql.UnitedStates(ql.UnitedStates.GovernmentBond),
    "NYMEX": ql.UnitedStates(ql.UnitedStates.GovernmentBond),
}


# ---------------------------------------------------------------------------
# Business-day utilities
# ---------------------------------------------------------------------------

def generate_business_days(
    start: date,
    end: date,
    calendar_name: str,
) -> list[date]:
    """Return all business days in [start, end] inclusive for the given calendar.

    Parameters
    ----------
    start, end : date
        Inclusive date range.
    calendar_name : str
        Key in the CALENDARS dict (e.g. ``"ZAR"``, ``"USD"``).

    Returns
    -------
    list[date]
        Sorted list of business days from *start* to *end* inclusive.
    """
    ql_cal = CALENDARS[calendar_name]
    ql_end = to_ql_date(end)
    d = to_ql_date(start)
    result: list[date] = []
    while d <= ql_end:
        if ql_cal.isBusinessDay(d):
            result.append(from_ql_date(d))
        d = ql.Date(d.serialNumber() + 1)
    return result


def advance_business_days(
    d: date,
    n: int,
    calendar_name: str,
) -> date:
    """Advance *d* by *n* business days in the given calendar.

    Parameters
    ----------
    d : date
        Starting date (need not itself be a business day).
    n : int
        Number of business days to advance (must be >= 0).
    calendar_name : str
        Key in the CALENDARS dict.

    Returns
    -------
    date
        The resulting date after advancing by *n* business days.
    """
    if n == 0:
        return d
    ql_cal = CALENDARS[calendar_name]
    ql_d = to_ql_date(d)
    count = 0
    while count < n:
        ql_d = ql.Date(ql_d.serialNumber() + 1)
        if ql_cal.isBusinessDay(ql_d):
            count += 1
    return from_ql_date(ql_d)

BUSINESS_CONVENTIONS: dict[str, int] = {
    "ModifiedFollowing": ql.ModifiedFollowing,
    "Following": ql.Following,
    "Preceding": ql.Preceding,
    "Unadjusted": ql.Unadjusted,
}

DAY_COUNTERS: dict[str, ql.DayCounter] = {
    "ACT/365": ql.Actual365Fixed(),
    "ACT/360": ql.Actual360(),
    "30/360": ql.Thirty360(ql.Thirty360.BondBasis),
}

DATE_GENERATION: dict[str, int] = {
    "Backward": ql.DateGeneration.Backward,
    "Forward": ql.DateGeneration.Forward,
}


# ---------------------------------------------------------------------------
# Schedule generation
# ---------------------------------------------------------------------------

def generate_sub_periods(
    pay_start: date,
    pay_end: date,
    reset_months: int,
    calendar: ql.Calendar,
    convention: int,
    day_counter: ql.DayCounter,
    direction: str = "Forward",
) -> list[tuple[date, date, float]]:
    """Slice a payment period into sub-periods of *reset_months* length.

    Parameters
    ----------
    pay_start, pay_end : date
        Inclusive payment period boundaries.
    reset_months : int
        Sub-period length in months (e.g. 3 for JIBAR-3m resets).
    calendar : ql.Calendar
        Calendar for business-day adjustment of sub-period end dates.
    convention : int
        QuantLib business-day convention (e.g. ql.ModifiedFollowing).
    day_counter : ql.DayCounter
        Day count convention used to compute sub-period accrual fractions.
    direction : str
        ``"Forward"`` (default) — advance from *pay_start*; any short stub
        falls at the **end** of the period.
        ``"Backward"`` — step back from *pay_end*; any short stub falls at
        the **start** of the period (mirrors QuantLib backward date generation
        and RiskFlow's standard schedule convention).

    Returns
    -------
    list of (sub_start, sub_end, accrual_fraction)
        Always sorted start→end.  At least one entry when pay_start < pay_end.
    """
    if direction not in ("Forward", "Backward"):
        raise ValueError(
            f"direction must be 'Forward' or 'Backward', got {direction!r}"
        )

    if direction == "Forward":
        subs: list[tuple[date, date, float]] = []
        current = pay_start
        while current < pay_end:
            ql_current = to_ql_date(current)
            ql_next = calendar.advance(
                ql_current, ql.Period(reset_months, ql.Months), convention
            )
            next_date = from_ql_date(ql_next)
            if next_date > pay_end:
                next_date = pay_end
            accrual = float(day_counter.yearFraction(
                to_ql_date(current), to_ql_date(next_date)
            ))
            subs.append((current, next_date, accrual))
            current = next_date
        return subs

    # Backward: step from pay_end towards pay_start.
    # The stub (short period), if any, appears at the START.
    boundary_dates: list[date] = [pay_end]
    current = pay_end
    while current > pay_start:
        ql_current = to_ql_date(current)
        ql_prev = calendar.advance(
            ql_current, ql.Period(-reset_months, ql.Months), convention
        )
        prev = from_ql_date(ql_prev)
        if prev <= pay_start:
            boundary_dates.append(pay_start)
            break
        boundary_dates.append(prev)
        current = prev
    boundary_dates.sort()  # ascending: pay_start … pay_end

    subs = []
    for i in range(len(boundary_dates) - 1):
        s, e = boundary_dates[i], boundary_dates[i + 1]
        accrual = float(day_counter.yearFraction(to_ql_date(s), to_ql_date(e)))
        subs.append((s, e, accrual))
    return subs


def build_bond_schedule(
    effective_date: date,
    maturity_date: date,
    freq_months: int,
    calendar: ql.Calendar,
    pay_convention: int = ql.Following,
    day_counter: ql.DayCounter | None = None,
    first_date: date | None = None,
    next_to_last_date: date | None = None,
    date_generation: int = ql.DateGeneration.Backward,
    end_of_month: bool = False,
) -> list[tuple[date, date, date, float]]:
    """Bond coupon schedule with Unadjusted accrual dates and Following pay dates.

    Accrual start/end dates are generated with the Unadjusted convention so that
    regular periods span exactly freq_months/12 of a year.  Payment dates are
    calendar-adjusted from accrual end dates using *pay_convention* (default:
    Following).  Discount factors must be computed to the payment date, not the
    accrual end date.

    Accrual fractions
    -----------------
    Regular (full-length) periods always use the constant simple-bond fraction
    ``freq_months / 12``, which matches the BESA/RiskFlow convention for
    South African nominal bonds regardless of the actual calendar-day count.

    Stub periods (short or long, front or back) use the actual year fraction
    from *day_counter* when one is provided.  When *day_counter* is None the
    constant fraction is used for all periods (legacy behaviour).

    Date generation
    ---------------
    *date_generation* controls how the coupon grid is constructed.  Defaults
    to ``ql.DateGeneration.Backward`` (anchor at maturity, step backwards).
    Pass ``ql.DateGeneration.Forward`` to anchor at *effective_date*.

    Stub types
    ----------
    A short front stub arises automatically when *effective_date* does not
    align with a regular backward-generated coupon date.

    A long front stub is produced by setting *first_date* to the second
    regular coupon date (skipping the first); the first period then spans
    from *effective_date* to *first_date*, longer than a regular period.

    A back stub (short or long) is produced via *next_to_last_date*: the
    final period runs from *next_to_last_date* to *maturity_date*.

    Parameters
    ----------
    effective_date : date
        Bond issue / start date (first accrual start).
    maturity_date : date
        Bond maturity (last accrual end, unadjusted).
    freq_months : int
        Coupon frequency in months (e.g. 6 = semi-annual, 12 = annual).
    calendar : ql.Calendar
        Business calendar used to adjust accrual end dates to payment dates.
    pay_convention : int
        QuantLib business-day convention for payment date adjustment.
        Defaults to ql.Following.
    day_counter : ql.DayCounter or None
        Used to compute accrual fractions for stub periods only.  Regular
        periods always use ``freq_months / 12`` regardless.  When None,
        every period uses the constant fraction (legacy).
    first_date : date or None
        Front-stub anchor: fixes the first coupon date.  Pass the second
        regular coupon date to produce a long front stub.
    next_to_last_date : date or None
        Back-stub anchor: fixes the last-but-one coupon date, producing a
        (short or long) final stub period.
    date_generation : int
        QuantLib DateGeneration rule.  Defaults to Backward.

    Returns
    -------
    list of (accrual_start, accrual_end, payment_date, accrual_fraction)
    """
    ql_first = to_ql_date(first_date) if first_date is not None else ql.Date()
    ql_ntl   = to_ql_date(next_to_last_date) if next_to_last_date is not None else ql.Date()

    ql_schedule = ql.Schedule(
        to_ql_date(effective_date),
        to_ql_date(maturity_date),
        ql.Period(freq_months, ql.Months),
        calendar,
        ql.Unadjusted,
        ql.Unadjusted,
        date_generation,
        end_of_month,
        ql_first,
        ql_ntl,
    )

    nominal_frac = freq_months / 12.0
    periods: list[tuple[date, date, date, float]] = []
    for i in range(1, len(ql_schedule)):
        ql_start = ql_schedule[i - 1]
        ql_end   = ql_schedule[i]
        pay_date = from_ql_date(calendar.adjust(ql_end, pay_convention))
        # Regular periods: constant simple-bond fraction (BESA/RiskFlow convention).
        # Stub periods: actual year fraction so the coupon is correctly sized.
        if day_counter is not None and not ql_schedule.isRegular(i):
            frac = float(day_counter.yearFraction(ql_start, ql_end))
        else:
            frac = nominal_frac
        periods.append((from_ql_date(ql_start), from_ql_date(ql_end), pay_date, frac))
    return periods


def build_schedule(
    effective_date: date,
    maturity_date: date,
    freq_months: int,
    calendar: ql.Calendar,
    convention: int,
    termination_convention: int,
    date_generation: int,
    day_counter: ql.DayCounter,
    end_of_month: bool = False,
    first_date: date | None = None,
    next_to_last_date: date | None = None,
    payment_offset_days: int = 0,
    payment_offset_convention: int | None = None,
) -> list[tuple[date, date, date, float]]:
    """Generate a payment schedule as (start, accrual_end, payment_date, accrual_fraction) tuples.

    Parameters
    ----------
    freq_months : int
        Payment frequency in months (e.g. 3=quarterly, 6=semi-annual,
        12=annual). Pass ``0`` for a zero-coupon schedule: a single period
        spanning ``effective_date`` to ``maturity_date`` with the full
        accrual fraction.
    first_date : date or None
        Front-stub anchor. When provided, the first coupon date is fixed here
        and the remaining dates are generated backwards/forwards from it.
        Ignored when ``freq_months=0``.
    next_to_last_date : date or None
        Back-stub anchor. When provided, backwards generation anchors from
        this date instead of maturity_date, producing a short final period
        [next_to_last_date, maturity_date].
        Ignored when ``freq_months=0``.
    payment_offset_days : int
        Number of calendar days to advance each accrual end date to obtain
        the payment date, using *payment_offset_convention* for business-day
        adjustment.  0 (default) means payment_date == accrual_end.
    payment_offset_convention : int or None
        QuantLib business-day convention for the payment-date advance.
        Defaults to *convention* when None.
    """
    pay_conv = payment_offset_convention if payment_offset_convention is not None else convention

    if freq_months == 0:
        ql_eff = to_ql_date(effective_date)
        ql_mat = to_ql_date(maturity_date)
        accrual = float(day_counter.yearFraction(ql_eff, ql_mat))
        if payment_offset_days > 0:
            pay_date = from_ql_date(
                calendar.advance(ql_mat, ql.Period(payment_offset_days, ql.Days), pay_conv)
            )
        else:
            pay_date = maturity_date
        return [(effective_date, maturity_date, pay_date, accrual)]

    ql_first = to_ql_date(first_date) if first_date is not None else ql.Date()
    ql_next_to_last = to_ql_date(next_to_last_date) if next_to_last_date is not None else ql.Date()

    ql_schedule = ql.Schedule(
        to_ql_date(effective_date),
        to_ql_date(maturity_date),
        ql.Period(freq_months, ql.Months),
        calendar,
        convention,
        termination_convention,
        date_generation,
        end_of_month,
        ql_first,
        ql_next_to_last,
    )

    periods: list[tuple[date, date, date, float]] = []
    for i in range(1, len(ql_schedule)):
        start = ql_schedule[i - 1]
        end = ql_schedule[i]
        accrual = day_counter.yearFraction(start, end)
        if payment_offset_days > 0:
            pay_date = from_ql_date(
                calendar.advance(end, ql.Period(payment_offset_days, ql.Days), pay_conv)
            )
        else:
            pay_date = from_ql_date(end)
        periods.append((from_ql_date(start), from_ql_date(end), pay_date, accrual))

    return periods
