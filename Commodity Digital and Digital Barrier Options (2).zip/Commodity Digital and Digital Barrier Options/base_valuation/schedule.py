"""
base_valuation/schedule.py
============================
Bond cashflow schedule generation for base (t0) valuation.

Thin wrapper around ``instruments.components.schedule_config.ScheduleConfig``
(which itself delegates to ``utils.ql_helpers.build_bond_schedule``) -- the
exact schedule generator used by the ``BondForward`` instrument -- so
schedules built here follow the same accrual conventions (Unadjusted
accrual dates, Following-adjusted payment dates, BESA constant-fraction
regular periods) as the rest of the pricing library.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

import QuantLib as ql

from instruments.components.schedule_config import ScheduleConfig


@dataclass
class BondSchedule:
    """A generated bond coupon schedule plus the conventions used to build it."""

    periods: list[tuple[date, date, date, float]]
    """(accrual_start, accrual_end, payment_date, accrual_fraction) per coupon."""

    config: ScheduleConfig

    @property
    def day_counter(self) -> ql.DayCounter:
        return self.config.day_counter

    @property
    def curve_day_counter(self) -> ql.DayCounter:
        return self.config.curve_day_counter

    @property
    def calendar(self) -> ql.Calendar:
        return self.config.ql_calendar

    @property
    def maturity_date(self) -> date:
        return max(e for _, e, _, _ in self.periods)


def build_bond_schedule(
    effective_date: date,
    maturity_date: date,
    coupon_frequency_months: int,
    calendar: str = "ZAR",
    day_count: str = "ACT/365",
    curve_day_count: str = "ACT/365",
    business_convention: str = "ModifiedFollowing",
    date_generation: str = "Backward",
    end_of_month: bool = False,
    first_date: date | None = None,
    next_to_last_date: date | None = None,
) -> BondSchedule:
    """Build a fixed-coupon bond schedule for base valuation.

    Parameters
    ----------
    effective_date : date
        Bond issue / start date (first accrual start).
    maturity_date : date
        Bond maturity (last accrual end, unadjusted).
    coupon_frequency_months : int
        Coupon frequency in months (e.g. 6 = semi-annual, 12 = annual).
    calendar : str
        Key into ``utils.ql_helpers.CALENDARS`` (e.g. ``"ZAR"``, ``"USD"``).
    day_count : str
        Accrual day count for stub-period fractions and accrued interest.
    curve_day_count : str
        Day count used downstream for curve year fractions; should match
        the convention used to build the discount curve.
    business_convention : str
        Business-day convention for the coupon schedule.
    date_generation : str
        ``"Backward"`` (anchor at maturity) or ``"Forward"`` (anchor at
        effective_date).
    end_of_month : bool
        End-of-month date-generation rule.
    first_date : date or None
        Front-stub anchor (second regular coupon date, for a long front
        stub). Leave None for an automatic short front stub.
    next_to_last_date : date or None
        Back-stub anchor producing a short or long final period.

    Returns
    -------
    BondSchedule
        ``periods`` plus the resolved calendar / day-count conventions
        needed downstream by ``base_valuation.bond_pv.value_bond``.
    """
    config = ScheduleConfig(
        calendar=calendar,
        business_convention=business_convention,
        termination_business_convention=business_convention,
        date_generation=date_generation,
        day_count=day_count,
        curve_day_count=curve_day_count,
        end_of_month=end_of_month,
    )
    periods = config.build_bond_schedule(
        effective_date,
        maturity_date,
        coupon_frequency_months,
        first_date=first_date,
        next_to_last_date=next_to_last_date,
    )
    return BondSchedule(periods=periods, config=config)
