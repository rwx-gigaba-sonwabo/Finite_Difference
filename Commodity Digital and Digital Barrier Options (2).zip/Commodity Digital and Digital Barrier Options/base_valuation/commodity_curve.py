"""
base_valuation/commodity_curve.py
====================================
Date-based commodity forward *price* curve construction for base (t0)
valuation.

Mirrors ``base_valuation.yield_curve.build_yield_curve`` (dates + values ->
an object with a date-based lookup method) but for a forward **price**
curve rather than a zero-rate curve: pillars are (date, price) pairs
(e.g. listed futures settlement prices) rather than (date, rate) pairs,
and the lookup returns an interpolated price rather than a discount
factor.

Interpolation reuses the exact same factories from ``utils.interpolation``
as the scenario/Monte-Carlo forward curve used by
``instruments.commodity_forward.CommodityForward`` and
``instruments.commodity_digital_option.CommodityDigitalOption`` --
``forward_price_interpolator`` (linear between pillars, linear
right-extrapolation -- the market-standard convention for projecting a
futures strip beyond its last quoted contract) by default, or
``linear_interpolator`` (flat extrapolation) on request.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Callable, Sequence

import numpy as np

from utils.ql_helpers import DAY_COUNTERS, to_ql_date
from utils.interpolation import forward_price_interpolator, linear_interpolator


FORWARD_INTERPOLATORS: dict[str, Callable] = {
    "forward_price": forward_price_interpolator,  # linear, linear right-extrap
    "linear": linear_interpolator,                 # linear, flat extrap
}


@dataclass
class CommodityForwardCurve:
    """A single-path (base valuation) commodity forward price curve."""

    val_date: date
    curve_dates: list[date]
    year_fracs: np.ndarray
    prices: np.ndarray
    day_counter: object
    interpolation: str
    _interp: Callable = field(repr=False)

    def price_at(self, target_date: date) -> float:
        """Interpolated forward price for delivery on *target_date*."""
        t = float(self.day_counter.yearFraction(
            to_ql_date(self.val_date), to_ql_date(target_date),
        ))
        return float(self._interp(t)[0])

    def price_at_year_frac(self, t: float) -> float:
        """Interpolated forward price at year fraction *t* from val_date."""
        return float(self._interp(float(t))[0])


def build_commodity_forward_curve(
    val_date: date,
    curve_dates: Sequence[date],
    prices: Sequence[float],
    day_count: str = "ACT/365",
    interpolation: str | Callable = "forward_price",
) -> CommodityForwardCurve:
    """Build a single-path commodity forward price curve from dates and prices.

    Parameters
    ----------
    val_date : date
        Curve reference / valuation date (t0).
    curve_dates : sequence of date
        Pillar delivery/expiry dates (e.g. listed futures contract months),
        strictly increasing, each on or after *val_date*.
    prices : sequence of float
        Forward/futures price at each pillar (e.g. USD per barrel).
    day_count : str
        Key into ``utils.ql_helpers.DAY_COUNTERS`` used to convert pillar
        dates into year fractions from *val_date*.
    interpolation : str or callable
        ``"forward_price"`` (default, linear right-extrapolation -- the
        market-standard futures-strip convention) or ``"linear"`` (flat
        extrapolation), or a custom interpolator factory with signature
        ``(year_fracs, prices) -> callable``.

    Returns
    -------
    CommodityForwardCurve
    """
    curve_dates = list(curve_dates)
    price_arr = np.asarray(prices, dtype=np.float64)

    if len(curve_dates) != len(price_arr):
        raise ValueError(
            f"curve_dates ({len(curve_dates)}) and prices ({len(price_arr)}) "
            "must have the same length"
        )
    if not curve_dates:
        raise ValueError("curve_dates/prices must contain at least one pillar")
    if any(d < val_date for d in curve_dates):
        raise ValueError("all curve_dates must be on or after val_date")
    for prev, nxt in zip(curve_dates, curve_dates[1:]):
        if nxt <= prev:
            raise ValueError("curve_dates must be strictly increasing")

    if isinstance(interpolation, str):
        if interpolation not in FORWARD_INTERPOLATORS:
            raise ValueError(
                f"Unknown interpolation scheme {interpolation!r}; "
                f"choose from {sorted(FORWARD_INTERPOLATORS)} or pass a callable"
            )
        interp_name = interpolation
        interpolator_factory = FORWARD_INTERPOLATORS[interpolation]
    else:
        interp_name = getattr(interpolation, "__name__", "custom")
        interpolator_factory = interpolation

    day_counter = DAY_COUNTERS[day_count]
    ql_val = to_ql_date(val_date)
    year_fracs = np.array(
        [day_counter.yearFraction(ql_val, to_ql_date(d)) for d in curve_dates],
        dtype=np.float64,
    )

    interp = interpolator_factory(year_fracs, price_arr.reshape(1, -1))

    return CommodityForwardCurve(
        val_date=val_date,
        curve_dates=curve_dates,
        year_fracs=year_fracs,
        prices=price_arr,
        day_counter=day_counter,
        interpolation=interp_name,
        _interp=interp,
    )