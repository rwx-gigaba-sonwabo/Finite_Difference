"""
base_valuation/yield_curve.py
==============================
Date-based yield curve construction for base (t0) valuation.

Wraps ``market_data.yield_curve.YieldCurve`` -- the same discounting
engine used for scenario / Monte-Carlo pricing throughout this codebase
-- behind an interface that accepts raw pillar dates and zero rates
instead of pre-computed year fractions, so a curve can be built directly
from a market data quote sheet.

Interpolation schemes
----------------------
Any factory from ``utils.interpolation`` is available by name via
``INTERPOLATORS``, or pass a custom callable with the same
``(year_fracs, rates) -> callable(t)`` factory signature.
"""
from __future__ import annotations

from datetime import date
from typing import Callable, Sequence

import numpy as np

from market_data.yield_curve import YieldCurve
from utils.ql_helpers import DAY_COUNTERS, to_ql_date
from utils.interpolation import (
    hermite_rt_interp,
    linear_interpolator,
    linear_rt_interp,
    reciprocal_time_interp,
    stitched_linear_rt_hermite_rt_interp,
)


INTERPOLATORS: dict[str, Callable] = {
    "linear": linear_interpolator,
    "linear_rt": linear_rt_interp,
    "reciprocal_time": reciprocal_time_interp,
    "hermite_rt": hermite_rt_interp,
    "stitched_linear_hermite_rt": stitched_linear_rt_hermite_rt_interp,
}


def build_yield_curve(
    val_date: date,
    curve_dates: Sequence[date],
    rates: Sequence[float],
    day_count: str = "ACT/365",
    interpolation: str | Callable = "linear",
) -> YieldCurve:
    """Build a single-path (base valuation) YieldCurve from dates and rates.

    Parameters
    ----------
    val_date : date
        Curve reference / valuation date (t0). Pillar year fractions are
        measured from here.
    curve_dates : sequence of date
        Pillar dates, strictly increasing, each on or after *val_date*.
    rates : sequence of float
        Annualised zero rate at each pillar date, in the continuously
        compounded convention used by ``YieldCurve.discount_factor``
        (``DF(t) = exp(-r(t) * t)``).
    day_count : str
        Key into ``utils.ql_helpers.DAY_COUNTERS`` used to convert pillar
        dates into year fractions from *val_date* (``"ACT/365"``,
        ``"ACT/360"``, ``"30/360"``).
    interpolation : str or callable
        Either a key into ``INTERPOLATORS`` (``"linear"``, ``"linear_rt"``,
        ``"reciprocal_time"``, ``"hermite_rt"``,
        ``"stitched_linear_hermite_rt"``) or a custom interpolator factory
        with signature ``(year_fracs, rates) -> callable``.

    Returns
    -------
    YieldCurve
        Single-path (n_paths=1) curve ready for use with
        ``base_valuation.bond_pv.value_bond`` and other base-valuation
        pricing functions.
    """
    curve_dates = list(curve_dates)
    rate_arr = np.asarray(rates, dtype=np.float64)

    if len(curve_dates) != len(rate_arr):
        raise ValueError(
            f"curve_dates ({len(curve_dates)}) and rates ({len(rate_arr)}) "
            "must have the same length"
        )
    if not curve_dates:
        raise ValueError("curve_dates/rates must contain at least one pillar")
    if any(d < val_date for d in curve_dates):
        raise ValueError("all curve_dates must be on or after val_date")
    for prev, nxt in zip(curve_dates, curve_dates[1:]):
        if nxt <= prev:
            raise ValueError("curve_dates must be strictly increasing")

    if isinstance(interpolation, str):
        if interpolation not in INTERPOLATORS:
            raise ValueError(
                f"Unknown interpolation scheme {interpolation!r}; "
                f"choose from {sorted(INTERPOLATORS)} or pass a callable"
            )
        interpolator = INTERPOLATORS[interpolation]
    else:
        interpolator = interpolation

    day_counter = DAY_COUNTERS[day_count]
    ql_val = to_ql_date(val_date)
    year_fracs = np.array(
        [day_counter.yearFraction(ql_val, to_ql_date(d)) for d in curve_dates],
        dtype=np.float64,
    )

    return YieldCurve(
        year_fracs=year_fracs,
        rates=rate_arr.reshape(1, -1),
        interpolator=interpolator,
    )
