"""
base_valuation/commodity_digital_option.py
=============================================
Base (t0) valuation of a European commodity digital
(cash-or-nothing / asset-or-nothing) option.

Composes the reusable pricing primitives already in the codebase:

- ``base_valuation.commodity_curve.build_commodity_forward_curve``
  -- dates/prices -> a date-based forward price lookup
- ``base_valuation.yield_curve.build_yield_curve``
  -- dates/rates -> YieldCurve, for discounting
- ``models.commodity_digital_pv.black76_digital_price`` /
  ``black76_digital_analytic_greeks`` / ``skew_adjusted_digital_price`` /
  ``bump_and_reprice_greeks`` -- the same pricing engine
  ``instruments.commodity_digital_option.CommodityDigitalOption`` uses

No scenario-cube / Monte-Carlo machinery is involved here: everything
runs on a single deterministic curve (n_paths=1) valued at t0. Volatility
is a plain scalar ``float`` by default -- no ``ScalarSlice`` / market_state
boilerplate required, since a base valuation has exactly one scenario. A
``vol_skew`` (``BenchmarkVolSkew`` or the lighter-weight ``SimpleSkew``) may
be supplied instead, optionally combined with ``apply_skew_adjustment=True``
for skew-consistent (not just vol-at-strike) pricing.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

import numpy as np

from base_valuation.commodity_curve import CommodityForwardCurve
from market_data.yield_curve import YieldCurve
from models.commodity_digital_pv import (
    black76_digital_price as _black76_digital_price,
    black76_digital_analytic_greeks as _black76_digital_analytic_greeks,
    skew_adjusted_digital_price as _skew_adjusted_digital_price,
    bump_and_reprice_greeks as _bump_and_reprice_greeks,
)
from utils.ql_helpers import DAY_COUNTERS, advance_business_days, to_ql_date


@dataclass
class CommodityDigitalOptionValuation:
    """Result of a base-valuation commodity digital option pricing run."""

    val_date: date
    price: float
    forward: float                 # spot-day adjusted forward used
    vol: float                     # vol-at-strike (reporting only when skew-adjusted)
    T_opt: float                   # year_frac(val_date, maturity_date)
    T_disc: float                  # year_frac(val_date, settlement_date)
    df: float
    curve_lookup_date: date
    settlement_date: date
    skew_adjusted: bool
    # None when skew_adjusted=True -- no closed form to differentiate; use
    # bump_and_reprice_commodity_digital_option instead.
    analytic_delta: float | None
    analytic_gamma: float | None
    analytic_vega: float | None
    analytic_theta: float | None


def value_commodity_digital_option(
    val_date: date,
    maturity_date: date,
    strike: float,
    is_call: bool,
    digital_type: str,
    payout: float,
    forward_curve: CommodityForwardCurve,
    discount_curve: YieldCurve,
    vol: float | None = None,
    vol_skew=None,
    apply_skew_adjustment: bool = False,
    skew_strike_bump_frac: float = 1e-3,
    spot_days: int = 0,
    spot_calendar: str = "USD",
    settle_days: int = 2,
    settlement_calendar: str = "USD",
    day_count: str = "ACT/365",
) -> CommodityDigitalOptionValuation:
    """Price + Greeks for a European commodity digital at t0.

    Same three-date convention as
    ``instruments.commodity_digital_option.CommodityDigitalOption``:
    ``T_opt`` (vol scaling / d1,d2) is always
    ``year_frac(val_date, maturity_date)``; ``spot_days`` shifts only the
    forward-curve lookup date; ``settle_days`` shifts only the discounting
    date.

    Volatility sourcing: pass a flat scalar ``vol``, or a ``vol_skew``
    (``BenchmarkVolSkew`` or ``SimpleSkew``, read at ``strike``/``T_opt``),
    or both ``vol_skew`` and ``apply_skew_adjustment=True`` for skew-
    consistent pricing via tight call/put-spread replication -- see
    :func:`models.commodity_digital_pv.skew_adjusted_digital_price`. A
    digital's fair value is the strike-derivative of the vanilla price, so
    it is first-order sensitive to the *slope* of the smile at the strike,
    not just its level -- which is all a plain vol-at-strike lookup
    captures. Analytic Greeks are unavailable when skew-adjusted (the price
    is itself a numerical replication); use
    :func:`bump_and_reprice_commodity_digital_option`.

    Parameters
    ----------
    val_date : date
        Valuation date (t0).
    maturity_date : date
        Expiry date (event tested at expiry).
    strike : float
        Event trigger level K.
    is_call : bool
        True: event is S_T >= K. False: event is S_T <= K.
    digital_type : {"cash", "asset"}
    payout : float
        Fixed cash amount (cash-or-nothing) or notional/quantity multiplier
        (asset-or-nothing).
    forward_curve : CommodityForwardCurve
        From ``base_valuation.commodity_curve.build_commodity_forward_curve``.
    discount_curve : YieldCurve
        From ``base_valuation.yield_curve.build_yield_curve``, referenced
        to *val_date*.
    vol : float, optional
        Scalar Black implied volatility (e.g. 0.30 for 30%). Ignored if
        ``vol_skew`` is given.
    vol_skew : BenchmarkVolSkew or SimpleSkew, optional
        Volatility skew/smile, read at ``strike``/``T_opt``. Required when
        ``apply_skew_adjustment=True``.
    apply_skew_adjustment : bool
        ``False`` (default) -- flat vol or vol-at-strike lookup (unchanged
        behaviour). ``True`` -- tight call/put-spread replication using
        ``vol_skew``'s full local slope at the strike.
    skew_strike_bump_frac : float
        Relative strike bump for the replicating spread (default 0.1%).
    spot_days, spot_calendar : as in CommodityDigitalOption.
    settle_days, settlement_calendar : as in CommodityDigitalOption.
    day_count : str

    Returns
    -------
    CommodityDigitalOptionValuation
    """
    if digital_type not in ("cash", "asset"):
        raise ValueError(f"digital_type must be 'cash' or 'asset', got {digital_type!r}")
    if apply_skew_adjustment and vol_skew is None:
        raise ValueError(
            "apply_skew_adjustment=True requires vol_skew (BenchmarkVolSkew or "
            "SimpleSkew) -- flat scalar vol has no slope to adjust for."
        )
    if vol_skew is None and vol is None:
        raise ValueError("either vol or vol_skew must be given")

    dc = DAY_COUNTERS[day_count]

    curve_lookup_date = advance_business_days(maturity_date, spot_days, spot_calendar)
    settlement_date = advance_business_days(maturity_date, settle_days, settlement_calendar)

    T_opt = max(
        float(dc.yearFraction(to_ql_date(val_date), to_ql_date(maturity_date))), 0.0,
    )
    T_disc = float(dc.yearFraction(to_ql_date(val_date), to_ql_date(settlement_date)))

    F = forward_curve.price_at(curve_lookup_date)
    df = float(discount_curve.discount_factor(T_disc)[0])

    F_arr = np.array([F])
    df_arr = np.array([df])

    if vol_skew is not None:
        vol_at_strike = float(vol_skew.get_vol(strike=strike, tenor=max(T_opt, 1e-8)))
    else:
        vol_at_strike = float(vol)

    if apply_skew_adjustment:
        vol_fn = lambda k: vol_skew.get_vol(strike=k, tenor=max(T_opt, 1e-8))  # noqa: E731
        price = float(_skew_adjusted_digital_price(
            F_arr, strike, vol_fn, df_arr, T_opt, is_call, digital_type,
            payout, skew_strike_bump_frac,
        )[0])
        deltas = (None, None, None, None)
    else:
        vol_arr = np.array([vol_at_strike])
        price = float(_black76_digital_price(
            F_arr, strike, vol_arr, df_arr, T_opt, is_call, digital_type, payout,
        )[0])
        greeks = _black76_digital_analytic_greeks(
            F_arr, strike, vol_arr, df_arr, T_opt, is_call, digital_type, payout,
        )
        deltas = (
            float(greeks["delta"][0]), float(greeks["gamma"][0]),
            float(greeks["vega"][0]), float(greeks["theta"][0]),
        )

    return CommodityDigitalOptionValuation(
        val_date=val_date,
        price=price,
        forward=F,
        vol=vol_at_strike,
        T_opt=T_opt,
        T_disc=T_disc,
        df=df,
        curve_lookup_date=curve_lookup_date,
        settlement_date=settlement_date,
        skew_adjusted=apply_skew_adjustment,
        analytic_delta=deltas[0],
        analytic_gamma=deltas[1],
        analytic_vega=deltas[2],
        analytic_theta=deltas[3],
    )


def bump_and_reprice_commodity_digital_option(
    val_date: date,
    maturity_date: date,
    strike: float,
    is_call: bool,
    digital_type: str,
    payout: float,
    forward_curve: CommodityForwardCurve,
    discount_curve: YieldCurve,
    vol: float | None = None,
    vol_skew=None,
    apply_skew_adjustment: bool = False,
    skew_strike_bump_frac: float = 1e-3,
    spot_days: int = 0,
    spot_calendar: str = "USD",
    settle_days: int = 2,
    settlement_calendar: str = "USD",
    day_count: str = "ACT/365",
    rel_bump_forward: float = 1e-4,
    abs_bump_vol: float = 1e-4,
    days_bump_theta: int = 1,
) -> dict[str, float]:
    """Numerical Delta/Gamma/Vega/Theta via central-difference bump-and-reprice
    -- the independent cross-check against :func:`value_commodity_digital_option`'s
    analytic Greeks (same prudency pattern as the scenario-engine instrument),
    and the *only* Greeks route when ``apply_skew_adjustment=True``.

    With ``apply_skew_adjustment=True``, Vega bumps the whole skew in
    parallel (every strike's vol shifted by the same amount) rather than a
    single flat number.
    """
    if apply_skew_adjustment and vol_skew is None:
        raise ValueError(
            "apply_skew_adjustment=True requires vol_skew (BenchmarkVolSkew or "
            "SimpleSkew) -- flat scalar vol has no slope to adjust for."
        )
    if vol_skew is None and vol is None:
        raise ValueError("either vol or vol_skew must be given")

    dc = DAY_COUNTERS[day_count]
    settlement_date = advance_business_days(maturity_date, settle_days, settlement_calendar)
    T_opt = max(
        float(dc.yearFraction(to_ql_date(val_date), to_ql_date(maturity_date))), 0.0,
    )

    if vol_skew is not None:
        vol0_scalar = float(vol_skew.get_vol(strike=strike, tenor=max(T_opt, 1e-8)))
    else:
        vol0_scalar = float(vol)

    def price_fn(F_b: np.ndarray, vol_b: np.ndarray, val_date_override: date | None):
        vd = val_date_override or val_date
        curve_lookup_date = advance_business_days(maturity_date, spot_days, spot_calendar)
        T_opt_b = max(
            float(dc.yearFraction(to_ql_date(vd), to_ql_date(maturity_date))), 0.0,
        )
        T_disc_b = float(dc.yearFraction(to_ql_date(vd), to_ql_date(settlement_date)))
        df_b = np.array([float(discount_curve.discount_factor(T_disc_b)[0])])

        if val_date_override is not None:
            F_use = np.array([forward_curve.price_at(curve_lookup_date)])
            vol_use = vol_b
        else:
            F_use, vol_use = F_b, vol_b

        if apply_skew_adjustment:
            shift = vol_use - np.array([vol0_scalar])  # 0, +h, or -h
            vol_fn = lambda k, s=shift: vol_skew.get_vol(strike=k, tenor=max(T_opt_b, 1e-8)) + s  # noqa: E731
            return _skew_adjusted_digital_price(
                F_use, strike, vol_fn, df_b, T_opt_b, is_call, digital_type,
                payout, skew_strike_bump_frac,
            )
        return _black76_digital_price(
            F_use, strike, vol_use, df_b, T_opt_b, is_call, digital_type, payout,
        )

    curve_lookup_date = advance_business_days(maturity_date, spot_days, spot_calendar)
    F0 = np.array([forward_curve.price_at(curve_lookup_date)])
    vol0 = np.array([vol0_scalar])

    g = _bump_and_reprice_greeks(
        price_fn, F0, vol0, val_date, rel_bump_forward, abs_bump_vol, days_bump_theta,
    )
    return {k: float(v[0]) for k, v in g.items()}
