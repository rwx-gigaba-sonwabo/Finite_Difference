"""
base_valuation/commodity_digital_barrier_option.py
======================================================
Base (t0) valuation of a commodity digital barrier option (One-Touch /
No-Touch, single or double barrier, continuously or discretely monitored).

Composes the reusable pricing primitives already in the codebase:

- ``base_valuation.commodity_curve.build_commodity_forward_curve``
- ``base_valuation.yield_curve.build_yield_curve``
- ``models.commodity_digital_pv.commodity_barrier_digital_price`` /
  ``commodity_barrier_digital_analytic_greeks`` / ``mc_digital_barrier_pv`` /
  ``implied_cost_of_carry`` / ``bump_and_reprice_greeks`` -- the same
  pricing engine ``instruments.commodity_digital_barrier_option.
  CommodityDigitalBarrierOption`` uses.

No scenario-cube / Monte-Carlo *exposure* machinery is involved here:
this is a single deterministic valuation at t0 (n_paths=1), not a path in
a simulated exposure profile. Consequently there is no "barrier already
touched on an earlier scenario date" state to track (that concept only
exists once a trade is running inside ``ExposureEngine`` across many
future simulation dates) -- the barrier window priced here is always
``[val_date, maturity_date]``. For the full exposure/CVA use case with
path-continuity across simulation dates, use
``instruments.commodity_digital_barrier_option.CommodityDigitalBarrierOption``.

Volatility is a plain scalar ``float`` by default -- no ``ScalarSlice`` /
market_state boilerplate required, since a base valuation has exactly one
scenario. A ``vol_skew`` (``BenchmarkVolSkew`` or the lighter-weight
``SimpleSkew``) may be supplied instead, optionally combined with
``apply_skew_adjustment=True`` for skew-consistent local-vol Monte Carlo
pricing (see :func:`value_commodity_digital_barrier_option`'s docstring).
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass
from datetime import date

import numpy as np

from base_valuation.commodity_curve import CommodityForwardCurve
from market_data.yield_curve import YieldCurve
from models.commodity_digital_pv import (
    commodity_barrier_digital_price as _commodity_barrier_digital_price,
    commodity_barrier_digital_analytic_greeks as _commodity_barrier_digital_analytic_greeks,
    mc_digital_barrier_pv as _mc_digital_barrier_pv,
    implied_cost_of_carry as _implied_cost_of_carry,
    bump_and_reprice_greeks as _bump_and_reprice_greeks,
)
from utils.ql_helpers import (
    DAY_COUNTERS,
    advance_business_days,
    generate_business_days,
    to_ql_date,
)


@dataclass
class CommodityDigitalBarrierValuation:
    """Result of a base-valuation commodity digital barrier pricing run."""

    val_date: date
    price: float
    pricing_method: str            # "closed_form" or "monte_carlo"
    forward: float                 # spot-day adjusted forward used
    implied_spot: float            # S0 = F * exp(-b * T_opt)
    cost_of_carry: float
    vol: float
    T_opt: float
    T_disc: float
    df: float
    curve_lookup_date: date
    settlement_date: date
    skew_adjusted: bool = False
    analytic_delta: float | None = None
    analytic_vega: float | None = None
    analytic_theta: float | None = None
    mc_stderr: float | None = None


def _resolve_cost_of_carry(
    forward_curve: CommodityForwardCurve,
    F: float,
    T_opt: float,
    cost_of_carry: float | None,
    carry_curve: YieldCurve | None,
) -> float:
    """Precedence: explicit scalar > carry curve > curve-implied fallback."""
    if cost_of_carry is not None:
        return float(cost_of_carry)
    if carry_curve is not None:
        return float(carry_curve.get_rate(max(T_opt, 1e-8))[0])
    near_T = float(forward_curve.year_fracs[0])
    near_F = np.array([forward_curve.prices[0]])
    b = _implied_cost_of_carry(near_T, near_F, max(T_opt, 1e-8), np.array([F]))
    return float(b[0])


def value_commodity_digital_barrier_option(
    val_date: date,
    maturity_date: date,
    upper_barrier: float | None,
    lower_barrier: float | None,
    touch: str,
    digital_type: str,
    payout: float,
    forward_curve: CommodityForwardCurve,
    discount_curve: YieldCurve,
    vol: float | None = None,
    vol_skew=None,
    apply_skew_adjustment: bool = False,
    monitoring: str = "continuous",
    monitoring_calendar: str = "USD",
    cost_of_carry: float | None = None,
    carry_curve: YieldCurve | None = None,
    spot_days: int = 0,
    spot_calendar: str = "USD",
    settle_days: int = 2,
    settlement_calendar: str = "USD",
    day_count: str = "ACT/365",
    n_mc_paths: int = 20_000,
    mc_seed: int = 0,
) -> CommodityDigitalBarrierValuation:
    """Price + Greeks for a commodity digital barrier option at t0.

    Same conventions as ``CommodityDigitalBarrierOption``: continuous +
    single barrier + cash-or-nothing uses the closed-form first-passage
    formula (with closed-form Delta/Vega/Theta); discrete monitoring,
    double barriers, asset-or-nothing payoffs, or skew adjustment have no
    closed form (per the source document's own allowance for the first two)
    and fall back to Monte Carlo, simulated over ``[val_date, maturity_date]``
    with ``n_mc_paths`` draws.

    Cost of carry ``b`` (drives the implied spot ``S0 = F*exp(-b*T)`` used
    by the barrier diffusion) is sourced with precedence: explicit scalar
    ``cost_of_carry`` > ``carry_curve`` > curve-implied from
    ``forward_curve``'s own nearest pillar vs the maturity pillar.

    **Skew adjustment** (``apply_skew_adjustment=True``): there is no
    call-spread-style static replication for a barrier (the closed form is
    driven by barrier *level*, not a strike to bump), so skew-consistent
    barrier pricing instead diffuses with a **level-dependent local vol**
    read off ``vol_skew`` at each simulated step's current price -- see
    :func:`models.commodity_digital_pv.mc_digital_barrier_pv`'s ``vol_fn``
    parameter for the precise "sticky-strike" caveat versus a rigorously
    calibrated Dupire local-vol surface. Requires ``vol_skew``. Analytic
    Greeks are unavailable in this mode; use
    :func:`bump_and_reprice_commodity_digital_barrier_option`.

    Parameters
    ----------
    val_date, maturity_date : date
    upper_barrier, lower_barrier : float or None
        At least one must be given.
    touch : {"in", "out"}
    digital_type : {"cash", "asset"}
    payout : float
    forward_curve : CommodityForwardCurve
    discount_curve : YieldCurve
    vol : float, optional
        Scalar Black implied volatility. Ignored if ``vol_skew`` is given.
    vol_skew : BenchmarkVolSkew or SimpleSkew, optional
        Volatility skew/smile, read at the barrier level / ``T_opt``.
        Required when ``apply_skew_adjustment=True``.
    apply_skew_adjustment : bool
        ``False`` (default) -- flat vol or vol-at-barrier lookup (unchanged
        behaviour). ``True`` -- skew-consistent local-vol Monte Carlo (see
        above). Requires ``vol_skew``.
    monitoring : {"continuous", "discrete"}
    monitoring_calendar : str
        Calendar for the discrete-monitoring date grid (only used when
        ``monitoring == "discrete"``; generated from ``val_date`` to
        ``maturity_date``).
    cost_of_carry, carry_curve : optional overrides (see precedence above).
    spot_days, spot_calendar, settle_days, settlement_calendar : as in
        CommodityDigitalBarrierOption.
    n_mc_paths : int
        Total Monte Carlo sample size (this is a standalone valuation, not
        a nested simulation -- unlike the scenario-engine instrument there
        is no outer-path multiplier, so this can be set much larger).
    mc_seed : int

    Returns
    -------
    CommodityDigitalBarrierValuation
    """
    if upper_barrier is None and lower_barrier is None:
        raise ValueError("At least one of upper_barrier/lower_barrier must be given.")
    if touch not in ("in", "out"):
        raise ValueError(f"touch must be 'in' or 'out', got {touch!r}")
    if digital_type not in ("cash", "asset"):
        raise ValueError(f"digital_type must be 'cash' or 'asset', got {digital_type!r}")
    if monitoring not in ("continuous", "discrete"):
        raise ValueError(f"monitoring must be 'continuous' or 'discrete', got {monitoring!r}")
    if apply_skew_adjustment and vol_skew is None:
        raise ValueError(
            "apply_skew_adjustment=True requires vol_skew (BenchmarkVolSkew or "
            "SimpleSkew) -- flat scalar vol has no skew to diffuse with."
        )
    if vol_skew is None and vol is None:
        raise ValueError("either vol or vol_skew must be given")

    dc = DAY_COUNTERS[day_count]
    double_barrier = upper_barrier is not None and lower_barrier is not None
    requires_mc = (
        monitoring == "discrete" or double_barrier or digital_type == "asset"
        or apply_skew_adjustment
    )
    if monitoring == "continuous" and (double_barrier or digital_type == "asset" or apply_skew_adjustment):
        reason = (
            "double barrier" if double_barrier
            else "asset-or-nothing" if digital_type == "asset"
            else "skew adjustment"
        )
        warnings.warn(
            f"continuous monitoring requested but no closed form is available for "
            f"{reason} digitals -- falling back to Monte Carlo "
            "(document-sanctioned exception).",
            stacklevel=2,
        )

    curve_lookup_date = advance_business_days(maturity_date, spot_days, spot_calendar)
    settlement_date = advance_business_days(maturity_date, settle_days, settlement_calendar)

    T_opt = max(
        float(dc.yearFraction(to_ql_date(val_date), to_ql_date(maturity_date))), 0.0,
    )
    T_disc = float(dc.yearFraction(to_ql_date(val_date), to_ql_date(settlement_date)))

    F = forward_curve.price_at(curve_lookup_date)
    df = float(discount_curve.discount_factor(T_disc)[0])
    b = _resolve_cost_of_carry(forward_curve, F, T_opt, cost_of_carry, carry_curve)
    S0 = F * np.exp(-b * T_opt)

    H_for_vol = upper_barrier if upper_barrier is not None else lower_barrier
    if vol_skew is not None:
        vol_at_barrier = float(vol_skew.get_vol(strike=H_for_vol, tenor=max(T_opt, 1e-8)))
    else:
        vol_at_barrier = float(vol)

    F_arr = np.array([F])
    vol_arr = np.array([vol_at_barrier])
    b_arr = np.array([b])
    df_arr = np.array([df])

    if T_opt <= 0.0:
        hit = (F_arr >= upper_barrier) if upper_barrier is not None else np.zeros(1, dtype=bool)
        if lower_barrier is not None:
            hit |= (F_arr <= lower_barrier)
        outcome = hit if touch == "in" else ~hit
        payoff = payout * (F_arr if digital_type == "asset" else 1.0)
        price = float((df_arr * np.where(outcome, payoff, 0.0))[0])
        return CommodityDigitalBarrierValuation(
            val_date=val_date, price=price, pricing_method="intrinsic",
            forward=F, implied_spot=float(S0), cost_of_carry=b, vol=vol_at_barrier,
            T_opt=T_opt, T_disc=T_disc, df=df,
            curve_lookup_date=curve_lookup_date, settlement_date=settlement_date,
            skew_adjusted=apply_skew_adjustment,
        )

    if requires_mc:
        vol_fn = None
        if apply_skew_adjustment:
            t = max(T_opt, 1e-8)
            vol_fn = lambda level: vol_skew.get_vol(strike=level, tenor=t)  # noqa: E731

        rng = np.random.default_rng(mc_seed)
        if monitoring == "discrete":
            monitoring_dates = generate_business_days(val_date, maturity_date, monitoring_calendar)
            monitoring_dates = [d for d in monitoring_dates if d > val_date] or [maturity_date]
        else:
            monitoring_dates = [maturity_date]
        monitoring_t = np.array([
            float(dc.yearFraction(to_ql_date(val_date), to_ql_date(d)))
            for d in monitoring_dates
        ])
        monitoring_t = monitoring_t[monitoring_t > 0.0]
        if monitoring_t.size == 0:
            monitoring_t = np.array([T_opt])

        pv = _mc_digital_barrier_pv(
            F0=F_arr, sigma=vol_arr, b=b_arr, T=T_opt, monitoring_t=monitoring_t,
            upper_barrier=upper_barrier, lower_barrier=lower_barrier,
            touch=touch, digital_type=digital_type, payout=payout, df=df_arr,
            rng=rng, n_inner=n_mc_paths, vol_fn=vol_fn,
        )
        price = float(pv[0])

        # Rough Monte Carlo standard error on the mean, for reporting: use
        # a second independent batch to estimate per-draw dispersion cheaply
        # (avoids threading raw per-draw payoffs back out of the vectorised
        # engine, which averages internally by design).
        rng2 = np.random.default_rng(mc_seed + 1)
        pv2 = _mc_digital_barrier_pv(
            F0=F_arr, sigma=vol_arr, b=b_arr, T=T_opt, monitoring_t=monitoring_t,
            upper_barrier=upper_barrier, lower_barrier=lower_barrier,
            touch=touch, digital_type=digital_type, payout=payout, df=df_arr,
            rng=rng2, n_inner=n_mc_paths, vol_fn=vol_fn,
        )
        mc_stderr = float(abs(pv[0] - pv2[0]) / np.sqrt(2.0))

        return CommodityDigitalBarrierValuation(
            val_date=val_date, price=price, pricing_method="monte_carlo",
            forward=F, implied_spot=float(S0), cost_of_carry=b, vol=vol_at_barrier,
            T_opt=T_opt, T_disc=T_disc, df=df,
            curve_lookup_date=curve_lookup_date, settlement_date=settlement_date,
            skew_adjusted=apply_skew_adjustment, mc_stderr=mc_stderr,
        )

    direction = "up" if upper_barrier is not None else "down"
    H = upper_barrier if upper_barrier is not None else lower_barrier
    price = float(_commodity_barrier_digital_price(
        F_arr, H, vol_arr, b_arr, df_arr, T_opt, direction, touch, payout,
    )[0])
    greeks = _commodity_barrier_digital_analytic_greeks(
        F_arr, H, vol_arr, b_arr, df_arr, T_opt, direction, touch, payout,
    )

    return CommodityDigitalBarrierValuation(
        val_date=val_date, price=price, pricing_method="closed_form",
        forward=F, implied_spot=float(S0), cost_of_carry=b, vol=vol_at_barrier,
        T_opt=T_opt, T_disc=T_disc, df=df,
        curve_lookup_date=curve_lookup_date, settlement_date=settlement_date,
        skew_adjusted=False,
        analytic_delta=float(greeks["delta"][0]),
        analytic_vega=float(greeks["vega"][0]),
        analytic_theta=float(greeks["theta"][0]),
    )


def bump_and_reprice_commodity_digital_barrier_option(
    val_date: date,
    maturity_date: date,
    upper_barrier: float | None,
    lower_barrier: float | None,
    touch: str,
    digital_type: str,
    payout: float,
    forward_curve: CommodityForwardCurve,
    discount_curve: YieldCurve,
    vol: float | None = None,
    vol_skew=None,
    apply_skew_adjustment: bool = False,
    monitoring: str = "continuous",
    monitoring_calendar: str = "USD",
    cost_of_carry: float | None = None,
    carry_curve: YieldCurve | None = None,
    spot_days: int = 0,
    spot_calendar: str = "USD",
    settle_days: int = 2,
    settlement_calendar: str = "USD",
    day_count: str = "ACT/365",
    n_mc_paths: int = 20_000,
    mc_seed: int = 0,
    rel_bump_forward: float = 1e-4,
    abs_bump_vol: float = 1e-4,
    days_bump_theta: int = 1,
) -> dict[str, float]:
    """Numerical Delta/Gamma/Vega/Theta via central-difference bump-and-reprice
    -- works for every configuration (continuous/discrete, single/double
    barrier, cash/asset, skew-adjusted), unlike the closed-form Greeks.
    Common random numbers (``mc_seed`` reseeded fresh per re-pricing) keep
    MC-based finite differences from being swamped by simulation noise.
    With ``apply_skew_adjustment=True``, Vega bumps the whole skew in
    parallel rather than a single flat number.

    The Delta/Gamma/Vega bumps hold ``b``, ``df`` and ``T_opt`` fixed at
    their base-case values and re-price directly off the bumped forward/vol
    (mirrors ``CommodityDigitalBarrierOption.greeks_bump_and_reprice``) --
    this isolates the F/vol sensitivity cleanly rather than letting a
    curve-implied cost-of-carry silently re-derive from the bumped forward.
    The Theta bump instead calls :func:`value_commodity_digital_barrier_option`
    fresh at ``val_date + 1 day``, so it *does* pick up full curve roll
    (including a curve-implied ``b``, if used) -- the "full P&L theta"
    counterpart to the closed-form "model theta".
    """
    if apply_skew_adjustment and vol_skew is None:
        raise ValueError(
            "apply_skew_adjustment=True requires vol_skew (BenchmarkVolSkew or "
            "SimpleSkew) -- flat scalar vol has no skew to diffuse with."
        )
    if vol_skew is None and vol is None:
        raise ValueError("either vol or vol_skew must be given")

    dc = DAY_COUNTERS[day_count]
    double_barrier = upper_barrier is not None and lower_barrier is not None
    requires_mc = (
        monitoring == "discrete" or double_barrier or digital_type == "asset"
        or apply_skew_adjustment
    )

    curve_lookup_date = advance_business_days(maturity_date, spot_days, spot_calendar)
    settlement_date = advance_business_days(maturity_date, settle_days, settlement_calendar)
    T_opt = max(
        float(dc.yearFraction(to_ql_date(val_date), to_ql_date(maturity_date))), 0.0,
    )
    T_disc = float(dc.yearFraction(to_ql_date(val_date), to_ql_date(settlement_date)))
    F0 = np.array([forward_curve.price_at(curve_lookup_date)])
    H_for_vol = upper_barrier if upper_barrier is not None else lower_barrier
    if vol_skew is not None:
        vol0_scalar = float(vol_skew.get_vol(strike=H_for_vol, tenor=max(T_opt, 1e-8)))
    else:
        vol0_scalar = float(vol)
    vol0 = np.array([vol0_scalar])
    df0 = np.array([float(discount_curve.discount_factor(T_disc)[0])])
    b0 = np.array([_resolve_cost_of_carry(forward_curve, F0[0], T_opt, cost_of_carry, carry_curve)])

    if requires_mc:
        if monitoring == "discrete":
            monitoring_dates = generate_business_days(val_date, maturity_date, monitoring_calendar)
            monitoring_dates = [d for d in monitoring_dates if d > val_date] or [maturity_date]
        else:
            monitoring_dates = [maturity_date]
        monitoring_t = np.array([
            float(dc.yearFraction(to_ql_date(val_date), to_ql_date(d)))
            for d in monitoring_dates
        ])
        monitoring_t = monitoring_t[monitoring_t > 0.0]
        if monitoring_t.size == 0:
            monitoring_t = np.array([T_opt])

    def price_fn(F_b: np.ndarray, vol_b: np.ndarray, val_date_override: date | None):
        if val_date_override is not None:
            result = value_commodity_digital_barrier_option(
                val_date=val_date_override, maturity_date=maturity_date,
                upper_barrier=upper_barrier, lower_barrier=lower_barrier,
                touch=touch, digital_type=digital_type, payout=payout,
                forward_curve=forward_curve, discount_curve=discount_curve,
                vol=vol, vol_skew=vol_skew, apply_skew_adjustment=apply_skew_adjustment,
                monitoring=monitoring, monitoring_calendar=monitoring_calendar,
                cost_of_carry=cost_of_carry, carry_curve=carry_curve,
                spot_days=spot_days, spot_calendar=spot_calendar,
                settle_days=settle_days, settlement_calendar=settlement_calendar,
                day_count=day_count, n_mc_paths=n_mc_paths, mc_seed=mc_seed,
            )
            return np.array([result.price])

        if T_opt <= 0.0:
            hit = (F_b >= upper_barrier) if upper_barrier is not None else np.zeros(1, dtype=bool)
            if lower_barrier is not None:
                hit |= (F_b <= lower_barrier)
            outcome = hit if touch == "in" else ~hit
            payoff = payout * (F_b if digital_type == "asset" else 1.0)
            return df0 * np.where(outcome, payoff, 0.0)

        if requires_mc:
            rng = np.random.default_rng(mc_seed)
            vol_fn = None
            if apply_skew_adjustment:
                shift = vol_b - vol0  # 0, +h, or -h
                t = max(T_opt, 1e-8)
                vol_fn = lambda level, s=shift: vol_skew.get_vol(strike=level, tenor=t) + s  # noqa: E731
            return _mc_digital_barrier_pv(
                F0=F_b, sigma=vol_b, b=b0, T=T_opt, monitoring_t=monitoring_t,
                upper_barrier=upper_barrier, lower_barrier=lower_barrier,
                touch=touch, digital_type=digital_type, payout=payout,
                df=df0, rng=rng, n_inner=n_mc_paths, vol_fn=vol_fn,
            )

        direction = "up" if upper_barrier is not None else "down"
        H = upper_barrier if upper_barrier is not None else lower_barrier
        return _commodity_barrier_digital_price(
            F_b, H, vol_b, b0, df0, T_opt, direction, touch, payout,
        )

    g = _bump_and_reprice_greeks(
        price_fn, F0, vol0, val_date, rel_bump_forward, abs_bump_vol, days_bump_theta,
    )
    return {k: float(v[0]) for k, v in g.items()}