"""Base (t0) valuation utilities: yield curves, bond schedules, bond PV.

Deterministic single-curve pricing built on top of the same primitives
used elsewhere in the codebase for scenario / Monte-Carlo XVA pricing
(``market_data.yield_curve.YieldCurve``, ``models.bond_pv``,
``instruments.components.schedule_config.ScheduleConfig``), so results
are consistent with the CVA engine's instrument pricers.
"""
