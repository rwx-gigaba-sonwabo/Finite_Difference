"""
base_valuation/bond_pv.py
============================
Base (t0) valuation of a fixed-coupon bond.

Composes the reusable pricing primitives already in the codebase:

- ``base_valuation.yield_curve.build_yield_curve``  -- dates/rates -> YieldCurve
- ``base_valuation.schedule.build_bond_schedule``    -- coupon schedule
- ``models.bond_pv.bond_pv`` / ``accrued_interest``  -- discounting engine
  (the same functions ``instruments.bond_forward.BondForward`` uses)

No scenario-cube / Monte-Carlo machinery is involved here: everything
runs on a single deterministic curve (n_paths=1) valued at t0.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from market_data.yield_curve import YieldCurve
from models.bond_pv import accrued_interest as _accrued_interest
from models.bond_pv import bond_pv as _bond_pv
from base_valuation.schedule import BondSchedule


@dataclass
class BondValuation:
    """Result of a base-valuation bond pricing run."""

    val_date: date
    dirty_price: float             # absolute currency
    accrued_interest: float        # absolute currency
    clean_price: float             # absolute currency
    dirty_price_per_100: float
    accrued_interest_per_100: float
    clean_price_per_100: float


def value_bond(
    schedule: BondSchedule,
    coupon_rate: float,
    notional: float,
    val_date: date,
    discount_curve: YieldCurve,
    ex_coupon_days: int = 0,
    compounding: bool = False,
) -> BondValuation:
    """Dirty price, accrued interest and clean price of a fixed-coupon bond at t0.

    Parameters
    ----------
    schedule : BondSchedule
        Coupon schedule from ``base_valuation.schedule.build_bond_schedule``.
    coupon_rate : float
        Annual coupon rate (e.g. 0.08 for 8%).
    notional : float
        Face value.
    val_date : date
        Valuation date (t0).
    discount_curve : YieldCurve
        Curve from ``base_valuation.yield_curve.build_yield_curve``,
        referenced to *val_date*.
    ex_coupon_days : int
        BESA book-close window in business days (0 = no CUMEX, i.e. always
        cum-coupon).
    compounding : bool
        True for compounding (no periodic coupon payout) bonds -- see
        ``models.bond_pv.bond_pv`` for the accumulation formula. False
        (default) for standard periodic-coupon bonds.

    Returns
    -------
    BondValuation
    """
    dirty = float(
        _bond_pv(
            schedule.periods,
            coupon_rate,
            notional,
            val_date,
            discount_curve,
            schedule.curve_day_counter,
            compounding=compounding,
        )[0]
    )

    ai_frac = _accrued_interest(
        schedule.periods,
        coupon_rate,
        val_date,
        schedule.day_counter,
        ex_coupon_days=ex_coupon_days,
        calendar=schedule.calendar,
    )
    ai = ai_frac * notional
    clean = dirty - ai

    return BondValuation(
        val_date=val_date,
        dirty_price=dirty,
        accrued_interest=ai,
        clean_price=clean,
        dirty_price_per_100=dirty / notional * 100.0,
        accrued_interest_per_100=ai / notional * 100.0,
        clean_price_per_100=clean / notional * 100.0,
    )
