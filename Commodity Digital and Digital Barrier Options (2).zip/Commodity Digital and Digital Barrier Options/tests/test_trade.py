import pytest
import numpy as np
from unittest.mock import MagicMock

from portfolio.trade import Trade
from instruments.instrument import Instrument


def make_instrument(npv_value: float = 100.0) -> Instrument:
    """Return a mock instrument that returns a constant NPV across all paths."""
    inst = MagicMock(spec=Instrument)
    inst.name = "mock_instrument"
    inst.scenario_npvs.return_value = np.full(10, npv_value)
    return inst


class TestTradeConstruction:
    def test_basic_construction(self):
        inst = make_instrument()
        t = Trade(trade_id="T1", counterparty_id="CPTY_A", instrument=inst)
        assert t.trade_id == "T1"
        assert t.counterparty_id == "CPTY_A"
        assert t.instrument is inst
        assert t.notional_scale == 1.0
        assert t.metadata == {}

    def test_custom_notional_scale(self):
        inst = make_instrument()
        t = Trade(trade_id="T2", counterparty_id="CPTY_A", instrument=inst, notional_scale=-1.0)
        assert t.notional_scale == -1.0

    def test_metadata_stored(self):
        inst = make_instrument()
        t = Trade(
            trade_id="T3",
            counterparty_id="CPTY_A",
            instrument=inst,
            metadata={"booking_entity": "ZAR_DESK", "trade_date": "2025-01-01"},
        )
        assert t.metadata["booking_entity"] == "ZAR_DESK"

    def test_zero_notional_scale_raises(self):
        inst = make_instrument()
        with pytest.raises(ValueError, match="notional_scale cannot be zero"):
            Trade(trade_id="T4", counterparty_id="CPTY_A", instrument=inst, notional_scale=0.0)

    def test_metadata_defaults_to_empty_dict(self):
        inst = make_instrument()
        t1 = Trade(trade_id="T5", counterparty_id="CPTY_A", instrument=inst)
        t2 = Trade(trade_id="T6", counterparty_id="CPTY_A", instrument=inst)
        # each instance must have its own dict, not a shared default
        t1.metadata["key"] = "value"
        assert "key" not in t2.metadata

    def test_instrument_reference_preserved(self):
        inst = make_instrument(npv_value=42.0)
        t = Trade(trade_id="T7", counterparty_id="CPTY_B", instrument=inst)
        result = t.instrument.scenario_npvs(None, {})
        np.testing.assert_array_equal(result, np.full(10, 42.0))
