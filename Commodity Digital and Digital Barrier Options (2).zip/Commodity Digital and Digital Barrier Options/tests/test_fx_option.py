"""Tests for instruments/fx_option.py — FXOption (Garman-Kohlhagen / Black-76).

The FX forward uses basis-adjusted CIP:
    F = S * (df_for * df_for_basis) / (df_dom * df_dom_basis)

With dom_basis_rate = 0 (no basis spread), df_dom_basis = 1 and the
formula reduces to standard CIP: F = S * df_for / df_dom.
"""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import numpy.testing as npt

from instruments.fx_option import FXOption
from market_data.risk_factor import CurveSlice, ScalarSlice
from utils.interpolation import linear_interpolator


# ---------------------------------------------------------------------------
# Constants  (ZAR/USD illustrative — domestic=ZAR, foreign=USD)
# ---------------------------------------------------------------------------

N_PATHS = 8
VAL_DATE = date(2025, 1, 2)
EXPIRY = date(2026, 1, 2)       # 365 days → T = 1.0 ACT/365
POST_EXPIRY = date(2026, 1, 3)  # first date where val_date > expiry

FX_SPOT = 18.50                 # ZAR per USD
DOM_RATE = 0.08                 # ZAR discount rate
DOM_BASIS_RATE = 0.00           # no basis spread → standard CIP
FOR_RATE = 0.05                 # USD discount rate
VOL = 0.15
STRIKE = 19.00                  # OTM call / ITM put
NOMINAL = 1_000_000.0           # 1M USD notional

TENORS = np.array([0.08, 0.25, 0.5, 1.0, 2.0, 3.0, 5.0], dtype=np.float64)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flat_curve(rate: float) -> CurveSlice:
    return CurveSlice(
        values=np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64),
        tenors=TENORS,
    )


def flat_spot(price: float = FX_SPOT) -> ScalarSlice:
    return ScalarSlice(values=np.full(N_PATHS, price, dtype=np.float64))


def flat_vol(vol: float = VOL) -> ScalarSlice:
    return ScalarSlice(values=np.full(N_PATHS, vol, dtype=np.float64))


def base_market_state(
    spot: float = FX_SPOT,
    dom: float = DOM_RATE,
    dom_basis: float = DOM_BASIS_RATE,
    for_: float = FOR_RATE,
    vol: float = VOL,
) -> dict:
    return {
        "FX_SPOT":   flat_spot(spot),
        "DOM_BASIS": flat_curve(dom_basis),
        "DOM":       flat_curve(dom),
        "FOR":       flat_curve(for_),
        "VOL":       flat_vol(vol),
    }


def make_option(
    strike: float = STRIKE,
    is_call: bool = True,
    nominal: float = NOMINAL,
) -> FXOption:
    return FXOption(
        name="FX_OPT",
        expiry_date=EXPIRY,
        strike=strike,
        is_call=is_call,
        nominal=nominal,
        domestic_basis="DOM_BASIS",
        domestic_curve="DOM",
        domestic_interpolator=linear_interpolator,
        domestic_basis_interpolator=linear_interpolator,
        foreign_curve="FOR",
        foreign_interpolator=linear_interpolator,
        fx_spot_name="FX_SPOT",
        vol_name="VOL",
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestFXOptionBasic:

    def test_post_expiry_returns_zeros(self):
        # FXOption uses val_date > expiry_date, so expiry date itself is live.
        opt = make_option()
        ms = base_market_state()
        pv = opt.scenario_npvs(POST_EXPIRY, ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_well_after_expiry_returns_zeros(self):
        opt = make_option()
        ms = base_market_state()
        pv = opt.scenario_npvs(date(2026, 6, 1), ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_all_paths_identical_for_flat_curves(self):
        opt = make_option()
        ms = base_market_state()
        pv = opt.scenario_npvs(VAL_DATE, ms)
        assert pv.shape == (N_PATHS,)
        npt.assert_allclose(pv, pv[0], rtol=1e-12)

    def test_nominal_scales_linearly(self):
        ms = base_market_state()
        pv1 = make_option(nominal=1.0).scenario_npvs(VAL_DATE, ms)
        pv2 = make_option(nominal=1_000.0).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv2, pv1 * 1_000.0, rtol=1e-12)

    def test_call_positive_put_positive(self):
        ms = base_market_state()
        call_pv = make_option(is_call=True, nominal=1.0).scenario_npvs(VAL_DATE, ms)
        put_pv = make_option(is_call=False, nominal=1.0).scenario_npvs(VAL_DATE, ms)
        assert np.all(call_pv > 0)
        assert np.all(put_pv > 0)

    def test_on_expiry_date_is_live(self):
        # val_date == expiry_date should return intrinsic-like value, not zero.
        opt = make_option(is_call=True, nominal=1.0)
        ms = base_market_state()
        pv = opt.scenario_npvs(EXPIRY, ms)
        assert np.all(pv >= 0)


class TestFXOptionPutCallParity:
    """C - P = df_dom * (F - K).

    With dom_basis_rate=0: F = spot * df_for / df_dom (standard CIP).
    With dom_basis_rate!=0: F = spot * df_for / (df_dom * df_dom_basis),
    and df returned is still df_dom (pure domestic discount).
    """

    def _check_parity(
        self, strike, spot, dom_rate, dom_basis_rate, for_rate
    ):
        ms = base_market_state(
            spot=spot, dom=dom_rate, dom_basis=dom_basis_rate, for_=for_rate
        )
        call = make_option(strike=strike, is_call=True, nominal=1.0)
        put = make_option(strike=strike, is_call=False, nominal=1.0)

        call_pv = call.scenario_npvs(VAL_DATE, ms)
        put_pv = put.scenario_npvs(VAL_DATE, ms)

        T = 1.0  # 365 days ACT/365
        df_dom = np.exp(-dom_rate * T)
        df_dom_basis = np.exp(-dom_basis_rate * T)
        df_for = np.exp(-for_rate * T)
        F = spot * df_for / (df_dom * df_dom_basis)
        expected_diff = df_dom * (F - strike)

        npt.assert_allclose(
            call_pv - put_pv, expected_diff, rtol=1e-8, atol=1e-10
        )

    def test_parity_no_basis(self):
        self._check_parity(
            strike=STRIKE, spot=FX_SPOT,
            dom_rate=DOM_RATE, dom_basis_rate=0.0, for_rate=FOR_RATE,
        )

    def test_parity_with_basis_spread(self):
        self._check_parity(
            strike=STRIKE, spot=FX_SPOT,
            dom_rate=DOM_RATE, dom_basis_rate=0.01, for_rate=FOR_RATE,
        )

    def test_parity_itm_call(self):
        self._check_parity(
            strike=17.00, spot=FX_SPOT,
            dom_rate=DOM_RATE, dom_basis_rate=0.0, for_rate=FOR_RATE,
        )

    def test_parity_atm_forward(self):
        T = 1.0
        F_atm = FX_SPOT * np.exp(-FOR_RATE * T) / np.exp(-DOM_RATE * T)
        self._check_parity(
            strike=F_atm, spot=FX_SPOT,
            dom_rate=DOM_RATE, dom_basis_rate=0.0, for_rate=FOR_RATE,
        )

    def test_parity_zero_rates(self):
        # Both rates zero: F = spot, df = 1
        self._check_parity(
            strike=STRIKE, spot=FX_SPOT,
            dom_rate=0.0, dom_basis_rate=0.0, for_rate=0.0,
        )

    def test_parity_varying_spot(self):
        self._check_parity(
            strike=STRIKE, spot=20.0,
            dom_rate=DOM_RATE, dom_basis_rate=0.0, for_rate=FOR_RATE,
        )


class TestFXOptionForwardPricing:

    def test_fx_forward_near_zero_vol(self):
        """With near-zero vol and F > K: call ≈ df_dom*(F-K), put ≈ 0."""
        T = 1.0
        df_dom = np.exp(-DOM_RATE * T)
        df_for = np.exp(-FOR_RATE * T)
        F = FX_SPOT * df_for / df_dom  # standard CIP, no basis

        strike_below = 15.0  # well below F
        ms = base_market_state(vol=0.001)

        call_pv = make_option(
            strike=strike_below, is_call=True, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms)
        put_pv = make_option(
            strike=strike_below, is_call=False, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms)

        expected_call = df_dom * (F - strike_below)
        npt.assert_allclose(call_pv, expected_call, rtol=1e-3)
        npt.assert_allclose(put_pv, 0.0, atol=1e-4)

    def test_covered_interest_parity_implied(self):
        """Recover FX forward from put-call parity: K + (C-P)/df_dom = F."""
        T = 1.0
        dom_rate, for_rate = 0.10, 0.03
        df_dom = np.exp(-dom_rate * T)
        df_for = np.exp(-for_rate * T)
        F_expected = FX_SPOT * df_for / df_dom

        ms = base_market_state(dom=dom_rate, for_=for_rate, vol=0.001)
        strike = FX_SPOT
        call_pv = make_option(
            strike=strike, is_call=True, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms)
        put_pv = make_option(
            strike=strike, is_call=False, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms)
        F_implied = strike + (call_pv[0] - put_pv[0]) / df_dom
        npt.assert_allclose(F_implied, F_expected, rtol=1e-4)

    def test_higher_foreign_rate_lowers_forward_and_call(self):
        """Higher USD rate → lower df_for → lower F → OTM call cheaper."""
        ms_low = base_market_state(for_=0.02)
        ms_high = base_market_state(for_=0.08)

        call_low = make_option(
            is_call=True, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms_low)[0]
        call_high = make_option(
            is_call=True, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms_high)[0]
        put_low = make_option(
            is_call=False, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms_low)[0]
        put_high = make_option(
            is_call=False, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms_high)[0]

        # Higher for_rate → lower df_for → lower forward → cheaper OTM call
        assert call_high < call_low
        # ... and more expensive OTM put
        assert put_high > put_low

    def test_basis_spread_affects_forward(self):
        """A non-zero domestic basis spread adjusts F relative to no-basis case."""
        ms_no_basis = base_market_state(dom_basis=0.0)
        ms_basis = base_market_state(dom_basis=0.02)

        call_no_basis = make_option(
            is_call=True, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms_no_basis)[0]
        call_with_basis = make_option(
            is_call=True, nominal=1.0,
        ).scenario_npvs(VAL_DATE, ms_basis)[0]

        # Non-zero basis changes the forward, so prices must differ.
        assert call_no_basis != call_with_basis


class TestFXOptionTriangulatedSpot:

    def test_triangulated_spot_matches_direct(self):
        """ZAR/USD ÷ EUR/USD = ZAR/EUR: triangulated option == direct spot option."""
        zar_usd = 18.50
        eur_usd = 1.10
        zar_eur = zar_usd / eur_usd  # ~16.818

        ms_direct = {
            "FX_SPOT":   ScalarSlice(values=np.full(N_PATHS, zar_eur)),
            "DOM_BASIS": flat_curve(0.0),
            "DOM":       flat_curve(DOM_RATE),
            "FOR":       flat_curve(FOR_RATE),
            "VOL":       flat_vol(),
        }
        ms_triangulated = {
            "ZAR_USD":   ScalarSlice(values=np.full(N_PATHS, zar_usd)),
            "EUR_USD":   ScalarSlice(values=np.full(N_PATHS, eur_usd)),
            "DOM_BASIS": flat_curve(0.0),
            "DOM":       flat_curve(DOM_RATE),
            "FOR":       flat_curve(FOR_RATE),
            "VOL":       flat_vol(),
        }

        opt_direct = make_option(strike=16.0, nominal=1.0)
        opt_triang = FXOption(
            name="FX_OPT_TRI",
            expiry_date=EXPIRY,
            strike=16.0,
            is_call=True,
            nominal=1.0,
            domestic_basis="DOM_BASIS",
            domestic_curve="DOM",
            domestic_interpolator=linear_interpolator,
            domestic_basis_interpolator=linear_interpolator,
            foreign_curve="FOR",
            foreign_interpolator=linear_interpolator,
            domestic_fx_name="ZAR_USD",
            foreign_fx_name="EUR_USD",
            vol_name="VOL",
        )

        pv_direct = opt_direct.scenario_npvs(VAL_DATE, ms_direct)
        pv_triang = opt_triang.scenario_npvs(VAL_DATE, ms_triangulated)
        npt.assert_allclose(pv_direct, pv_triang, rtol=1e-10)
