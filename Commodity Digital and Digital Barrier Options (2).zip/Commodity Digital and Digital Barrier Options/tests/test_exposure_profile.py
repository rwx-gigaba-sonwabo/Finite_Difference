import pytest
import numpy as np
from datetime import date

from pricing.exposure_profile import ExposureProfile


def make_profile(
    n_paths: int = 10,
    n_dates: int = 5,
    mtm_value: float = 100.0,
    collateral_value: float = 0.0,
    netting_set_id: str = "NS1",
) -> ExposureProfile:
    dates = tuple(date(2025, m, 1) for m in range(1, n_dates + 1))
    mtm = np.full((n_paths, n_dates), mtm_value)
    collateral = np.full((n_paths, n_dates), collateral_value)
    net = mtm - collateral
    exposure = np.maximum(net, 0.0)
    neg_exposure = np.minimum(net, 0.0)
    return ExposureProfile(
        netting_set_id=netting_set_id,
        dates=dates,
        mtm=mtm,
        collateral=collateral,
        exposure=exposure,
        neg_exposure=neg_exposure,
    )


class TestExposureProfileConstruction:
    def test_basic_construction(self):
        p = make_profile()
        assert p.netting_set_id == "NS1"
        assert p.n_paths == 10
        assert p.n_dates == 5

    def test_shapes_stored_correctly(self):
        p = make_profile(n_paths=8, n_dates=4)
        assert p.mtm.shape == (8, 4)
        assert p.collateral.shape == (8, 4)
        assert p.exposure.shape == (8, 4)
        assert p.neg_exposure.shape == (8, 4)

    def test_wrong_mtm_dims_raises(self):
        dates = (date(2025, 1, 1),)
        with pytest.raises(ValueError, match="'mtm' must be 2-dimensional"):
            ExposureProfile(
                netting_set_id="NS1",
                dates=dates,
                mtm=np.array([1.0]),
                collateral=np.zeros((1, 1)),
                exposure=np.zeros((1, 1)),
                neg_exposure=np.zeros((1, 1)),
            )

    def test_date_length_mismatch_raises(self):
        dates = (date(2025, 1, 1), date(2025, 2, 1))  # 2 dates
        with pytest.raises(ValueError, match="'mtm' second dimension"):
            ExposureProfile(
                netting_set_id="NS1",
                dates=dates,
                mtm=np.zeros((5, 3)),          # 3 != 2
                collateral=np.zeros((5, 3)),
                exposure=np.zeros((5, 3)),
                neg_exposure=np.zeros((5, 3)),
            )

    def test_path_mismatch_raises(self):
        dates = (date(2025, 1, 1),)
        with pytest.raises(ValueError, match="first dimension"):
            ExposureProfile(
                netting_set_id="NS1",
                dates=dates,
                mtm=np.zeros((5, 1)),
                collateral=np.zeros((3, 1)),   # 3 != 5
                exposure=np.zeros((5, 1)),
                neg_exposure=np.zeros((5, 1)),
            )

    def test_frozen(self):
        p = make_profile()
        with pytest.raises((TypeError, AttributeError)):
            p.netting_set_id = "other"


class TestExposureProfileStatistics:
    def test_epe_all_positive(self):
        p = make_profile(mtm_value=100.0, collateral_value=0.0)
        np.testing.assert_allclose(p.epe, np.full(5, 100.0))

    def test_epe_all_negative_mtm(self):
        p = make_profile(mtm_value=-50.0, collateral_value=0.0)
        np.testing.assert_allclose(p.epe, np.zeros(5))

    def test_ene_all_negative_mtm(self):
        p = make_profile(mtm_value=-50.0, collateral_value=0.0)
        np.testing.assert_allclose(p.ene, np.full(5, -50.0))

    def test_ene_all_positive_mtm(self):
        p = make_profile(mtm_value=100.0, collateral_value=0.0)
        np.testing.assert_allclose(p.ene, np.zeros(5))

    def test_collateral_reduces_exposure(self):
        p = make_profile(mtm_value=100.0, collateral_value=80.0)
        np.testing.assert_allclose(p.epe, np.full(5, 20.0))

    def test_overcollateralised_exposure_is_zero(self):
        p = make_profile(mtm_value=50.0, collateral_value=100.0)
        np.testing.assert_allclose(p.epe, np.zeros(5))

    def test_pfe_shape(self):
        p = make_profile()
        assert p.pfe(0.95).shape == (5,)

    def test_pfe_invalid_alpha_raises(self):
        p = make_profile()
        with pytest.raises(ValueError, match="alpha"):
            p.pfe(1.5)
        with pytest.raises(ValueError, match="alpha"):
            p.pfe(0.0)

    def test_pfe_all_same_paths(self):
        p = make_profile(mtm_value=100.0)
        np.testing.assert_allclose(p.pfe(0.95), np.full(5, 100.0))

    def test_peak_epe(self):
        # build a profile where EPE increases over time
        n_paths, n_dates = 4, 3
        dates = tuple(date(2025, m, 1) for m in range(1, n_dates + 1))
        # mtm ramps up: 10, 20, 30 across all paths
        mtm = np.tile(np.array([[10.0, 20.0, 30.0]]), (n_paths, 1))
        zeros = np.zeros((n_paths, n_dates))
        p = ExposureProfile(
            netting_set_id="NS1",
            dates=dates,
            mtm=mtm,
            collateral=zeros,
            exposure=mtm,
            neg_exposure=zeros,
        )
        assert p.peak_epe == pytest.approx(30.0)

    def test_effective_epe_non_decreasing(self):
        n_paths, n_dates = 4, 3
        dates = tuple(date(2025, m, 1) for m in range(1, n_dates + 1))
        # EPE: 30, 20, 10 (decreasing) → effective EPE uses running max
        mtm = np.tile(np.array([[30.0, 20.0, 10.0]]), (n_paths, 1))
        zeros = np.zeros((n_paths, n_dates))
        p = ExposureProfile(
            netting_set_id="NS1",
            dates=dates,
            mtm=mtm,
            collateral=zeros,
            exposure=mtm,
            neg_exposure=zeros,
        )
        # running max = [30, 30, 30], mean = 30
        assert p.effective_epe == pytest.approx(30.0)
