"""
Shared fixtures for the CVA Pricer test suite.
"""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import pytest

from market_data.scenario_cube import ScenarioCubeBuilder
from utils.interpolation import linear_interpolator, linear_rt_interp, hermite_rt_interp


# ---------------------------------------------------------------------------
# Basic parameters
# ---------------------------------------------------------------------------

N_PATHS = 10
N_DATES = 5

FLAT_RATE = 0.05  # 5% flat yield curve
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0], dtype=np.float64)


@pytest.fixture
def n_paths():
    return N_PATHS


@pytest.fixture
def valuation_date():
    return date(2025, 1, 2)


@pytest.fixture
def sim_dates(valuation_date):
    """5 quarterly simulation dates starting at valuation_date."""
    return tuple(
        date(valuation_date.year, valuation_date.month, valuation_date.day)
        + timedelta(days=90 * i)
        for i in range(N_DATES)
    )


@pytest.fixture
def tenors():
    return TENORS.copy()


@pytest.fixture
def flat_rates(n_paths):
    """Flat 5% yield curve: shape (n_paths, n_tenors)."""
    return np.full((n_paths, len(TENORS)), FLAT_RATE, dtype=np.float64)


@pytest.fixture
def flat_curve_slice(flat_rates, tenors):
    """A CurveSlice with a flat 5% curve."""
    from market_data.risk_factor import CurveSlice
    return CurveSlice(values=flat_rates, tenors=tenors)


@pytest.fixture
def flat_discount_curve(flat_rates, tenors):
    """YieldCurve with a flat 5% curve."""
    from market_data.yield_curve import YieldCurve
    return YieldCurve(
        year_fracs=tenors,
        rates=flat_rates,
        interpolator=linear_interpolator,
    )


@pytest.fixture
def scenario_cube(valuation_date, sim_dates, n_paths, tenors):
    """A simple ScenarioCube with one curve factor (flat 5%)."""
    n_times = len(sim_dates)
    # shape: (n_paths, n_times, n_tenors) — all paths identical, flat 5%
    curve_data = np.full((n_paths, n_times, len(tenors)), FLAT_RATE, dtype=np.float64)
    builder = ScenarioCubeBuilder(n_paths=n_paths, valuation_date=valuation_date)
    builder.add_curve_factor("DISC", curve_data, tenors, dates=sim_dates)
    return builder.build()


@pytest.fixture
def scenario_cube_with_credit(valuation_date, sim_dates, n_paths, tenors):
    """ScenarioCube with discount + credit (hazard) curve factors."""
    n_times = len(sim_dates)
    curve_data = np.full((n_paths, n_times, len(tenors)), FLAT_RATE, dtype=np.float64)
    credit_data = np.full((n_paths, n_times, len(tenors)), 0.01, dtype=np.float64)  # 1% hazard

    builder = ScenarioCubeBuilder(n_paths=n_paths, valuation_date=valuation_date)
    builder.add_curve_factor("DISC", curve_data, tenors, dates=sim_dates)
    builder.add_curve_factor("CREDIT", credit_data, tenors, dates=sim_dates)
    return builder.build()


# ---------------------------------------------------------------------------
# Swap fixture helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def at_market_swap(valuation_date):
    """
    A receive-fixed / pay-floating IRS where the fixed rate equals the
    flat forward rate so NPV should be ~0 at inception.
    """
    from instruments.ir_swap import IRSwap, LegType, SwapLeg

    effective = valuation_date
    maturity = date(effective.year + 2, effective.month, effective.day)

    return IRSwap(
        name="TEST_SWAP",
        effective_date=effective,
        maturity_date=maturity,
        notional=1_000_000,
        receive_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=FLAT_RATE),
        pay_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
        discount_curve_name="DISC",
        interpolator=linear_interpolator,
        calendar="TARGET",
    )
