"""
Tests for instruments/ir_swap.py — IRSwap.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt
import pytest

from datetime import timedelta

from instruments.ir_swap import IRSwap, LegType, SwapLeg
from instruments.components.schedule_config import ScheduleConfig
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice
from market_data.scenario_cube import ScenarioCubeBuilder
from pricing.exposure_engine import ExposureEngine
from portfolio.netting_set import NettingSet
from portfolio.trade import Trade
from utils.interpolation import linear_interpolator, linear_rt_interp


# ---------------------------------------------------------------------------
# Helpers / constants
# ---------------------------------------------------------------------------

N_PATHS = 8
VAL_DATE = date(2025, 1, 2)
FLAT_RATE = 0.05
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0], dtype=np.float64)


def flat_rates(rate=FLAT_RATE) -> np.ndarray:
    return np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64)


def flat_curve_slice(rate=FLAT_RATE) -> CurveSlice:
    return CurveSlice(values=flat_rates(rate), tenors=TENORS)


def make_market_state(rate=FLAT_RATE) -> dict:
    return {"DISC": flat_curve_slice(rate)}


def make_payer_swap(
    effective: date = VAL_DATE,
    maturity: date | None = None,
    fixed_rate: float = FLAT_RATE,
    notional: float = 1_000_000,
) -> IRSwap:
    if maturity is None:
        maturity = date(effective.year + 2, effective.month, effective.day)
    return IRSwap(
        name="PAYER",
        effective_date=effective,
        maturity_date=maturity,
        notional=notional,
        receive_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
        pay_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=fixed_rate),
        discount_curve_name="DISC",
        interpolator=linear_interpolator,
        calendar="TARGET",
    )


def make_receiver_swap(
    effective: date = VAL_DATE,
    maturity: date | None = None,
    fixed_rate: float = FLAT_RATE,
    notional: float = 1_000_000,
) -> IRSwap:
    if maturity is None:
        maturity = date(effective.year + 2, effective.month, effective.day)
    return IRSwap(
        name="RECEIVER",
        effective_date=effective,
        maturity_date=maturity,
        notional=notional,
        receive_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=fixed_rate),
        pay_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
        discount_curve_name="DISC",
        interpolator=linear_interpolator,
        calendar="TARGET",
    )


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestIRSwapConstruction:

    def test_builds_without_error(self):
        swap = make_payer_swap()
        assert swap.name == "PAYER"

    def test_schedule_not_empty(self):
        swap = make_payer_swap()
        assert len(swap.receive_schedule) > 0
        assert len(swap.pay_schedule) > 0

    def test_accrual_fractions_positive(self):
        swap = make_payer_swap()
        for _, _, _, accrual in swap.receive_schedule:
            assert accrual > 0

    def test_fixed_leg_requires_rate(self):
        with pytest.raises(ValueError, match="fixed_rate"):
            SwapLeg(LegType.FIXED, frequency=6)

    def test_floating_leg_requires_curve_name(self):
        with pytest.raises(ValueError, match="curve_name"):
            SwapLeg(LegType.FLOATING, frequency=6)


# ---------------------------------------------------------------------------
# price() — shape and type
# ---------------------------------------------------------------------------

class TestIRSwapPriceShape:

    def test_npv_shape_n_paths(self):
        swap = make_payer_swap()
        npv = swap.scenario_npvs(VAL_DATE, make_market_state())
        assert npv.shape == (N_PATHS,)

    def test_npv_dtype_float(self):
        swap = make_payer_swap()
        npv = swap.scenario_npvs(VAL_DATE, make_market_state())
        assert npv.dtype in (np.float64, np.float32)

    def test_zero_npv_after_maturity(self):
        swap = make_payer_swap()
        past_maturity = date(swap.maturity_date.year + 1, 1, 1)
        npv = swap.scenario_npvs(past_maturity, make_market_state())
        npt.assert_array_equal(npv, 0.0)


# ---------------------------------------------------------------------------
# At-market NPV ≈ 0
# ---------------------------------------------------------------------------

class TestAtMarketSwap:

    def test_at_market_payer_npv_near_zero(self):
        """
        Payer swap with fixed rate = par rate on a flat curve
        should have NPV ≈ 0 at inception.
        """
        swap = make_payer_swap(fixed_rate=FLAT_RATE)
        npv = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE))
        # The par rate on a flat curve is not exactly FLAT_RATE due to
        # ACT/365 accrual vs. simply compounded discounting, but it should
        # be close for reasonable maturities.
        npt.assert_allclose(npv, 0.0, atol=5_000)  # within 5000 notional units on 1MM

    def test_at_market_receiver_npv_near_zero(self):
        swap = make_receiver_swap(fixed_rate=FLAT_RATE)
        npv = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE))
        npt.assert_allclose(npv, 0.0, atol=5_000)

    def test_payer_equals_minus_receiver(self):
        """Payer NPV should be the negative of receiver NPV."""
        payer = make_payer_swap(fixed_rate=FLAT_RATE)
        receiver = make_receiver_swap(fixed_rate=FLAT_RATE)
        npv_payer = payer.scenario_npvs(VAL_DATE, make_market_state())
        npv_receiver = receiver.scenario_npvs(VAL_DATE, make_market_state())
        npt.assert_allclose(npv_payer, -npv_receiver, atol=1e-6)

    def test_higher_fixed_rate_positive_for_receiver(self):
        """
        Receiver (receive-fixed) profits when fixed rate > par rate.
        """
        swap = make_receiver_swap(fixed_rate=FLAT_RATE + 0.02)
        npv = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE))
        assert np.all(npv > 0), "Receiver should benefit from above-par fixed rate"

    def test_lower_fixed_rate_negative_for_receiver(self):
        swap = make_receiver_swap(fixed_rate=FLAT_RATE - 0.02)
        npv = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE))
        assert np.all(npv < 0), "Receiver should lose when fixed rate < par rate"

    def test_all_paths_identical_on_flat_curve(self):
        """On a flat identical curve across all paths, all NPVs should be equal."""
        swap = make_receiver_swap()
        npv = swap.scenario_npvs(VAL_DATE, make_market_state())
        assert np.all(npv == npv[0])


# ---------------------------------------------------------------------------
# Sensitivity / direction tests
# ---------------------------------------------------------------------------

class TestIRSwapSensitivity:

    def test_npv_scales_with_notional(self):
        """NPV should scale linearly with notional."""
        swap_1m = make_receiver_swap(notional=1_000_000, fixed_rate=FLAT_RATE + 0.01)
        swap_2m = make_receiver_swap(notional=2_000_000, fixed_rate=FLAT_RATE + 0.01)
        npv_1m = swap_1m.scenario_npvs(VAL_DATE, make_market_state())
        npv_2m = swap_2m.scenario_npvs(VAL_DATE, make_market_state())
        npt.assert_allclose(npv_2m, 2.0 * npv_1m, rtol=1e-10)

    def test_receiver_duration_positive(self):
        """Receiver swap benefits from falling rates (rate down → NPV up)."""
        swap = make_receiver_swap(fixed_rate=FLAT_RATE)
        npv_base = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE))
        npv_down = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE - 0.01))
        assert np.all(npv_down > npv_base), "Receiver should gain when rates fall"

    def test_payer_duration_negative(self):
        """Payer swap benefits from rising rates."""
        swap = make_payer_swap(fixed_rate=FLAT_RATE)
        npv_base = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE))
        npv_up = swap.scenario_npvs(VAL_DATE, make_market_state(FLAT_RATE + 0.01))
        assert np.all(npv_up > npv_base), "Payer should gain when rates rise"


# ---------------------------------------------------------------------------
# Current fixing
# ---------------------------------------------------------------------------

class TestCurrentFixing:

    def test_current_fixing_overrides_forward_rate(self):
        """
        A swap whose in-progress period fixing (supplied via the fixings dict)
        differs from the prevailing forward rate should produce a different NPV.
        """
        swap = IRSwap(
            name="SWAP",
            effective_date=VAL_DATE,
            maturity_date=date(VAL_DATE.year + 2, VAL_DATE.month, VAL_DATE.day),
            notional=1_000_000,
            receive_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=FLAT_RATE),
            pay_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
            discount_curve_name="DISC",
            interpolator=linear_interpolator,
            calendar="TARGET",
        )
        ms = make_market_state(FLAT_RATE)
        npv_no_fix = swap.scenario_npvs(VAL_DATE, ms)
        # Supply a fixing of 10% (higher than FLAT_RATE) for the current period
        fixings = {("DISC", VAL_DATE): np.full(N_PATHS, 0.10)}
        npv_with_fix = swap.scenario_npvs(VAL_DATE, ms, fixings=fixings)
        # Higher floating rate → higher pay leg PV → lower NPV for receiver
        assert np.all(npv_with_fix < npv_no_fix)


# ---------------------------------------------------------------------------
# Integration: ScenarioCube → IRSwap.price
# ---------------------------------------------------------------------------

class TestIRSwapWithCube:

    def test_price_from_cube_time_slice(self):
        sim_dates = (VAL_DATE, VAL_DATE + timedelta(days=180))
        n_times = len(sim_dates)
        curve_data = np.full((N_PATHS, n_times, len(TENORS)), FLAT_RATE)
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("DISC", curve_data, TENORS, dates=sim_dates)
        cube = builder.build()

        swap = make_receiver_swap()
        for t_idx in range(cube.n_times):
            ms = cube.get_time_slice(t_idx)
            sim_date = cube.dates[t_idx]
            npv = swap.scenario_npvs(sim_date, ms)
            assert npv.shape == (N_PATHS,)


# ---------------------------------------------------------------------------
# OIS initial CF seeding (RiskFlow old_resets alignment)
# ---------------------------------------------------------------------------

class TestOISInitialCFSeeding:
    """OIS in-progress period: step-by-step CF accumulation.

    For a coupon that started before the simulation horizon, the engine starts
    CF_realized at 1.0 (no history) and accumulates one step at a time:

        CF_realized_{t+1} = CF_realized_t * (1 / DF(Δt, from curve at t))

    ``ois_initial_cfs`` seeds the starting CF so the engine begins from the
    correct historical compound factor rather than from 1.0.

    MTM at VAL_DATE (accrual window, CF = 1.0 unseeded):
        float_pv = N * (1.0 - DF_remaining)
        net_mtm  = float_pv - fixed_pv

    Seeding with CF_HIST shifts the float_pv by N * (CF_HIST - 1.0):
        float_pv_seeded = N * (CF_HIST - DF_remaining)
        diff = N * (CF_HIST - 1.0)  # independent of the remaining DF
    """

    OIS_RATE = 0.05
    NOTIONAL = 1_000_000.0

    EFFECTIVE = date(2024, 7, 1)
    MATURITY  = date(2025, 7, 1)

    def _make_ois_swap(self, ois_initial_cfs=None):
        return IRSwap(
            name="OIS_SWAP",
            effective_date=self.EFFECTIVE,
            maturity_date=self.MATURITY,
            notional=self.NOTIONAL,
            receive_leg=SwapLeg(
                LegType.FLOATING,
                frequency=12,
                curve_name="OIS",
                overnight_compounding=True,
            ),
            pay_leg=SwapLeg(
                LegType.FIXED, frequency=12, fixed_rate=self.OIS_RATE,
            ),
            discount_curve_name="OIS",
            interpolator=linear_interpolator,
            calendar="TARGET",
            ois_initial_cfs=ois_initial_cfs,
        )

    def _make_cube(self, sim_dates):
        n_times = len(sim_dates)
        data = np.full((N_PATHS, n_times, len(TENORS)), self.OIS_RATE)
        builder = ScenarioCubeBuilder(
            n_paths=N_PATHS, valuation_date=sim_dates[0],
        )
        builder.add_curve_factor("OIS", data, TENORS, dates=sim_dates)
        return builder.build()

    def _run_engine(self, swap, sim_dates):
        cube = self._make_cube(sim_dates)
        trade = Trade(trade_id="T1", counterparty_id="CPT", instrument=swap)
        ns = NettingSet(
            netting_set_id="NS", counterparty_id="CPT", trades=[trade],
        )
        return ExposureEngine(cube).compute(ns).mtm

    def test_unseeded_in_progress_uses_unit_cf(self):
        """Without ois_initial_cfs, CF_realized = 1.0 at VAL_DATE.

        MTM = N * (1.0 - DF_remaining) - fixed_pv.
        No backward extrapolation from the current curve.
        """
        import QuantLib as ql
        from utils.ql_helpers import to_ql_date

        swap = self._make_ois_swap()
        mtm  = self._run_engine(swap, (VAL_DATE, self.MATURITY))

        dc = ql.Actual365Fixed()
        r = self.OIS_RATE
        tau_fwd  = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(self.MATURITY)))
        tau_full = float(dc.yearFraction(to_ql_date(self.EFFECTIVE), to_ql_date(self.MATURITY)))

        df_remaining = np.exp(-r * tau_fwd)
        float_pv = self.NOTIONAL * (1.0 - df_remaining)
        fixed_pv = self.NOTIONAL * r * tau_full * df_remaining
        expected = float_pv - fixed_pv

        npt.assert_allclose(mtm[:, 0], expected, rtol=1e-6)

    def test_ois_initial_cfs_shifts_mtm_by_historical_coupon(self):
        """Seeded MTM exceeds unseeded MTM by N*(CF_HIST-1) at VAL_DATE.

        The DF_remaining terms cancel so the shift is path-independent.
        """
        CF_HIST  = 1.025
        unseeded = self._make_ois_swap()
        p_start  = unseeded.receive_schedule[0][0]

        seeded = self._make_ois_swap(
            ois_initial_cfs={("OIS", p_start): CF_HIST},
        )

        mtm_seeded   = self._run_engine(seeded,   (VAL_DATE, self.MATURITY))
        mtm_unseeded = self._run_engine(unseeded, (VAL_DATE, self.MATURITY))

        expected_diff = self.NOTIONAL * (CF_HIST - 1.0)
        npt.assert_allclose(
            mtm_seeded[:, 0] - mtm_unseeded[:, 0],
            expected_diff,
            rtol=1e-6,
        )


# ---------------------------------------------------------------------------
# OIS payment-offset exceedance (SOFR 2-day settlement window)
# ---------------------------------------------------------------------------

class TestOISPaymentOffset:
    """SOFR OIS 2-business-day payment offset: exceedance fix.

    When the simulation date falls inside the settlement window
    [T_end, T_pay), the engine previously accumulated overnight CF past
    T_end and leg_pv applied a negative-tenor df_end_fwd correction.
    For stochastic paths where the OIS curve moved between T_end and
    sim_date the two errors did not cancel, producing path-dependent NPV
    overestimates (exceedances on paths where rates fell).

    Fix: engine caps CF accumulation at p_end; leg_pv uses CF_realized
    directly (no df_end_fwd) when fwd_t_ends[0] <= 0.

    The test uses a single semi-annual OIS period seeded via
    ois_initial_cfs and a rate-drop from 5% (during the period) to 0%
    (at the settlement step) so that the buggy df_end_fwd = 1.0 fails
    to cancel the overcompounding at all — the exceedance is maximally
    exposed rather than hidden by near-cancellation.
    """

    NOTIONAL = 1_000_000.0
    RATE_PERIOD = 0.05   # OIS rate during the accrual period
    RATE_SETTLE = 0.00   # OIS rate drops to 0 at T_MID (maximises the bug)
    FIXED_RATE  = 0.00   # zero fixed rate isolates the float leg

    # Single 6M accrual period on TARGET calendar
    T_START = date(2024, 7, 2)   # effective date
    T_END   = date(2025, 1, 2)   # accrual end (= VAL_DATE)
    # On TARGET calendar: Jan 3 2025 = Friday, Jan 6 2025 = Monday
    T_MID   = date(2025, 1, 3)   # 1BD into the 2-day settlement window
    T_PAY   = date(2025, 1, 6)   # T_END + 2BD = payment date

    def _make_sc(self, offset_days):
        return ScheduleConfig(
            calendar="TARGET",
            business_convention="ModifiedFollowing",
            termination_business_convention="ModifiedFollowing",
            day_count="ACT/365",
            curve_day_count="ACT/365",
            payment_offset_days=offset_days,
            pay_date_convention="Following",
        )

    def _make_cube(self, sim_dates, rates_per_step):
        n_times = len(sim_dates)
        data = np.empty((N_PATHS, n_times, len(TENORS)))
        for t_idx, r in enumerate(rates_per_step):
            data[:, t_idx, :] = r
        builder = ScenarioCubeBuilder(
            n_paths=N_PATHS, valuation_date=sim_dates[0],
        )
        builder.add_curve_factor("OIS", data, TENORS, dates=sim_dates)
        return builder.build()

    def _make_swap(self, cf_true, offset_days=2):
        sc = self._make_sc(offset_days)
        return IRSwap(
            name="SOFR_OIS",
            effective_date=self.T_START,
            maturity_date=self.T_END,
            notional=self.NOTIONAL,
            receive_leg=SwapLeg(
                LegType.FLOATING, frequency=6, curve_name="OIS",
                overnight_compounding=True,
            ),
            pay_leg=SwapLeg(
                LegType.FIXED, frequency=6, fixed_rate=self.FIXED_RATE,
            ),
            discount_curve_name="OIS",
            interpolator=linear_interpolator,
            schedule_config=sc,
            ois_initial_cfs={("OIS", self.T_START): cf_true},
        )

    def _run_engine(self, swap, sim_dates, rates_per_step):
        cube = self._make_cube(sim_dates, rates_per_step)
        trade = Trade(trade_id="T1", counterparty_id="CPT", instrument=swap)
        ns = NettingSet(
            netting_set_id="NS", counterparty_id="CPT", trades=[trade],
        )
        return ExposureEngine(cube).compute(ns).mtm

    def test_npv_exact_in_settlement_window_after_rate_drop(self):
        """NPV at T_MID = N*(CF_true-1)*DF_pay regardless of curve move.

        With the old code: CF was overcompounded by 1BD at 5%, and
        df_end_fwd = exp(0%*1BD) = 1 failed to cancel it, so NPV was
        inflated by N*CF_true*(exp(5%/365)-1).  With the fix: CF is
        capped at T_END and used directly, giving the exact value.
        """
        import QuantLib as ql
        from utils.ql_helpers import to_ql_date

        dc = ql.Actual365Fixed()
        tau = dc.yearFraction(to_ql_date(self.T_START), to_ql_date(self.T_END))
        cf_true = float(np.exp(self.RATE_PERIOD * float(tau)))

        # Rates: 5% at T_END (used for CF seed check), 0% at T_MID and T_PAY.
        # At 0%: DF(T_MID→T_PAY) = 1.0, so float_pv = N*(CF_true-1)*1.
        sim_dates = (self.T_END, self.T_MID, self.T_PAY)
        rates    = [self.RATE_PERIOD, self.RATE_SETTLE, self.RATE_SETTLE]

        swap = self._make_swap(cf_true)
        mtm  = self._run_engine(swap, sim_dates, rates)

        # With RATE_SETTLE=0%: DF(T_MID→T_PAY) = exp(-0*3/365) = 1.0
        expected = self.NOTIONAL * (cf_true - 1.0) * 1.0
        npt.assert_allclose(mtm[:, 1], expected, rtol=1e-6)

    def test_npv_smooth_from_accrual_end_to_payment_date(self):
        """NPV rises monotonically from T_END to T_PAY as DF→1 — no spike."""
        import QuantLib as ql
        from utils.ql_helpers import to_ql_date

        dc = ql.Actual365Fixed()
        tau = dc.yearFraction(to_ql_date(self.T_START), to_ql_date(self.T_END))
        cf_true = float(np.exp(self.RATE_PERIOD * float(tau)))

        # Flat curve at 5% throughout so DF ratios are analytically known.
        sim_dates = (self.T_END, self.T_MID, self.T_PAY)
        rates     = [self.RATE_PERIOD] * 3

        swap = self._make_swap(cf_true)
        mtm  = self._run_engine(swap, sim_dates, rates)

        coupon = self.NOTIONAL * (cf_true - 1.0)

        tau_mid_pay = float(dc.yearFraction(
            to_ql_date(self.T_MID), to_ql_date(self.T_PAY),
        ))
        tau_end_pay = float(dc.yearFraction(
            to_ql_date(self.T_END), to_ql_date(self.T_PAY),
        ))

        expected_end = coupon * np.exp(-self.RATE_PERIOD * tau_end_pay)
        expected_mid = coupon * np.exp(-self.RATE_PERIOD * tau_mid_pay)
        expected_pay = coupon * 1.0   # DF(T_PAY→T_PAY) = 1

        npt.assert_allclose(mtm[:, 0], expected_end, rtol=1e-6)
        npt.assert_allclose(mtm[:, 1], expected_mid, rtol=1e-6)
        npt.assert_allclose(mtm[:, 2], expected_pay, rtol=1e-6)

        # No exceedance: NPV is non-decreasing through the settlement window.
        assert np.all(mtm[:, 1] >= mtm[:, 0] - 1.0)
        assert np.all(mtm[:, 2] >= mtm[:, 1] - 1.0)
