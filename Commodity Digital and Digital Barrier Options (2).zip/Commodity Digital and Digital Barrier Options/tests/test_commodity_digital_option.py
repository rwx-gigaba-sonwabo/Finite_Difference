"""
Tests for instruments/commodity_digital_option.py — CommodityDigitalOption.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt

from instruments.commodity_digital_option import CommodityDigitalOption
from market_data.risk_factor import CurveSlice, ScalarSlice
from models.commodity_digital_pv import black76_digital_price
from utils.interpolation import forward_price_interpolator, linear_interpolator
from utils.ql_helpers import DAY_COUNTERS, advance_business_days, to_ql_date

N_PATHS = 6
VAL_DATE = date(2025, 1, 2)
MATURITY = date(2026, 1, 2)  # ACT/365 -> T ~= 1.0

FWD_PRICE = 80.0
VOL = 0.30
DISC_RATE = 0.05

FWD_TENORS = np.array([45750.0, 45841.0, 46024.0, 46389.0, 47484.0])  # Excel serials
CURVE_TENORS_YF = np.array([0.25, 0.5, 1.0, 2.0, 5.0])


def fwd_slice(price=FWD_PRICE):
    return CurveSlice(
        values=np.full((N_PATHS, len(FWD_TENORS)), price, dtype=np.float64),
        tenors=FWD_TENORS,
    )


def disc_slice(rate=DISC_RATE):
    return CurveSlice(
        values=np.full((N_PATHS, len(CURVE_TENORS_YF)), rate, dtype=np.float64),
        tenors=CURVE_TENORS_YF,
    )


def vol_slice(vol=VOL):
    return ScalarSlice(values=np.full(N_PATHS, vol, dtype=np.float64))


def make_market_state(price=FWD_PRICE, vol=VOL, rate=DISC_RATE):
    return {"FWD": fwd_slice(price), "DISC": disc_slice(rate), "VOL": vol_slice(vol)}


def make_instrument(
    strike=80.0, is_call=True, digital_type="cash", payout=100.0,
    spot_days=0, settle_days=2, maturity=MATURITY,
):
    return CommodityDigitalOption(
        name="TEST_DIGITAL",
        maturity_date=maturity,
        strike=strike,
        is_call=is_call,
        digital_type=digital_type,
        payout=payout,
        forward_curve_name="FWD",
        discount_curve_name="DISC",
        vol_name="VOL",
        forward_interpolator=forward_price_interpolator,
        discount_interpolator=linear_interpolator,
        spot_days=spot_days,
        spot_calendar="USD",
        settle_days=settle_days,
        settlement_calendar="USD",
        day_count="ACT/365",
    )


# ---------------------------------------------------------------------------
# scenario_npvs
# ---------------------------------------------------------------------------

def test_scenario_npvs_matches_model_function_directly():
    inst = make_instrument(spot_days=0, settle_days=0)
    ms = make_market_state()
    npv = inst.scenario_npvs(VAL_DATE, ms)

    dc = DAY_COUNTERS["ACT/365"]
    T = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(MATURITY)))
    expected = black76_digital_price(
        np.full(N_PATHS, FWD_PRICE), 80.0, np.full(N_PATHS, VOL),
        np.full(N_PATHS, np.exp(-DISC_RATE * T)), T, True, "cash", 100.0,
    )
    npt.assert_allclose(npv, expected, rtol=1e-6)


def test_settle_days_only_affects_discounting_not_time_to_expiry():
    """T_opt (vol scaling) must stay year_frac(val,maturity); only the DF
    tenor should move with settle_days."""
    inst0 = make_instrument(settle_days=0)
    inst2 = make_instrument(settle_days=30)
    ms = make_market_state()

    npv0 = inst0.scenario_npvs(VAL_DATE, ms)
    npv2 = inst2.scenario_npvs(VAL_DATE, ms)

    # With a positive discount rate, more settlement lag -> lower DF -> lower price.
    assert np.all(npv2 < npv0)

    # But the *probability* component (price / DF) should be identical,
    # proving T_opt (and hence vol scaling / d2) is untouched by settle_days.
    dc = DAY_COUNTERS["ACT/365"]
    settle0 = advance_business_days(MATURITY, 0, "USD")
    settle2 = advance_business_days(MATURITY, 30, "USD")
    T_disc0 = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(settle0)))
    T_disc2 = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(settle2)))
    df0 = np.exp(-DISC_RATE * T_disc0)
    df2 = np.exp(-DISC_RATE * T_disc2)
    npt.assert_allclose(npv0 / df0, npv2 / df2, rtol=1e-8)


def test_spot_days_shifts_only_the_curve_lookup_point():
    """spot_days should change which forward-curve tenor is read (and
    hence F, since the curve isn't flat), while T_opt/T_disc stay fixed."""
    inst0 = make_instrument(spot_days=0, settle_days=0)
    inst5 = make_instrument(spot_days=5, settle_days=0)

    # Upward-sloping forward curve: shifting the lookup date forward should
    # pick up a (slightly) higher forward price.
    sloped_curve = CurveSlice(
        values=np.tile(np.linspace(70.0, 90.0, len(FWD_TENORS)), (N_PATHS, 1)),
        tenors=FWD_TENORS,
    )
    ms = {"FWD": sloped_curve, "DISC": disc_slice(), "VOL": vol_slice()}

    npv0 = inst0.scenario_npvs(VAL_DATE, ms)
    npv5 = inst5.scenario_npvs(VAL_DATE, ms)
    # Both call digitals struck at 80 with a rising forward -> higher F
    # (from the spot-day shift) raises the probability of finishing ITM.
    assert np.all(npv5 >= npv0)


def test_past_settlement_date_returns_zero():
    inst = make_instrument(settle_days=2)
    ms = make_market_state()
    npv = inst.scenario_npvs(date(2027, 1, 5), ms)
    npt.assert_allclose(npv, np.zeros(N_PATHS))


def test_asset_or_nothing_vs_cash_or_nothing_consistency():
    """Asset-or-nothing call minus K * cash-or-nothing call (vanilla
    replication identity) reproduces the standard European call value."""
    inst_cash = make_instrument(digital_type="cash", payout=1.0)
    inst_asset = make_instrument(digital_type="asset", payout=1.0)
    ms = make_market_state()

    v_cash = inst_cash.scenario_npvs(VAL_DATE, ms)
    v_asset = inst_asset.scenario_npvs(VAL_DATE, ms)

    from models.equity_pv import black76_euro_option
    dc = DAY_COUNTERS["ACT/365"]
    settle = advance_business_days(MATURITY, 2, "USD")
    T_disc = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(settle)))
    df = np.exp(-DISC_RATE * T_disc)
    vanilla_call = black76_euro_option(
        np.full(N_PATHS, FWD_PRICE), 80.0, np.full(N_PATHS, VOL),
        np.full(N_PATHS, df), 1.0, True,
    )
    npt.assert_allclose(v_asset - 80.0 * v_cash, vanilla_call, rtol=1e-6)


# ---------------------------------------------------------------------------
# Greeks
# ---------------------------------------------------------------------------

def test_analytic_delta_matches_bump_and_reprice():
    inst = make_instrument()
    ms = make_market_state()

    analytic = inst.analytic_greeks(VAL_DATE, ms)
    bump = inst.greeks_bump_and_reprice(VAL_DATE, ms)
    npt.assert_allclose(analytic["delta"], bump["delta"], rtol=1e-3)


def test_analytic_gamma_matches_bump_and_reprice():
    inst = make_instrument()
    ms = make_market_state()

    analytic = inst.analytic_greeks(VAL_DATE, ms)
    bump = inst.greeks_bump_and_reprice(VAL_DATE, ms)
    npt.assert_allclose(analytic["gamma"], bump["gamma"], rtol=5e-2)


def test_bump_theta_is_negative_for_atm_cash_digital_deep_in_time_value():
    """Sanity: an ATM digital held near the middle of its life typically
    loses value from one day of decay (not a universal law, but true for
    this parameterisation) -- exercised mainly to confirm the theta bump
    runs end-to-end and returns a finite, sane number."""
    inst = make_instrument(strike=FWD_PRICE)
    ms = make_market_state()
    bump = inst.greeks_bump_and_reprice(VAL_DATE, ms)
    assert np.all(np.isfinite(bump["theta"]))