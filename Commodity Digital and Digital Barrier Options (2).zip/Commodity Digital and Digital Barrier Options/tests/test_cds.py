"""
Tests for instruments/cds.py — CDS.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt
import pytest

from instruments.cds import CDS
from market_data.risk_factor import CurveSlice
from market_data.scenario_cube import ScenarioCubeBuilder
from utils.interpolation import linear_interpolator, linear_rt_interp


# ---------------------------------------------------------------------------
# Helpers / constants
# ---------------------------------------------------------------------------

N_PATHS = 8
VAL_DATE = date(2025, 1, 2)
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0], dtype=np.float64)

DISC_RATE = 0.05    # 5% flat discount curve
HAZARD_RATE = 0.01  # 1% flat hazard rate
RECOVERY = 0.40     # 40% recovery


def flat_rates(rate: float, n_paths: int = N_PATHS) -> np.ndarray:
    return np.full((n_paths, len(TENORS)), rate, dtype=np.float64)


def make_market_state(disc_rate=DISC_RATE, hazard_rate=HAZARD_RATE) -> dict:
    return {
        "DISC": CurveSlice(values=flat_rates(disc_rate), tenors=TENORS),
        "CREDIT": CurveSlice(values=flat_rates(hazard_rate), tenors=TENORS),
    }


def make_cds(
    coupon: float,
    is_buyer: bool = True,
    recovery: float = RECOVERY,
    effective: date = VAL_DATE,
    maturity: date | None = None,
    notional: float = 1_000_000,
) -> CDS:
    if maturity is None:
        maturity = date(effective.year + 5, effective.month, effective.day)
    return CDS(
        name="TEST_CDS",
        effective_date=effective,
        maturity_date=maturity,
        notional=notional,
        coupon=coupon,
        recovery_rate=recovery,
        discount_curve_name="DISC",
        credit_curve_name="CREDIT",
        interpolator=linear_interpolator,
        is_protection_buyer=is_buyer,
        calendar="USD",
    )


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestCDSConstruction:

    def test_builds_without_error(self):
        cds = make_cds(coupon=0.01)
        assert cds.name == "TEST_CDS"

    def test_schedule_not_empty(self):
        cds = make_cds(coupon=0.01)
        assert len(cds.schedule) > 0

    def test_accrual_fractions_positive(self):
        cds = make_cds(coupon=0.01)
        for _, _, _, accrual in cds.schedule:
            assert accrual > 0


# ---------------------------------------------------------------------------
# price() — shape and type
# ---------------------------------------------------------------------------

class TestCDSPriceShape:

    def test_npv_shape(self):
        cds = make_cds(coupon=0.01)
        npv = cds.scenario_npvs(VAL_DATE, make_market_state())
        assert npv.shape == (N_PATHS,)

    def test_npv_dtype_float(self):
        cds = make_cds(coupon=0.01)
        npv = cds.scenario_npvs(VAL_DATE, make_market_state())
        assert npv.dtype in (np.float64, np.float32)

    def test_zero_npv_after_maturity(self):
        cds = make_cds(coupon=0.01)
        past_maturity = date(cds.maturity_date.year + 1, 1, 1)
        npv = cds.scenario_npvs(past_maturity, make_market_state())
        npt.assert_array_equal(npv, 0.0)

    def test_all_paths_identical_on_flat_curve(self):
        """All paths should have the same NPV on a flat identical curve."""
        cds = make_cds(coupon=0.01)
        npv = cds.scenario_npvs(VAL_DATE, make_market_state())
        assert np.all(npv == npv[0])


# ---------------------------------------------------------------------------
# Protection buyer vs seller
# ---------------------------------------------------------------------------

class TestProtectionBuyerSeller:

    def test_buyer_is_negative_of_seller(self):
        """Buyer NPV should equal the negative of seller NPV."""
        coupon = 0.01
        buyer = make_cds(coupon=coupon, is_buyer=True)
        seller = make_cds(coupon=coupon, is_buyer=False)
        ms = make_market_state()
        npv_buyer = buyer.scenario_npvs(VAL_DATE, ms)
        npv_seller = seller.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(npv_buyer, -npv_seller, atol=1e-6)

    def test_buyer_pays_premium_at_low_coupon(self):
        """
        If coupon < fair spread, protection buyer overpays → NPV < 0.
        We achieve this by setting coupon much lower than the hazard rate.
        """
        # With hazard_rate=0.10, the fair spread >> 0.001
        cds = make_cds(
            coupon=0.001,
            is_buyer=True,
            recovery=0.40,
        )
        ms = make_market_state(hazard_rate=0.10)
        npv = cds.scenario_npvs(VAL_DATE, ms)
        # Buyer gets cheap protection relative to fair spread → positive NPV
        # (protection leg > premium leg for buyer)
        assert np.all(npv > 0), "Buyer should have positive NPV when coupon < fair spread"

    def test_buyer_receives_excess_at_high_coupon(self):
        """
        If coupon > fair spread, buyer gets worse deal → NPV < 0.
        """
        cds = make_cds(coupon=0.20, is_buyer=True, recovery=0.40)
        ms = make_market_state(hazard_rate=0.01)  # low default risk
        npv = cds.scenario_npvs(VAL_DATE, ms)
        assert np.all(npv < 0), "Buyer should have negative NPV when coupon > fair spread"


# ---------------------------------------------------------------------------
# Sensitivity
# ---------------------------------------------------------------------------

class TestCDSSensitivity:

    def test_npv_scales_with_notional(self):
        coupon = 0.05  # fixed coupon
        cds_1m = make_cds(coupon=coupon, notional=1_000_000)
        cds_2m = make_cds(coupon=coupon, notional=2_000_000)
        ms = make_market_state()
        npv_1m = cds_1m.scenario_npvs(VAL_DATE, ms)
        npv_2m = cds_2m.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(npv_2m, 2.0 * npv_1m, rtol=1e-10)

    def test_higher_hazard_rate_increases_protection_leg(self):
        """Higher hazard rate → more default probability → buyer benefits more (higher NPV)."""
        cds = make_cds(coupon=0.01, is_buyer=True)
        npv_low = cds.scenario_npvs(VAL_DATE, make_market_state(hazard_rate=0.01))
        npv_high = cds.scenario_npvs(VAL_DATE, make_market_state(hazard_rate=0.10))
        # Both could be positive or negative, but high hazard should produce higher NPV for buyer
        assert np.all(npv_high > npv_low), (
            "Higher hazard rate should increase protection buyer NPV"
        )

    def test_recovery_rate_effect(self):
        """Higher recovery → lower protection leg PV → lower buyer NPV."""
        cds_low_rec = make_cds(coupon=0.01, recovery=0.10)
        cds_high_rec = make_cds(coupon=0.01, recovery=0.70)
        ms = make_market_state(hazard_rate=0.05)
        npv_low = cds_low_rec.scenario_npvs(VAL_DATE, ms)
        npv_high = cds_high_rec.scenario_npvs(VAL_DATE, ms)
        assert np.all(npv_low > npv_high), (
            "Lower recovery should produce higher protection buyer NPV"
        )


# ---------------------------------------------------------------------------
# Fair spread / near-zero NPV
# ---------------------------------------------------------------------------

class TestCDSFairSpread:

    def test_near_fair_spread_npv_near_zero(self):
        """
        We can compute the approximate fair spread analytically for a flat
        hazard rate h and flat discount rate r:
            s ≈ h * (1 - R)  (in continuous approximation)
        We verify the NPV is in the right ballpark near this coupon.
        """
        h = 0.02
        r = 0.05
        R = 0.40
        # Approximate fair spread
        approx_fair = h * (1.0 - R)

        cds = make_cds(coupon=approx_fair, recovery=R)
        ms = make_market_state(disc_rate=r, hazard_rate=h)
        npv = cds.scenario_npvs(VAL_DATE, ms)
        # Not exactly zero, but should be small relative to notional
        assert np.all(np.abs(npv) < 50_000), (
            f"NPV {npv[0]:.2f} far from zero at approximate fair spread"
        )

    def test_buyer_seller_symmetry(self):
        """Buyer + seller NPV = 0 regardless of coupon level."""
        for coupon in [0.001, 0.01, 0.05, 0.10]:
            buyer = make_cds(coupon=coupon, is_buyer=True)
            seller = make_cds(coupon=coupon, is_buyer=False)
            ms = make_market_state()
            total = buyer.scenario_npvs(VAL_DATE, ms) + seller.scenario_npvs(VAL_DATE, ms)
            npt.assert_allclose(total, 0.0, atol=1e-6,
                                err_msg=f"Buyer+seller should sum to zero (coupon={coupon})")


# ---------------------------------------------------------------------------
# Integration: ScenarioCube → CDS.price
# ---------------------------------------------------------------------------

class TestCDSWithCube:

    def test_price_from_cube_time_slice(self):
        from datetime import timedelta
        sim_dates = (VAL_DATE, date(2025, 7, 2))
        n_times = len(sim_dates)
        curve_data = np.full((N_PATHS, n_times, len(TENORS)), DISC_RATE)
        credit_data = np.full((N_PATHS, n_times, len(TENORS)), HAZARD_RATE)

        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("DISC", curve_data, TENORS, dates=sim_dates)
        builder.add_curve_factor("CREDIT", credit_data, TENORS, dates=sim_dates)
        cube = builder.build()

        cds = make_cds(coupon=0.01)
        for t_idx in range(cube.n_times):
            ms = cube.get_time_slice(t_idx)
            sim_date = cube.dates[t_idx]
            npv = cds.scenario_npvs(sim_date, ms)
            assert npv.shape == (N_PATHS,)

    def test_get_reset_dates_empty_for_fixed_coupon(self):
        cds = make_cds(coupon=0.01)
        assert cds.get_reset_dates() == []
