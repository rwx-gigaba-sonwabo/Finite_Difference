"""Tests for the BenchmarkVolSkew volatility surface."""

import numpy as np
import pytest

from market_data.vol_surface import BenchmarkVolSkew


# ---------------------------------------------------------------------------
# Helpers – build a simple flat-term-structure skew for testing
# ---------------------------------------------------------------------------

def _flat_term(value: float) -> np.ndarray:
    """Return a single-point term structure (flat at *value*)."""
    return np.array([[1.0, value]])


def _make_skew(
    v0=0.20, s=-0.10, L=0.05, R=0.03, C=-0.20, D=0.20,
    lam=0.50, rho=0.50, atm_ref=100.0,
) -> BenchmarkVolSkew:
    return BenchmarkVolSkew(
        v0=_flat_term(v0),
        s=_flat_term(s),
        L=_flat_term(L),
        R=_flat_term(R),
        C=_flat_term(C),
        D=_flat_term(D),
        lam=_flat_term(lam),
        rho=_flat_term(rho),
        atm_ref=_flat_term(atm_ref),
    )


# ---------------------------------------------------------------------------
# ATM vol
# ---------------------------------------------------------------------------

class TestATMVol:
    def test_atm_returns_v0(self):
        skew = _make_skew()
        vol = skew.get_vol(strike=100.0, tenor=1.0)
        assert vol == pytest.approx(0.20, abs=1e-12)


# ---------------------------------------------------------------------------
# Piecewise continuity
# ---------------------------------------------------------------------------

class TestContinuity:
    """Volatility must be continuous at every region boundary."""

    @pytest.fixture()
    def skew(self):
        return _make_skew()

    @pytest.fixture()
    def params(self, skew):
        return skew._params_at_tenor(1.0)

    def test_continuity_at_C(self, skew, params):
        C = params["C"]
        eps = 1e-10
        v_left = skew.get_vol(strike=100.0 * np.exp(C - eps), tenor=1.0)
        v_right = skew.get_vol(strike=100.0 * np.exp(C + eps), tenor=1.0)
        assert v_left == pytest.approx(v_right, abs=1e-6)

    def test_continuity_at_D(self, skew, params):
        D = params["D"]
        eps = 1e-10
        v_left = skew.get_vol(strike=100.0 * np.exp(D - eps), tenor=1.0)
        v_right = skew.get_vol(strike=100.0 * np.exp(D + eps), tenor=1.0)
        assert v_left == pytest.approx(v_right, abs=1e-6)

    def test_continuity_at_left_wing(self, skew, params):
        lam_C = (1 + params["lam"]) * params["C"]
        eps = 1e-10
        v_left = skew.get_vol(strike=100.0 * np.exp(lam_C - eps), tenor=1.0)
        v_right = skew.get_vol(strike=100.0 * np.exp(lam_C + eps), tenor=1.0)
        assert v_left == pytest.approx(v_right, abs=1e-6)

    def test_continuity_at_right_wing(self, skew, params):
        rho_D = (1 + params["rho"]) * params["D"]
        eps = 1e-10
        v_left = skew.get_vol(strike=100.0 * np.exp(rho_D - eps), tenor=1.0)
        v_right = skew.get_vol(strike=100.0 * np.exp(rho_D + eps), tenor=1.0)
        assert v_left == pytest.approx(v_right, abs=1e-6)


# ---------------------------------------------------------------------------
# Flat wings
# ---------------------------------------------------------------------------

class TestFlatWings:
    def test_left_wing_is_flat(self):
        skew = _make_skew()
        # Deep OTM put – both in region I
        v1 = skew.get_vol(strike=100.0 * np.exp(-0.50), tenor=1.0)
        v2 = skew.get_vol(strike=100.0 * np.exp(-0.80), tenor=1.0)
        assert v1 == pytest.approx(v2, abs=1e-12)

    def test_right_wing_is_flat(self):
        skew = _make_skew()
        v1 = skew.get_vol(strike=100.0 * np.exp(0.50), tenor=1.0)
        v2 = skew.get_vol(strike=100.0 * np.exp(0.80), tenor=1.0)
        assert v1 == pytest.approx(v2, abs=1e-12)


# ---------------------------------------------------------------------------
# Degenerate parameters (no wings)
# ---------------------------------------------------------------------------

class TestNoWings:
    def test_zero_lambda_no_division_error(self):
        skew = _make_skew(lam=0.0)
        vol = skew.get_vol(strike=80.0, tenor=1.0)
        assert np.isfinite(vol)

    def test_zero_rho_no_division_error(self):
        skew = _make_skew(rho=0.0)
        vol = skew.get_vol(strike=120.0, tenor=1.0)
        assert np.isfinite(vol)

    def test_zero_C_no_division_error(self):
        skew = _make_skew(C=0.0)
        vol = skew.get_vol(strike=80.0, tenor=1.0)
        assert np.isfinite(vol)

    def test_zero_D_no_division_error(self):
        skew = _make_skew(D=0.0)
        vol = skew.get_vol(strike=120.0, tenor=1.0)
        assert np.isfinite(vol)

    def test_no_left_wing_flat_extrapolates(self):
        skew = _make_skew(lam=0.0)
        # Both deep OTM — should be flat at the value of v(C)
        v1 = skew.get_vol(strike=100.0 * np.exp(-0.50), tenor=1.0)
        v2 = skew.get_vol(strike=100.0 * np.exp(-0.80), tenor=1.0)
        assert v1 == pytest.approx(v2, abs=1e-12)

    def test_no_right_wing_flat_extrapolates(self):
        skew = _make_skew(rho=0.0)
        v1 = skew.get_vol(strike=100.0 * np.exp(0.50), tenor=1.0)
        v2 = skew.get_vol(strike=100.0 * np.exp(0.80), tenor=1.0)
        assert v1 == pytest.approx(v2, abs=1e-12)

    def test_atm_unaffected_by_zero_wings(self):
        skew_wings = _make_skew()
        skew_no_wings = _make_skew(lam=0.0, rho=0.0)
        v1 = skew_wings.get_vol(strike=100.0, tenor=1.0)
        v2 = skew_no_wings.get_vol(strike=100.0, tenor=1.0)
        assert v1 == pytest.approx(v2, abs=1e-12)


# ---------------------------------------------------------------------------
# Vectorised evaluation
# ---------------------------------------------------------------------------

class TestVectorised:
    def test_array_strikes(self):
        skew = _make_skew()
        strikes = np.array([80.0, 90.0, 100.0, 110.0, 120.0])
        vols = skew.get_vol(strike=strikes, tenor=1.0)
        assert vols.shape == (5,)
        # ATM should still be v0
        assert vols[2] == pytest.approx(0.20, abs=1e-10)
        # Lower strikes should have higher vol (negative slope s)
        assert vols[0] > vols[2]


# ---------------------------------------------------------------------------
# Sticky delta
# ---------------------------------------------------------------------------

class TestStickyDelta:
    def test_sticky_delta_differs_from_strike(self):
        skew = _make_skew()
        strike = 110.0
        fwd_skew = 105.0
        fwd_exp = 102.0
        vol_strike = skew.get_vol(strike=strike, tenor=1.0, sticky="strike")
        vol_delta = skew.get_vol(
            strike=strike, tenor=1.0,
            forward_skew=fwd_skew, forward_expiry=fwd_exp,
            sticky="delta",
        )
        # They should differ because fwd_skew != fwd_exp
        assert vol_strike != pytest.approx(vol_delta, abs=1e-6)

    def test_sticky_delta_equals_strike_when_fwds_equal(self):
        skew = _make_skew()
        strike = 110.0
        fwd = 100.0
        vol_strike = skew.get_vol(strike=strike, tenor=1.0, sticky="strike")
        vol_delta = skew.get_vol(
            strike=strike, tenor=1.0,
            forward_skew=fwd, forward_expiry=fwd,
            sticky="delta",
        )
        assert vol_strike == pytest.approx(vol_delta, abs=1e-12)


# ---------------------------------------------------------------------------
# Term structure interpolation
# ---------------------------------------------------------------------------

class TestTermStructure:
    def test_interpolation_of_v0_in_variance(self):
        v0_term = np.array([[0.5, 0.18], [1.0, 0.20], [2.0, 0.24]])
        skew = BenchmarkVolSkew(
            v0=v0_term,
            s=_flat_term(-0.10),
            L=_flat_term(0.05),
            R=_flat_term(0.03),
            C=_flat_term(-0.20),
            D=_flat_term(0.20),
            lam=_flat_term(0.50),
            rho=_flat_term(0.50),
            atm_ref=_flat_term(100.0),
        )
        # At tenor=0.75, v0 is interpolated in variance space:
        #   var(0.5) = 0.18^2 * 0.5 = 0.0162
        #   var(1.0) = 0.20^2 * 1.0 = 0.04
        #   var(0.75) = 0.0162 + (0.04 - 0.0162) * (0.75 - 0.5) / (1.0 - 0.5) = 0.0281
        #   vol(0.75) = sqrt(0.0281 / 0.75)
        expected_var = 0.0162 + (0.04 - 0.0162) * 0.5
        expected_vol = np.sqrt(expected_var / 0.75)
        vol = skew.get_vol(strike=100.0, tenor=0.75)
        assert vol == pytest.approx(expected_vol, abs=1e-10)
