"""
Tests for base_valuation/commodity_curve.py, base_valuation/commodity_digital_option.py,
and base_valuation/commodity_digital_barrier_option.py.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt
import pytest

from base_valuation.commodity_curve import build_commodity_forward_curve
from base_valuation.yield_curve import build_yield_curve
from base_valuation.commodity_digital_option import (
    value_commodity_digital_option,
    bump_and_reprice_commodity_digital_option,
)
from base_valuation.commodity_digital_barrier_option import (
    value_commodity_digital_barrier_option,
    bump_and_reprice_commodity_digital_barrier_option,
)
from models.commodity_digital_pv import (
    black76_digital_price,
    commodity_barrier_digital_price,
)
from utils.ql_helpers import DAY_COUNTERS, advance_business_days, to_ql_date

VAL_DATE = date(2025, 1, 2)
MATURITY = date(2026, 1, 2)

CURVE_DATES = [date(2025, 4, 2), date(2025, 7, 2), date(2026, 1, 2), date(2027, 1, 2), date(2030, 1, 2)]
CURVE_PRICES = [78.0, 79.0, 80.0, 82.0, 88.0]
DISC_DATES = [date(2025, 4, 2), date(2026, 1, 2), date(2027, 1, 2), date(2030, 1, 2)]
DISC_RATES = [0.05, 0.05, 0.05, 0.05]


def make_forward_curve():
    return build_commodity_forward_curve(VAL_DATE, CURVE_DATES, CURVE_PRICES)


def make_disc_curve():
    return build_yield_curve(VAL_DATE, DISC_DATES, DISC_RATES)


# ---------------------------------------------------------------------------
# CommodityForwardCurve
# ---------------------------------------------------------------------------

def test_forward_curve_exact_pillar_lookup():
    curve = make_forward_curve()
    npt.assert_allclose(curve.price_at(date(2026, 1, 2)), 80.0, rtol=1e-8)


def test_forward_curve_interpolates_between_pillars():
    curve = make_forward_curve()
    p = curve.price_at(date(2025, 5, 17))  # roughly midway between Apr and Jul pillars
    assert 78.0 < p < 79.0


def test_forward_curve_rejects_non_increasing_dates():
    with pytest.raises(ValueError):
        build_commodity_forward_curve(VAL_DATE, [date(2025, 6, 1), date(2025, 6, 1)], [1.0, 2.0])


def test_forward_curve_rejects_dates_before_val_date():
    with pytest.raises(ValueError):
        build_commodity_forward_curve(VAL_DATE, [date(2024, 1, 1)], [1.0])


# ---------------------------------------------------------------------------
# European digital
# ---------------------------------------------------------------------------

def test_value_matches_model_function_directly():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    vol = 0.30

    result = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=vol,
        spot_days=0, settle_days=0,
    )

    dc = DAY_COUNTERS["ACT/365"]
    T = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(MATURITY)))
    F = fwd_curve.price_at(MATURITY)
    df = float(disc_curve.discount_factor(T)[0])
    expected = float(black76_digital_price(
        np.array([F]), 80.0, np.array([vol]), np.array([df]), T, True, "cash", 100.0,
    )[0])
    npt.assert_allclose(result.price, expected, rtol=1e-8)
    npt.assert_allclose(result.forward, F)
    npt.assert_allclose(result.df, df)


def test_scalar_vol_accepted_as_plain_float():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    # vol passed as a bare python float (not an array/ScalarSlice) -- the
    # explicit requirement for the base_valuation layer.
    result = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.25,
    )
    assert isinstance(result.vol, float)
    assert result.vol == 0.25
    assert isinstance(result.price, float)


def test_settle_days_moves_discount_date_only():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    r0 = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3, settle_days=0,
    )
    r2 = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3, settle_days=10,
    )
    assert r0.T_opt == r2.T_opt          # untouched by settle_days
    assert r0.T_disc < r2.T_disc          # discount tenor moved
    assert r0.forward == r2.forward       # curve lookup untouched by settle_days


def test_spot_days_moves_curve_lookup_only():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    r0 = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3, spot_days=0,
    )
    r5 = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3, spot_days=5,
    )
    assert r0.T_opt == r5.T_opt
    assert r0.T_disc == r5.T_disc
    assert r0.forward != r5.forward  # sloped curve -> different lookup point


def test_analytic_greeks_match_bump_and_reprice():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    result = value_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
    )
    bump = bump_and_reprice_commodity_digital_option(
        val_date=VAL_DATE, maturity_date=MATURITY, strike=80.0, is_call=True,
        digital_type="cash", payout=100.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
    )
    npt.assert_allclose(result.analytic_delta, bump["delta"], rtol=1e-3)
    npt.assert_allclose(result.analytic_gamma, bump["gamma"], rtol=5e-2)


# ---------------------------------------------------------------------------
# Barrier digital
# ---------------------------------------------------------------------------

def test_continuous_barrier_matches_model_function():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    result = value_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        cost_of_carry=0.04, settle_days=0,
    )
    assert result.pricing_method == "closed_form"

    dc = DAY_COUNTERS["ACT/365"]
    T = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(MATURITY)))
    F = fwd_curve.price_at(MATURITY)
    df = float(disc_curve.discount_factor(T)[0])
    expected = float(commodity_barrier_digital_price(
        np.array([F]), 100.0, np.array([0.3]), np.array([0.04]), np.array([df]),
        T, "up", "in", 200.0,
    )[0])
    npt.assert_allclose(result.price, expected, rtol=1e-8)


def test_cost_of_carry_precedence_explicit_wins():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    result = value_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        cost_of_carry=0.07,
    )
    assert result.cost_of_carry == 0.07


def test_cost_of_carry_curve_implied_fallback():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    result = value_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        # neither cost_of_carry nor carry_curve given
    )
    assert np.isfinite(result.cost_of_carry)
    assert result.price >= 0.0


def test_discrete_monitoring_falls_back_to_monte_carlo():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    result = value_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        cost_of_carry=0.04, monitoring="discrete", n_mc_paths=5000,
    )
    assert result.pricing_method == "monte_carlo"
    assert result.mc_stderr is not None and result.mc_stderr >= 0.0


def test_double_barrier_warns_and_uses_monte_carlo():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    with pytest.warns(UserWarning, match="Monte Carlo"):
        result = value_commodity_digital_barrier_option(
            val_date=VAL_DATE, maturity_date=MATURITY,
            upper_barrier=100.0, lower_barrier=60.0, touch="in",
            digital_type="cash", payout=200.0,
            forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
            cost_of_carry=0.04, n_mc_paths=3000,
        )
    assert result.pricing_method == "monte_carlo"


def test_analytic_delta_vega_match_bump_and_reprice():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    result = value_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        cost_of_carry=0.04,
    )
    bump = bump_and_reprice_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        cost_of_carry=0.04,
    )
    npt.assert_allclose(result.analytic_delta, bump["delta"], rtol=2e-3)
    npt.assert_allclose(result.analytic_vega, bump["vega"], rtol=2e-3)


def test_bump_and_reprice_runs_for_discrete_and_double_barrier():
    fwd_curve = make_forward_curve()
    disc_curve = make_disc_curve()
    bump_discrete = bump_and_reprice_commodity_digital_barrier_option(
        val_date=VAL_DATE, maturity_date=MATURITY,
        upper_barrier=100.0, lower_barrier=None, touch="in",
        digital_type="cash", payout=200.0,
        forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
        cost_of_carry=0.04, monitoring="discrete", n_mc_paths=2000,
    )
    assert all(np.isfinite(v) for v in bump_discrete.values())

    with pytest.warns(UserWarning):
        bump_double = bump_and_reprice_commodity_digital_barrier_option(
            val_date=VAL_DATE, maturity_date=MATURITY,
            upper_barrier=100.0, lower_barrier=60.0, touch="in",
            digital_type="cash", payout=200.0,
            forward_curve=fwd_curve, discount_curve=disc_curve, vol=0.3,
            cost_of_carry=0.04, n_mc_paths=2000,
        )
    assert all(np.isfinite(v) for v in bump_double.values())