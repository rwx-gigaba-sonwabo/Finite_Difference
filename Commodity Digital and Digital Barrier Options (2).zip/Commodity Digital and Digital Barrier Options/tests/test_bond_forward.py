"""Tests for instruments/bond_forward.py and models/bond_pv.py."""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt
import pytest
import QuantLib as ql

from instruments.bond_forward import BondForward
from market_data.risk_factor import CurveSlice
from market_data.scenario_cube import ScenarioCubeBuilder
from market_data.yield_curve import YieldCurve
from models.bond_pv import accrued_interest, bond_pv
from utils.interpolation import linear_interpolator
from utils.ql_helpers import DAY_COUNTERS, advance_business_days, to_ql_date

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

N_PATHS = 8
VAL_DATE = date(2025, 1, 2)
EFFECTIVE = VAL_DATE
MATURITY = date(2030, 1, 2)       # 5-year bond
DELIVERY = date(2025, 7, 2)       # ~6-month forward delivery
COUPON_RATE = 0.08                 # 8 % annual
COUPON_FREQ = 6                    # semi-annual
NOTIONAL = 1_000_000.0
FLAT_RATE = 0.06

TENORS = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0], dtype=np.float64)
# BESA T+3 settlement: delivery_date + 3 business days (TARGET calendar)
DELIVERY_SETTLE = advance_business_days(DELIVERY, 3, "TARGET")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flat_curve_slice(rate: float = FLAT_RATE) -> CurveSlice:
    return CurveSlice(
        values=np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64),
        tenors=TENORS,
    )


def make_market_state(rate: float = FLAT_RATE) -> dict:
    return {"DISC": flat_curve_slice(rate)}


def single_path_curve(rate: float = FLAT_RATE) -> YieldCurve:
    return YieldCurve(
        TENORS,
        np.full((1, len(TENORS)), rate, dtype=np.float64),
        linear_interpolator,
    )


def make_bond_forward(
    forward_clean_price: float | None = None,
    direction: int = 1,
    notional: float = NOTIONAL,
    flat_rate: float = FLAT_RATE,
    effective: date = EFFECTIVE,
    maturity: date = MATURITY,
    delivery: date = DELIVERY,
) -> BondForward:
    if forward_clean_price is None:
        forward_clean_price = _fair_forward_clean_price(flat_rate, effective, maturity, delivery)
    return BondForward(
        name="TEST_FWD",
        effective_date=effective,
        maturity_date=maturity,
        delivery_date=delivery,
        coupon_rate=COUPON_RATE,
        coupon_frequency=COUPON_FREQ,
        notional=notional,
        forward_clean_price=forward_clean_price,
        bond_curve_name="DISC",
        interpolator=linear_interpolator,
        direction=direction,
        calendar="TARGET",
        day_count="ACT/365",
        curve_day_count="ACT/365",
    )


def _fair_forward_clean_price(
    rate: float,
    effective: date,
    maturity: date,
    delivery: date,
    settlement_lag: int = 3,
) -> float:
    """Compute the at-market clean forward price on a flat zero curve.

    Uses delivery_settle = delivery + settlement_lag BD as the effective
    delivery date so that the computed price is consistent with BondForward's
    internal T+settlement_lag pricing.
    """
    from instruments.components.schedule_config import ScheduleConfig
    sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
    schedule = sc.build_bond_schedule(effective, maturity, COUPON_FREQ)
    curve = single_path_curve(rate)
    dc = DAY_COUNTERS["ACT/365"]

    delivery_settle = advance_business_days(delivery, settlement_lag, "TARGET")

    # PV of cashflows after delivery_settle (single path)
    pv_after = bond_pv(schedule, COUPON_RATE, NOTIONAL, effective, curve, dc,
                       cutoff_date=delivery_settle)
    T_del = float(dc.yearFraction(to_ql_date(effective), to_ql_date(delivery_settle)))
    df_del = curve.discount_factor(T_del)

    # Fair dirty forward price (per unit notional as fraction)
    fair_dirty_frac = float(pv_after[0]) / (NOTIONAL * float(df_del[0]))

    # Subtract accrued interest at delivery_settle to get clean
    ai = accrued_interest(schedule, COUPON_RATE, delivery_settle, dc)
    return fair_dirty_frac - ai


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestBondForwardConstruction:

    def test_builds_without_error(self):
        bf = make_bond_forward()
        assert bf.name == "TEST_FWD"

    def test_schedule_not_empty(self):
        bf = make_bond_forward()
        assert len(bf._schedule) > 0

    def test_schedule_starts_at_effective(self):
        bf = make_bond_forward()
        first_start = bf._schedule[0][0]
        assert first_start == EFFECTIVE

    def test_schedule_ends_at_maturity(self):
        bf = make_bond_forward()
        last_end = max(e for _, e, _, _ in bf._schedule)
        assert last_end == MATURITY

    def test_delivery_before_maturity_validates(self):
        with pytest.raises(ValueError, match="delivery_date"):
            BondForward(
                name="BAD",
                effective_date=EFFECTIVE,
                maturity_date=MATURITY,
                delivery_date=date(2031, 1, 2),  # after maturity
                coupon_rate=COUPON_RATE,
                coupon_frequency=COUPON_FREQ,
                notional=NOTIONAL,
                forward_clean_price=0.98,
                bond_curve_name="DISC",
                interpolator=linear_interpolator,
                calendar="TARGET",
            )

    def test_delivery_equal_maturity_raises(self):
        with pytest.raises(ValueError):
            BondForward(
                name="BAD",
                effective_date=EFFECTIVE,
                maturity_date=MATURITY,
                delivery_date=MATURITY,
                coupon_rate=COUPON_RATE,
                coupon_frequency=COUPON_FREQ,
                notional=NOTIONAL,
                forward_clean_price=0.98,
                bond_curve_name="DISC",
                interpolator=linear_interpolator,
                calendar="TARGET",
            )


# ---------------------------------------------------------------------------
# Output shape and dtype
# ---------------------------------------------------------------------------

class TestBondForwardShape:

    def test_output_shape(self):
        bf = make_bond_forward()
        npv = bf.scenario_npvs(VAL_DATE, make_market_state())
        assert npv.shape == (N_PATHS,)

    def test_output_dtype_float(self):
        bf = make_bond_forward()
        npv = bf.scenario_npvs(VAL_DATE, make_market_state())
        assert npv.dtype == np.float64

    def test_n_paths_one(self):
        bf = make_bond_forward()
        state = {"DISC": CurveSlice(
            values=np.full((1, len(TENORS)), FLAT_RATE),
            tenors=TENORS,
        )}
        npv = bf.scenario_npvs(VAL_DATE, state)
        assert npv.shape == (1,)


# ---------------------------------------------------------------------------
# Expiry
# ---------------------------------------------------------------------------

class TestBondForwardExpiry:

    def test_nonzero_on_delivery_date(self):
        """Between delivery_date and delivery_settle the forward is still live (T+3 stub).

        An at-market forward on a flat curve always has NPV = 0 by construction,
        so we use an off-market settlement_amount to confirm the position is live
        (i.e. the T+3 expiry check has NOT fired at delivery_date).
        """
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(FLAT_RATE)
        dc = DAY_COUNTERS["ACT/365"]

        pv_after = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                                  cutoff_date=DELIVERY_SETTLE)[0])
        T_del = float(dc.yearFraction(to_ql_date(EFFECTIVE), to_ql_date(DELIVERY_SETTLE)))
        fair_dirty = pv_after / float(curve.discount_factor(T_del)[0])
        # Buyer pays 2 % below fair dirty -> position is in the money
        off_market_sa = fair_dirty * 0.98

        bf = BondForward(
            name="STUB_TEST",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=0.0,
            bond_curve_name="DISC", interpolator=linear_interpolator,
            settlement_amount=off_market_sa, calendar="TARGET",
            day_count="ACT/365", curve_day_count="ACT/365",
        )
        npv = bf.scenario_npvs(DELIVERY, make_market_state())
        # If the T+3 expiry check fires here the NPV would be exactly zero;
        # non-zero means the stub window is correctly kept live.
        assert np.all(npv != 0.0), (
            "NPV must be non-zero on delivery_date: settlement does not occur until "
            f"delivery_settle={DELIVERY_SETTLE} (delivery_date + 3 BD)"
        )

    def test_zero_on_delivery_settle_date(self):
        """NPV = 0 on the delivery settlement date (delivery_date + 3 BD)."""
        bf = make_bond_forward()
        npv = bf.scenario_npvs(DELIVERY_SETTLE, make_market_state())
        npt.assert_array_equal(npv, np.zeros(N_PATHS))

    def test_zero_after_delivery_settle_date(self):
        """NPV remains zero for all dates after delivery settlement."""
        import datetime
        bf = make_bond_forward()
        after = DELIVERY_SETTLE + datetime.timedelta(days=30)
        npv = bf.scenario_npvs(after, make_market_state())
        npt.assert_array_equal(npv, np.zeros(N_PATHS))


# ---------------------------------------------------------------------------
# At-market: NPV ≈ 0 at inception
# ---------------------------------------------------------------------------

class TestBondForwardAtMarket:

    def test_at_market_npv_near_zero(self):
        """Fair forward price implies zero NPV on the pricing date."""
        bf = make_bond_forward()
        npv = bf.scenario_npvs(VAL_DATE, make_market_state())
        # All paths see the same flat curve, so NPVs should be identical and ≈ 0
        npt.assert_allclose(npv, 0.0, atol=1e-6)

    def test_at_market_all_paths_identical(self):
        """Flat curve → all paths produce the same NPV."""
        bf = make_bond_forward()
        npv = bf.scenario_npvs(VAL_DATE, make_market_state())
        npt.assert_allclose(npv, npv[0], rtol=1e-12)

    def test_higher_rate_shifts_forward_price(self):
        """A higher-rate fair forward price yields zero NPV at the higher rate."""
        higher_rate = 0.08
        fair_price = _fair_forward_clean_price(higher_rate, EFFECTIVE, MATURITY, DELIVERY)
        bf = make_bond_forward(forward_clean_price=fair_price, flat_rate=higher_rate)
        npv = bf.scenario_npvs(VAL_DATE, make_market_state(higher_rate))
        npt.assert_allclose(npv, 0.0, atol=1e-6)


# ---------------------------------------------------------------------------
# Direction
# ---------------------------------------------------------------------------

class TestBondForwardDirection:

    def test_long_plus_short_is_zero(self):
        """Buyer + seller NPVs cancel out exactly."""
        bf_long = make_bond_forward(direction=1)
        bf_short = make_bond_forward(direction=-1)
        ms = make_market_state()
        npv_long = bf_long.scenario_npvs(VAL_DATE, ms)
        npv_short = bf_short.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(npv_long + npv_short, 0.0, atol=1e-10)

    def test_off_market_long_positive_when_rate_falls(self):
        """When rates fall after a forward is struck, the buyer is in the money."""
        # Strike the forward at the fair price for FLAT_RATE
        fair_price = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)
        bf_long = make_bond_forward(forward_clean_price=fair_price, direction=1)
        # Now rates fall: bond prices rise, long forward gains
        lower_rate = 0.04
        npv = bf_long.scenario_npvs(VAL_DATE, make_market_state(lower_rate))
        assert np.all(npv > 0), "Long forward should be in the money when rates fall"

    def test_off_market_long_negative_when_rate_rises(self):
        """When rates rise, the buyer of the forward is out of the money."""
        fair_price = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)
        bf_long = make_bond_forward(forward_clean_price=fair_price, direction=1)
        higher_rate = 0.10
        npv = bf_long.scenario_npvs(VAL_DATE, make_market_state(higher_rate))
        assert np.all(npv < 0), "Long forward should be out of the money when rates rise"


# ---------------------------------------------------------------------------
# Notional scaling
# ---------------------------------------------------------------------------

class TestBondForwardNotional:

    def test_npv_scales_linearly_with_notional(self):
        """Doubling notional doubles NPV."""
        fair = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)
        # Use an off-market price to get nonzero NPV
        off_price = fair * 0.98
        ms = make_market_state()
        bf1 = make_bond_forward(forward_clean_price=off_price, notional=NOTIONAL)
        bf2 = make_bond_forward(forward_clean_price=off_price, notional=2 * NOTIONAL)
        npv1 = bf1.scenario_npvs(VAL_DATE, ms)
        npv2 = bf2.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(npv2, 2 * npv1, rtol=1e-10)


# ---------------------------------------------------------------------------
# Accrued interest helper
# ---------------------------------------------------------------------------

class TestAccruedInterest:

    def _get_schedule(self) -> list:
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        return sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)

    def test_zero_on_coupon_date(self):
        """Accrued interest resets to zero on a coupon payment date."""
        schedule = self._get_schedule()
        # First coupon end date is a coupon payment date
        first_coupon_date = schedule[0][1]
        dc = DAY_COUNTERS["ACT/365"]
        ai = accrued_interest(schedule, COUPON_RATE, first_coupon_date, dc)
        assert ai == 0.0

    def test_positive_mid_period(self):
        """Accrued interest is positive in the middle of a coupon period."""
        schedule = self._get_schedule()
        dc = DAY_COUNTERS["ACT/365"]
        # Pick a date midway through the first coupon period
        s, e, _, _ = schedule[0]
        days = (e - s).days
        mid = date(s.year, s.month, s.day)
        import datetime
        mid = s + datetime.timedelta(days=days // 2)
        ai = accrued_interest(schedule, COUPON_RATE, mid, dc)
        assert ai > 0.0

    def test_ai_less_than_full_coupon(self):
        """Accrued interest never exceeds a full coupon payment."""
        schedule = self._get_schedule()
        dc = DAY_COUNTERS["ACT/365"]
        # Just before first coupon
        import datetime
        just_before = schedule[0][1] - datetime.timedelta(days=1)
        ai = accrued_interest(schedule, COUPON_RATE, just_before, dc)
        full_coupon = COUPON_RATE * schedule[0][3]
        assert ai < full_coupon + 1e-8


# ---------------------------------------------------------------------------
# Bond PV helper
# ---------------------------------------------------------------------------

class TestBondPV:

    def _make(self, rate=FLAT_RATE):
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(rate)
        dc = DAY_COUNTERS["ACT/365"]
        return schedule, curve, dc

    def test_full_bond_pv_shape(self):
        schedule, curve, dc = self._make()
        pv = bond_pv(schedule, COUPON_RATE, NOTIONAL, VAL_DATE, curve, dc)
        assert pv.shape == (1,)

    def test_full_bond_pv_positive(self):
        schedule, curve, dc = self._make()
        pv = bond_pv(schedule, COUPON_RATE, NOTIONAL, VAL_DATE, curve, dc)
        assert float(pv[0]) > 0.0

    def test_cutoff_reduces_pv(self):
        """PV with cutoff_date < maturity is less than full bond PV."""
        schedule, curve, dc = self._make()
        pv_full = bond_pv(schedule, COUPON_RATE, NOTIONAL, VAL_DATE, curve, dc)
        pv_cut = bond_pv(schedule, COUPON_RATE, NOTIONAL, VAL_DATE, curve, dc, cutoff_date=DELIVERY)
        assert float(pv_cut[0]) < float(pv_full[0])

    def test_coupon_rate_zero_gives_discount_bond(self):
        """Zero coupon → PV equals discounted notional only."""
        schedule, curve, dc = self._make()
        T_mat = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(MATURITY)))
        expected = NOTIONAL * float(np.exp(-FLAT_RATE * T_mat))
        pv = bond_pv(schedule, 0.0, NOTIONAL, VAL_DATE, curve, dc)
        npt.assert_allclose(float(pv[0]), expected, rtol=1e-6)

    def test_past_maturity_returns_zeros(self):
        schedule, curve, dc = self._make()
        pv = bond_pv(schedule, COUPON_RATE, NOTIONAL, date(2031, 1, 2), curve, dc)
        assert pv.shape == (1,)
        npt.assert_array_equal(pv, 0.0)


# ---------------------------------------------------------------------------
# ScenarioCube integration
# ---------------------------------------------------------------------------

class TestBondForwardCubeIntegration:

    def test_scenario_cube_workflow(self):
        """Full end-to-end: build a ScenarioCube and price across time steps.

        With T+3 settlement, NPV is non-zero on delivery_date (booking date)
        because cash doesn't exchange until delivery_settle = delivery_date + 3 BD.
        NPV is zero only from delivery_settle onward.
        """
        sim_dates = (
            date(2025, 1, 2),
            date(2025, 4, 2),
            date(2025, 7, 2),   # delivery_date: still live (T+3 stub window)
            date(2025, 10, 2),  # post-delivery_settle: zeros
        )
        n_times = len(sim_dates)
        # Curve data: (n_paths, n_times, n_tenors) — flat rate on all paths/times
        curve_data = np.full((N_PATHS, n_times, len(TENORS)), FLAT_RATE)
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=sim_dates[0])
        builder.add_curve_factor("DISC", curve_data, TENORS, sim_dates)
        cube = builder.build()

        bf = make_bond_forward()

        for i, d in enumerate(sim_dates):
            ms = cube.get_time_slice(i)
            npv = bf.scenario_npvs(d, ms)
            assert npv.shape == (N_PATHS,)
            # Zero only after delivery_settle (DELIVERY + 3 BD), not at delivery_date itself
            if d >= DELIVERY_SETTLE:
                npt.assert_array_equal(npv, np.zeros(N_PATHS))

    def test_npv_decreases_toward_delivery_at_market(self):
        """At-market forward NPV remains near zero as we approach delivery."""
        fair = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)
        bf = make_bond_forward(forward_clean_price=fair)
        ms = make_market_state()

        pre_delivery_dates = [
            date(2025, 1, 2),
            date(2025, 3, 2),
            date(2025, 5, 2),
        ]
        for d in pre_delivery_dates:
            # Recompute fair price at each horizon for a truly at-market test
            fair_d = _fair_forward_clean_price(FLAT_RATE, d, MATURITY, DELIVERY)
            bf_d = make_bond_forward(forward_clean_price=fair_d)
            npv = bf_d.scenario_npvs(d, ms)
            npt.assert_allclose(npv, 0.0, atol=1e-5)

    def test_npv_instrument_npv_method(self):
        """The convenience npv() method returns a scalar consistent with scenario_npvs."""
        state_1path = {
            "DISC": CurveSlice(
                values=np.full((1, len(TENORS)), FLAT_RATE),
                tenors=TENORS,
            )
        }
        bf = make_bond_forward()
        scalar_npv = bf.npv(VAL_DATE, state_1path)
        assert isinstance(scalar_npv, float)
        arr_npv = bf.scenario_npvs(VAL_DATE, state_1path)
        assert scalar_npv == float(arr_npv[0])


# ---------------------------------------------------------------------------
# BESA CUMEX (ex-coupon) accrued interest
# ---------------------------------------------------------------------------

class TestBesaCumex:
    """Verify the BESA ex-coupon (CUMEX=0) accrued-interest logic."""

    def _schedule_and_dc(self):
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        return schedule, DAY_COUNTERS["ACT/365"]

    def _first_coupon_date(self, schedule) -> date:
        return schedule[0][1]

    def _book_close_date(self, coupon_date: date, ex_days: int = 10) -> date:
        """Return the first date inside the ex-coupon window (BCD itself)."""
        cal = ql.TARGET()
        ql_ncd = to_ql_date(coupon_date)
        bcd = cal.advance(ql_ncd, ql.Period(-ex_days, ql.Days), ql.Preceding)
        return date(bcd.year(), bcd.month(), bcd.dayOfMonth())

    def test_cumex_disabled_by_default_gives_positive_ai(self):
        """Without ex_coupon_days, AI is always positive inside the book-close window."""
        schedule, dc = self._schedule_and_dc()
        ncd = self._first_coupon_date(schedule)
        # Delivery 3 calendar days before coupon (well inside 10-BD window for most calendars)
        import datetime
        delivery_xc = ncd - datetime.timedelta(days=3)
        ai = accrued_interest(schedule, COUPON_RATE, delivery_xc, dc)
        assert ai > 0.0, "Default behaviour (no CUMEX) must return positive AI"

    def test_cumex_enabled_inside_window_gives_negative_ai(self):
        """With ex_coupon_days=10 and TARGET calendar, AI is negative inside book-close."""
        schedule, dc = self._schedule_and_dc()
        ncd = self._first_coupon_date(schedule)
        bcd = self._book_close_date(ncd, ex_days=10)
        # Delivery on the book-close date itself (first day inside window)
        ai = accrued_interest(
            schedule, COUPON_RATE, bcd, dc,
            ex_coupon_days=10, calendar=ql.TARGET(),
        )
        assert ai < 0.0, "AI must be negative when delivery is on the book-close date"

    def test_cumex_enabled_outside_window_gives_positive_ai(self):
        """One business day before book-close, AI is still positive (CUMEX=1)."""
        import datetime
        schedule, dc = self._schedule_and_dc()
        ncd = self._first_coupon_date(schedule)
        bcd = self._book_close_date(ncd, ex_days=10)
        # One calendar day before BCD — outside the window
        delivery_normal = bcd - datetime.timedelta(days=1)
        ai = accrued_interest(
            schedule, COUPON_RATE, delivery_normal, dc,
            ex_coupon_days=10, calendar=ql.TARGET(),
        )
        assert ai > 0.0, "AI must be positive just before the book-close date"

    def test_cumex_ai_magnitude_matches_besa_formula(self):
        """Negative AI equals coupon_rate * yearFraction(delivery, NCD) exactly."""
        schedule, dc = self._schedule_and_dc()
        ncd = self._first_coupon_date(schedule)
        bcd = self._book_close_date(ncd, ex_days=10)
        ai = accrued_interest(
            schedule, COUPON_RATE, bcd, dc,
            ex_coupon_days=10, calendar=ql.TARGET(),
        )
        # BESA formula: AI = -coupon_rate * ACT365(BCD, NCD)
        expected = -COUPON_RATE * float(dc.yearFraction(to_ql_date(bcd), to_ql_date(ncd)))
        npt.assert_allclose(ai, expected, rtol=1e-12)

    def test_cumex_bond_forward_npv_uses_negative_ai(self):
        """BondForward with ex_coupon_days=10 uses negative AI, shifting NPV vs no-CUMEX."""
        import datetime
        from instruments.components.schedule_config import ScheduleConfig

        # Identify first coupon date and construct a delivery inside the window
        sc_ref = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc_ref.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        ncd = schedule[0][1]
        bcd = self._book_close_date(ncd, ex_days=10)

        # Compute at-market price ignoring CUMEX (so the CUMEX version is off-market)
        fair_no_cumex = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, bcd)

        ms = make_market_state()

        bf_no_cumex = BondForward(
            name="NO_CUMEX",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=bcd,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=fair_no_cumex,
            bond_curve_name="DISC", interpolator=linear_interpolator,
            ex_coupon_days=0, calendar="TARGET",
            day_count="ACT/365", curve_day_count="ACT/365",
        )
        bf_cumex = BondForward(
            name="CUMEX",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=bcd,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=fair_no_cumex,
            bond_curve_name="DISC", interpolator=linear_interpolator,
            ex_coupon_days=10, calendar="TARGET",
            day_count="ACT/365", curve_day_count="ACT/365",
        )

        npv_no_cumex = bf_no_cumex.scenario_npvs(VAL_DATE, ms)
        npv_cumex = bf_cumex.scenario_npvs(VAL_DATE, ms)

        # CUMEX changes AI at delivery -> different forward dirty price -> different NPV
        assert not np.allclose(npv_cumex, npv_no_cumex), \
            "CUMEX and no-CUMEX NPV must differ when delivery is inside the book-close window"


# ---------------------------------------------------------------------------
# Settlement amount (absolute dirty strike)
# ---------------------------------------------------------------------------

class TestSettlementAmount:
    """settlement_amount takes priority over forward_clean_price + AI."""

    def _fair_settlement_amount(self, rate: float = FLAT_RATE) -> float:
        """Compute the at-market settlement amount (dirty) for the default forward."""
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(rate)
        dc = DAY_COUNTERS["ACT/365"]

        pv_after = bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                           cutoff_date=DELIVERY_SETTLE)
        T_del = float(dc.yearFraction(to_ql_date(EFFECTIVE), to_ql_date(DELIVERY_SETTLE)))
        df_del = float(curve.discount_factor(T_del)[0])
        return float(pv_after[0]) / df_del

    def test_settlement_amount_at_market_gives_zero_npv(self):
        """Specifying the fair dirty settlement amount produces zero NPV on all paths."""
        fair_sa = self._fair_settlement_amount()
        bf = BondForward(
            name="SA_TEST",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=0.0,  # ignored when settlement_amount set
            bond_curve_name="DISC", interpolator=linear_interpolator,
            settlement_amount=fair_sa, calendar="TARGET",
            day_count="ACT/365", curve_day_count="ACT/365",
        )
        npv = bf.scenario_npvs(VAL_DATE, make_market_state())
        npt.assert_allclose(npv, 0.0, atol=1e-6)

    def test_settlement_amount_overrides_forward_clean_price(self):
        """NPV from settlement_amount differs from the same clean price with different AI."""
        # Compute the at-market clean price and its implied dirty settlement amount
        fair_clean = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)

        # BondForward using the clean price path (standard)
        bf_clean = make_bond_forward(forward_clean_price=fair_clean)
        npv_clean = bf_clean.scenario_npvs(VAL_DATE, make_market_state())

        # BondForward with a settlement_amount set to a deliberately wrong value
        # (2% below fair dirty) — should produce a different NPV
        from instruments.components.schedule_config import ScheduleConfig
        sc_ref = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc_ref.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        ai = accrued_interest(schedule, COUPON_RATE, DELIVERY_SETTLE, DAY_COUNTERS["ACT/365"])
        fair_dirty = (fair_clean + ai) * NOTIONAL
        off_dirty = fair_dirty * 0.98  # 2% below fair -> buyer is in-the-money

        bf_sa = BondForward(
            name="SA_OFF",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=fair_clean,  # would give zero NPV alone
            bond_curve_name="DISC", interpolator=linear_interpolator,
            settlement_amount=off_dirty,  # overrides clean price -> positive NPV
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )
        npv_sa = bf_sa.scenario_npvs(VAL_DATE, make_market_state())

        # settlement_amount path should be ITM (buyer pays less than fair)
        assert np.all(npv_sa > 0), "settlement_amount below fair dirty must give positive NPV"
        assert not np.allclose(npv_sa, npv_clean), \
            "settlement_amount must override forward_clean_price"

    def test_settlement_amount_direction_symmetry(self):
        """Long + short with the same settlement_amount sum to zero."""
        fair_sa = self._fair_settlement_amount() * 0.98  # off-market to get nonzero NPV
        ms = make_market_state()
        bf_long = BondForward(
            name="L", effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=0.0, bond_curve_name="DISC",
            interpolator=linear_interpolator, direction=1, settlement_amount=fair_sa,
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )
        bf_short = BondForward(
            name="S", effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=0.0, bond_curve_name="DISC",
            interpolator=linear_interpolator, direction=-1, settlement_amount=fair_sa,
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )
        npt.assert_allclose(
            bf_long.scenario_npvs(VAL_DATE, ms) + bf_short.scenario_npvs(VAL_DATE, ms),
            0.0, atol=1e-10,
        )


# ---------------------------------------------------------------------------
# Compounding bond
# ---------------------------------------------------------------------------

class TestCompounding:
    """Verify the compounding bond PV and forward pricing logic."""

    def _make_compounding_pv(self, rate: float = FLAT_RATE) -> float:
        """Compounded terminal PV for a single-path flat curve."""
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(rate)
        dc = DAY_COUNTERS["ACT/365"]

        terminal = NOTIONAL
        for _, _, _, a in schedule:
            terminal *= 1.0 + COUPON_RATE * a

        T_mat = float(dc.yearFraction(to_ql_date(EFFECTIVE), to_ql_date(MATURITY)))
        df_mat = float(curve.discount_factor(T_mat)[0])
        return terminal * df_mat

    def test_compounding_pv_higher_than_simple(self):
        """Compounding bond PV > simple-coupon bond PV (same rate, same notional)."""
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(FLAT_RATE)
        dc = DAY_COUNTERS["ACT/365"]

        pv_simple = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc)[0])
        pv_compound = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                                    compounding=True)[0])
        assert pv_compound > pv_simple, \
            "Compounding accumulates more value than periodic payouts at the same rate"

    def test_compounding_terminal_matches_formula(self):
        """bond_pv(compounding=True) equals notional * prod(1 + r*a) * DF(maturity)."""
        expected = self._make_compounding_pv()
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(FLAT_RATE)
        dc = DAY_COUNTERS["ACT/365"]

        result = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                                compounding=True)[0])
        npt.assert_allclose(result, expected, rtol=1e-12)

    def test_compounding_cutoff_still_zeros_past_maturity(self):
        """bond_pv with compounding=True and cutoff_date past maturity returns zeros."""
        from instruments.components.schedule_config import ScheduleConfig
        sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(FLAT_RATE)
        dc = DAY_COUNTERS["ACT/365"]

        pv = bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                     cutoff_date=date(2031, 1, 1), compounding=True)
        npt.assert_array_equal(pv, 0.0)

    def test_compounding_forward_at_market_zero_npv_via_settlement_amount(self):
        """A compounding bond forward is zero NPV when settlement_amount = fair dirty."""
        from instruments.components.schedule_config import ScheduleConfig
        sc_ref = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc_ref.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(FLAT_RATE)
        dc = DAY_COUNTERS["ACT/365"]

        # Fair settlement amount = PV_after_delivery_settle / DF(delivery_settle)
        pv_after = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                                  cutoff_date=DELIVERY_SETTLE, compounding=True)[0])
        T_del = float(dc.yearFraction(to_ql_date(EFFECTIVE), to_ql_date(DELIVERY_SETTLE)))
        df_del = float(curve.discount_factor(T_del)[0])
        fair_sa = pv_after / df_del

        bf = BondForward(
            name="COMP_FWD",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=0.0,
            bond_curve_name="DISC", interpolator=linear_interpolator,
            compounding=True, settlement_amount=fair_sa,
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )
        npv = bf.scenario_npvs(VAL_DATE, make_market_state())
        npt.assert_allclose(npv, 0.0, atol=1e-6)

    def test_compounding_forward_pv_higher_than_simple_pv_after(self):
        """Post-delivery PV for compounding bond > simple bond (same params)."""
        from instruments.components.schedule_config import ScheduleConfig
        sc_ref = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
        schedule = sc_ref.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
        curve = single_path_curve(FLAT_RATE)
        dc = DAY_COUNTERS["ACT/365"]

        pv_simple = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                                   cutoff_date=DELIVERY)[0])
        pv_compound = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE, curve, dc,
                                     cutoff_date=DELIVERY, compounding=True)[0])
        assert pv_compound > pv_simple


# ---------------------------------------------------------------------------
# Three-curve framework (bond / repo / forward-swap)
# ---------------------------------------------------------------------------

BOND_RATE  = 0.085   # ZAR-BOND  -- government bond yield
REPO_RATE  = 0.075   # ZAR-BOND-REPO -- repo financing rate
SWAP_RATE  = 0.065   # ZAR-SWAP  -- OIS / swap payoff discount rate


def _three_curve_market(
    bond_rate: float = BOND_RATE,
    repo_rate: float = REPO_RATE,
    swap_rate: float = SWAP_RATE,
    n_paths: int = N_PATHS,
) -> dict:
    """Market state with three distinct curve slices."""
    def _slice(rate):
        return CurveSlice(
            values=np.full((n_paths, len(TENORS)), rate, dtype=np.float64),
            tenors=TENORS,
        )
    return {
        "ZAR-BOND": _slice(bond_rate),
        "ZAR-BOND-REPO": _slice(repo_rate),
        "ZAR-SWAP": _slice(swap_rate),
    }


def _three_curve_fair_settlement(
    bond_rate: float = BOND_RATE,
    repo_rate: float = REPO_RATE,
) -> float:
    """Fair dirty settlement amount in ZAR using the three-curve formula.

    At-market condition: K_dirty = PV_after_bond / DF_repo
    """
    from instruments.components.schedule_config import ScheduleConfig
    sc = ScheduleConfig(calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365")
    schedule = sc.build_bond_schedule(EFFECTIVE, MATURITY, COUPON_FREQ)
    bond_crv = single_path_curve(bond_rate)
    repo_crv = single_path_curve(repo_rate)
    dc = DAY_COUNTERS["ACT/365"]

    pv_after = float(bond_pv(schedule, COUPON_RATE, NOTIONAL, EFFECTIVE,
                              bond_crv, dc, cutoff_date=DELIVERY_SETTLE)[0])
    T_del = float(dc.yearFraction(to_ql_date(EFFECTIVE), to_ql_date(DELIVERY_SETTLE)))
    df_repo = float(repo_crv.discount_factor(T_del)[0])
    return pv_after / df_repo


class TestThreeCurve:
    """Verify the three-curve bond forward pricing framework."""

    def _make(
        self,
        settlement_amount: float | None = None,
        forward_clean_price: float = 0.0,
        direction: int = 1,
        repo_curve_name: str | None = "ZAR-BOND-REPO",
        forward_curve_name: str | None = "ZAR-SWAP",
    ) -> BondForward:
        return BondForward(
            name="3C",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=forward_clean_price,
            bond_curve_name="ZAR-BOND", interpolator=linear_interpolator,
            direction=direction,
            repo_curve_name=repo_curve_name,
            forward_curve_name=forward_curve_name,
            settlement_amount=settlement_amount,
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )

    def test_three_curve_at_market_zero_npv(self):
        """Fair settlement amount from repo curve gives zero NPV across all paths."""
        fair_sa = _three_curve_fair_settlement(BOND_RATE, REPO_RATE)
        bf = self._make(settlement_amount=fair_sa)
        npv = bf.scenario_npvs(VAL_DATE, _three_curve_market())
        npt.assert_allclose(npv, 0.0, atol=1e-5)

    def test_three_curve_differs_from_single_curve(self):
        """Three-curve NPV differs from single-curve when repo != bond rate."""
        # Fair price computed with repo curve (three-curve)
        fair_sa_3c = _three_curve_fair_settlement(BOND_RATE, REPO_RATE)

        # Same settlement amount priced on single-curve vs three-curve market
        bf = self._make(settlement_amount=fair_sa_3c)
        npv_3c = bf.scenario_npvs(VAL_DATE, _three_curve_market())   # three-curve: ~0

        # Single-curve market: bond_curve used for all three roles
        ms_single = {"ZAR-BOND": CurveSlice(
            values=np.full((N_PATHS, len(TENORS)), BOND_RATE, dtype=np.float64),
            tenors=TENORS,
        )}
        bf_single = BondForward(
            name="1C",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=0.0,
            bond_curve_name="ZAR-BOND", interpolator=linear_interpolator,
            settlement_amount=fair_sa_3c,
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )
        npv_1c = bf_single.scenario_npvs(VAL_DATE, ms_single)  # single-curve: not zero

        # The two should differ because REPO_RATE != BOND_RATE
        assert not np.allclose(npv_3c, npv_1c), \
            "Three-curve NPV must differ from single-curve when repo != bond rate"

    def test_three_curve_collapses_to_single_curve_when_rates_equal(self):
        """When all three rates are identical the three-curve formula reduces to single-curve."""
        rate = FLAT_RATE
        fair_clean = _fair_forward_clean_price(rate, EFFECTIVE, MATURITY, DELIVERY)

        # Single-curve instrument (no repo/forward names)
        bf_1c = make_bond_forward(forward_clean_price=fair_clean)
        ms_1c = make_market_state(rate)

        # Three-curve instrument but all rates equal
        ms_3c = {
            "ZAR-BOND": CurveSlice(values=np.full((N_PATHS, len(TENORS)), rate), tenors=TENORS),
            "ZAR-BOND-REPO": CurveSlice(values=np.full((N_PATHS, len(TENORS)), rate), tenors=TENORS),
            "ZAR-SWAP": CurveSlice(values=np.full((N_PATHS, len(TENORS)), rate), tenors=TENORS),
        }
        bf_3c = BondForward(
            name="3C_EQUAL",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=fair_clean,
            bond_curve_name="ZAR-BOND", interpolator=linear_interpolator,
            repo_curve_name="ZAR-BOND-REPO", forward_curve_name="ZAR-SWAP",
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )

        npv_1c = bf_1c.scenario_npvs(VAL_DATE, ms_1c)
        npv_3c = bf_3c.scenario_npvs(VAL_DATE, ms_3c)
        npt.assert_allclose(npv_3c, npv_1c, rtol=1e-12,
                            err_msg="Equal rates: three-curve must match single-curve exactly")

    def test_three_curve_long_plus_short_is_zero(self):
        """Long + short with identical three-curve setup must net to zero."""
        fair_sa = _three_curve_fair_settlement(BOND_RATE, REPO_RATE) * 0.98
        ms = _three_curve_market()
        npv_long  = self._make(settlement_amount=fair_sa, direction=+1).scenario_npvs(VAL_DATE, ms)
        npv_short = self._make(settlement_amount=fair_sa, direction=-1).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(npv_long + npv_short, 0.0, atol=1e-10)

    def test_discount_curve_name_property_returns_forward_curve(self):
        """discount_curve_name property returns forward_curve_name for CSA compatibility."""
        bf = self._make(forward_curve_name="ZAR-SWAP")
        assert bf.discount_curve_name == "ZAR-SWAP"

    def test_discount_curve_name_property_falls_back_to_bond_curve(self):
        """When forward_curve_name is None, discount_curve_name returns bond_curve_name."""
        bf = self._make(forward_curve_name=None, repo_curve_name=None)
        assert bf.discount_curve_name == "ZAR-BOND"

    def test_missing_repo_or_forward_curve_falls_back_gracefully(self):
        """If repo/forward keys are not in market_state, falls back to bond_curve."""
        fair_clean = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)
        bf = BondForward(
            name="FALLBACK",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=DELIVERY,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=fair_clean,
            bond_curve_name="ZAR-BOND", interpolator=linear_interpolator,
            repo_curve_name="ZAR-BOND-REPO",  # intentionally absent from market_state
            forward_curve_name="ZAR-SWAP",    # intentionally absent from market_state
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )
        ms = {"ZAR-BOND": CurveSlice(
            values=np.full((N_PATHS, len(TENORS)), FLAT_RATE), tenors=TENORS,
        )}
        # Falls back to single-curve -- should price near zero (at-market)
        npv = bf.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(npv, 0.0, atol=1e-5)


# ---------------------------------------------------------------------------
# Per-curve interpolation schemes
# ---------------------------------------------------------------------------

class TestPerCurveInterpolation:
    """Each of the three curves can use an independent interpolation scheme."""

    def _make(
        self,
        delivery: date = DELIVERY,
        settlement_amount: float | None = None,
        forward_clean_price: float = 0.0,
        interpolator=linear_interpolator,
        repo_interpolator=None,
        forward_interpolator=None,
        repo_curve_name: str | None = "ZAR-BOND-REPO",
        forward_curve_name: str | None = "ZAR-SWAP",
    ) -> BondForward:
        return BondForward(
            name="INTERP",
            effective_date=EFFECTIVE, maturity_date=MATURITY, delivery_date=delivery,
            coupon_rate=COUPON_RATE, coupon_frequency=COUPON_FREQ,
            notional=NOTIONAL, forward_clean_price=forward_clean_price,
            bond_curve_name="ZAR-BOND", interpolator=interpolator,
            repo_curve_name=repo_curve_name, forward_curve_name=forward_curve_name,
            repo_interpolator=repo_interpolator,
            forward_interpolator=forward_interpolator,
            settlement_amount=settlement_amount,
            calendar="TARGET", day_count="ACT/365", curve_day_count="ACT/365",
        )

    def test_none_interpolators_fall_back_to_bond_interpolator(self):
        """repo and forward interpolators default to the bond interpolator when None."""
        bf = self._make()
        assert bf.bond_interpolator is linear_interpolator
        assert bf.repo_interpolator is linear_interpolator
        assert bf.forward_interpolator is linear_interpolator

    def test_explicit_interpolators_are_stored_independently(self):
        """Explicitly supplied interpolators are stored per curve without cross-contamination."""
        from utils.interpolation import linear_rt_interp
        bf = self._make(
            repo_interpolator=linear_rt_interp,
            forward_interpolator=linear_rt_interp,
        )
        assert bf.bond_interpolator is linear_interpolator
        assert bf.repo_interpolator is linear_rt_interp
        assert bf.forward_interpolator is linear_rt_interp

    def test_partial_override_leaves_other_curves_unchanged(self):
        """Setting only forward_interpolator leaves repo_interpolator on the default."""
        from utils.interpolation import linear_rt_interp
        bf = self._make(forward_interpolator=linear_rt_interp)
        assert bf.bond_interpolator is linear_interpolator
        assert bf.repo_interpolator is linear_interpolator   # fallback, not overridden
        assert bf.forward_interpolator is linear_rt_interp

    def test_different_forward_interpolators_give_different_npv_on_sloped_curve(self):
        """On a sloped forward curve with off-grid delivery, interpolation scheme affects DF(T_del)."""
        from utils.interpolation import linear_rt_interp

        # Delivery at ~9 months from VAL_DATE (between the 0.5yr and 1.0yr tenor nodes)
        delivery_9m = date(2025, 10, 2)  # 273 days / 365 = 0.748 yr

        # Sloped swap curve: 60 bp spread across the tenor grid
        sloped = np.array([0.060, 0.065, 0.070, 0.075, 0.080, 0.085, 0.090, 0.095])

        ms = {
            "ZAR-BOND":      CurveSlice(values=np.full((1, len(TENORS)), FLAT_RATE), tenors=TENORS),
            "ZAR-BOND-REPO": CurveSlice(values=np.full((1, len(TENORS)), FLAT_RATE), tenors=TENORS),
            "ZAR-SWAP":      CurveSlice(values=sloped.reshape(1, -1), tenors=TENORS),
        }

        sa = NOTIONAL * 0.95  # off-market, so NPV depends on forward DF

        bf_lin = self._make(delivery=delivery_9m, settlement_amount=sa,
                            forward_interpolator=linear_interpolator)
        bf_rt  = self._make(delivery=delivery_9m, settlement_amount=sa,
                            forward_interpolator=linear_rt_interp)

        npv_lin = bf_lin.scenario_npvs(VAL_DATE, ms)
        npv_rt  = bf_rt.scenario_npvs(VAL_DATE, ms)

        assert not np.allclose(npv_lin, npv_rt), (
            "linear and linear_rt interpolators must give different DFs at an off-grid "
            "delivery tenor on a sloped curve, and therefore different NPVs"
        )

    def test_different_repo_interpolators_give_different_npv_on_sloped_curve(self):
        """On a sloped repo curve with off-grid delivery, repo interpolation scheme affects DF_repo."""
        from utils.interpolation import linear_rt_interp

        delivery_9m = date(2025, 10, 2)

        sloped = np.array([0.060, 0.065, 0.070, 0.075, 0.080, 0.085, 0.090, 0.095])

        ms = {
            "ZAR-BOND":      CurveSlice(values=np.full((1, len(TENORS)), FLAT_RATE), tenors=TENORS),
            "ZAR-BOND-REPO": CurveSlice(values=sloped.reshape(1, -1), tenors=TENORS),
            "ZAR-SWAP":      CurveSlice(values=np.full((1, len(TENORS)), FLAT_RATE), tenors=TENORS),
        }

        sa = NOTIONAL * 0.95

        bf_lin = self._make(delivery=delivery_9m, settlement_amount=sa,
                            repo_interpolator=linear_interpolator)
        bf_rt  = self._make(delivery=delivery_9m, settlement_amount=sa,
                            repo_interpolator=linear_rt_interp)

        npv_lin = bf_lin.scenario_npvs(VAL_DATE, ms)
        npv_rt  = bf_rt.scenario_npvs(VAL_DATE, ms)

        assert not np.allclose(npv_lin, npv_rt), (
            "Different repo interpolators on a sloped repo curve must produce "
            "different DF_repo at an off-grid delivery tenor, and therefore different NPVs"
        )

    def test_same_interpolators_match_baseline(self):
        """Explicitly specifying the bond interpolator for all three curves matches the default."""
        from utils.interpolation import linear_rt_interp

        fair_clean = _fair_forward_clean_price(FLAT_RATE, EFFECTIVE, MATURITY, DELIVERY)
        ms = {
            "ZAR-BOND":      CurveSlice(values=np.full((N_PATHS, len(TENORS)), FLAT_RATE), tenors=TENORS),
            "ZAR-BOND-REPO": CurveSlice(values=np.full((N_PATHS, len(TENORS)), FLAT_RATE), tenors=TENORS),
            "ZAR-SWAP":      CurveSlice(values=np.full((N_PATHS, len(TENORS)), FLAT_RATE), tenors=TENORS),
        }

        # Default: all three curves use linear_interpolator implicitly
        bf_default = self._make(forward_clean_price=fair_clean,
                                repo_interpolator=None, forward_interpolator=None)
        # Explicit: all three use linear_rt_interp
        bf_rt_all = self._make(forward_clean_price=fair_clean,
                               interpolator=linear_rt_interp,
                               repo_interpolator=linear_rt_interp,
                               forward_interpolator=linear_rt_interp)

        npv_default = bf_default.scenario_npvs(VAL_DATE, ms)
        npv_rt_all  = bf_rt_all.scenario_npvs(VAL_DATE, ms)

        # On a FLAT curve both interpolators give identical rates at every point,
        # so both must produce the same (near-zero at-market) NPV.
        npt.assert_allclose(npv_default, npv_rt_all, atol=1e-6,
                            err_msg="Flat curve: any two interpolators must agree exactly")
