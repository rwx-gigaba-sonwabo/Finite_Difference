"""
Tests for market_data/discount_curve.py — YieldCurve.
"""
from __future__ import annotations

import numpy as np
import numpy.testing as npt
import pytest

from market_data.yield_curve import YieldCurve
from utils.interpolation import linear_interpolator, linear_rt_interp


N_PATHS = 6
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0, 10.0], dtype=np.float64)
FLAT_RATE = 0.05


def make_flat_handler(rate=FLAT_RATE, interpolator=linear_interpolator) -> YieldCurve:
    rates = np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64)
    return YieldCurve(
        year_fracs=TENORS,
        rates=rates,
        interpolator=interpolator,
    )


def make_upward_handler(interpolator=linear_interpolator) -> YieldCurve:
    base = np.array([0.02, 0.03, 0.04, 0.05, 0.06, 0.07], dtype=np.float64)
    rates = np.tile(base, (N_PATHS, 1))
    return YieldCurve(
        year_fracs=TENORS,
        rates=rates,
        interpolator=interpolator,
    )


# ---------------------------------------------------------------------------
# get_rate
# ---------------------------------------------------------------------------

class TestGetRate:

    def test_flat_rate_at_pillar(self):
        handler = make_flat_handler(0.05)
        for t in TENORS:
            r = handler.get_rate(t)
            assert r.shape == (N_PATHS,)
            npt.assert_allclose(r, 0.05, atol=1e-10)

    def test_flat_rate_shape_scalar(self):
        handler = make_flat_handler()
        r = handler.get_rate(2.5)
        assert r.shape == (N_PATHS,)

    def test_flat_rate_shape_array(self):
        handler = make_flat_handler()
        t = np.array([0.5, 1.0, 2.0, 5.0])
        r = handler.get_rate(t)
        assert r.shape == (N_PATHS, 4)

    def test_rate_is_float(self):
        handler = make_flat_handler()
        r = handler.get_rate(1.0)
        assert r.dtype == np.float64

    def test_upward_curve_rates_positive(self):
        handler = make_upward_handler()
        t = np.linspace(0.25, 10.0, 20)
        r = handler.get_rate(t)
        assert np.all(r > 0), "All rates should be positive"


# ---------------------------------------------------------------------------
# discount_factor
# ---------------------------------------------------------------------------

class TestDiscountFactor:

    def test_df_at_zero_approx_one(self):
        """At t very close to 0, DF should approach 1."""
        handler = make_flat_handler()
        # The flat extrapolation returns rate=0.05 even at t=0,
        # so DF(0) = exp(-0.05*0) = 1.0
        df = handler.discount_factor(0.0)
        npt.assert_allclose(df, 1.0, atol=1e-10)

    def test_df_shape_scalar(self):
        handler = make_flat_handler()
        df = handler.discount_factor(1.0)
        assert df.shape == (N_PATHS,)

    def test_df_shape_array(self):
        handler = make_flat_handler()
        t = np.array([0.5, 1.0, 2.0, 5.0])
        df = handler.discount_factor(t)
        assert df.shape == (N_PATHS, 4)

    def test_flat_df_analytical(self):
        """For flat 5% curve, DF(t) = exp(-0.05*t)."""
        handler = make_flat_handler(0.05)
        for t in [0.5, 1.0, 2.0, 5.0]:
            df = handler.discount_factor(t)
            expected = np.exp(-0.05 * t)
            npt.assert_allclose(df, expected, atol=1e-10)

    def test_df_monotone_decreasing(self):
        """Discount factors must be strictly decreasing with maturity."""
        handler = make_flat_handler()
        t_vals = np.array([0.5, 1.0, 2.0, 5.0, 10.0])
        dfs = handler.discount_factor(t_vals)  # (N_PATHS, 5)
        for path_idx in range(N_PATHS):
            df_path = dfs[path_idx]
            assert np.all(np.diff(df_path) < 0), (
                f"Path {path_idx}: DFs not monotone decreasing: {df_path}"
            )

    def test_df_bounded_between_zero_and_one(self):
        handler = make_upward_handler()
        t = np.array([0.25, 1.0, 5.0, 10.0])
        dfs = handler.discount_factor(t)
        assert np.all(dfs > 0)
        assert np.all(dfs <= 1.0)

    def test_upward_curve_df_monotone_decreasing(self):
        handler = make_upward_handler()
        t = np.array([0.25, 0.5, 1.0, 2.0, 5.0, 10.0])
        dfs = handler.discount_factor(t)
        for path_idx in range(N_PATHS):
            assert np.all(np.diff(dfs[path_idx]) < 0)


# ---------------------------------------------------------------------------
# forward_rate
# ---------------------------------------------------------------------------

class TestForwardRate:

    def test_flat_curve_forward_equals_spot(self):
        """
        On a flat curve, the forward rate should equal the spot rate
        regardless of the period.
        """
        handler = make_flat_handler(0.05)
        fwd = handler.forward_rate(1.0, 2.0)
        assert fwd.shape == (N_PATHS,)
        # F(1,2) = (DF(1)/DF(2) - 1) / 1.0
        # = (exp(-0.05)/exp(-0.10) - 1) / 1.0 = exp(0.05) - 1
        expected = np.exp(0.05) - 1.0
        npt.assert_allclose(fwd, expected, atol=1e-8)

    def test_forward_rate_no_tau(self):
        handler = make_flat_handler()
        fwd = handler.forward_rate(1.0, 2.0)
        assert fwd.shape == (N_PATHS,)

    def test_forward_rate_with_explicit_tau(self):
        handler = make_flat_handler(0.05)
        fwd_default = handler.forward_rate(1.0, 2.0)
        fwd_explicit = handler.forward_rate(1.0, 2.0, tau=1.0)
        npt.assert_allclose(fwd_default, fwd_explicit, atol=1e-15)

    def test_forward_rate_consistency_with_dfs(self):
        """Spot DFs reconstructed from forward rates should match direct DFs."""
        handler = make_upward_handler()
        t_start = 1.0
        t_end = 2.0
        df1 = handler.discount_factor(t_start)   # (N_PATHS,)
        df2 = handler.discount_factor(t_end)      # (N_PATHS,)
        fwd = handler.forward_rate(t_start, t_end)  # (N_PATHS,)
        tau = t_end - t_start
        # Reconstruct: df2 = df1 / (1 + fwd * tau)
        df2_reconstructed = df1 / (1.0 + fwd * tau)
        npt.assert_allclose(df2_reconstructed, df2, atol=1e-10)

    def test_forward_rate_shape_array_inputs(self):
        handler = make_flat_handler()
        t_starts = np.array([0.25, 0.5, 1.0, 2.0])
        t_ends = np.array([0.5, 1.0, 2.0, 5.0])
        fwd = handler.forward_rate(t_starts, t_ends)
        assert fwd.shape == (N_PATHS, 4)

    def test_forward_rate_positive_for_positive_rates(self):
        handler = make_flat_handler(0.05)
        fwd = handler.forward_rate(1.0, 2.0)
        assert np.all(fwd > 0)

    def test_with_linear_rt_interp(self):
        """YieldCurve works with all interpolator types."""
        handler = make_flat_handler(interpolator=linear_rt_interp)
        df = handler.discount_factor(1.0)
        npt.assert_allclose(df, np.exp(-0.05 * 1.0), atol=1e-10)
