"""
Tests for ExposureEngine.

Covers:
- Uncollateralised netting set: exposure = max(mtm, 0)
- Fully collateralised: MPOR lookback reduces exposure
- Forward close-out: discount curve replaced by risky curve
- Multi-trade netting: NPVs summed before exposure calculation
- Netting benefit: netted exposure <= sum of individual exposures
- IM: FIXED method adds constant to collateral
"""
from __future__ import annotations

from datetime import date, timedelta
from unittest.mock import MagicMock

import numpy as np
import pytest

from instruments.instrument import Instrument
from portfolio.trade import Trade
from portfolio.csa import CSA, CloseOutMethod, InitialMarginMethod
from portfolio.netting_set import NettingSet
from market_data.risk_factor import CurveSlice
from market_data.scenario_cube import ScenarioCubeBuilder
from pricing.exposure_engine import ExposureEngine
from utils.interpolation import linear_interpolator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

N_PATHS = 8
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0], dtype=np.float64)
FLAT_RATE = 0.05


def make_cube(valuation_date, sim_dates, n_paths=N_PATHS, extra_curves: dict | None = None):
    n_times = len(sim_dates)
    curve_data = np.full((n_paths, n_times, len(TENORS)), FLAT_RATE)
    builder = ScenarioCubeBuilder(n_paths=n_paths, valuation_date=valuation_date)
    builder.add_curve_factor("DISC", curve_data, TENORS, dates=sim_dates)
    if extra_curves:
        for name, rate in extra_curves.items():
            data = np.full((n_paths, n_times, len(TENORS)), rate)
            builder.add_curve_factor(name, data, TENORS, dates=sim_dates)
    return builder.build()


def make_const_instrument(npv_per_path: float, discount_curve_name: str = "DISC") -> Instrument:
    """Instrument that always returns a constant NPV across all paths."""
    inst = MagicMock(spec=Instrument)
    inst.name = "const_instrument"
    inst.discount_curve_name = discount_curve_name
    inst.scenario_npvs.return_value = np.full(N_PATHS, npv_per_path)
    return inst


def make_trade(trade_id: str, npv: float, cpty: str = "CPTY_A", scale: float = 1.0) -> Trade:
    return Trade(
        trade_id=trade_id,
        counterparty_id=cpty,
        instrument=make_const_instrument(npv),
        notional_scale=scale,
    )


def make_netting_set(trades: list[Trade], csa: CSA | None = None) -> NettingSet:
    return NettingSet(
        netting_set_id="NS1",
        counterparty_id="CPTY_A",
        trades=trades,
        csa=csa,
    )


def quarterly_dates(valuation_date: date, n: int = 5) -> tuple[date, ...]:
    return tuple(valuation_date + timedelta(days=90 * i) for i in range(n))


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def val_date():
    return date(2025, 1, 2)


@pytest.fixture
def sim_dates(val_date):
    return quarterly_dates(val_date, n=6)


@pytest.fixture
def cube(val_date, sim_dates):
    return make_cube(val_date, sim_dates)


# ---------------------------------------------------------------------------
# Uncollateralised: exposure = max(mtm, 0)
# ---------------------------------------------------------------------------

class TestUncollateralised:
    def test_profile_shape(self, cube, sim_dates):
        ns = make_netting_set([make_trade("T1", npv=100.0)])
        engine = ExposureEngine(cube)
        profile = engine.compute(ns)
        assert profile.mtm.shape == (N_PATHS, len(sim_dates))
        assert profile.exposure.shape == (N_PATHS, len(sim_dates))
        assert profile.neg_exposure.shape == (N_PATHS, len(sim_dates))
        assert profile.collateral.shape == (N_PATHS, len(sim_dates))

    def test_collateral_is_zero(self, cube, sim_dates):
        ns = make_netting_set([make_trade("T1", npv=100.0)])
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_array_equal(profile.collateral, 0.0)

    def test_positive_npv_exposure_equals_mtm(self, cube):
        ns = make_netting_set([make_trade("T1", npv=200.0)])
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_allclose(profile.exposure, profile.mtm)
        np.testing.assert_array_equal(profile.neg_exposure, 0.0)

    def test_negative_npv_exposure_is_zero(self, cube):
        ns = make_netting_set([make_trade("T1", npv=-150.0)])
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_array_equal(profile.exposure, 0.0)
        np.testing.assert_allclose(profile.neg_exposure, profile.mtm)

    def test_netting_set_id_preserved(self, cube):
        ns = NettingSet(netting_set_id="MY_NS", counterparty_id="CPTY_A",
                        trades=[make_trade("T1", npv=10.0)])
        profile = ExposureEngine(cube).compute(ns)
        assert profile.netting_set_id == "MY_NS"

    def test_dates_preserved(self, cube, sim_dates):
        ns = make_netting_set([make_trade("T1", npv=10.0)])
        profile = ExposureEngine(cube).compute(ns)
        assert profile.dates == sim_dates

    def test_epe_positive_book(self, cube):
        ns = make_netting_set([make_trade("T1", npv=100.0)])
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_allclose(profile.epe, np.full(len(cube.dates), 100.0))


# ---------------------------------------------------------------------------
# Multi-trade netting
# ---------------------------------------------------------------------------

class TestMultiTradeNetting:
    def test_two_trades_npvs_summed(self, cube):
        ns = make_netting_set([
            make_trade("T1", npv=300.0),
            make_trade("T2", npv=-100.0),
        ])
        profile = ExposureEngine(cube).compute(ns)
        # Net MTM = 200 → exposure = 200
        np.testing.assert_allclose(profile.mtm, 200.0)
        np.testing.assert_allclose(profile.exposure, 200.0)

    def test_notional_scale_applied(self, cube):
        # T1 has npv=100, scale=-1 → contributes -100
        # T2 has npv=50, scale=1 → contributes +50 → net=-50
        ns = make_netting_set([
            make_trade("T1", npv=100.0, scale=-1.0),
            make_trade("T2", npv=50.0, scale=1.0),
        ])
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_allclose(profile.mtm, -50.0)
        np.testing.assert_array_equal(profile.exposure, 0.0)

    def test_netting_benefit(self, cube):
        """Netted exposure <= sum of individual gross exposures."""
        ns_netted = make_netting_set([
            make_trade("T1", npv=200.0),
            make_trade("T2", npv=-150.0),
        ])
        profile_netted = ExposureEngine(cube).compute(ns_netted)

        # Gross exposure: each trade independently
        ns_t1 = make_netting_set([make_trade("T1", npv=200.0)])
        ns_t2 = make_netting_set([make_trade("T2", npv=-150.0)])
        epe_t1 = ExposureEngine(cube).compute(ns_t1).epe
        epe_t2 = ExposureEngine(cube).compute(ns_t2).epe

        assert np.all(profile_netted.epe <= epe_t1 + epe_t2 + 1e-10)

    def test_empty_netting_set_returns_zeros(self, cube, sim_dates):
        ns = NettingSet(netting_set_id="NS_EMPTY", counterparty_id="CPTY_A")
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_array_equal(profile.mtm, 0.0)
        np.testing.assert_array_equal(profile.exposure, 0.0)


# ---------------------------------------------------------------------------
# Collateralised: MPOR lookback
# ---------------------------------------------------------------------------

class TestCollateral:
    def test_fully_collateralised_zero_threshold_no_exposure(self, val_date):
        """With zero threshold and MPOR=0, collateral = MTM → exposure = 0."""
        sim_dates = quarterly_dates(val_date, n=4)
        cube = make_cube(val_date, sim_dates)
        csa = CSA(vm_threshold=0.0, vm_threshold_post=0.0, mpor_days=0)
        ns = make_netting_set([make_trade("T1", npv=100.0)], csa=csa)
        profile = ExposureEngine(cube).compute(ns)
        np.testing.assert_allclose(profile.exposure, 0.0, atol=1e-10)

    def test_mpor_lookback_uses_lagged_mtm(self, val_date):
        """With MPOR > sim date spacing, first dates have no collateral."""
        # quarterly dates ~90 days apart, MPOR = 100 days → first date has no collateral
        sim_dates = quarterly_dates(val_date, n=4)
        cube = make_cube(val_date, sim_dates)
        csa = CSA(vm_threshold=0.0, mpor_days=100)
        ns = make_netting_set([make_trade("T1", npv=100.0)], csa=csa)
        profile = ExposureEngine(cube).compute(ns)
        # At t=0 (date=val_date), lookback = val_date - 100 days which is before all sim dates
        # → collateral at t=0 should be 0
        np.testing.assert_array_equal(profile.collateral[:, 0], 0.0)

    def test_vm_threshold_respected(self, val_date):
        """Collateral only called above threshold."""
        sim_dates = quarterly_dates(val_date, n=3)
        cube = make_cube(val_date, sim_dates)
        # threshold=50, npv=100 → VM = max(100-50, 0) = 50 (after MPOR lag settles)
        csa = CSA(vm_threshold=50.0, mpor_days=0)
        ns = make_netting_set([make_trade("T1", npv=100.0)], csa=csa)
        profile = ExposureEngine(cube).compute(ns)
        # exposure = max(100 - 50, 0) = 50 at dates where lag is available
        # with mpor=0 the lag_idx maps to the same date; bisect_right(dates, date)-1 = same index
        # all dates should have collateral = 50 (threshold applied on lagged mtm=100)
        collateral_settled = profile.collateral[:, 1:]  # skip t=0 if mpor could be boundary
        assert np.all(collateral_settled >= 0)

    def test_fixed_im_adds_to_collateral(self, val_date):
        """Fixed IM is added to VM in collateral account."""
        sim_dates = quarterly_dates(val_date, n=3)
        cube = make_cube(val_date, sim_dates)
        csa = CSA(vm_threshold=0.0, mpor_days=0, im_method=InitialMarginMethod.FIXED, im_amount=25.0)
        ns = make_netting_set([make_trade("T1", npv=100.0)], csa=csa)
        profile_no_im = ExposureEngine(cube).compute(
            make_netting_set([make_trade("T1", npv=100.0)], CSA(vm_threshold=0.0, mpor_days=0))
        )
        profile_with_im = ExposureEngine(cube).compute(ns)
        # collateral with IM should be 25 more than without IM (where collateral ≥ 0)
        diff = profile_with_im.collateral - profile_no_im.collateral
        np.testing.assert_allclose(diff, 25.0, atol=1e-10)

    def test_negative_mtm_vm_posted(self, val_date):
        """Negative MTM means we post VM — collateral is negative."""
        sim_dates = quarterly_dates(val_date, n=3)
        cube = make_cube(val_date, sim_dates)
        csa = CSA(vm_threshold=0.0, vm_threshold_post=0.0, mpor_days=0)
        ns = make_netting_set([make_trade("T1", npv=-100.0)], csa=csa)
        profile = ExposureEngine(cube).compute(ns)
        # At dates with settled collateral, we post 100 → collateral = -100
        assert np.all(profile.collateral[:, 1:] <= 0)


# ---------------------------------------------------------------------------
# Forward close-out
# ---------------------------------------------------------------------------

class TestForwardCloseOut:
    def test_forward_closeout_uses_risky_curve(self, val_date):
        """Under FORWARD close-out, instrument is priced with the risky curve."""
        sim_dates = quarterly_dates(val_date, n=3)
        cube = make_cube(val_date, sim_dates, extra_curves={"RISKY": 0.08})

        # Track which market_state the instrument received
        call_states = []

        inst = MagicMock(spec=Instrument)
        inst.name = "forward_co_inst"
        inst.discount_curve_name = "DISC"
        inst.scenario_npvs.side_effect = lambda vd, ms, fixings=None, rng=None: (
            call_states.append(ms) or np.zeros(N_PATHS)
        )

        trade = Trade(trade_id="T1", counterparty_id="CPTY_A", instrument=inst)
        csa = CSA(close_out_method=CloseOutMethod.FORWARD, risky_curve_name="RISKY")
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A", trades=[trade], csa=csa)

        ExposureEngine(cube).compute(ns)

        # In each pricing call, the DISC key should map to the RISKY curve slice
        for state in call_states:
            assert "DISC" in state
            # The DISC slot should hold the risky curve values (0.08)
            np.testing.assert_allclose(state["DISC"].values, 0.08)

    def test_standard_closeout_unmodified(self, val_date):
        """Under STANDARD close-out, market state is passed through unchanged."""
        sim_dates = quarterly_dates(val_date, n=3)
        cube = make_cube(val_date, sim_dates, extra_curves={"RISKY": 0.08})

        call_states = []
        inst = MagicMock(spec=Instrument)
        inst.name = "std_co_inst"
        inst.discount_curve_name = "DISC"
        inst.scenario_npvs.side_effect = lambda vd, ms, fixings=None, rng=None: (
            call_states.append(ms) or np.zeros(N_PATHS)
        )

        trade = Trade(trade_id="T1", counterparty_id="CPTY_A", instrument=inst)
        csa = CSA(close_out_method=CloseOutMethod.STANDARD)
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A", trades=[trade], csa=csa)

        ExposureEngine(cube).compute(ns)

        # DISC should still hold the flat 5% curve, not the risky one
        for state in call_states:
            np.testing.assert_allclose(state["DISC"].values, FLAT_RATE)


# ---------------------------------------------------------------------------
# Integration: real IRSwap via scenario cube
# ---------------------------------------------------------------------------

class TestIntegration:
    @pytest.fixture
    def sim_dates(self, valuation_date):
        # at_market_swap matures 2 years out; need cube to cover that.
        return tuple(valuation_date + timedelta(days=90 * i) for i in range(10))

    def test_at_market_swap_epe_positive(self, at_market_swap, scenario_cube):
        """At-market swap has near-zero MTM at inception; EPE can still be positive."""
        from utils.interpolation import linear_interpolator
        trade = Trade(
            trade_id="SWAP1",
            counterparty_id="CPTY_A",
            instrument=at_market_swap,
        )
        ns = NettingSet(netting_set_id="NS_SWAP", counterparty_id="CPTY_A", trades=[trade])
        profile = ExposureEngine(scenario_cube).compute(ns)
        assert profile.mtm.shape == (scenario_cube.n_paths, scenario_cube.n_times)
        assert np.all(np.isfinite(profile.exposure))
        assert np.all(profile.exposure >= -1e-8)  # exposure is non-negative

    def test_receiver_payer_mtm_opposite(self, valuation_date, scenario_cube):
        """Receiver swap MTM = -payer swap MTM."""
        from instruments.ir_swap import IRSwap, LegType, SwapLeg
        from utils.interpolation import linear_interpolator

        effective = valuation_date
        maturity = date(effective.year + 2, effective.month, effective.day)

        receiver = IRSwap(
            name="RECV",
            effective_date=effective,
            maturity_date=maturity,
            notional=1_000_000,
            receive_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=FLAT_RATE),
            pay_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
            discount_curve_name="DISC",
            interpolator=linear_interpolator,
            calendar="TARGET",
        )
        payer = IRSwap(
            name="PAY",
            effective_date=effective,
            maturity_date=maturity,
            notional=1_000_000,
            receive_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
            pay_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=FLAT_RATE),
            discount_curve_name="DISC",
            interpolator=linear_interpolator,
            calendar="TARGET",
        )

        t1 = Trade(trade_id="RECV", counterparty_id="CPTY_A", instrument=receiver)
        t2 = Trade(trade_id="PAY", counterparty_id="CPTY_A", instrument=payer)
        ns_netted = NettingSet(netting_set_id="NS_NET", counterparty_id="CPTY_A", trades=[t1, t2])
        profile = ExposureEngine(scenario_cube).compute(ns_netted)
        # Netted MTM of receiver + payer = 0 (they cancel exactly)
        np.testing.assert_allclose(profile.mtm, 0.0, atol=1e-6)
        np.testing.assert_allclose(profile.exposure, 0.0, atol=1e-6)
