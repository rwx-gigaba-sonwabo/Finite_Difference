"""
Tests for pricing/cube_pricer.py — CubePricer.
"""
from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import numpy as np
import numpy.testing as npt
import pandas as pd
import pytest

from instruments.cds import CDS
from instruments.ir_swap import IRSwap, LegType, SwapLeg
from market_data.scenario_cube import ScenarioCubeBuilder
from pricing.cube_pricer import CubePricer
from utils.interpolation import linear_interpolator


# ---------------------------------------------------------------------------
# Helpers / constants
# ---------------------------------------------------------------------------

N_PATHS = 6
N_DATES = 4
VAL_DATE = date(2025, 1, 2)
FLAT_RATE = 0.05
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0], dtype=np.float64)

SIM_DATES = tuple(
    VAL_DATE + timedelta(days=90 * i) for i in range(N_DATES)
)


def build_swap_cube() -> tuple:
    n_times = len(SIM_DATES)
    curve_data = np.full((N_PATHS, n_times, len(TENORS)), FLAT_RATE, dtype=np.float64)
    builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
    builder.add_curve_factor("DISC", curve_data, TENORS, dates=SIM_DATES)
    cube = builder.build()

    swap = IRSwap(
        name="RECV",
        effective_date=VAL_DATE,
        maturity_date=date(VAL_DATE.year + 3, VAL_DATE.month, VAL_DATE.day),
        notional=1_000_000,
        receive_leg=SwapLeg(LegType.FIXED, frequency=6, fixed_rate=FLAT_RATE),
        pay_leg=SwapLeg(LegType.FLOATING, frequency=6, curve_name="DISC"),
        discount_curve_name="DISC",
        interpolator=linear_interpolator,
        calendar="TARGET",
    )
    return cube, swap


def build_cds_cube() -> tuple:
    n_times = len(SIM_DATES)
    disc_data = np.full((N_PATHS, n_times, len(TENORS)), FLAT_RATE)
    credit_data = np.full((N_PATHS, n_times, len(TENORS)), 0.01)

    builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
    builder.add_curve_factor("DISC", disc_data, TENORS, dates=SIM_DATES)
    builder.add_curve_factor("CREDIT", credit_data, TENORS, dates=SIM_DATES)
    cube = builder.build()

    cds = CDS(
        name="TEST_CDS",
        effective_date=VAL_DATE,
        maturity_date=date(VAL_DATE.year + 5, VAL_DATE.month, VAL_DATE.day),
        notional=1_000_000,
        coupon=0.01,
        recovery_rate=0.40,
        discount_curve_name="DISC",
        credit_curve_name="CREDIT",
        interpolator=linear_interpolator,
    )
    return cube, cds


# ---------------------------------------------------------------------------
# CubePricer.calculate_mtm
# ---------------------------------------------------------------------------

class TestCalculateMtm:

    def test_returns_dict(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        assert isinstance(result, dict)

    def test_keys_are_simulation_dates(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        assert set(result.keys()) == set(SIM_DATES)

    def test_each_date_has_path_dict(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        for d in SIM_DATES:
            assert isinstance(result[d], dict)

    def test_each_path_dict_has_all_paths(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        for d in SIM_DATES:
            assert set(result[d].keys()) == set(range(N_PATHS))

    def test_values_are_floats(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        for d in SIM_DATES:
            for p, v in result[d].items():
                assert isinstance(v, float), f"NPV at ({d}, {p}) is not float: {type(v)}"

    def test_all_paths_identical_on_flat_curve(self):
        """On flat identical curves, all paths should yield the same NPV."""
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        for d in SIM_DATES:
            npvs = list(result[d].values())
            npt.assert_allclose(npvs, npvs[0], atol=1e-6)

    def test_mtm_with_cds(self):
        cube, cds = build_cds_cube()
        pricer = CubePricer(cube, cds)
        result = pricer.calculate_mtm()
        assert len(result) == N_DATES


# ---------------------------------------------------------------------------
# CubePricer.calculate_mtm_df
# ---------------------------------------------------------------------------

class TestCalculateMtmDf:

    def test_returns_dataframe(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        df = pricer.calculate_mtm_df()
        assert isinstance(df, pd.DataFrame)

    def test_dataframe_shape(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        df = pricer.calculate_mtm_df()
        # Rows = dates, columns = paths
        assert df.shape == (N_DATES, N_PATHS)

    def test_dataframe_columns_are_path_indices(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        df = pricer.calculate_mtm_df()
        assert set(df.columns) == set(range(N_PATHS))

    def test_dataframe_index_contains_dates(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        df = pricer.calculate_mtm_df()
        for d in SIM_DATES:
            assert d in df.index

    def test_dataframe_values_match_dict(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        mtm_dict = pricer.calculate_mtm()
        mtm_df = pricer.calculate_mtm_df()
        for d in SIM_DATES:
            for p in range(N_PATHS):
                npt.assert_allclose(
                    mtm_df.loc[d, p],
                    mtm_dict[d][p],
                    atol=1e-12,
                )

    def test_values_are_numeric(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        df = pricer.calculate_mtm_df()
        assert df.dtypes.apply(lambda d: np.issubdtype(d, np.number)).all()


# ---------------------------------------------------------------------------
# mtm_to_csv
# ---------------------------------------------------------------------------

class TestMtmToCsv:

    def test_csv_written(self, tmp_path):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        filepath = tmp_path / "mtm.csv"
        pricer.mtm_to_csv(str(filepath))
        assert filepath.exists()

    def test_csv_has_correct_number_of_rows(self, tmp_path):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        filepath = tmp_path / "mtm.csv"
        pricer.mtm_to_csv(str(filepath))
        read_back = pd.read_csv(filepath, index_col="date")
        assert len(read_back) == N_DATES

    def test_csv_has_correct_number_of_columns(self, tmp_path):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        filepath = tmp_path / "mtm.csv"
        pricer.mtm_to_csv(str(filepath))
        read_back = pd.read_csv(filepath, index_col="date")
        # columns are path indices
        assert len(read_back.columns) == N_PATHS


# ---------------------------------------------------------------------------
# Integration test: build cube → create swap → price → check MTM at t=0
# ---------------------------------------------------------------------------

class TestCubePricerIntegration:

    def test_mtm_at_t0_near_at_market(self):
        """
        At t=0 with a flat 5% curve, the at-market receiver swap NPV
        should be close to zero (within a reasonable tolerance).
        """
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        first_date = cube.dates[0]
        npvs_t0 = list(result[first_date].values())
        # Should be small relative to notional (1MM)
        for npv in npvs_t0:
            assert abs(npv) < 50_000, f"NPV {npv:.2f} unexpectedly large at t=0"

    def test_npv_decreases_toward_maturity(self):
        """
        For a receiver with fixed > floating and rates below fixed rate,
        the trade value generally decreases as time passes.
        This is a smoke test: simply verify all dates have finite NPVs.
        """
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        for d, path_npvs in result.items():
            for p, npv in path_npvs.items():
                assert np.isfinite(npv), f"Non-finite NPV at date={d}, path={p}"

    def test_cube_pricer_with_cube_dates_count(self):
        cube, swap = build_swap_cube()
        pricer = CubePricer(cube, swap)
        result = pricer.calculate_mtm()
        assert len(result) == cube.n_times

    def test_cds_integration_all_finite(self):
        cube, cds = build_cds_cube()
        pricer = CubePricer(cube, cds)
        df = pricer.calculate_mtm_df()
        assert df.notna().all().all(), "All NPVs should be finite"
