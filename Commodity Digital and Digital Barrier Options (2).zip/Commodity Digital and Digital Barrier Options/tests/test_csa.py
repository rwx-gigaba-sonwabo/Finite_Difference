import pytest
from portfolio.csa import CSA, InitialMarginMethod, CloseOutMethod


class TestCSADefaults:
    def test_default_construction(self):
        csa = CSA()
        assert csa.vm_threshold == 0.0
        assert csa.vm_threshold_post == 0.0
        assert csa.mta == 0.0
        assert csa.mpor_days == 10
        assert csa.im_method is InitialMarginMethod.NONE
        assert csa.im_amount == 0.0
        assert csa.close_out_method is CloseOutMethod.STANDARD
        assert csa.risky_curve_name is None
        assert csa.collateral_currency == "ZAR"

    def test_is_collateralised_default(self):
        # zero threshold = fully collateralised on VM
        assert CSA().is_collateralised is True

    def test_is_collateralised_with_im(self):
        csa = CSA(im_method=InitialMarginMethod.FIXED, im_amount=1_000.0)
        assert csa.is_collateralised is True


class TestCSAValidation:
    def test_negative_vm_threshold_raises(self):
        with pytest.raises(ValueError, match="vm_threshold"):
            CSA(vm_threshold=-1.0)

    def test_negative_vm_threshold_post_raises(self):
        with pytest.raises(ValueError, match="vm_threshold_post"):
            CSA(vm_threshold_post=-1.0)

    def test_negative_mta_raises(self):
        with pytest.raises(ValueError, match="mta"):
            CSA(mta=-0.01)

    def test_negative_mpor_raises(self):
        with pytest.raises(ValueError, match="mpor_days"):
            CSA(mpor_days=-1)

    def test_negative_im_amount_raises(self):
        with pytest.raises(ValueError, match="im_amount"):
            CSA(im_amount=-100.0)

    def test_forward_closeout_without_risky_curve_raises(self):
        with pytest.raises(ValueError, match="risky_curve_name"):
            CSA(close_out_method=CloseOutMethod.FORWARD)

    def test_forward_closeout_with_risky_curve_ok(self):
        csa = CSA(
            close_out_method=CloseOutMethod.FORWARD,
            risky_curve_name="ZAR_RISKY",
        )
        assert csa.risky_curve_name == "ZAR_RISKY"


class TestCSAConfigurations:
    def test_uncollateralised_like(self):
        # high threshold effectively means uncollateralised
        csa = CSA(vm_threshold=1e12, vm_threshold_post=1e12)
        assert csa.vm_threshold == 1e12

    def test_fixed_im(self):
        csa = CSA(im_method=InitialMarginMethod.FIXED, im_amount=500_000.0)
        assert csa.im_method is InitialMarginMethod.FIXED
        assert csa.im_amount == 500_000.0

    def test_schedule_im(self):
        csa = CSA(im_method=InitialMarginMethod.SCHEDULE)
        assert csa.im_method is InitialMarginMethod.SCHEDULE

    def test_mpor_zero_allowed(self):
        # MPOR of 0 means instantaneous collateral — unusual but valid
        csa = CSA(mpor_days=0)
        assert csa.mpor_days == 0

    def test_custom_currency(self):
        csa = CSA(collateral_currency="USD")
        assert csa.collateral_currency == "USD"
