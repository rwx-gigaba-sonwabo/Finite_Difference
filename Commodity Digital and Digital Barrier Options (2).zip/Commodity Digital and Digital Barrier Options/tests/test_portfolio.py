import pytest
from unittest.mock import MagicMock

from instruments.instrument import Instrument
from portfolio.trade import Trade
from portfolio.netting_set import NettingSet
from portfolio.portfolio import Portfolio


def make_netting_set(ns_id: str, counterparty_id: str = "CPTY_A", n_trades: int = 0) -> NettingSet:
    ns = NettingSet(netting_set_id=ns_id, counterparty_id=counterparty_id)
    for i in range(n_trades):
        inst = MagicMock(spec=Instrument)
        inst.name = f"{ns_id}_T{i}"
        ns.add_trade(Trade(trade_id=f"{ns_id}_T{i}", counterparty_id=counterparty_id, instrument=inst))
    return ns


class TestPortfolioConstruction:
    def test_empty_portfolio(self):
        p = Portfolio()
        assert p.n_netting_sets == 0
        assert p.n_trades == 0
        assert p.counterparty_ids == []

    def test_construction_with_netting_sets(self):
        ns1 = make_netting_set("NS1", "CPTY_A", n_trades=2)
        ns2 = make_netting_set("NS2", "CPTY_B", n_trades=1)
        p = Portfolio(netting_sets=[ns1, ns2])
        assert p.n_netting_sets == 2
        assert p.n_trades == 3

    def test_netting_sets_default_independent(self):
        p1 = Portfolio()
        p2 = Portfolio()
        p1.add_netting_set(make_netting_set("NS1"))
        assert p2.n_netting_sets == 0


class TestPortfolioMutation:
    def test_add_netting_set(self):
        p = Portfolio()
        p.add_netting_set(make_netting_set("NS1"))
        assert p.n_netting_sets == 1

    def test_add_duplicate_netting_set_raises(self):
        p = Portfolio()
        p.add_netting_set(make_netting_set("NS1"))
        with pytest.raises(ValueError, match="NS1"):
            p.add_netting_set(make_netting_set("NS1"))

    def test_get_netting_set(self):
        p = Portfolio()
        ns = make_netting_set("NS1")
        p.add_netting_set(ns)
        assert p.get_netting_set("NS1") is ns

    def test_get_netting_set_missing_raises(self):
        p = Portfolio()
        with pytest.raises(KeyError, match="NS99"):
            p.get_netting_set("NS99")


class TestPortfolioQueries:
    def test_get_by_counterparty(self):
        p = Portfolio()
        p.add_netting_set(make_netting_set("NS1", "CPTY_A"))
        p.add_netting_set(make_netting_set("NS2", "CPTY_A"))
        p.add_netting_set(make_netting_set("NS3", "CPTY_B"))
        result = p.get_by_counterparty("CPTY_A")
        assert len(result) == 2
        assert all(ns.counterparty_id == "CPTY_A" for ns in result)

    def test_get_by_counterparty_none(self):
        p = Portfolio()
        p.add_netting_set(make_netting_set("NS1", "CPTY_A"))
        assert p.get_by_counterparty("CPTY_Z") == []

    def test_counterparty_ids_unique(self):
        p = Portfolio()
        p.add_netting_set(make_netting_set("NS1", "CPTY_A"))
        p.add_netting_set(make_netting_set("NS2", "CPTY_A"))
        p.add_netting_set(make_netting_set("NS3", "CPTY_B"))
        ids = p.counterparty_ids
        assert sorted(ids) == ["CPTY_A", "CPTY_B"]

    def test_n_trades_aggregates_across_netting_sets(self):
        p = Portfolio()
        p.add_netting_set(make_netting_set("NS1", "CPTY_A", n_trades=3))
        p.add_netting_set(make_netting_set("NS2", "CPTY_B", n_trades=2))
        assert p.n_trades == 5
