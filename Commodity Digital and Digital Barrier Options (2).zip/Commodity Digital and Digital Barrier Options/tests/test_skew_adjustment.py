"""
Tests for the skew-adjustment feature added across:

- market_data/vol_surface.py::SimpleSkew
- models/commodity_digital_pv.py::skew_adjusted_digital_price
- models/commodity_digital_pv.py::mc_digital_barrier_pv(vol_fn=...)
- instruments/commodity_digital_option.py (apply_skew_adjustment)
- instruments/commodity_digital_barrier_option.py (apply_skew_adjustment)
- base_valuation/commodity_digital_option.py (apply_skew_adjustment)
- base_valuation/commodity_digital_barrier_option.py (apply_skew_adjustment)
"""
from __future__ import annotations

import warnings
from datetime import date

import numpy as np
import numpy.testing as npt
import pytest

from market_data.vol_surface import SimpleSkew
from models.commodity_digital_pv import (
    black76_digital_price,
    skew_adjusted_digital_price,
    mc_digital_barrier_pv,
)
from models.equity_pv import black76_euro_option


# ---------------------------------------------------------------------------
# SimpleSkew
# ---------------------------------------------------------------------------

def test_simple_skew_exact_quote_lookup():
    skew = SimpleSkew(strikes=[80, 100, 120], vols=[0.35, 0.30, 0.28])
    assert skew.get_vol(strike=100.0) == pytest.approx(0.30)


def test_simple_skew_linear_interpolation():
    skew = SimpleSkew(strikes=[80, 120], vols=[0.30, 0.40])
    assert skew.get_vol(strike=100.0) == pytest.approx(0.35)


def test_simple_skew_flat_extrapolation():
    skew = SimpleSkew(strikes=[80, 120], vols=[0.30, 0.40])
    assert skew.get_vol(strike=50.0) == pytest.approx(0.30)
    assert skew.get_vol(strike=200.0) == pytest.approx(0.40)


def test_simple_skew_array_strike_matches_shape():
    skew = SimpleSkew(strikes=[80, 100, 120], vols=[0.35, 0.30, 0.28])
    out = skew.get_vol(strike=np.array([[80.0, 100.0], [120.0, 90.0]]))
    assert out.shape == (2, 2)


def test_simple_skew_tenor_argument_ignored():
    skew = SimpleSkew(strikes=[80, 120], vols=[0.30, 0.40])
    assert skew.get_vol(strike=100.0, tenor=0.5) == skew.get_vol(strike=100.0, tenor=5.0)


def test_simple_skew_rejects_non_increasing_strikes():
    with pytest.raises(ValueError):
        SimpleSkew(strikes=[100, 90], vols=[0.3, 0.3])


def test_simple_skew_rejects_mismatched_lengths():
    with pytest.raises(ValueError):
        SimpleSkew(strikes=[80, 100], vols=[0.3])


# ---------------------------------------------------------------------------
# skew_adjusted_digital_price
# ---------------------------------------------------------------------------

def test_skew_adjusted_converges_to_flat_formula_when_smile_is_flat():
    F = np.array([100.0])
    K = 100.0
    T = 1.0
    df = np.array([0.95])
    flat = SimpleSkew(strikes=[50, 100, 150], vols=[0.30, 0.30, 0.30])
    vol_fn = lambda k: flat.get_vol(strike=k)  # noqa: E731

    p_skew = skew_adjusted_digital_price(F, K, vol_fn, df, T, True, "cash", 100.0)
    p_flat = black76_digital_price(F, K, np.array([0.30]), df, T, True, "cash", 100.0)
    npt.assert_allclose(p_skew, p_flat, atol=1e-3)  # tiny finite-h residual expected


def test_skew_adjusted_asset_minus_k_cash_equals_vanilla_call():
    """Static replication identity (call): AssetDigitalCall - K*CashDigitalCall
    == vanilla call price at the smile-consistent vol -- must hold exactly
    regardless of skew shape, since it's pure algebra, not an approximation."""
    F = np.array([100.0])
    K = 95.0
    T = 0.75
    df = np.array([0.97])
    skew = SimpleSkew(strikes=[60, 95, 130], vols=[0.22, 0.30, 0.42])
    vol_fn = lambda k: skew.get_vol(strike=k)  # noqa: E731

    asset = skew_adjusted_digital_price(F, K, vol_fn, df, T, True, "asset", 1.0)
    cash = skew_adjusted_digital_price(F, K, vol_fn, df, T, True, "cash", 1.0)
    vanilla_call = black76_euro_option(F, K, np.array([vol_fn(K)]), df, T, True)
    npt.assert_allclose(asset - K * cash, vanilla_call, rtol=1e-8)


def test_skew_adjusted_k_cash_minus_asset_equals_vanilla_put():
    """Static replication identity (put): K*CashDigitalPut - AssetDigitalPut
    == vanilla put price -- the sign-flipped counterpart of the call
    identity above (P(K) = K*E[1{S<=K}] - E[S*1{S<=K}], all discounted)."""
    F = np.array([100.0])
    K = 95.0
    T = 0.75
    df = np.array([0.97])
    skew = SimpleSkew(strikes=[60, 95, 130], vols=[0.22, 0.30, 0.42])
    vol_fn = lambda k: skew.get_vol(strike=k)  # noqa: E731

    asset = skew_adjusted_digital_price(F, K, vol_fn, df, T, False, "asset", 1.0)
    cash = skew_adjusted_digital_price(F, K, vol_fn, df, T, False, "cash", 1.0)
    vanilla_put = black76_euro_option(F, K, np.array([vol_fn(K)]), df, T, False)
    npt.assert_allclose(K * cash - asset, vanilla_put, rtol=1e-8)


def test_skew_adjusted_direction_matches_intuition_for_positive_skew():
    """Rising skew (higher vol at higher strikes) flattens the call price
    curve's decay in K, which must *lower* the cash-or-nothing call digital
    relative to a flat-vol baseline at the same ATM level."""
    F = np.array([100.0])
    K = 100.0
    T = 1.0
    df = np.array([0.95])
    rising = SimpleSkew(strikes=[50, 100, 150], vols=[0.20, 0.30, 0.45])
    vol_fn = lambda k: rising.get_vol(strike=k)  # noqa: E731

    p_skew = skew_adjusted_digital_price(F, K, vol_fn, df, T, True, "cash", 100.0)
    p_flat = black76_digital_price(F, K, np.array([0.30]), df, T, True, "cash", 100.0)
    assert p_skew[0] < p_flat[0]


def test_skew_adjusted_put_uses_correct_sign():
    F = np.array([100.0])
    K = 100.0
    T = 1.0
    df = np.array([0.95])
    flat = SimpleSkew(strikes=[50, 150], vols=[0.30, 0.30])
    vol_fn = lambda k: flat.get_vol(strike=k)  # noqa: E731
    call = skew_adjusted_digital_price(F, K, vol_fn, df, T, True, "cash", 1.0)
    put = skew_adjusted_digital_price(F, K, vol_fn, df, T, False, "cash", 1.0)
    npt.assert_allclose(call + put, df, rtol=1e-3)


def test_skew_adjusted_rejects_bad_digital_type():
    F = np.array([100.0])
    vol_fn = lambda k: 0.3  # noqa: E731
    with pytest.raises(ValueError):
        skew_adjusted_digital_price(F, 100.0, vol_fn, np.array([0.95]), 1.0, True, "bogus", 1.0)


# ---------------------------------------------------------------------------
# mc_digital_barrier_pv with local-vol vol_fn
# ---------------------------------------------------------------------------

def test_mc_vol_fn_none_matches_prior_flat_sigma_behaviour():
    """Backward-compatibility guard: vol_fn=None must reproduce the
    original flat-sigma code path bit-for-bit (same rng stream)."""
    rng1 = np.random.default_rng(11)
    rng2 = np.random.default_rng(11)
    F0 = np.full(50, 100.0)
    sigma = np.full(50, 0.30)
    b = np.full(50, 0.02)
    df = np.full(50, 0.95)
    monitoring_t = np.linspace(0.05, 1.0, 20)

    pv_a = mc_digital_barrier_pv(
        F0, sigma, b, 1.0, monitoring_t, upper_barrier=120.0, lower_barrier=None,
        touch="in", digital_type="cash", payout=1.0, df=df, rng=rng1, n_inner=200,
    )
    pv_b = mc_digital_barrier_pv(
        F0, sigma, b, 1.0, monitoring_t, upper_barrier=120.0, lower_barrier=None,
        touch="in", digital_type="cash", payout=1.0, df=df, rng=rng2, n_inner=200,
        vol_fn=None,
    )
    npt.assert_array_equal(pv_a, pv_b)


def test_mc_local_vol_runs_and_is_finite():
    rng = np.random.default_rng(3)
    F0 = np.full(20, 100.0)
    sigma = np.full(20, 0.30)  # ignored when vol_fn given
    b = np.full(20, 0.0)
    df = np.full(20, 0.95)
    skew = SimpleSkew(strikes=[70, 100, 140], vols=[0.20, 0.30, 0.45])
    monitoring_t = np.linspace(0.05, 1.0, 30)

    pv = mc_digital_barrier_pv(
        F0, sigma, b, 1.0, monitoring_t, upper_barrier=130.0, lower_barrier=None,
        touch="in", digital_type="cash", payout=1.0, df=df, rng=rng, n_inner=500,
        vol_fn=lambda S: skew.get_vol(strike=S),
    )
    assert np.all(np.isfinite(pv))
    assert np.all(pv >= 0.0)


# ---------------------------------------------------------------------------
# CommodityDigitalOption
# ---------------------------------------------------------------------------

class TestCommodityDigitalOptionSkew:
    N_PATHS = 4
    VAL_DATE = date(2025, 1, 2)
    MATURITY = date(2026, 1, 2)
    FWD_TENORS = np.array([45750.0, 45841.0, 46024.0, 46389.0, 47484.0])

    def _instrument(self, apply_skew_adjustment=True, vol_skew=None):
        from instruments.commodity_digital_option import CommodityDigitalOption
        from utils.interpolation import forward_price_interpolator, linear_interpolator

        if vol_skew is None:
            vol_skew = SimpleSkew(strikes=[70, 80, 90], vols=[0.35, 0.30, 0.28])
        return CommodityDigitalOption(
            name="X", maturity_date=self.MATURITY, strike=80.0, is_call=True,
            digital_type="cash", payout=100.0, forward_curve_name="FWD",
            discount_curve_name="DISC", vol_skew=vol_skew,
            apply_skew_adjustment=apply_skew_adjustment,
            forward_interpolator=forward_price_interpolator,
            discount_interpolator=linear_interpolator, spot_days=0, settle_days=0,
        )

    def _market_state(self):
        from market_data.risk_factor import CurveSlice
        fwd = CurveSlice(values=np.full((self.N_PATHS, len(self.FWD_TENORS)), 80.0),
                          tenors=self.FWD_TENORS)
        disc = CurveSlice(values=np.full((self.N_PATHS, 4), 0.05),
                           tenors=np.array([0.25, 0.5, 1.0, 2.0]))
        return {"FWD": fwd, "DISC": disc}

    def test_construction_requires_vol_skew(self):
        from instruments.commodity_digital_option import CommodityDigitalOption
        with pytest.raises(ValueError, match="vol_skew"):
            CommodityDigitalOption(
                name="Y", maturity_date=self.MATURITY, strike=80.0, is_call=True,
                digital_type="cash", payout=100.0, forward_curve_name="FWD",
                discount_curve_name="DISC", apply_skew_adjustment=True,
            )

    def test_price_matches_model_function(self):
        inst = self._instrument()
        ms = self._market_state()
        npv = inst.scenario_npvs(self.VAL_DATE, ms)

        vol_fn = lambda k: inst.vol_skew.get_vol(strike=k, tenor=1.0)  # noqa: E731
        expected = skew_adjusted_digital_price(
            np.full(self.N_PATHS, 80.0), 80.0, vol_fn, np.exp(-0.05 * np.ones(self.N_PATHS)),
            1.0, True, "cash", 100.0,
        )
        npt.assert_allclose(npv, expected, rtol=1e-6)

    def test_analytic_greeks_raise(self):
        inst = self._instrument()
        ms = self._market_state()
        with pytest.raises(NotImplementedError):
            inst.analytic_greeks(self.VAL_DATE, ms)

    def test_bump_and_reprice_finite(self):
        inst = self._instrument()
        ms = self._market_state()
        g = inst.greeks_bump_and_reprice(self.VAL_DATE, ms)
        assert all(np.all(np.isfinite(v)) for v in g.values())

    def test_flag_off_is_unaffected_by_skew_slope(self):
        """apply_skew_adjustment=False must ignore the smile's slope
        entirely and use the plain vol-at-strike lookup (pre-existing
        behaviour, unchanged)."""
        inst_flat = self._instrument(apply_skew_adjustment=False)
        ms = self._market_state()
        npv = inst_flat.scenario_npvs(self.VAL_DATE, ms)

        from models.commodity_digital_pv import black76_digital_price as ref
        expected = ref(np.full(self.N_PATHS, 80.0), 80.0, np.array([0.30]),
                        np.exp(-0.05 * np.ones(self.N_PATHS)), 1.0, True, "cash", 100.0)
        npt.assert_allclose(npv, expected, rtol=1e-6)


# ---------------------------------------------------------------------------
# CommodityDigitalBarrierOption
# ---------------------------------------------------------------------------

class TestCommodityDigitalBarrierOptionSkew:
    N_PATHS = 4
    VAL_DATE = date(2025, 1, 2)
    MATURITY = date(2026, 1, 2)
    FWD_TENORS = np.array([45658.0, 45750.0, 45841.0, 46024.0, 46389.0, 47484.0])

    def _market_state(self):
        from market_data.risk_factor import CurveSlice
        fwd = CurveSlice(values=np.full((self.N_PATHS, len(self.FWD_TENORS)), 100.0),
                          tenors=self.FWD_TENORS)
        disc = CurveSlice(values=np.full((self.N_PATHS, 4), 0.05),
                           tenors=np.array([0.083, 0.25, 0.5, 1.0]))
        return {"FWD": fwd, "DISC": disc}

    def _instrument(self, monitoring="continuous"):
        from instruments.commodity_digital_barrier_option import CommodityDigitalBarrierOption
        skew = SimpleSkew(strikes=[80, 100, 130], vols=[0.25, 0.30, 0.40])
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            return CommodityDigitalBarrierOption(
                name="B", maturity_date=self.MATURITY, monitoring_start_date=self.VAL_DATE,
                upper_barrier=130.0, lower_barrier=None, touch="in", digital_type="cash",
                payout=200.0, forward_curve_name="FWD", discount_curve_name="DISC",
                vol_skew=skew, apply_skew_adjustment=True, monitoring=monitoring,
                cost_of_carry=0.04, settle_days=0,
            )

    def test_construction_requires_vol_skew(self):
        from instruments.commodity_digital_barrier_option import CommodityDigitalBarrierOption
        with pytest.raises(ValueError, match="vol_skew"):
            CommodityDigitalBarrierOption(
                name="C", maturity_date=self.MATURITY, monitoring_start_date=self.VAL_DATE,
                upper_barrier=130.0, lower_barrier=None, touch="in", digital_type="cash",
                payout=200.0, forward_curve_name="FWD", discount_curve_name="DISC",
                apply_skew_adjustment=True,
            )

    def test_continuous_request_warns_and_forces_mc(self):
        from instruments.commodity_digital_barrier_option import CommodityDigitalBarrierOption
        skew = SimpleSkew(strikes=[80, 100, 130], vols=[0.25, 0.30, 0.40])
        with pytest.warns(UserWarning, match="skew adjustment"):
            inst = CommodityDigitalBarrierOption(
                name="D", maturity_date=self.MATURITY, monitoring_start_date=self.VAL_DATE,
                upper_barrier=130.0, lower_barrier=None, touch="in", digital_type="cash",
                payout=200.0, forward_curve_name="FWD", discount_curve_name="DISC",
                vol_skew=skew, apply_skew_adjustment=True, monitoring="continuous",
                cost_of_carry=0.04,
            )
        assert inst._requires_mc

    def test_price_requires_rng(self):
        inst = self._instrument()
        ms = self._market_state()
        with pytest.raises(ValueError, match="rng"):
            inst.scenario_npvs(self.VAL_DATE, ms, rng=None)

    def test_price_finite_with_rng(self):
        inst = self._instrument()
        ms = self._market_state()
        rng = np.random.default_rng(2)
        npv = inst.scenario_npvs(self.VAL_DATE, ms, rng=rng)
        assert np.all(np.isfinite(npv))
        assert np.all(npv >= 0.0)

    def test_analytic_greeks_raise(self):
        inst = self._instrument()
        ms = self._market_state()
        with pytest.raises(NotImplementedError):
            inst.analytic_greeks(self.VAL_DATE, ms)

    def test_bump_and_reprice_finite(self):
        inst = self._instrument()
        ms = self._market_state()
        g = inst.greeks_bump_and_reprice(self.VAL_DATE, ms, mc_seed=4)
        assert all(np.all(np.isfinite(v)) for v in g.values())


# ---------------------------------------------------------------------------
# base_valuation layer
# ---------------------------------------------------------------------------

class TestBaseValuationSkew:
    VAL_DATE = date(2025, 1, 2)
    MATURITY = date(2026, 1, 2)

    def _curves(self):
        from base_valuation.commodity_curve import build_commodity_forward_curve
        from base_valuation.yield_curve import build_yield_curve
        fwd = build_commodity_forward_curve(
            self.VAL_DATE,
            [date(2025, 4, 2), date(2025, 7, 2), date(2026, 1, 2), date(2027, 1, 2)],
            [78.0, 79.0, 80.0, 82.0],
        )
        disc = build_yield_curve(
            self.VAL_DATE,
            [date(2025, 4, 2), date(2026, 1, 2), date(2027, 1, 2)],
            [0.05, 0.05, 0.05],
        )
        return fwd, disc

    def test_digital_requires_vol_or_vol_skew(self):
        from base_valuation.commodity_digital_option import value_commodity_digital_option
        fwd, disc = self._curves()
        with pytest.raises(ValueError, match="vol"):
            value_commodity_digital_option(
                self.VAL_DATE, self.MATURITY, 80.0, True, "cash", 100.0, fwd, disc,
            )

    def test_digital_skew_adjusted_price_and_none_greeks(self):
        from base_valuation.commodity_digital_option import value_commodity_digital_option
        fwd, disc = self._curves()
        skew = SimpleSkew(strikes=[70, 80, 90], vols=[0.35, 0.30, 0.28])
        result = value_commodity_digital_option(
            self.VAL_DATE, self.MATURITY, 80.0, True, "cash", 100.0, fwd, disc,
            vol_skew=skew, apply_skew_adjustment=True,
        )
        assert result.skew_adjusted is True
        assert result.analytic_delta is None
        assert np.isfinite(result.price)

    def test_digital_bump_and_reprice_skew(self):
        from base_valuation.commodity_digital_option import bump_and_reprice_commodity_digital_option
        fwd, disc = self._curves()
        skew = SimpleSkew(strikes=[70, 80, 90], vols=[0.35, 0.30, 0.28])
        g = bump_and_reprice_commodity_digital_option(
            self.VAL_DATE, self.MATURITY, 80.0, True, "cash", 100.0, fwd, disc,
            vol_skew=skew, apply_skew_adjustment=True,
        )
        assert all(np.isfinite(v) for v in g.values())

    def test_barrier_requires_vol_skew_for_adjustment(self):
        from base_valuation.commodity_digital_barrier_option import value_commodity_digital_barrier_option
        fwd, disc = self._curves()
        with pytest.raises(ValueError, match="vol_skew"):
            value_commodity_digital_barrier_option(
                self.VAL_DATE, self.MATURITY, 95.0, None, "in", "cash", 200.0, fwd, disc,
                vol=0.3, apply_skew_adjustment=True,
            )

    def test_barrier_skew_adjusted_uses_mc_and_warns(self):
        from base_valuation.commodity_digital_barrier_option import value_commodity_digital_barrier_option
        fwd, disc = self._curves()
        skew = SimpleSkew(strikes=[70, 95, 130], vols=[0.35, 0.30, 0.42])
        with pytest.warns(UserWarning, match="skew adjustment"):
            result = value_commodity_digital_barrier_option(
                self.VAL_DATE, self.MATURITY, 95.0, None, "in", "cash", 200.0, fwd, disc,
                vol_skew=skew, apply_skew_adjustment=True, cost_of_carry=0.04, n_mc_paths=3000,
            )
        assert result.pricing_method == "monte_carlo"
        assert result.skew_adjusted is True
        assert result.analytic_delta is None

    def test_barrier_bump_and_reprice_skew(self):
        from base_valuation.commodity_digital_barrier_option import (
            bump_and_reprice_commodity_digital_barrier_option,
        )
        fwd, disc = self._curves()
        skew = SimpleSkew(strikes=[70, 95, 130], vols=[0.35, 0.30, 0.42])
        g = bump_and_reprice_commodity_digital_barrier_option(
            self.VAL_DATE, self.MATURITY, 95.0, None, "in", "cash", 200.0, fwd, disc,
            vol_skew=skew, apply_skew_adjustment=True, cost_of_carry=0.04, n_mc_paths=2000,
        )
        assert all(np.isfinite(v) for v in g.values())
