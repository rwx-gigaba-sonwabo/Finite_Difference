"""
Tests for sub-period compounding and averaging on CashflowLeg / leg_pv.

Covers:
  - generate_sub_periods helper
  - _apply_compounding_method (all five methods + two averaging methods)
  - leg_pv dispatch for Flat / Include_Margin / Exclude_Margin / Exponential
  - Average_Rate / Average_Interest
  - IRSwap.get_reset_dates sub-period emission
  - IndexLinkedSwap nominal leg compounding (get_reset_dates + compute_fixings)
  - In-progress compounding: past sub-periods via fixings, future via fwd curve
  - CashflowLeg validation
"""
from __future__ import annotations

import math
from datetime import date

import numpy as np
import numpy.testing as npt
import pytest
import QuantLib as ql

from instruments.components.cashflow_leg import CashflowLeg, LegType
from instruments.components.inflation_leg import InflationLeg
from instruments.index_linked_swap import IndexLinkedSwap
from instruments.ir_swap import IRSwap
from market_data.risk_factor import CurveSlice
from market_data.yield_curve import YieldCurve
from models.cashflow_pv import leg_pv, _apply_compounding_method
from utils.interpolation import linear_interpolator
from utils.ql_helpers import generate_sub_periods, CALENDARS, DAY_COUNTERS


# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

N_PATHS = 4
NOTIONAL = 1_000_000.0
FLAT_FWD = 0.07        # 7% JIBAR
FLAT_DISC = 0.08       # 8% discount rate
SPREAD = 0.01          # 100 bp spread


def flat_curve_slice(rate: float, n_paths: int = N_PATHS) -> CurveSlice:
    return CurveSlice(
        values=np.full((n_paths, 2), rate, dtype=np.float64),
        tenors=np.array([0.0, 10.0], dtype=np.float64),
    )


def make_market_state(fwd_rate=FLAT_FWD, disc_rate=FLAT_DISC, n_paths=N_PATHS):
    return {
        "JIBAR": flat_curve_slice(fwd_rate, n_paths),
        "DISC":  flat_curve_slice(disc_rate, n_paths),
    }


def make_discount_curve(rate=FLAT_DISC, n_paths=N_PATHS):
    sl = flat_curve_slice(rate, n_paths)
    return YieldCurve(year_fracs=sl.tenors, rates=sl.values, interpolator=linear_interpolator)


# ---------------------------------------------------------------------------
# generate_sub_periods
# ---------------------------------------------------------------------------

class TestGenerateSubPeriods:
    def test_even_division(self):
        cal = CALENDARS["ZAR"]
        dc = DAY_COUNTERS["ACT/365"]
        # 6M payment, 3M resets → 2 sub-periods
        start = date(2025, 1, 2)
        end   = date(2025, 7, 2)
        subs = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc)
        assert len(subs) == 2
        assert subs[0][0] == start
        assert subs[-1][1] == end
        # Continuity
        assert subs[0][1] == subs[1][0]

    def test_uneven_stub(self):
        cal = CALENDARS["ZAR"]
        dc = DAY_COUNTERS["ACT/365"]
        # 5M payment with 3M resets → 2 sub-periods, last is 2M stub
        start = date(2025, 1, 2)
        end   = date(2025, 6, 2)
        subs = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc)
        assert len(subs) == 2
        assert subs[-1][1] == end

    def test_accrual_sum_equals_full_period(self):
        cal = CALENDARS["ZAR"]
        dc = DAY_COUNTERS["ACT/365"]
        start = date(2025, 1, 2)
        end   = date(2026, 1, 2)  # 1Y
        subs = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc)
        total_accrual = sum(a for _, _, a in subs)
        full_accrual = dc.yearFraction(
            ql.Date(start.day, start.month, start.year),
            ql.Date(end.day, end.month, end.year),
        )
        npt.assert_allclose(total_accrual, float(full_accrual), rtol=1e-12)

    def test_backward_stub_is_at_start(self):
        """Backward generation: uneven period → short stub is the FIRST sub-period."""
        cal = CALENDARS["ZAR"]
        dc = DAY_COUNTERS["ACT/365"]
        # 5M payment with 3M resets → first sub-period is 2M stub, second is 3M
        start = date(2025, 1, 2)
        end   = date(2025, 6, 2)
        subs_bwd = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc, direction="Backward")
        subs_fwd = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc, direction="Forward")
        assert len(subs_bwd) == 2
        assert subs_bwd[0][0] == start
        assert subs_bwd[-1][1] == end
        # Backward stub (first period) is shorter than the last period
        assert subs_bwd[0][2] < subs_bwd[1][2]
        # Forward stub (last period) is shorter than the first period
        assert subs_fwd[-1][2] < subs_fwd[0][2]

    def test_even_division_same_for_both_directions(self):
        """Even division (e.g., 6M/3M) produces identical sub-periods regardless of direction."""
        cal = CALENDARS["ZAR"]
        dc = DAY_COUNTERS["ACT/365"]
        start = date(2025, 1, 2)
        end   = date(2025, 7, 2)
        subs_fwd = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc, direction="Forward")
        subs_bwd = generate_sub_periods(start, end, 3, cal, ql.ModifiedFollowing, dc, direction="Backward")
        assert len(subs_fwd) == len(subs_bwd) == 2
        for (s_f, e_f, a_f), (s_b, e_b, a_b) in zip(subs_fwd, subs_bwd):
            assert s_f == s_b and e_f == e_b
            npt.assert_allclose(a_f, a_b, rtol=1e-12)

    def test_invalid_direction_raises(self):
        """Unsupported direction string raises ValueError."""
        cal = CALENDARS["ZAR"]
        dc = DAY_COUNTERS["ACT/365"]
        with pytest.raises(ValueError, match="direction"):
            generate_sub_periods(
                date(2025, 1, 2), date(2025, 7, 2), 3,
                cal, ql.ModifiedFollowing, dc, direction="Random",
            )


# ---------------------------------------------------------------------------
# _apply_compounding_method
# ---------------------------------------------------------------------------

class TestApplyCompoundingMethod:
    """Analytical verification of each method with two equal sub-periods."""

    def setup_method(self):
        # Two 3M sub-periods, JIBAR=7%, spread=1%
        self.r = 0.07
        self.m = SPREAD
        self.tau1 = 0.25
        self.tau2 = 0.25
        self.tau_total = 0.50
        sub_rates = np.full((N_PATHS, 2), self.r)
        self.sub_rates = sub_rates
        self.sub_accruals = np.array([self.tau1, self.tau2])

    def _call(self, compounding_method="None", averaging_method="None"):
        return _apply_compounding_method(
            self.sub_rates, self.sub_accruals, self.tau_total,
            self.m, compounding_method, averaging_method,
        )

    def test_include_margin(self):
        # prod((1 + (r+m)*tau)) - 1 = (1 + 0.08*0.25)^2 - 1
        expected = (1 + (self.r + self.m) * self.tau1) ** 2 - 1
        result = self._call("Include_Margin")
        npt.assert_allclose(result, expected, rtol=1e-12)

    def test_flat(self):
        # RiskFlow exact recurrence: total_new = total_old*(1+r*tau) + (r+m)*tau
        # For 2 equal sub-periods: total = (r+m)*tau*(2 + r*tau)
        r, m, tau = self.r, self.m, self.tau1
        expected = (r + m) * tau * (2 + r * tau)
        result = self._call("Flat")
        npt.assert_allclose(result, expected, rtol=1e-12)

    def test_exclude_margin(self):
        # Same formula as Flat
        result_flat = self._call("Flat")
        result_excl = self._call("Exclude_Margin")
        npt.assert_allclose(result_excl, result_flat, rtol=1e-12)

    def test_exponential(self):
        # exp(sum(r*tau)) - 1 + m*tau_total
        expected = math.exp(self.r * self.tau_total) - 1 + self.m * self.tau_total
        result = self._call("Exponential")
        npt.assert_allclose(result, expected, rtol=1e-12)

    def test_average_rate(self):
        # (mean(r) + m) * tau_total = (0.07 + 0.01) * 0.5
        expected = (self.r + self.m) * self.tau_total
        result = self._call(averaging_method="Average_Rate")
        npt.assert_allclose(result, expected, rtol=1e-12)

    def test_average_interest(self):
        # sum(r*tau) + m*tau_total = 2*(0.07*0.25) + 0.01*0.5
        expected = 2 * (self.r * self.tau1) + self.m * self.tau_total
        result = self._call(averaging_method="Average_Interest")
        npt.assert_allclose(result, expected, rtol=1e-12)

    def test_compounding_takes_precedence_over_averaging(self):
        """When both compounding_method and averaging_method are non-'None',
        compounding wins — matching RiskFlow's engine which never reads
        Averaging_Method when Compounding_Method is active."""
        result_both = _apply_compounding_method(
            self.sub_rates, self.sub_accruals, self.tau_total,
            self.m, "Include_Margin", "Average_Rate",
        )
        result_comp_only = _apply_compounding_method(
            self.sub_rates, self.sub_accruals, self.tau_total,
            self.m, "Include_Margin", "None",
        )
        npt.assert_allclose(result_both, result_comp_only, rtol=1e-12)

    def test_include_margin_greater_than_flat(self):
        # Include_Margin compounds the spread; should exceed Flat when r,m>0
        inc = self._call("Include_Margin")
        flat = self._call("Flat")
        assert np.all(inc > flat)

    def test_per_path_variation(self):
        # Different rates on different paths → different results.
        # Note: the RiskFlow recurrence is order-sensitive, so [r1, r2] != [r2, r1].
        sub_rates = np.array([[0.06, 0.08]] * N_PATHS, dtype=float)
        sub_rates[0] = [0.08, 0.06]   # same two rates but reversed order
        result = _apply_compounding_method(
            sub_rates, self.sub_accruals, self.tau_total,
            self.m, "Flat", "None",
        )
        assert result.shape == (N_PATHS,)
        # [0.08, 0.06] and [0.06, 0.08] give different recurrence totals
        assert not np.allclose(result[0], result[1])


# ---------------------------------------------------------------------------
# leg_pv dispatch — full PV with discounting
# ---------------------------------------------------------------------------

class TestLegPvCompounding:
    """End-to-end leg_pv tests with sub-period compounding."""

    def _make_schedule(self):
        # Single 6M payment period: Jan→Jul 2025
        from utils.ql_helpers import DAY_COUNTERS, build_schedule, CALENDARS, BUSINESS_CONVENTIONS, DATE_GENERATION
        cal = CALENDARS["ZAR"]
        dc  = DAY_COUNTERS["ACT/365"]
        return build_schedule(
            date(2025, 1, 2), date(2025, 7, 2), freq_months=6,
            calendar=cal,
            convention=ql.ModifiedFollowing,
            termination_convention=ql.ModifiedFollowing,
            date_generation=ql.DateGeneration.Backward,
            day_counter=dc,
        )

    def _common_kwargs(self, leg):
        return dict(
            leg=leg,
            notional=NOTIONAL,
            val_date=date(2025, 1, 2),
            market_state=make_market_state(),
            discount_curve=make_discount_curve(),
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
            day_counter=DAY_COUNTERS["ACT/365"],
            curve_day_counter=DAY_COUNTERS["ACT/365"],
            calendar=CALENDARS["ZAR"],
            fixings=None,
        )

    def test_flat_gt_simple_on_flat_cc_curve(self):
        """RiskFlow Flat compounding is slightly above simple interest on a flat CC curve.

        The recurrence total_new = total_old*(1+r*tau) + (r+m)*tau introduces a
        cross-term (r+m)*tau_1 * r*tau_2 that makes Flat exceed simple interest
        whenever margin > 0.  (With zero spread they would coincide.)
        """
        schedule = self._make_schedule()

        simple_leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
        )
        flat_leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
            reset_frequency_months=3, compounding_method="Flat",
        )
        pv_simple = leg_pv(schedule, **self._common_kwargs(simple_leg))
        pv_flat   = leg_pv(schedule, **self._common_kwargs(flat_leg))
        assert np.all(pv_flat > pv_simple)

    def test_include_margin_gt_flat(self):
        """Include_Margin (compounds spread) > Flat (spread linear)."""
        schedule = self._make_schedule()
        kwargs_base = dict(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
            reset_frequency_months=3,
        )
        pv_flat = leg_pv(schedule, **self._common_kwargs(
            CashflowLeg(**kwargs_base, compounding_method="Flat")))
        pv_inc  = leg_pv(schedule, **self._common_kwargs(
            CashflowLeg(**kwargs_base, compounding_method="Include_Margin")))
        assert np.all(pv_inc > pv_flat)

    def test_flat_analytical(self):
        """leg_pv Flat result matches RiskFlow recurrence hand-computed value.

        The YieldCurve stores CC rates: DF(t) = exp(-r*t), so the simply-compounded
        forward rate for a sub-period [t_s, t_e] with accrual tau is:
            r_sc = (exp(r_cc*(t_e - t_s)) - 1) / tau
        This must be used in the recurrence, not the raw r_cc input.
        """
        schedule = self._make_schedule()
        leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
            reset_frequency_months=3, compounding_method="Flat",
        )
        pv = leg_pv(schedule, **self._common_kwargs(leg))

        # Approx sub-period taus: Jan-02→Apr-02 (90d) and Apr-02→Jul-02 (91d) ACT/365
        tau1, tau2 = 90 / 365, 91 / 365
        # Actual simply-compounded forward rates on the flat 7% CC curve
        r_sc_1 = (math.exp(FLAT_FWD * tau1) - 1) / tau1
        r_sc_2 = (math.exp(FLAT_FWD * tau2) - 1) / tau2
        # RiskFlow exact recurrence: total_new = total_old*(1+r*tau) + (r+m)*tau
        total = 0.0
        total = total * (1 + r_sc_1 * tau1) + (r_sc_1 + SPREAD) * tau1
        total = total * (1 + r_sc_2 * tau2) + (r_sc_2 + SPREAD) * tau2
        df = math.exp(-FLAT_DISC * (tau1 + tau2))
        expected = NOTIONAL * total * df
        npt.assert_allclose(pv, expected, rtol=1e-3)   # residual from ZAR calendar adjustments

    def test_average_rate_lt_simple_on_flat_cc_curve(self):
        """Average_Rate underestimates simple interest on a flat CC curve.

        On a flat CC curve at rate r, each sub-period simply-compounded rate is
        r_sc_sub = (exp(r*tau_sub)-1)/tau_sub, which is strictly less than the
        full-period rate r_sc_full = (exp(r*tau_total)-1)/tau_total for
        tau_sub < tau_total.  Hence mean(r_sc_sub) < r_sc_full, giving PV_avg < PV_simple.
        """
        schedule = self._make_schedule()
        avg_leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
            reset_frequency_months=3, averaging_method="Average_Rate",
        )
        simple_leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
        )
        pv_avg    = leg_pv(schedule, **self._common_kwargs(avg_leg))
        pv_simple = leg_pv(schedule, **self._common_kwargs(simple_leg))
        assert np.all(pv_avg < pv_simple), (
            "Average_Rate must be less than simple interest on a flat CC curve"
        )
        assert np.all(np.isfinite(pv_avg))

    def test_average_interest_lt_simple_on_flat_cc_curve(self):
        """Average_Interest underestimates simple interest on a flat CC curve.

        sum_i(r_sc_i * tau_i) = sum_i(exp(r*tau_i)-1) < exp(r*tau_total)-1
        by convexity of exp, so PV_avg_interest < PV_simple.
        """
        schedule = self._make_schedule()
        avg_leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
            reset_frequency_months=3, averaging_method="Average_Interest",
        )
        simple_leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=SPREAD,
        )
        pv_avg    = leg_pv(schedule, **self._common_kwargs(avg_leg))
        pv_simple = leg_pv(schedule, **self._common_kwargs(simple_leg))
        assert np.all(pv_avg < pv_simple), (
            "Average_Interest must be less than simple interest on a flat CC curve"
        )
        assert np.all(np.isfinite(pv_avg))

    def test_in_progress_uses_past_fixing(self):
        """Past sub-period rate from fixings dominates; future from fwd curve."""
        schedule = self._make_schedule()   # Jan→Jul 2025 (6M, 2 sub-periods of 3M each)

        leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR", spread=0.0,
            reset_frequency_months=3, compounding_method="Flat",
        )
        # Val date = Apr-02 (second sub-period start): first sub-period is past
        val_date = date(2025, 4, 2)
        fixed_rate = 0.12   # past fixing far from current fwd
        fixings = {("JIBAR", date(2025, 1, 2)): np.full(N_PATHS, fixed_rate)}

        kwargs = dict(
            leg=leg,
            notional=NOTIONAL,
            val_date=val_date,
            market_state=make_market_state(fwd_rate=0.07),
            discount_curve=make_discount_curve(),
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
            day_counter=DAY_COUNTERS["ACT/365"],
            curve_day_counter=DAY_COUNTERS["ACT/365"],
            calendar=CALENDARS["ZAR"],
            fixings=fixings,
        )
        pv_with_fixing = leg_pv(schedule, **kwargs)
        pv_no_fixing   = leg_pv(schedule, **{**kwargs, "fixings": None})

        # Past fixing at 12% vs forward at 7% → PV must differ
        assert not np.allclose(pv_with_fixing, pv_no_fixing, rtol=1e-3)


# ---------------------------------------------------------------------------
# IRSwap.get_reset_dates sub-period emission
# ---------------------------------------------------------------------------

class TestIRSwapSubPeriodResets:
    def _make_swap(self, *, recv_reset_months=0, pay_reset_months=0):
        return IRSwap(
            name="TEST",
            effective_date=date(2025, 1, 2),
            maturity_date=date(2026, 1, 2),
            notional=NOTIONAL,
            receive_leg=CashflowLeg(
                leg_type=LegType.FLOATING, frequency=6,
                curve_name="JIBAR",
                reset_frequency_months=recv_reset_months,
                compounding_method="Flat" if recv_reset_months else "None",
            ),
            pay_leg=CashflowLeg(
                leg_type=LegType.FIXED, frequency=6,
                fixed_rate=0.09,
            ),
            discount_curve_name="DISC",
            interpolator=linear_interpolator,
            calendar="ZAR",
        )

    def test_no_sub_periods_two_resets(self):
        """Standard: 1Y semi-annual → 2 payment periods → 2 reset tuples."""
        swap = self._make_swap()
        resets = swap.get_reset_dates()
        assert len(resets) == 2

    def test_sub_periods_four_resets(self):
        """1Y semi-annual payment, 3M JIBAR resets → 4 sub-period resets."""
        swap = self._make_swap(recv_reset_months=3)
        resets = swap.get_reset_dates()
        assert len(resets) == 4

    def test_sub_period_continuity(self):
        """Sub-period end dates of one payment period chain correctly."""
        swap = self._make_swap(recv_reset_months=3)
        resets = swap.get_reset_dates()
        # First payment period: Jan→Apr, Apr→Jul; second: Jul→Oct, Oct→Jan
        dates = [r[0] for r in resets]
        # All reset dates should be in ascending order
        assert dates == sorted(dates)

    def test_scenario_npvs_compounding_swap(self):
        """Full pricing: compounded JIBAR swap gives finite, non-zero NPV."""
        swap = self._make_swap(recv_reset_months=3)
        ms = make_market_state()
        npvs = swap.scenario_npvs(date(2025, 1, 2), ms)
        assert npvs.shape == (N_PATHS,)
        assert np.all(np.isfinite(npvs))
        assert not np.allclose(npvs, 0.0)


# ---------------------------------------------------------------------------
# IndexLinkedSwap nominal leg compounding
# ---------------------------------------------------------------------------

class TestILSNominalCompounding:
    def _make_ils(self, *, reset_months=0, compounding="None"):
        base_cpi = 130.0
        return IndexLinkedSwap(
            name="ILS_COMP",
            effective_date=date(2025, 1, 2),
            maturity_date=date(2028, 1, 2),
            notional=NOTIONAL,
            inflation_leg=InflationLeg(
                frequency=6,
                fixed_rate=0.02,
                cpi_curve_name="ZAR_CPI",
                base_cpi=base_cpi,
                lag_months=4,
            ),
            nominal_leg=CashflowLeg(
                leg_type=LegType.FLOATING, frequency=6,
                curve_name="JIBAR", spread=SPREAD,
                reset_frequency_months=reset_months,
                compounding_method=compounding,
            ),
            discount_curve_name="DISC",
            discount_interpolator=linear_interpolator,
            cpi_interpolator=linear_interpolator,
            forward_interpolator=linear_interpolator,
            inflation_receiver=True,
            calendar="TARGET",
        )

    def _market_state(self, n_paths=N_PATHS, cpi=130.0):
        # Multi-tenor CPI curve (legacy mode): flat CPI across all future
        # reference months so the index ratio = 1.0 everywhere.
        # Tenors cover the BESA bracket dates of a 3-year ILS (4-month lag):
        # bracket dates run from ~Mar-2025 to ~Sep-2027, max ~2.66 yr fracs.
        cpi_tenors = np.array([0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0])
        return {
            "DISC":    flat_curve_slice(FLAT_DISC, n_paths),
            "JIBAR":   flat_curve_slice(FLAT_FWD, n_paths),
            "ZAR_CPI": CurveSlice(
                values=np.tile(np.full(len(cpi_tenors), cpi), (n_paths, 1)),
                tenors=cpi_tenors,
            ),
        }

    def test_get_reset_dates_sub_periods(self):
        """3Y ILS with semi-annual payment and 3M backward resets.

        Calendar-adjusted periods that are slightly over 6M (e.g., 186 days in
        TARGET) produce a short stub sub-period at the front under backward
        generation, yielding 3 sub-periods for those payment periods.
        """
        ils = self._make_ils(reset_months=3, compounding="Flat")
        resets = ils.get_reset_dates()
        # At least 12 (2 per period × 6 periods); calendar stubs can add more
        assert len(resets) >= 12

    def test_get_reset_dates_standard(self):
        """Standard (no sub-periods): 3Y semi-annual → 6 reset tuples."""
        ils = self._make_ils()
        resets = ils.get_reset_dates()
        assert len(resets) == 6

    def test_scenario_npvs_compounding(self):
        """Full ILS pricing with compounding nominal leg produces finite NPV."""
        ils = self._make_ils(reset_months=3, compounding="Flat")
        ms = self._market_state()
        npvs = ils.scenario_npvs(date(2025, 1, 2), ms)
        assert npvs.shape == (N_PATHS,)
        assert np.all(np.isfinite(npvs))

    def test_include_margin_npv_differs_from_simple(self):
        """Include_Margin compounding on nominal leg gives different NPV from simple.

        Unlike Flat (which equals simple on a flat CC curve), Include_Margin
        compounds the spread too, producing a higher nominal-leg PV and thus a
        lower net NPV when we are inflation receivers.
        """
        ils_simple = self._make_ils()
        ils_comp   = self._make_ils(reset_months=3, compounding="Include_Margin")
        ms = self._market_state()
        val = date(2025, 1, 2)
        npv_simple = ils_simple.scenario_npvs(val, ms)
        npv_comp   = ils_comp.scenario_npvs(val, ms)
        # Include_Margin: higher nominal PV → lower inflation-receiver NPV
        assert np.all(npv_comp < npv_simple)


# ---------------------------------------------------------------------------
# CashflowLeg validation
# ---------------------------------------------------------------------------

class TestCashflowLegValidation:
    def test_invalid_compounding_method(self):
        with pytest.raises(ValueError, match="compounding_method"):
            CashflowLeg(
                leg_type=LegType.FLOATING, frequency=6,
                curve_name="JIBAR", compounding_method="BadMethod",
            )

    def test_invalid_averaging_method(self):
        with pytest.raises(ValueError, match="averaging_method"):
            CashflowLeg(
                leg_type=LegType.FLOATING, frequency=6,
                curve_name="JIBAR", averaging_method="Daily_LIBOR",
            )

    def test_both_methods_set_does_not_raise(self):
        """Both compounding and averaging set simultaneously is valid (RiskFlow allows it).
        Compounding takes precedence; averaging_method is silently ignored."""
        leg = CashflowLeg(
            leg_type=LegType.FLOATING, frequency=6,
            curve_name="JIBAR",
            reset_frequency_months=3,
            compounding_method="Include_Margin",
            averaging_method="Average_Rate",
        )
        assert leg.compounding_method == "Include_Margin"
        assert leg.averaging_method == "Average_Rate"
