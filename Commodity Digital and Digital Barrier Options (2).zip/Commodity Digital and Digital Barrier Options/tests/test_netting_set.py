import pytest
from unittest.mock import MagicMock

from instruments.instrument import Instrument
from portfolio.trade import Trade
from portfolio.csa import CSA
from portfolio.netting_set import NettingSet


def make_trade(trade_id: str, counterparty_id: str = "CPTY_A") -> Trade:
    inst = MagicMock(spec=Instrument)
    inst.name = trade_id
    return Trade(trade_id=trade_id, counterparty_id=counterparty_id, instrument=inst)


class TestNettingSetConstruction:
    def test_basic_construction(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        assert ns.netting_set_id == "NS1"
        assert ns.counterparty_id == "CPTY_A"
        assert ns.trades == []
        assert ns.csa is None

    def test_construction_with_trades(self):
        t1 = make_trade("T1")
        t2 = make_trade("T2")
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A", trades=[t1, t2])
        assert ns.n_trades == 2

    def test_construction_with_csa(self):
        csa = CSA(vm_threshold=0.0, mpor_days=10)
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A", csa=csa)
        assert ns.csa is csa

    def test_mismatched_counterparty_raises(self):
        t_wrong = make_trade("T1", counterparty_id="CPTY_B")
        with pytest.raises(ValueError, match="CPTY_B"):
            NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A", trades=[t_wrong])

    def test_trades_default_independent(self):
        ns1 = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        ns2 = NettingSet(netting_set_id="NS2", counterparty_id="CPTY_A")
        ns1.add_trade(make_trade("T1"))
        assert ns2.n_trades == 0


class TestNettingSetMutation:
    def test_add_trade(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        ns.add_trade(make_trade("T1"))
        assert ns.n_trades == 1

    def test_add_trade_wrong_counterparty_raises(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        with pytest.raises(ValueError, match="CPTY_B"):
            ns.add_trade(make_trade("T1", counterparty_id="CPTY_B"))

    def test_remove_trade(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        ns.add_trade(make_trade("T1"))
        ns.add_trade(make_trade("T2"))
        ns.remove_trade("T1")
        assert ns.n_trades == 1
        assert ns.trades[0].trade_id == "T2"

    def test_remove_nonexistent_trade_is_noop(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        ns.remove_trade("NONEXISTENT")  # should not raise
        assert ns.n_trades == 0

    def test_get_trade(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        t = make_trade("T1")
        ns.add_trade(t)
        assert ns.get_trade("T1") is t

    def test_get_trade_missing_raises(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        with pytest.raises(KeyError, match="T99"):
            ns.get_trade("T99")


class TestNettingSetProperties:
    def test_is_collateralised_no_csa(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        assert ns.is_collateralised is False

    def test_is_collateralised_with_csa(self):
        csa = CSA(vm_threshold=0.0)
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A", csa=csa)
        assert ns.is_collateralised is True

    def test_n_trades(self):
        ns = NettingSet(netting_set_id="NS1", counterparty_id="CPTY_A")
        assert ns.n_trades == 0
        ns.add_trade(make_trade("T1"))
        ns.add_trade(make_trade("T2"))
        assert ns.n_trades == 2
