"""
Tests for instruments/commodity_digital_barrier_option.py —
CommodityDigitalBarrierOption.
"""
from __future__ import annotations

import warnings
from datetime import date

import numpy as np
import numpy.testing as npt
import pytest

from instruments.commodity_digital_barrier_option import CommodityDigitalBarrierOption
from market_data.risk_factor import CurveSlice, ScalarSlice
from models.commodity_digital_pv import commodity_barrier_digital_price
from utils.interpolation import forward_price_interpolator, linear_interpolator
from utils.ql_helpers import DAY_COUNTERS, advance_business_days, to_ql_date

N_PATHS = 6
VAL_DATE = date(2025, 1, 2)
MONITOR_START = date(2025, 1, 2)
MATURITY = date(2026, 1, 2)  # ACT/365 -> T ~= 1.0

FWD_PRICE = 4861.9443
VOL = 0.276
DISC_RATE = 0.036943
COST_OF_CARRY = 0.035428

FWD_TENORS = np.array([45658.0, 45750.0, 45841.0, 46024.0, 46389.0, 47484.0])  # Excel serials
CURVE_TENORS_YF = np.array([0.083, 0.25, 0.5, 1.0, 2.0, 5.0])


def fwd_slice(price=FWD_PRICE):
    return CurveSlice(
        values=np.full((N_PATHS, len(FWD_TENORS)), price, dtype=np.float64),
        tenors=FWD_TENORS,
    )


def disc_slice(rate=DISC_RATE):
    return CurveSlice(
        values=np.full((N_PATHS, len(CURVE_TENORS_YF)), rate, dtype=np.float64),
        tenors=CURVE_TENORS_YF,
    )


def vol_slice(vol=VOL):
    return ScalarSlice(values=np.full(N_PATHS, vol, dtype=np.float64))


def make_market_state(price=FWD_PRICE, vol=VOL, rate=DISC_RATE):
    return {"FWD": fwd_slice(price), "DISC": disc_slice(rate), "VOL": vol_slice(vol)}


def make_instrument(
    upper_barrier=5000.0, lower_barrier=None, touch="in", digital_type="cash",
    monitoring="continuous", payout=200.0, n_mc_inner_paths=2000,
    settle_days=0, spot_days=0,
):
    return CommodityDigitalBarrierOption(
        name="TEST_BARRIER",
        maturity_date=MATURITY,
        monitoring_start_date=MONITOR_START,
        upper_barrier=upper_barrier,
        lower_barrier=lower_barrier,
        touch=touch,
        digital_type=digital_type,
        payout=payout,
        forward_curve_name="FWD",
        discount_curve_name="DISC",
        vol_name="VOL",
        monitoring=monitoring,
        monitoring_calendar="USD",
        forward_interpolator=forward_price_interpolator,
        discount_interpolator=linear_interpolator,
        cost_of_carry=COST_OF_CARRY,
        spot_days=spot_days,
        settle_days=settle_days,
        settlement_calendar="USD",
        n_mc_inner_paths=n_mc_inner_paths,
        day_count="ACT/365",
    )


# ---------------------------------------------------------------------------
# Continuous closed form — matches the model-level function directly
# ---------------------------------------------------------------------------

def test_continuous_up_in_matches_model_function():
    inst = make_instrument(touch="in")
    ms = make_market_state()
    npv = inst.scenario_npvs(VAL_DATE, ms)

    dc = DAY_COUNTERS["ACT/365"]
    T = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(MATURITY)))
    expected = commodity_barrier_digital_price(
        np.full(N_PATHS, FWD_PRICE), 5000.0, np.full(N_PATHS, VOL),
        np.full(N_PATHS, COST_OF_CARRY), np.full(N_PATHS, np.exp(-DISC_RATE * T)),
        T, "up", "in", 200.0,
    )
    npt.assert_allclose(npv, expected, rtol=1e-6)


def test_one_touch_and_no_touch_sum_to_certain_payout():
    inst_in = make_instrument(touch="in")
    inst_out = make_instrument(touch="out")
    ms = make_market_state()

    v_in = inst_in.scenario_npvs(VAL_DATE, ms)
    v_out = inst_out.scenario_npvs(VAL_DATE, ms)

    dc = DAY_COUNTERS["ACT/365"]
    T = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(MATURITY)))
    df = np.exp(-DISC_RATE * T)
    npt.assert_allclose(v_in + v_out, df * 200.0, rtol=1e-8)


def test_past_settlement_returns_zero():
    inst = make_instrument(settle_days=2)
    ms = make_market_state()
    npv = inst.scenario_npvs(date(2027, 1, 5), ms)
    npt.assert_allclose(npv, np.zeros(N_PATHS))


# ---------------------------------------------------------------------------
# Cost-of-carry sourcing precedence
# ---------------------------------------------------------------------------

def test_curve_implied_cost_of_carry_fallback_runs():
    inst = CommodityDigitalBarrierOption(
        name="TEST_IMPLIED_B",
        maturity_date=MATURITY,
        monitoring_start_date=MONITOR_START,
        upper_barrier=5000.0,
        lower_barrier=None,
        touch="in",
        digital_type="cash",
        payout=200.0,
        forward_curve_name="FWD",
        discount_curve_name="DISC",
        vol_name="VOL",
        monitoring="continuous",
        monitoring_calendar="USD",
        cost_of_carry=None,      # no explicit b
        carry_curve_name=None,   # no dedicated carry curve
        settle_days=0,
    )
    # Sloped forward curve so the curve-implied b is non-trivial.
    sloped = CurveSlice(
        values=np.tile(np.linspace(4700.0, 5200.0, len(FWD_TENORS)), (N_PATHS, 1)),
        tenors=FWD_TENORS,
    )
    ms = {"FWD": sloped, "DISC": disc_slice(), "VOL": vol_slice()}
    npv = inst.scenario_npvs(VAL_DATE, ms)
    assert np.all(np.isfinite(npv))
    assert np.all(npv >= 0.0)


# ---------------------------------------------------------------------------
# Discrete Monte Carlo
# ---------------------------------------------------------------------------

def test_discrete_monitoring_requires_rng():
    inst = make_instrument(monitoring="discrete")
    ms = make_market_state()
    with pytest.raises(ValueError, match="rng"):
        inst.scenario_npvs(VAL_DATE, ms, rng=None)


def test_discrete_monitoring_approximates_continuous_closed_form():
    inst_disc = make_instrument(monitoring="discrete", n_mc_inner_paths=3000)
    inst_cont = make_instrument(monitoring="continuous")
    ms = make_market_state()

    rng = np.random.default_rng(123)
    npv_mc = inst_disc.scenario_npvs(VAL_DATE, ms, rng=rng)
    npv_cf = inst_cont.scenario_npvs(VAL_DATE, ms)

    npt.assert_allclose(npv_mc.mean(), npv_cf.mean(), rtol=0.05)


def test_double_barrier_and_asset_type_fall_back_to_mc_with_warning():
    with pytest.warns(UserWarning, match="Monte Carlo"):
        inst = make_instrument(upper_barrier=5200.0, lower_barrier=4500.0)
    assert inst._requires_mc

    with pytest.warns(UserWarning, match="Monte Carlo"):
        inst_asset = make_instrument(digital_type="asset")
    assert inst_asset._requires_mc

    ms = make_market_state()
    rng = np.random.default_rng(1)
    npv = inst.scenario_npvs(VAL_DATE, ms, rng=rng)
    assert np.all(np.isfinite(npv))


# ---------------------------------------------------------------------------
# Path-continuity latch (fixings)
# ---------------------------------------------------------------------------

def test_get_commodity_fixing_schedule_matches_monitoring_dates():
    inst = make_instrument()
    sched = inst.get_commodity_fixing_schedule()
    assert len(sched) == len(inst._monitoring_dates)
    assert sched[0][0] == inst._monitoring_dates[0]


def test_already_touched_fixing_forces_deterministic_payout():
    inst = make_instrument(touch="in", payout=200.0)
    ms = make_market_state()

    later_val_date = date(2025, 6, 2)
    monitor_date = next(d for d in inst._monitoring_dates if d <= later_val_date)

    # Stamp a fixing that breached the upper barrier on an earlier date.
    fixings = {("FWD", monitor_date): np.full(N_PATHS, 5500.0)}
    npv = inst.scenario_npvs(later_val_date, ms, fixings=fixings)

    dc = DAY_COUNTERS["ACT/365"]
    settle = advance_business_days(MATURITY, 0, "USD")
    T_disc = float(dc.yearFraction(to_ql_date(later_val_date), to_ql_date(settle)))
    expected = np.full(N_PATHS, 200.0 * np.exp(-DISC_RATE * T_disc))
    npt.assert_allclose(npv, expected, rtol=1e-8)


def test_already_touched_no_touch_pays_zero():
    inst = make_instrument(touch="out", payout=200.0)
    ms = make_market_state()

    later_val_date = date(2025, 6, 2)
    monitor_date = next(d for d in inst._monitoring_dates if d <= later_val_date)
    fixings = {("FWD", monitor_date): np.full(N_PATHS, 5500.0)}
    npv = inst.scenario_npvs(later_val_date, ms, fixings=fixings)
    npt.assert_allclose(npv, np.zeros(N_PATHS))


def test_compute_commodity_fixings_stamps_new_dates_only():
    inst = make_instrument()
    ms = make_market_state()
    sim_date = date(2025, 1, 3)

    fixings1 = inst.compute_commodity_fixings(ms, sim_date)
    assert len(fixings1) > 0

    fixings2 = inst.compute_commodity_fixings(ms, sim_date, existing_fixings=fixings1)
    assert fixings2 == {}  # nothing new to stamp


# ---------------------------------------------------------------------------
# Greeks
# ---------------------------------------------------------------------------

def test_analytic_delta_vega_match_bump_and_reprice():
    inst = make_instrument()
    ms = make_market_state()

    analytic = inst.analytic_greeks(VAL_DATE, ms)
    bump = inst.greeks_bump_and_reprice(VAL_DATE, ms)
    npt.assert_allclose(analytic["delta"], bump["delta"], rtol=1e-3)
    npt.assert_allclose(analytic["vega"], bump["vega"], rtol=1e-3)


def test_analytic_greeks_raise_for_mc_only_configurations():
    with pytest.warns(UserWarning):
        inst = make_instrument(digital_type="asset")
    ms = make_market_state()
    with pytest.raises(NotImplementedError):
        inst.analytic_greeks(VAL_DATE, ms)


def test_bump_and_reprice_greeks_work_for_discrete_mc():
    inst = make_instrument(monitoring="discrete", n_mc_inner_paths=1500)
    ms = make_market_state()
    bump = inst.greeks_bump_and_reprice(VAL_DATE, ms, mc_seed=99)
    assert np.all(np.isfinite(bump["delta"]))
    assert np.all(np.isfinite(bump["vega"]))
    assert np.all(np.isfinite(bump["theta"]))