"""
Tests for market_data/static_curve.py — generate_static_curve_scenarios
and hazard_rates_from_default_probs.
"""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import numpy.testing as npt
import pytest

from market_data.curve_generation import (
    generate_static_curve_scenarios,
    hazard_rates_from_default_probs,
)
from utils.interpolation import linear_interpolator, linear_rt_interp


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VAL_DATE = date(2025, 1, 2)
N_PATHS = 5
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0, 10.0], dtype=np.float64)
OUTPUT_TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0], dtype=np.float64)
FLAT_RATE = 0.05

SIM_DATES = tuple(
    VAL_DATE + timedelta(days=90 * i) for i in range(5)
)


# ---------------------------------------------------------------------------
# generate_static_curve_scenarios — shape tests
# ---------------------------------------------------------------------------

class TestGenerateStaticCurveScenariosShape:

    def test_output_shape(self):
        rates = np.full(len(TENORS), FLAT_RATE)
        paths, out_tenors, out_dates = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
        )
        n_times = len(SIM_DATES)
        n_out = len(OUTPUT_TENORS)
        assert paths.shape == (N_PATHS, n_times, n_out)

    def test_returns_three_tuple(self):
        rates = np.full(len(TENORS), FLAT_RATE)
        result = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
        )
        assert len(result) == 3

    def test_output_tenors_passthrough(self):
        rates = np.full(len(TENORS), FLAT_RATE)
        _, out_tenors, _ = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
        )
        npt.assert_array_equal(out_tenors, OUTPUT_TENORS)

    def test_simulation_dates_passthrough(self):
        rates = np.full(len(TENORS), FLAT_RATE)
        _, _, out_dates = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
        )
        assert out_dates == SIM_DATES


# ---------------------------------------------------------------------------
# generate_static_curve_scenarios — flat curve forward roll
# ---------------------------------------------------------------------------

class TestGenerateStaticCurveScenariosValues:

    def test_flat_curve_forward_rates_equal_spot(self):
        """
        For a flat spot curve, forward rolled rates should still equal
        the spot rate at all output tenors and all simulation dates.
        """
        rates = np.full(len(TENORS), FLAT_RATE)
        paths, _, _ = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_rt_interp,
        )
        npt.assert_allclose(paths, FLAT_RATE, atol=1e-8)

    def test_all_paths_identical(self):
        """Static curve: all paths should be identical at every time step."""
        rates = np.array([0.02, 0.03, 0.04, 0.05, 0.06, 0.07])
        paths, _, _ = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
        )
        for t_idx in range(len(SIM_DATES)):
            for p in range(1, N_PATHS):
                npt.assert_array_equal(paths[0, t_idx, :], paths[p, t_idx, :])

    def test_first_date_is_valuation_date_returns_spot(self):
        """
        When the first simulation date equals the valuation date,
        the forward curve should equal the spot curve.
        """
        rates = np.array([0.02, 0.03, 0.04, 0.05, 0.06, 0.07])
        sim_dates_with_val = (VAL_DATE,) + SIM_DATES[1:]
        paths, _, _ = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=sim_dates_with_val,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
        )
        from market_data.yield_curve import YieldCurve
        rates_2d = rates[np.newaxis, :]
        curve = YieldCurve(
            year_fracs=TENORS,
            rates=rates_2d,
            interpolator=linear_interpolator,
        )
        spot_rates = curve.get_rate(OUTPUT_TENORS)[0, :]
        npt.assert_allclose(paths[0, 0, :], spot_rates, atol=1e-10)


# ---------------------------------------------------------------------------
# Frozen mode
# ---------------------------------------------------------------------------

class TestFrozenMode:

    def test_frozen_paths_identical_across_all_dates(self):
        rates = np.array([0.02, 0.03, 0.04, 0.05, 0.06, 0.07])
        paths, _, _ = generate_static_curve_scenarios(
            rates=rates,
            tenors=TENORS,
            simulation_dates=SIM_DATES,
            valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS,
            n_paths=N_PATHS,
            interpolator=linear_interpolator,
            frozen=True,
        )
        for t_idx in range(1, len(SIM_DATES)):
            npt.assert_array_equal(paths[0, 0, :], paths[0, t_idx, :])

    def test_frozen_vs_non_frozen_at_val_date_equal(self):
        """At valuation date, frozen and non-frozen should agree."""
        rates = np.array([0.02, 0.03, 0.04, 0.05, 0.06, 0.07])
        sim_dates = (VAL_DATE,)
        paths_f, _, _ = generate_static_curve_scenarios(
            rates=rates, tenors=TENORS,
            simulation_dates=sim_dates, valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS, n_paths=N_PATHS,
            interpolator=linear_interpolator, frozen=True,
        )
        paths_nf, _, _ = generate_static_curve_scenarios(
            rates=rates, tenors=TENORS,
            simulation_dates=sim_dates, valuation_date=VAL_DATE,
            output_tenors=OUTPUT_TENORS, n_paths=N_PATHS,
            interpolator=linear_interpolator, frozen=False,
        )
        npt.assert_allclose(paths_f, paths_nf, atol=1e-10)


# ---------------------------------------------------------------------------
# hazard_rates_from_default_probs
# ---------------------------------------------------------------------------

class TestHazardRatesFromDefaultProbs:

    def test_basic_conversion(self):
        pd_curve = [[0.25, 0.001], [0.5, 0.003], [1.0, 0.008], [2.0, 0.018]]
        tenors, hazards = hazard_rates_from_default_probs(pd_curve)
        assert tenors.shape == (4,)
        assert hazards.shape == (4,)

    def test_hazard_rates_positive(self):
        pd_curve = [[0.25, 0.001], [0.5, 0.003], [1.0, 0.008], [2.0, 0.018]]
        _, hazards = hazard_rates_from_default_probs(pd_curve)
        assert np.all(hazards > 0)

    def test_analytical_hazard_rate(self):
        """h = -ln(1 - PD) / t for each pillar."""
        pd_curve = [[1.0, 0.01], [2.0, 0.02]]
        tenors, hazards = hazard_rates_from_default_probs(pd_curve)
        expected = np.array([-np.log(1 - 0.01) / 1.0, -np.log(1 - 0.02) / 2.0])
        npt.assert_allclose(hazards, expected, atol=1e-12)

    def test_sorted_by_tenor(self):
        pd_curve = [[2.0, 0.02], [0.5, 0.005], [1.0, 0.01]]
        tenors, _ = hazard_rates_from_default_probs(pd_curve)
        assert np.all(np.diff(tenors) > 0), "Tenors should be sorted ascending"

    def test_zero_tenor_excluded(self):
        pd_curve = [[0.0, 0.0], [1.0, 0.01], [2.0, 0.02]]
        tenors, hazards = hazard_rates_from_default_probs(pd_curve)
        assert not np.any(tenors == 0.0)

    def test_pd_ge_1_raises(self):
        pd_curve = [[1.0, 1.0]]
        with pytest.raises(ValueError, match="Default probabilities"):
            hazard_rates_from_default_probs(pd_curve)

    def test_pd_negative_raises(self):
        pd_curve = [[1.0, -0.01]]
        with pytest.raises(ValueError, match="Default probabilities"):
            hazard_rates_from_default_probs(pd_curve)

    def test_no_positive_tenors_raises(self):
        pd_curve = [[0.0, 0.0]]
        with pytest.raises(ValueError, match="No positive tenors"):
            hazard_rates_from_default_probs(pd_curve)

    def test_accepts_numpy_array(self):
        pd_arr = np.array([[0.5, 0.005], [1.0, 0.01], [2.0, 0.02]])
        tenors, hazards = hazard_rates_from_default_probs(pd_arr)
        assert tenors.shape == (3,)
        assert hazards.shape == (3,)

    def test_survival_probability_round_trip(self):
        """exp(-h(t) * t) should equal 1 - PD(t)."""
        pd_curve = [[0.5, 0.005], [1.0, 0.01], [2.0, 0.025]]
        tenors, hazards = hazard_rates_from_default_probs(pd_curve)
        pds = np.array([0.005, 0.01, 0.025])
        surv_reconstructed = np.exp(-hazards * tenors)
        npt.assert_allclose(surv_reconstructed, 1.0 - pds, atol=1e-12)
