"""
Tests for utils/conversion.py — convert_to_year_fracs.
"""
from __future__ import annotations

import numpy as np
import numpy.testing as npt
import pytest

from utils.conversion import convert_to_year_fracs


class TestConvertToYearFracs:

    def test_same_date_is_zero(self):
        base = np.datetime64("2025-01-02")
        dates = np.array(["2025-01-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(dates, base, "ACT/365")
        npt.assert_allclose(result, [0.0], atol=1e-12)

    def test_act365_one_year(self):
        base = np.datetime64("2025-01-02")
        future = np.array(["2026-01-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(future, base, "ACT/365")
        # 365 days / 365 = 1.0
        expected = 365.0 / 365.0
        npt.assert_allclose(result, [expected], atol=1e-10)

    def test_act360_one_year(self):
        base = np.datetime64("2025-01-02")
        future = np.array(["2026-01-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(future, base, "ACT/360")
        expected = 365.0 / 360.0
        npt.assert_allclose(result, [expected], atol=1e-10)

    def test_act365_90_days(self):
        base = np.datetime64("2025-01-02")
        future = np.array(["2025-04-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(future, base, "ACT/365")
        days = (np.datetime64("2025-04-02") - np.datetime64("2025-01-02")).astype(float)
        npt.assert_allclose(result, [days / 365.0], atol=1e-10)

    def test_act360_90_days(self):
        base = np.datetime64("2025-01-02")
        future = np.array(["2025-04-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(future, base, "ACT/360")
        days = (np.datetime64("2025-04-02") - np.datetime64("2025-01-02")).astype(float)
        npt.assert_allclose(result, [days / 360.0], atol=1e-10)

    def test_multiple_dates(self):
        base = np.datetime64("2025-01-02")
        dates = np.array(["2025-04-02", "2025-07-02", "2026-01-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(dates, base)
        assert result.shape == (3,)
        assert np.all(result > 0)
        # Should be sorted ascending
        assert result[0] < result[1] < result[2]

    def test_negative_year_frac_for_past_date(self):
        base = np.datetime64("2025-01-02")
        past = np.array(["2024-01-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(past, base)
        assert result[0] < 0

    def test_default_day_count_is_act365(self):
        base = np.datetime64("2025-01-02")
        dates = np.array(["2026-01-02"], dtype="datetime64[D]")
        result_default = convert_to_year_fracs(dates, base)
        result_explicit = convert_to_year_fracs(dates, base, "ACT/365")
        npt.assert_allclose(result_default, result_explicit, atol=1e-15)

    def test_unsupported_day_count_raises(self):
        base = np.datetime64("2025-01-02")
        dates = np.array(["2026-01-02"], dtype="datetime64[D]")
        with pytest.raises(ValueError, match="Unsupported day count"):
            convert_to_year_fracs(dates, base, "30/360")

    def test_act365_act360_ratio(self):
        """ACT/360 result should be 365/360 times the ACT/365 result."""
        base = np.datetime64("2025-01-02")
        dates = np.array(["2025-07-02", "2026-01-02"], dtype="datetime64[D]")
        r365 = convert_to_year_fracs(dates, base, "ACT/365")
        r360 = convert_to_year_fracs(dates, base, "ACT/360")
        npt.assert_allclose(r360 / r365, 365.0 / 360.0, atol=1e-10)

    def test_case_insensitive_and_no_space(self):
        """Day count string should be normalised (upper, strip spaces)."""
        base = np.datetime64("2025-01-02")
        dates = np.array(["2026-01-02"], dtype="datetime64[D]")
        r1 = convert_to_year_fracs(dates, base, "act/365")
        r2 = convert_to_year_fracs(dates, base, "ACT/365")
        npt.assert_allclose(r1, r2, atol=1e-15)

    def test_output_dtype_float64(self):
        base = np.datetime64("2025-01-02")
        dates = np.array(["2025-04-02", "2025-07-02"], dtype="datetime64[D]")
        result = convert_to_year_fracs(dates, base)
        assert result.dtype == np.float64
