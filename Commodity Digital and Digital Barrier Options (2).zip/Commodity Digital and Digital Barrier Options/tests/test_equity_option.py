"""Tests for instruments/equity_option.py — EquityOption (Black-76)."""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt

from instruments.equity_option import EquityOption
from market_data.risk_factor import CurveSlice, ScalarSlice
from market_data.vol_surface import BenchmarkVolSkew
from utils.interpolation import linear_interpolator


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

N_PATHS = 8
VAL_DATE = date(2025, 1, 2)
EXPIRY = date(2026, 1, 2)   # 365 days → T = 1.0 ACT/365

SPOT = 100.0
CARRY_RATE = 0.05
DIV_RATE = 0.02
DISC_RATE = 0.04
VOL = 0.20
STRIKE = 105.0
NOMINAL = 1_000.0

TENORS = np.array([0.08, 0.25, 0.5, 1.0, 2.0, 3.0, 5.0], dtype=np.float64)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flat_curve(rate: float) -> CurveSlice:
    return CurveSlice(
        values=np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64),
        tenors=TENORS,
    )


def flat_spot(price: float = SPOT) -> ScalarSlice:
    return ScalarSlice(values=np.full(N_PATHS, price, dtype=np.float64))


def flat_vol(vol: float = VOL) -> ScalarSlice:
    return ScalarSlice(values=np.full(N_PATHS, vol, dtype=np.float64))


def base_market_state(
    carry: float = CARRY_RATE,
    div: float = DIV_RATE,
    disc: float = DISC_RATE,
    spot: float = SPOT,
    vol: float = VOL,
) -> dict:
    return {
        "SPOT": flat_spot(spot),
        "CARRY": flat_curve(carry),
        "DIV": flat_curve(div),
        "DISC": flat_curve(disc),
        "VOL": flat_vol(vol),
    }


def make_option(
    strike: float = STRIKE,
    is_call: bool = True,
    nominal: float = NOMINAL,
    discount_curve_name: str = "",
) -> EquityOption:
    return EquityOption(
        name="EQ_OPT",
        expiry_date=EXPIRY,
        strike=strike,
        is_call=is_call,
        nominal=nominal,
        spot_name="SPOT",
        carry_curve_name="CARRY",
        dividend_curve_name="DIV",
        vol_name="VOL",
        carry_interpolator=linear_interpolator,
        dividend_interpolator=linear_interpolator,
        discount_curve_name=discount_curve_name,
        discount_interpolator=linear_interpolator,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestEquityOptionBasic:

    def test_post_expiry_returns_zeros(self):
        opt = make_option()
        ms = base_market_state()
        pv = opt.scenario_npvs(EXPIRY, ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_after_expiry_returns_zeros(self):
        opt = make_option()
        ms = base_market_state()
        pv = opt.scenario_npvs(date(2026, 6, 1), ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_all_paths_identical_for_flat_curves(self):
        opt = make_option()
        ms = base_market_state()
        pv = opt.scenario_npvs(VAL_DATE, ms)
        assert pv.shape == (N_PATHS,)
        npt.assert_allclose(pv, pv[0], rtol=1e-12)

    def test_nominal_scales_linearly(self):
        ms = base_market_state()
        pv1 = make_option(nominal=1.0).scenario_npvs(VAL_DATE, ms)
        pv2 = make_option(nominal=500.0).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv2, pv1 * 500.0, rtol=1e-12)

    def test_call_positive_put_positive(self):
        ms = base_market_state()
        call_pv = make_option(is_call=True).scenario_npvs(VAL_DATE, ms)
        put_pv = make_option(is_call=False).scenario_npvs(VAL_DATE, ms)
        assert np.all(call_pv > 0)
        assert np.all(put_pv > 0)


class TestEquityOptionPutCallParity:
    """C - P = df * (F - K), verified analytically from the curve inputs."""

    def _check_parity(self, strike, carry, div, disc_rate, disc_curve_name):
        ms = base_market_state(carry=carry, div=div, disc=disc_rate)
        call = make_option(strike=strike, is_call=True, nominal=1.0,
                           discount_curve_name=disc_curve_name)
        put = make_option(strike=strike, is_call=False, nominal=1.0,
                          discount_curve_name=disc_curve_name)

        call_pv = call.scenario_npvs(VAL_DATE, ms)
        put_pv = put.scenario_npvs(VAL_DATE, ms)

        # T = 365/365 = 1.0 for these dates
        T = 1.0
        df_disc = np.exp(-disc_rate * T)
        df_carry = np.exp(-carry * T)
        df_div = np.exp(-div * T)

        # Forward: F = spot * df_div / df_carry
        F = SPOT * df_div / df_carry
        # Discount used by the pricer
        df = df_disc if disc_curve_name else df_carry

        expected_diff = df * (F - strike)
        npt.assert_allclose(call_pv - put_pv, expected_diff, rtol=1e-8, atol=1e-10)

    def test_parity_carry_curve_discounting(self):
        self._check_parity(
            strike=STRIKE, carry=CARRY_RATE, div=DIV_RATE,
            disc_rate=CARRY_RATE, disc_curve_name="",
        )

    def test_parity_separate_discount_curve(self):
        self._check_parity(
            strike=STRIKE, carry=CARRY_RATE, div=DIV_RATE,
            disc_rate=DISC_RATE, disc_curve_name="DISC",
        )

    def test_parity_atm_forward(self):
        # strike = F → C = P (same price for call and put)
        T = 1.0
        F_atm = SPOT * np.exp((CARRY_RATE - DIV_RATE) * T)
        self._check_parity(
            strike=F_atm, carry=CARRY_RATE, div=DIV_RATE,
            disc_rate=CARRY_RATE, disc_curve_name="",
        )

    def test_parity_itm_call_otm_put(self):
        # strike well below forward → deep ITM call, deep OTM put
        self._check_parity(
            strike=80.0, carry=CARRY_RATE, div=DIV_RATE,
            disc_rate=DISC_RATE, disc_curve_name="DISC",
        )


class TestEquityOptionDiscountCurve:

    def test_separate_discount_lowers_pv_when_disc_higher_than_carry(self):
        """Higher discount rate reduces PV vs carry curve discounting."""
        ms = base_market_state(carry=CARRY_RATE, disc=CARRY_RATE + 0.03)
        pv_carry = (
            make_option(discount_curve_name="").scenario_npvs(VAL_DATE, ms)
        )
        pv_disc = (
            make_option(discount_curve_name="DISC").scenario_npvs(VAL_DATE, ms)
        )
        assert np.all(pv_disc < pv_carry)

    def test_when_disc_equals_carry_both_paths_agree(self):
        ms = base_market_state(carry=CARRY_RATE, disc=CARRY_RATE)
        pv_carry = (
            make_option(discount_curve_name="").scenario_npvs(VAL_DATE, ms)
        )
        pv_disc = (
            make_option(discount_curve_name="DISC").scenario_npvs(VAL_DATE, ms)
        )
        npt.assert_allclose(pv_carry, pv_disc, rtol=1e-10)


class TestEquityOptionVolSkew:

    def _flat_skew(self, atm_vol: float) -> BenchmarkVolSkew:
        """Flat benchmark skew — returns atm_vol for all strikes."""
        term = np.array([[0.5, atm_vol], [2.0, atm_vol]])
        zero = np.array([[0.5, 0.0], [2.0, 0.0]])
        one = np.array([[0.5, 1.0], [2.0, 1.0]])
        neg_one = np.array([[0.5, -1.0], [2.0, -1.0]])
        return BenchmarkVolSkew(
            v0=term, s=zero, L=zero, R=zero,
            C=neg_one, D=one, lam=zero, rho=zero, atm_ref=term,
        )

    def test_vol_skew_matches_flat_scalar_vol(self):
        """Flat skew surface should give same PV as a matching scalar vol."""
        skew = self._flat_skew(VOL)

        ms = base_market_state()

        opt_scalar = make_option(is_call=True, nominal=1.0)
        pv_scalar = opt_scalar.scenario_npvs(VAL_DATE, ms)

        opt_skew = EquityOption(
            name="EQ_OPT_SKEW",
            expiry_date=EXPIRY,
            strike=STRIKE,
            is_call=True,
            nominal=1.0,
            spot_name="SPOT",
            carry_curve_name="CARRY",
            dividend_curve_name="DIV",
            vol_name="",
            carry_interpolator=linear_interpolator,
            dividend_interpolator=linear_interpolator,
            vol_skew=skew,
            sticky="strike",
        )
        pv_skew = opt_skew.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv_skew, pv_scalar, rtol=1e-6)
