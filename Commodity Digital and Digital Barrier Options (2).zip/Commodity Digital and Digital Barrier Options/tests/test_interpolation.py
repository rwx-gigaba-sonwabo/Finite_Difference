"""
Tests for utils/interpolation.py — linear_interpolator, linear_rt_interp,
hermite_rt_interp.
"""
from __future__ import annotations

import numpy as np
import numpy.testing as npt
import pytest

from utils.interpolation import hermite_rt_interp, linear_interpolator, linear_rt_interp

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

N_PATHS = 4
TENORS = np.array([0.5, 1.0, 2.0, 5.0, 10.0], dtype=np.float64)


def flat_rates(rate: float = 0.05) -> np.ndarray:
    return np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64)


def upward_rates() -> np.ndarray:
    """Upward sloping: 2%, 3%, 4%, 6%, 7% at tenors 0.5,1,2,5,10."""
    base = np.array([0.02, 0.03, 0.04, 0.06, 0.07], dtype=np.float64)
    return np.tile(base, (N_PATHS, 1))


# ---------------------------------------------------------------------------
# linear_interpolator
# ---------------------------------------------------------------------------

class TestLinearInterpolator:

    def test_flat_curve_scalar(self):
        rates = flat_rates(0.05)
        interp = linear_interpolator(TENORS, rates)
        result = interp(1.5)
        assert result.shape == (N_PATHS,)
        npt.assert_allclose(result, 0.05, atol=1e-10)

    def test_flat_curve_array(self):
        rates = flat_rates(0.05)
        interp = linear_interpolator(TENORS, rates)
        t_arr = np.array([0.5, 1.0, 2.0, 5.0])
        result = interp(t_arr)
        assert result.shape == (N_PATHS, 4)
        npt.assert_allclose(result, 0.05, atol=1e-10)

    def test_interpolation_at_pillars(self):
        rates = upward_rates()
        interp = linear_interpolator(TENORS, rates)
        for i, t in enumerate(TENORS):
            result = interp(t)
            npt.assert_allclose(result, rates[:, i], atol=1e-10,
                                err_msg=f"Failed at pillar t={t}")

    def test_linear_midpoint(self):
        """Value at midpoint of segment [1.0, 2.0] should be the linear midpoint."""
        rates = upward_rates()
        interp = linear_interpolator(TENORS, rates)
        mid = interp(1.5)
        expected = (rates[:, 1] + rates[:, 2]) / 2.0
        npt.assert_allclose(mid, expected, atol=1e-10)

    def test_flat_extrapolation_below(self):
        rates = upward_rates()
        interp = linear_interpolator(TENORS, rates)
        result = interp(0.1)  # below minimum tenor 0.5
        npt.assert_allclose(result, rates[:, 0], atol=1e-10)

    def test_flat_extrapolation_above(self):
        rates = upward_rates()
        interp = linear_interpolator(TENORS, rates)
        result = interp(15.0)  # above maximum tenor 10.0
        npt.assert_allclose(result, rates[:, -1], atol=1e-10)

    def test_returns_n_paths_shape_scalar(self):
        rates = flat_rates()
        interp = linear_interpolator(TENORS, rates)
        assert interp(2.0).shape == (N_PATHS,)

    def test_returns_n_paths_n_queries_shape(self):
        rates = flat_rates()
        interp = linear_interpolator(TENORS, rates)
        t = np.array([1.0, 2.0, 3.0])
        assert interp(t).shape == (N_PATHS, 3)


# ---------------------------------------------------------------------------
# linear_rt_interp
# ---------------------------------------------------------------------------

class TestLinearRtInterp:

    def test_flat_curve_scalar(self):
        rates = flat_rates(0.05)
        interp = linear_rt_interp(TENORS, rates)
        result = interp(1.5)
        assert result.shape == (N_PATHS,)
        npt.assert_allclose(result, 0.05, atol=1e-10)

    def test_flat_curve_array(self):
        rates = flat_rates(0.05)
        interp = linear_rt_interp(TENORS, rates)
        t_arr = np.array([0.5, 1.0, 2.0, 5.0])
        result = interp(t_arr)
        assert result.shape == (N_PATHS, 4)
        npt.assert_allclose(result, 0.05, atol=1e-10)

    def test_at_pillars(self):
        rates = upward_rates()
        interp = linear_rt_interp(TENORS, rates)
        for i, t in enumerate(TENORS):
            result = interp(t)
            npt.assert_allclose(result, rates[:, i], atol=1e-10,
                                err_msg=f"Failed at pillar t={t}")

    def test_flat_extrapolation_below(self):
        rates = upward_rates()
        interp = linear_rt_interp(TENORS, rates)
        result = interp(0.1)
        npt.assert_allclose(result, rates[:, 0], atol=1e-10)

    def test_flat_extrapolation_above(self):
        rates = upward_rates()
        interp = linear_rt_interp(TENORS, rates)
        result = interp(15.0)
        npt.assert_allclose(result, rates[:, -1], atol=1e-10)

    def test_shape_scalar(self):
        rates = flat_rates()
        interp = linear_rt_interp(TENORS, rates)
        assert interp(3.0).shape == (N_PATHS,)

    def test_shape_array(self):
        rates = flat_rates()
        interp = linear_rt_interp(TENORS, rates)
        assert interp(np.array([1.0, 2.0])).shape == (N_PATHS, 2)

    def test_rt_interpolation_between_pillars(self):
        """
        For linear rt interp, interpolated value at t=1.5 should come from
        linear interpolation of rt products at t=1.0 and t=2.0.
        """
        rates = upward_rates()
        interp = linear_rt_interp(TENORS, rates)
        result = interp(1.5)
        # rt at 1.0 = rates[:,1]*1.0, rt at 2.0 = rates[:,2]*2.0
        rt1 = rates[:, 1] * 1.0
        rt2 = rates[:, 2] * 2.0
        frac = (1.5 - 1.0) / (2.0 - 1.0)
        rt_mid = rt1 + (rt2 - rt1) * frac
        expected = rt_mid / 1.5
        npt.assert_allclose(result, expected, atol=1e-10)


# ---------------------------------------------------------------------------
# hermite_rt_interp
# ---------------------------------------------------------------------------

class TestHermiteRtInterp:

    def test_flat_curve_scalar(self):
        rates = flat_rates(0.05)
        interp = hermite_rt_interp(TENORS, rates)
        result = interp(1.5)
        assert result.shape == (N_PATHS,)
        npt.assert_allclose(result, 0.05, atol=1e-10)

    def test_flat_curve_array(self):
        rates = flat_rates(0.05)
        interp = hermite_rt_interp(TENORS, rates)
        t_arr = np.array([0.5, 1.0, 2.0, 5.0])
        result = interp(t_arr)
        assert result.shape == (N_PATHS, 4)
        npt.assert_allclose(result, 0.05, atol=1e-10)

    def test_at_pillars(self):
        rates = upward_rates()
        interp = hermite_rt_interp(TENORS, rates)
        for i, t in enumerate(TENORS):
            result = interp(t)
            npt.assert_allclose(result, rates[:, i], atol=1e-10,
                                err_msg=f"Failed at pillar t={t}")

    def test_flat_extrapolation_below(self):
        rates = upward_rates()
        interp = hermite_rt_interp(TENORS, rates)
        result = interp(0.1)
        npt.assert_allclose(result, rates[:, 0], atol=1e-10)

    def test_flat_extrapolation_above(self):
        rates = upward_rates()
        interp = hermite_rt_interp(TENORS, rates)
        result = interp(15.0)
        npt.assert_allclose(result, rates[:, -1], atol=1e-10)

    def test_shape_scalar(self):
        rates = flat_rates()
        interp = hermite_rt_interp(TENORS, rates)
        assert interp(3.0).shape == (N_PATHS,)

    def test_shape_array(self):
        rates = flat_rates()
        interp = hermite_rt_interp(TENORS, rates)
        assert interp(np.array([1.0, 2.0, 3.0])).shape == (N_PATHS, 3)

    def test_continuity_at_pillars(self):
        """Hermite spline must be continuous at knots."""
        rates = upward_rates()
        interp = hermite_rt_interp(TENORS, rates)
        eps = 1e-8
        for t in TENORS[1:-1]:
            left = interp(t - eps)
            right = interp(t + eps)
            npt.assert_allclose(left, right, atol=1e-5,
                                err_msg=f"Discontinuity near t={t}")

    def test_upward_sloping_monotone(self):
        """For strongly upward sloping curves, Hermite interpolated rates should be positive."""
        rates = upward_rates()
        interp = hermite_rt_interp(TENORS, rates)
        test_points = np.linspace(TENORS[0], TENORS[-1], 50)
        result = interp(test_points)
        assert np.all(result > 0), "All interpolated rates should be positive"


# ---------------------------------------------------------------------------
# Cross-interpolator consistency on flat curve
# ---------------------------------------------------------------------------

class TestInterpolatorConsistency:

    def test_all_agree_on_flat_curve(self):
        """All three interpolators should agree on a flat curve."""
        rates = flat_rates(0.05)
        t_test = np.array([0.75, 1.5, 3.0, 7.0])
        li = linear_interpolator(TENORS, rates)(t_test)
        lr = linear_rt_interp(TENORS, rates)(t_test)
        hr = hermite_rt_interp(TENORS, rates)(t_test)
        npt.assert_allclose(li, lr, atol=1e-10)
        npt.assert_allclose(li, hr, atol=1e-10)
