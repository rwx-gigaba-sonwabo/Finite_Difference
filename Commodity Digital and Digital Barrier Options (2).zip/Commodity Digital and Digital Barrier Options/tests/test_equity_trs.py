"""
Tests for instruments/equity_trs.py — EquityTRS, including spot/settlement lag.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt
from instruments.equity_trs import EquityTRS
from instruments.components.cashflow_leg import CashflowLeg, LegType
from instruments.components.schedule_config import ScheduleConfig
from market_data.risk_factor import CurveSlice, ScalarSlice
from utils.interpolation import linear_interpolator


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

N_PATHS = 8
VAL_DATE = date(2025, 1, 2)
MATURITY = date(2026, 1, 2)     # 1-year TRS, quarterly = 4 periods
SPOT = 100.0
CARRY_RATE = 0.05               # 5% carry (funding) rate
DIV_RATE = 0.02                 # 2% dividend yield
DISC_RATE = 0.04                # 4% discount rate
NOTIONAL = SPOT * 1_000         # initial_price × quantity
QUANTITY = 1_000.0

TENORS = np.array([0.08, 0.25, 0.5, 1.0, 2.0, 3.0, 5.0], dtype=np.float64)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flat_curve_slice(rate: float) -> CurveSlice:
    return CurveSlice(
        values=np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64),
        tenors=TENORS,
    )


def flat_spot_slice(price: float = SPOT) -> ScalarSlice:
    return ScalarSlice(values=np.full(N_PATHS, price, dtype=np.float64))


def make_market_state(
    carry: float = CARRY_RATE,
    div: float = DIV_RATE,
    disc: float = DISC_RATE,
    spot: float = SPOT,
) -> dict:
    return {
        "SPOT": flat_spot_slice(spot),
        "CARRY": flat_curve_slice(carry),
        "DIV": flat_curve_slice(div),
        "DISC": flat_curve_slice(disc),
    }


def make_trs(
    effective: date = VAL_DATE,
    maturity: date = MATURITY,
    initial_price: float = SPOT,
    spot_lag: int = 0,
    settlement_calendar: str = "ZAR",
    carry: float = CARRY_RATE,
    div: float = DIV_RATE,
) -> EquityTRS:
    interest_leg = CashflowLeg(
        leg_type=LegType.FIXED,
        frequency=3,
        fixed_rate=carry - div,  # breakeven fixed rate ≈ net carry
        curve_name="DISC",
    )
    return EquityTRS(
        name="TRS",
        effective_date=effective,
        maturity_date=maturity,
        quantity=QUANTITY,
        notional=NOTIONAL,
        interest_leg=interest_leg,
        spot_name="SPOT",
        carry_curve_name="CARRY",
        dividend_curve_name="DIV",
        discount_curve_name="DISC",
        carry_interpolator=linear_interpolator,
        dividend_interpolator=linear_interpolator,
        discount_interpolator=linear_interpolator,
        schedule_config=ScheduleConfig(calendar="ZAR"),
        initial_price=initial_price,
        return_nominal_scaling="Price",
        interest_nominal_scaling="Initial Price",
        is_receiver=True,
        spot_lag=spot_lag,
        settlement_calendar=settlement_calendar,
    )


# ---------------------------------------------------------------------------
# Tests — basic pricing (no settlement lag)
# ---------------------------------------------------------------------------

class TestIntermediatePaymentDate:
    """Simulation date exactly on an intermediate reset/payment date.

    When val_date == T_i (a mid-life reset), the just-completed period
    [T_{i-1}, T_i] must be included at DF=1 (payment still outstanding).
    Omitting it creates a discontinuity in the EE profile at reset dates —
    this is what riskflow's >= convention is designed to avoid.
    """

    def _first_intermediate_date(self, trs: EquityTRS) -> date:
        """First period-end date strictly before maturity."""
        ends = sorted({e for _, e, _, _ in trs.return_schedule})
        return next(e for e in ends if e < trs.maturity_date)

    def test_completing_period_included_at_reset(self):
        """NPV on a reset date must include the just-completed payoff."""
        trs = make_trs()
        t_i = self._first_intermediate_date(trs)
        ms = make_market_state()

        pv_on = trs.scenario_npvs(t_i, ms)

        # Price one calendar day before the reset: the completing period is
        # in-progress (t_s < 0) with t_e ≈ 0, payoff ≈ spot − initial_price.
        # With include_sim_date_cashflows=True these must be close (not differ
        # by a whole period payoff).
        from datetime import timedelta
        trs_before = make_trs()
        pv_before = trs_before.scenario_npvs(t_i - timedelta(days=1), ms)

        # They won't be exactly equal (tiny carry difference), but must be
        # within a small tolerance relative to notional — NOT differ by
        # ~(spot - initial_price) * quantity which ≈ 0 here since spot == IP.
        npt.assert_allclose(pv_on, pv_before, atol=NOTIONAL * 0.01)

    def test_completing_period_payoff_nonzero_when_spot_differs(self):
        """With spot != initial_price, NPV on reset includes the gain.

        Use carry=div=0 so future-period payoffs are zero and the only
        contribution to pv_up - pv_flat is the completing period's gain.
        With zero carry and zero dividends: H_past = 0, F(T) = spot for
        all T, so future period payoffs = 0 and the interest fixed_rate = 0.
        The sole difference is quantity * (new_spot - SPOT) at DF=1.
        """
        new_spot = SPOT * 1.10  # equity up 10%
        trs = make_trs(initial_price=SPOT, carry=0.0, div=0.0)
        t_i = self._first_intermediate_date(trs)

        ms_up = make_market_state(spot=new_spot, carry=0.0, div=0.0)
        ms_flat = make_market_state(spot=SPOT, carry=0.0, div=0.0)

        pv_up = trs.scenario_npvs(t_i, ms_up)
        pv_flat = trs.scenario_npvs(t_i, ms_flat)

        # Exact: no carry, no dividends, no coupon
        # (fixed_rate = carry-div = 0).
        expected_gain = (new_spot - SPOT) * QUANTITY
        npt.assert_allclose(pv_up - pv_flat, expected_gain, rtol=1e-10)

    def test_include_false_excludes_completing_period(self):
        """Explicit include=False drops the completing payoff (legacy mode).

        Same zero-carry setup so future periods contribute nothing and the
        only difference between include=True and include=False is exactly
        quantity * (spot - initial_price) for the completing period.
        """
        new_spot = SPOT * 1.10
        trs_inc = make_trs(initial_price=SPOT, carry=0.0, div=0.0)
        trs_exc = EquityTRS(
            name="TRS_exc",
            effective_date=VAL_DATE,
            maturity_date=MATURITY,
            quantity=QUANTITY,
            notional=NOTIONAL,
            interest_leg=CashflowLeg(
                leg_type=LegType.FIXED,
                frequency=3,
                fixed_rate=0.0,
                curve_name="DISC",
            ),
            spot_name="SPOT",
            carry_curve_name="CARRY",
            dividend_curve_name="DIV",
            discount_curve_name="DISC",
            carry_interpolator=linear_interpolator,
            dividend_interpolator=linear_interpolator,
            discount_interpolator=linear_interpolator,
            schedule_config=ScheduleConfig(calendar="ZAR"),
            initial_price=SPOT,
            include_sim_date_cashflows=False,
        )
        t_i = self._first_intermediate_date(trs_inc)
        ms_up = make_market_state(spot=new_spot, carry=0.0, div=0.0)

        pv_inc = trs_inc.scenario_npvs(t_i, ms_up)
        pv_exc = trs_exc.scenario_npvs(t_i, ms_up)

        # Exact difference = completing period payoff at DF=1.
        expected_drop = (new_spot - SPOT) * QUANTITY
        npt.assert_allclose(pv_inc - pv_exc, expected_drop, rtol=1e-10)


class TestNoLag:
    def test_at_maturity_returns_zeros(self):
        trs = make_trs()
        ms = make_market_state()
        pv = trs.scenario_npvs(MATURITY, ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_post_maturity_returns_zeros(self):
        trs = make_trs()
        ms = make_market_state()
        pv = trs.scenario_npvs(date(2026, 6, 1), ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_pv_shape(self):
        trs = make_trs()
        ms = make_market_state()
        pv = trs.scenario_npvs(VAL_DATE, ms)
        assert pv.shape == (N_PATHS,)

    def test_all_paths_equal_for_flat_market(self):
        """Flat market → all paths should give identical PV."""
        trs = make_trs()
        ms = make_market_state()
        pv = trs.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv, pv[0], rtol=1e-12)

    def test_receiver_vs_payer(self):
        """Payer PV = -Receiver PV."""
        trs_recv = make_trs()
        trs_pay = make_trs()
        trs_pay.is_receiver = False

        ms = make_market_state()
        pv_recv = trs_recv.scenario_npvs(VAL_DATE, ms)
        pv_pay = trs_pay.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv_recv, -pv_pay, rtol=1e-12)


# ---------------------------------------------------------------------------
# Tests — settlement lag
# ---------------------------------------------------------------------------

class TestSettlementLag:
    def test_settle_map_populated(self):
        trs = make_trs(spot_lag=3)
        assert len(trs._settle_map) > 0

    def test_final_settle_date_is_maturity_regardless_of_lag(self):
        # Payment is at the scheduled period end (T_end), so expiry is at
        # maturity_date for both lag=0 and lag>0.
        trs_0 = make_trs(spot_lag=0)
        trs_3 = make_trs(spot_lag=3)
        assert trs_0._final_settle_date == MATURITY
        assert trs_3._final_settle_date == MATURITY

    def test_zero_carry_zero_div_gives_zero_return_pv(self):
        """With carry=div=0 the forward equals spot and dividends are zero.

        The return leg payoff (F_end - F_start + d_fv) is exactly zero every
        period, so trs_return_leg_pv returns zeros regardless of lag.
        """
        trs_0 = make_trs(spot_lag=0, carry=0.0, div=0.0)
        trs_3 = make_trs(spot_lag=3, carry=0.0, div=0.0)
        # interest leg fixed_rate = carry - div = 0
        ms = make_market_state(carry=0.0, div=0.0)

        pv_0 = trs_0.scenario_npvs(VAL_DATE, ms)
        pv_3 = trs_3.scenario_npvs(VAL_DATE, ms)
        # Both should be zero (zero return payoff, zero interest coupon)
        npt.assert_allclose(pv_0, np.zeros(N_PATHS), atol=1e-8)
        npt.assert_allclose(pv_3, np.zeros(N_PATHS), atol=1e-8)

    def test_fwd_tenors_shift_by_lag(self):
        """t_starts_fwd / t_ends_fwd differ from t_starts / t_ends.

        With spot_lag=N the forward carry period runs from val_settle to
        T_settle, so each tenor is shifted relative to the raw period dates
        by approximately (T_settle - val_settle) - (T_end - val_date) ≈ 0
        for equal business-day shifts.  The key invariant is that the arrays
        are non-None and the forward carry length is correct.
        """
        trs = make_trs(spot_lag=3)
        from utils.ql_helpers import advance_business_days, to_ql_date

        val_date = VAL_DATE
        val_settle = advance_business_days(val_date, 3, "ZAR")
        dc = trs.schedule_config.curve_day_counter
        ql_val_settle = to_ql_date(val_settle)

        future_return = [
            (s, e, pay, af) for s, e, pay, af in trs.return_schedule
            if pay > val_date
        ]
        for s, e, _, _ in future_return:
            t_s_fwd = dc.yearFraction(
                ql_val_settle, to_ql_date(trs._settle_map[s])
            )
            t_e_fwd = dc.yearFraction(
                ql_val_settle, to_ql_date(trs._settle_map[e])
            )
            # Carry length from val_settle to T_settle
            carry_len_lag = t_e_fwd - t_s_fwd
            # Carry length from val_date to T_end (no lag)
            t_s_raw = dc.yearFraction(to_ql_date(val_date), to_ql_date(s))
            t_e_raw = dc.yearFraction(to_ql_date(val_date), to_ql_date(e))
            carry_len_raw = t_e_raw - t_s_raw
            # The carry lengths must be equal (same period, just shifted dates)
            npt.assert_allclose(carry_len_lag, carry_len_raw, atol=5e-4)

    def test_at_maturity_returns_zeros_with_lag(self):
        """lag=0 and lag=3 both expire at maturity_date (payment at T_end)."""
        trs_0 = make_trs(spot_lag=0)
        trs_3 = make_trs(spot_lag=3)
        ms = make_market_state()

        npt.assert_array_equal(
            trs_0.scenario_npvs(MATURITY, ms), np.zeros(N_PATHS)
        )
        npt.assert_array_equal(
            trs_3.scenario_npvs(MATURITY, ms), np.zeros(N_PATHS)
        )

    def test_post_maturity_returns_zeros_with_lag(self):
        """Post-maturity is zero for any spot_lag."""
        trs = make_trs(spot_lag=3)
        ms = make_market_state()
        pv = trs.scenario_npvs(date(2026, 3, 1), ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_pv_shape_with_lag(self):
        trs = make_trs(spot_lag=3)
        ms = make_market_state()
        pv = trs.scenario_npvs(VAL_DATE, ms)
        assert pv.shape == (N_PATHS,)

    def test_settlement_calendar_defaults_to_schedule_calendar(self):
        """When settlement_calendar=None, the schedule calendar is used."""
        trs = make_trs(spot_lag=3, settlement_calendar=None)
        assert trs._settlement_cal == trs.schedule_config.calendar

    def test_all_paths_equal_flat_market_with_lag(self):
        """Flat market → all paths equal even with settlement lag."""
        trs = make_trs(spot_lag=3)
        ms = make_market_state()
        pv = trs.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv, pv[0], rtol=1e-12)


# ---------------------------------------------------------------------------
# Tests — equity spot fixing for "Price" scaling
# ---------------------------------------------------------------------------

class TestEquityFixings:
    """Verify per-path equity spot fixings are used for the in-progress
    return period's F_start instead of the scalar self.initial_price.

    For "Price" scaling the notional base for each period is the equity
    price observed at the period start.  When the simulation has advanced
    past a reset date, the engine stamps the spot at that date and passes
    it through fixings.  Without this, scenario_npvs falls back to
    self.initial_price (the construction-time scalar), which is only
    correct for the very first period and produces errors proportional to
    the cumulative equity move for all later periods.
    """

    def test_get_equity_reset_schedule_contains_starts_and_ends(self):
        trs = make_trs()
        schedule = trs.get_equity_reset_schedule()
        starts = {s for s, _, _, _ in trs.return_schedule}
        ends = {e for _, e, _, _ in trs.return_schedule}
        assert starts.issubset(set(schedule))
        assert ends.issubset(set(schedule))

    def test_get_equity_reset_schedule_is_sorted(self):
        trs = make_trs()
        schedule = trs.get_equity_reset_schedule()
        assert schedule == sorted(schedule)

    def test_get_equity_reset_schedule_first_date_is_effective_date(self):
        trs = make_trs()
        assert trs.get_equity_reset_schedule()[0] == VAL_DATE

    def test_compute_equity_fixing_for_date_stamps_current_spot(self):
        trs = make_trs()
        reset_date = trs.return_schedule[0][0]
        new_spot = SPOT * 1.15
        fix_state = make_market_state(spot=new_spot)
        result = trs._compute_equity_fixing_for_date(reset_date, fix_state)
        assert ("SPOT", reset_date) in result
        npt.assert_allclose(
            result[("SPOT", reset_date)], np.full(N_PATHS, new_spot)
        )

    def test_compute_equity_fixing_copies_array(self):
        """Returned array must be a copy, not a view into the scenario cube."""
        trs = make_trs()
        reset_date = trs.return_schedule[0][0]
        fix_state = make_market_state(spot=SPOT)
        result = trs._compute_equity_fixing_for_date(reset_date, fix_state)
        arr = result[("SPOT", reset_date)]
        arr[:] = 0.0
        # Original market state must be unaffected
        npt.assert_allclose(fix_state["SPOT"].values, np.full(N_PATHS, SPOT))

    def test_fixing_overrides_initial_price_for_in_progress_period(self):
        """scenario_npvs with fixings uses F_start = fixing spot,
        not self.initial_price, for the in-progress return period.

        Setup: zero carry and zero dividends so F(T) = spot for all T and
        all future-period payoffs are exactly zero.  The only non-zero
        contribution is the completing period [period_start, period_end].

        With fixing at period_start = 110 and current spot = 110:
            payoff = spot − F_start = 110 − 110 = 0
        Without fixing (fallback to initial_price = 100):
            payoff = spot − F_start = 110 − 100 = 10 per unit

        The difference must equal (fixing_spot − initial_price) × quantity.
        """
        trs = make_trs(initial_price=SPOT, carry=0.0, div=0.0)

        period_start = trs.return_schedule[0][0]  # = VAL_DATE
        period_end = trs.return_schedule[0][1]    # first quarterly end

        # equity moved 10 % at the period-start reset
        fixing_spot = SPOT * 1.10
        fixings_with = {
            ("SPOT", period_start): np.full(
                N_PATHS, fixing_spot, dtype=np.float64
            )
        }

        # Current spot also at 110 on the completing date.
        ms = make_market_state(spot=fixing_spot, carry=0.0, div=0.0)

        pv_with = trs.scenario_npvs(period_end, ms, fixings=fixings_with)
        pv_without = trs.scenario_npvs(period_end, ms, fixings=None)

        expected_diff = (fixing_spot - SPOT) * QUANTITY  # 10 × 1 000 = 10 000
        npt.assert_allclose(pv_without - pv_with, expected_diff, rtol=1e-8)

    def test_per_path_fixing_produces_per_path_pv(self):
        """When the fixing is a per-path array (not a scalar), each path's
        PV must reflect its own F_start — confirming the per-path fixing
        flows through to the payoff correctly.
        """
        trs = make_trs(initial_price=SPOT, carry=0.0, div=0.0)

        period_start = trs.return_schedule[0][0]
        period_end = trs.return_schedule[0][1]

        # Each path has a distinct fixing: path i → SPOT + i
        fixing_values = np.array(
            [SPOT + i for i in range(N_PATHS)], dtype=np.float64
        )
        fixings = {("SPOT", period_start): fixing_values}

        # Current spot is flat at SPOT + 4 (median path value for N_PATHS=8).
        current_spot = SPOT + 4.0
        ms = make_market_state(spot=current_spot, carry=0.0, div=0.0)

        pv = trs.scenario_npvs(period_end, ms, fixings=fixings)

        # Zero carry/div: completing payoff = (current_spot − F_start_i) × Q.
        # Future periods: zero (F_end = F_start = current_spot for all T).
        expected = (current_spot - fixing_values) * QUANTITY
        npt.assert_allclose(pv, expected, rtol=1e-8)


# ---------------------------------------------------------------------------
# Tests — t_s_fwd == 0 edge case (non-business-day val_date + settlement lag)
# ---------------------------------------------------------------------------


class TestNonBusinessDaySettlement:
    """Regression: advance_business_days(Friday, n) equals
    advance_business_days(Saturday, n) when period_start is a Friday
    and val_date is the following Saturday.

    In this case t_s_fwd = yearFraction(val_settle, T_start_settle) = 0,
    but val_date > period_start so the period IS in-progress.  The fix
    uses t_s = yearFraction(val_date, period_start) for detection:
    t_s < 0 (Saturday > Friday) → in-progress.
    t_s = 0 (val_date == period_start) → future.
    """

    def test_saturday_after_friday_reset_is_in_progress(self):
        """Saturday after a Friday reset must be treated as in-progress.

        period_start = 2025-11-28 (Friday).  With spot_lag=3:
        advance(Friday, 3) == advance(Saturday, 3) so t_s_fwd = 0.
        But val_date (Saturday) > period_start (Friday) → t_s < 0
        → in-progress.

        Zero carry/div: in-progress payoff = spot - fixing.
        Friday val_date (== period_start): future branch → payoff = 0.
        """
        from utils.ql_helpers import advance_business_days

        period_start = date(2025, 11, 28)  # Friday
        trs = make_trs(
            effective=period_start,
            maturity=date(2026, 11, 28),
            initial_price=SPOT,
            spot_lag=3,
            carry=0.0,
            div=0.0,
        )

        # Confirm premise: T_start_settle == val_settle for Saturday.
        settle_ps = advance_business_days(period_start, 3, "ZAR")
        settle_sat = advance_business_days(date(2025, 11, 29), 3, "ZAR")
        assert settle_ps == settle_sat, (
            f"Test premise: T_start_settle={settle_ps} != "
            f"val_settle(Sat)={settle_sat}"
        )

        current_spot = SPOT * 1.10
        ms = make_market_state(spot=current_spot, carry=0.0, div=0.0)
        fixings = {
            ("SPOT", period_start): np.full(
                N_PATHS, SPOT, dtype=np.float64
            )
        }

        # On the reset date itself (Friday): future branch → payoff = 0.
        pv_fri = trs.scenario_npvs(period_start, ms, fixings=fixings)
        npt.assert_allclose(pv_fri, np.zeros(N_PATHS), atol=1e-8)

        # Day after reset (Saturday): in-progress → payoff = spot - SPOT > 0.
        pv_sat = trs.scenario_npvs(
            date(2025, 11, 29), ms, fixings=fixings
        )
        assert np.all(pv_sat > 0), (
            f"Expected in-progress payoff > 0, got {pv_sat}"
        )
