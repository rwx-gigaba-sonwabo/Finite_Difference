"""
Tests for market_data/scenario_cube.py — ScenarioCube and ScenarioCubeBuilder.
"""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import numpy.testing as npt
import pytest

from market_data.risk_factor import (
    CurveSlice,
    FactorSpec,
    RiskFactorType,
    ScalarSlice,
    SurfaceSlice,
)
from market_data.scenario_cube import ScenarioCube, ScenarioCubeBuilder


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

N_PATHS = 8
N_TIMES = 4
N_TENORS = 5
N_STRIKES = 3
VAL_DATE = date(2025, 1, 2)

SIM_DATES = tuple(
    VAL_DATE + timedelta(days=90 * i) for i in range(N_TIMES)
)

TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0], dtype=np.float64)
STRIKES = np.array([0.04, 0.05, 0.06], dtype=np.float64)


def make_scalar_paths(value: float = 0.01) -> np.ndarray:
    return np.full((N_PATHS, N_TIMES), value, dtype=np.float64)


def make_curve_paths(value: float = 0.05) -> np.ndarray:
    return np.full((N_PATHS, N_TIMES, N_TENORS), value, dtype=np.float64)


def make_surface_paths(value: float = 0.2) -> np.ndarray:
    return np.full((N_PATHS, N_TIMES, N_TENORS, N_STRIKES), value, dtype=np.float64)


def build_simple_cube() -> ScenarioCube:
    builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
    builder.add_curve_factor("DISC", make_curve_paths(0.05), TENORS, dates=SIM_DATES)
    return builder.build()


# ---------------------------------------------------------------------------
# ScenarioCubeBuilder — basic builds
# ---------------------------------------------------------------------------

class TestScenarioCubeBuilder:

    def test_build_with_scalar_factor(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_factor("VOL", make_scalar_paths(0.2), SIM_DATES)
        cube = builder.build()
        assert cube.n_paths == N_PATHS
        assert cube.n_times == N_TIMES

    def test_build_with_curve_factor(self):
        cube = build_simple_cube()
        assert cube.n_paths == N_PATHS
        assert cube.n_times == N_TIMES
        assert "DISC" in cube.factor_names

    def test_build_with_surface_factor(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_surface_factor(
            "VOL_SURF", make_surface_paths(), TENORS, STRIKES, dates=SIM_DATES
        )
        cube = builder.build()
        assert cube.n_paths == N_PATHS
        assert cube.n_times == N_TIMES

    def test_factor_names_preserved_in_order(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("DISC", make_curve_paths(), TENORS, dates=SIM_DATES)
        builder.add_factor("SCALAR", make_scalar_paths(), SIM_DATES)
        cube = builder.build()
        assert "DISC" in cube.factor_names
        assert "SCALAR" in cube.factor_names
        assert cube.factor_names[0] == "DISC"
        assert cube.factor_names[1] == "SCALAR"

    def test_duplicate_factor_name_raises(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("DISC", make_curve_paths(), TENORS, dates=SIM_DATES)
        with pytest.raises(ValueError, match="already added"):
            builder.add_curve_factor("DISC", make_curve_paths(), TENORS, dates=SIM_DATES)

    def test_wrong_n_paths_raises(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        bad_paths = make_curve_paths()[:N_PATHS - 1]  # wrong number of paths
        with pytest.raises(ValueError, match="paths"):
            builder.add_curve_factor("DISC", bad_paths, TENORS, dates=SIM_DATES)

    def test_mismatched_dates_raises(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        too_few_dates = SIM_DATES[:N_TIMES - 1]
        with pytest.raises(ValueError):
            builder.add_curve_factor("DISC", make_curve_paths(), TENORS, dates=too_few_dates)

    def test_build_twice_raises(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("DISC", make_curve_paths(), TENORS, dates=SIM_DATES)
        builder.build()
        with pytest.raises(RuntimeError, match="only be used once"):
            builder.build()

    def test_empty_builder_raises(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        with pytest.raises(ValueError, match="empty"):
            builder.build()

    def test_add_after_build_raises(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("DISC", make_curve_paths(), TENORS, dates=SIM_DATES)
        builder.build()
        with pytest.raises(RuntimeError, match="Cannot modify"):
            builder.add_factor("X", make_scalar_paths(), SIM_DATES)

    def test_year_fractions_computed(self):
        cube = build_simple_cube()
        assert cube.year_fractions.shape == (N_TIMES,)
        # First date is val_date, so first yf should be 0
        npt.assert_allclose(cube.year_fractions[0], 0.0, atol=1e-10)
        # All subsequent fractions should be positive
        assert np.all(cube.year_fractions[1:] > 0)


# ---------------------------------------------------------------------------
# Date union (forward-fill)
# ---------------------------------------------------------------------------

class TestDateUnion:

    def test_union_of_factor_dates(self):
        """Factors with different date sets — cube should span the full union."""
        dates_a = SIM_DATES                 # all N_TIMES dates
        dates_b = SIM_DATES[1:]             # N_TIMES - 1 dates (no first date)

        paths_a = make_curve_paths()
        paths_b = np.full((N_PATHS, N_TIMES - 1, N_TENORS), 0.07, dtype=np.float64)

        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("A", paths_a, TENORS, dates=dates_a)
        builder.add_curve_factor("B", paths_b, TENORS, dates=dates_b)
        cube = builder.build()

        # Union = all N_TIMES dates
        assert cube.n_times == N_TIMES
        assert cube.dates == SIM_DATES

        # Factor B has no value at SIM_DATES[0]: it forward-fills its first
        # available value (index 0 of paths_b = SIM_DATES[1] value = 0.07).
        b_slice = cube.get_time_slice(0)
        np.testing.assert_allclose(b_slice["B"].values, 0.07)

    def test_disjoint_factor_dates_builds_union(self):
        """Factors with fully disjoint date sets build a cube over all dates."""
        dates_a = SIM_DATES[:2]
        dates_b = SIM_DATES[2:]

        paths_a = np.full((N_PATHS, 2, N_TENORS), 0.05)
        paths_b = np.full((N_PATHS, 2, N_TENORS), 0.08)

        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_curve_factor("A", paths_a, TENORS, dates=dates_a)
        builder.add_curve_factor("B", paths_b, TENORS, dates=dates_b)
        cube = builder.build()

        assert cube.n_times == N_TIMES
        assert cube.dates == SIM_DATES

        # Factor A is forward-filled at SIM_DATES[2] and SIM_DATES[3]
        # with its last known value (SIM_DATES[1] = 0.05).
        a_at_3 = cube.get_time_slice(3)
        np.testing.assert_allclose(a_at_3["A"].values, 0.05)
        # Factor B is back-filled at SIM_DATES[0] and SIM_DATES[1]
        # with its first available value (SIM_DATES[2] = 0.08).
        b_at_0 = cube.get_time_slice(0)
        np.testing.assert_allclose(b_at_0["B"].values, 0.08)


# ---------------------------------------------------------------------------
# get_time_slice
# ---------------------------------------------------------------------------

class TestGetTimeSlice:

    def test_returns_dict(self):
        cube = build_simple_cube()
        slc = cube.get_time_slice(0)
        assert isinstance(slc, dict)

    def test_curve_slice_type(self):
        cube = build_simple_cube()
        slc = cube.get_time_slice(0)
        assert isinstance(slc["DISC"], CurveSlice)

    def test_curve_slice_values_shape(self):
        cube = build_simple_cube()
        slc = cube.get_time_slice(0)
        assert slc["DISC"].values.shape == (N_PATHS, N_TENORS)

    def test_curve_slice_tenors(self):
        cube = build_simple_cube()
        slc = cube.get_time_slice(0)
        npt.assert_array_equal(slc["DISC"].tenors, TENORS)

    def test_scalar_slice_type(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_factor("VOL", make_scalar_paths(), SIM_DATES)
        cube = builder.build()
        slc = cube.get_time_slice(0)
        assert isinstance(slc["VOL"], ScalarSlice)

    def test_scalar_slice_shape(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_factor("VOL", make_scalar_paths(), SIM_DATES)
        cube = builder.build()
        slc = cube.get_time_slice(0)
        assert slc["VOL"].values.shape == (N_PATHS,)

    def test_surface_slice_type(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_surface_factor("S", make_surface_paths(), TENORS, STRIKES, SIM_DATES)
        cube = builder.build()
        slc = cube.get_time_slice(0)
        assert isinstance(slc["S"], SurfaceSlice)

    def test_surface_slice_shape(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_surface_factor("S", make_surface_paths(), TENORS, STRIKES, SIM_DATES)
        cube = builder.build()
        slc = cube.get_time_slice(0)
        assert slc["S"].values.shape == (N_PATHS, N_TENORS, N_STRIKES)

    def test_out_of_range_raises(self):
        cube = build_simple_cube()
        with pytest.raises(IndexError):
            cube.get_time_slice(cube.n_times)

    def test_negative_index_raises(self):
        cube = build_simple_cube()
        with pytest.raises(IndexError):
            cube.get_time_slice(-1)

    def test_all_time_slices_same_shape(self):
        cube = build_simple_cube()
        for t in range(cube.n_times):
            slc = cube.get_time_slice(t)
            assert slc["DISC"].values.shape == (N_PATHS, N_TENORS)


# ---------------------------------------------------------------------------
# get_path_slice
# ---------------------------------------------------------------------------

class TestGetPathSlice:

    def test_returns_dict(self):
        cube = build_simple_cube()
        slc = cube.get_path_slice(0)
        assert isinstance(slc, dict)

    def test_curve_path_shape(self):
        cube = build_simple_cube()
        slc = cube.get_path_slice(0)
        assert slc["DISC"].shape == (N_TIMES, N_TENORS)

    def test_scalar_path_shape(self):
        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=VAL_DATE)
        builder.add_factor("VOL", make_scalar_paths(), SIM_DATES)
        cube = builder.build()
        slc = cube.get_path_slice(0)
        assert slc["VOL"].shape == (N_TIMES,)

    def test_out_of_range_raises(self):
        cube = build_simple_cube()
        with pytest.raises(IndexError):
            cube.get_path_slice(cube.n_paths)

    def test_path_values_correct(self):
        """Values in a path slice should match those in the time slices."""
        cube = build_simple_cube()
        path_slc = cube.get_path_slice(3)
        for t in range(N_TIMES):
            time_slc = cube.get_time_slice(t)
            npt.assert_array_equal(
                path_slc["DISC"][t, :],
                time_slc["DISC"].values[3, :],
            )


# ---------------------------------------------------------------------------
# Immutability
# ---------------------------------------------------------------------------

class TestImmutability:

    def test_data_arrays_not_writeable(self):
        cube = build_simple_cube()
        arr = cube.data["DISC"]
        assert not arr.flags.writeable

    def test_year_fractions_not_writeable(self):
        cube = build_simple_cube()
        assert not cube.year_fractions.flags.writeable

    def test_cannot_set_attribute(self):
        cube = build_simple_cube()
        with pytest.raises((AttributeError, TypeError)):
            cube.n_paths = 999  # type: ignore[misc]
