"""
Tests for CVAEngine and FVAEngine.

Uses analytically tractable scenarios (flat curves, constant EPE) so
expected values can be verified by hand or simple closed-form expressions.
"""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import pytest

from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice
from pricing.cva_engine import CVAEngine
from pricing.exposure_profile import ExposureProfile
from pricing.fva_engine import FVAEngine
from utils.interpolation import linear_interpolator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TENORS = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 10.0], dtype=np.float64)


def flat_curve_handler(rate: float) -> YieldCurve:
    """Single-path flat curve handler."""
    rates = np.full((1, len(TENORS)), rate, dtype=np.float64)
    return YieldCurve(
        year_fracs=TENORS,
        rates=rates,
        interpolator=linear_interpolator,
    )


def make_profile(
    n_paths: int,
    dates: tuple[date, ...],
    epe_value: float = 100.0,
    ene_value: float = 0.0,
) -> ExposureProfile:
    """Profile with constant EPE and ENE across all paths and dates."""
    n_dates = len(dates)
    mtm = np.full((n_paths, n_dates), epe_value if ene_value == 0.0 else ene_value)
    exposure = np.full((n_paths, n_dates), max(epe_value, 0.0))
    neg_exposure = np.full((n_paths, n_dates), min(ene_value, 0.0))
    collateral = np.zeros((n_paths, n_dates))
    return ExposureProfile(
        netting_set_id="NS_TEST",
        dates=dates,
        mtm=mtm,
        collateral=collateral,
        exposure=exposure,
        neg_exposure=neg_exposure,
    )


def quarterly_dates(val_date: date, n: int) -> tuple[date, ...]:
    return tuple(val_date + timedelta(days=90 * i) for i in range(1, n + 1))


# ---------------------------------------------------------------------------
# CVAEngine
# ---------------------------------------------------------------------------

class TestCVAEngine:
    @pytest.fixture
    def val_date(self):
        return date(2025, 1, 2)

    def test_zero_epe_gives_zero_cva(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(n_paths=10, dates=dates, epe_value=0.0)
        engine = CVAEngine(valuation_date=val_date)
        cva = engine.compute(
            profile,
            hazard_curve=flat_curve_handler(0.01),
            discount_curve=flat_curve_handler(0.05),
        )
        assert cva == pytest.approx(0.0, abs=1e-10)

    def test_zero_hazard_gives_zero_cva(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(n_paths=10, dates=dates, epe_value=1_000_000.0)
        engine = CVAEngine(valuation_date=val_date)
        cva = engine.compute(
            profile,
            hazard_curve=flat_curve_handler(0.0),
            discount_curve=flat_curve_handler(0.05),
        )
        assert cva == pytest.approx(0.0, abs=1e-10)

    def test_cva_positive(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(n_paths=10, dates=dates, epe_value=1_000_000.0)
        engine = CVAEngine(valuation_date=val_date)
        cva = engine.compute(
            profile,
            hazard_curve=flat_curve_handler(0.02),
            discount_curve=flat_curve_handler(0.05),
        )
        assert cva > 0.0

    def test_higher_hazard_higher_cva(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(n_paths=10, dates=dates, epe_value=1_000_000.0)
        engine = CVAEngine(valuation_date=val_date)
        cva_low = engine.compute(profile, flat_curve_handler(0.01), flat_curve_handler(0.05))
        cva_high = engine.compute(profile, flat_curve_handler(0.05), flat_curve_handler(0.05))
        assert cva_high > cva_low

    def test_higher_epe_higher_cva(self, val_date):
        dates = quarterly_dates(val_date, 4)
        engine = CVAEngine(valuation_date=val_date)
        hazard = flat_curve_handler(0.02)
        disc = flat_curve_handler(0.05)
        cva_small = engine.compute(make_profile(10, dates, epe_value=100.0), hazard, disc)
        cva_large = engine.compute(make_profile(10, dates, epe_value=1_000_000.0), hazard, disc)
        assert cva_large > cva_small
        # Linearity: 10000x EPE → 10000x CVA
        assert cva_large == pytest.approx(cva_small * 10_000.0, rel=1e-6)

    def test_higher_recovery_lower_cva(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates, epe_value=1_000_000.0)
        engine = CVAEngine(valuation_date=val_date)
        cva_low_r = engine.compute(profile, flat_curve_handler(0.02), flat_curve_handler(0.05), recovery=0.2)
        cva_high_r = engine.compute(profile, flat_curve_handler(0.02), flat_curve_handler(0.05), recovery=0.6)
        assert cva_low_r > cva_high_r

    def test_recovery_scaling(self, val_date):
        """CVA scales linearly with (1 - R)."""
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates, epe_value=1_000_000.0)
        engine = CVAEngine(valuation_date=val_date)
        h = flat_curve_handler(0.02)
        d = flat_curve_handler(0.05)
        cva_0 = engine.compute(profile, h, d, recovery=0.0)
        cva_4 = engine.compute(profile, h, d, recovery=0.4)
        assert cva_4 == pytest.approx(cva_0 * 0.6, rel=1e-6)

    def test_invalid_recovery_raises(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates)
        engine = CVAEngine(valuation_date=val_date)
        with pytest.raises(ValueError, match="recovery"):
            engine.compute(profile, flat_curve_handler(0.02), flat_curve_handler(0.05), recovery=1.0)
        with pytest.raises(ValueError, match="recovery"):
            engine.compute(profile, flat_curve_handler(0.02), flat_curve_handler(0.05), recovery=-0.1)

    def test_single_date(self, val_date):
        dates = (val_date + timedelta(days=365),)
        profile = make_profile(10, dates, epe_value=1_000_000.0)
        engine = CVAEngine(valuation_date=val_date)
        cva = engine.compute(profile, flat_curve_handler(0.02), flat_curve_handler(0.05))
        assert cva > 0.0
        assert np.isfinite(cva)


# ---------------------------------------------------------------------------
# FVAEngine
# ---------------------------------------------------------------------------

class TestFVAEngine:
    @pytest.fixture
    def val_date(self):
        return date(2025, 1, 2)

    def test_zero_epe_zero_ene_gives_zero_fva(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates, epe_value=0.0, ene_value=0.0)
        engine = FVAEngine(valuation_date=val_date)
        fva, fca, fba = engine.compute(profile, flat_curve_handler(0.06), flat_curve_handler(0.05))
        assert fva == pytest.approx(0.0, abs=1e-10)
        assert fca == pytest.approx(0.0, abs=1e-10)
        assert fba == pytest.approx(0.0, abs=1e-10)

    def test_zero_spread_gives_zero_fva(self, val_date):
        """If funding rate = risk-free rate, funding spread = 0 → FVA = 0."""
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates, epe_value=1_000_000.0)
        engine = FVAEngine(valuation_date=val_date)
        fva, fca, fba = engine.compute(
            profile,
            funding_curve=flat_curve_handler(0.05),
            discount_curve=flat_curve_handler(0.05),
        )
        assert fva == pytest.approx(0.0, abs=1e-8)
        assert fca == pytest.approx(0.0, abs=1e-8)

    def test_positive_epe_positive_fca(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates, epe_value=1_000_000.0, ene_value=0.0)
        engine = FVAEngine(valuation_date=val_date)
        fva, fca, fba = engine.compute(profile, flat_curve_handler(0.06), flat_curve_handler(0.05))
        assert fca > 0.0
        assert fba == pytest.approx(0.0, abs=1e-10)
        assert fva == pytest.approx(fca, rel=1e-10)

    def test_negative_ene_positive_fba(self, val_date):
        """Negative MTM (we owe money) → positive FBA (funding benefit)."""
        dates = quarterly_dates(val_date, 4)
        n_paths, n_dates = 10, len(dates)
        mtm = np.full((n_paths, n_dates), -1_000_000.0)
        profile = ExposureProfile(
            netting_set_id="NS",
            dates=dates,
            mtm=mtm,
            collateral=np.zeros((n_paths, n_dates)),
            exposure=np.zeros((n_paths, n_dates)),
            neg_exposure=mtm.copy(),
        )
        engine = FVAEngine(valuation_date=val_date)
        fva, fca, fba = engine.compute(profile, flat_curve_handler(0.06), flat_curve_handler(0.05))
        assert fba > 0.0
        assert fca == pytest.approx(0.0, abs=1e-10)
        assert fva == pytest.approx(-fba, rel=1e-10)  # FVA = FCA - FBA < 0

    def test_fva_equals_fca_minus_fba(self, val_date):
        """FVA = FCA - FBA by definition."""
        dates = quarterly_dates(val_date, 6)
        n_paths, n_dates = 10, len(dates)
        mtm = np.random.default_rng(42).normal(0, 100_000, (n_paths, n_dates))
        exposure = np.maximum(mtm, 0.0)
        neg_exposure = np.minimum(mtm, 0.0)
        profile = ExposureProfile(
            netting_set_id="NS",
            dates=dates,
            mtm=mtm,
            collateral=np.zeros((n_paths, n_dates)),
            exposure=exposure,
            neg_exposure=neg_exposure,
        )
        engine = FVAEngine(valuation_date=val_date)
        fva, fca, fba = engine.compute(profile, flat_curve_handler(0.07), flat_curve_handler(0.05))
        assert fva == pytest.approx(fca - fba, rel=1e-10)

    def test_larger_spread_larger_fca(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates, epe_value=1_000_000.0)
        engine = FVAEngine(valuation_date=val_date)
        _, fca_small, _ = engine.compute(profile, flat_curve_handler(0.06), flat_curve_handler(0.05))
        _, fca_large, _ = engine.compute(profile, flat_curve_handler(0.10), flat_curve_handler(0.05))
        assert fca_large > fca_small

    def test_returns_three_values(self, val_date):
        dates = quarterly_dates(val_date, 4)
        profile = make_profile(10, dates)
        engine = FVAEngine(valuation_date=val_date)
        result = engine.compute(profile, flat_curve_handler(0.06), flat_curve_handler(0.05))
        assert len(result) == 3
