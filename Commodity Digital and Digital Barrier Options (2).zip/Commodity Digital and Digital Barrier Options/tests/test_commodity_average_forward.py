"""
Tests for instruments/commodity_average_forward.py — CommodityAverageForward.

Analytical reference:
    Standard (USD payoff, ZAR-CSA):
        avg_price  = arithmetic mean of daily forward prices (USD)
        FX_fwd     = FX_spot * DF_for(T_pay) / DF_dom(T_pay)
        PV_USD     = (avg_price - strike_USD) * notional
                     * FX_fwd * DF_MM(T_pay) / FX_spot
                   ≡ (avg_price - strike_USD) * notional * DF_for(T_pay)
                     when DF_dom == DF_MM  (i.e. dom_rate == mm_rate)

    Composite (ZAR payoff):
        PV_ZAR     = (avg_price * FX_fwd - strike_ZAR) * notional
                     * DF_MM(T_pay)
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt

from instruments.commodity_average_forward import CommodityAverageForward
from market_data.risk_factor import CurveSlice, ScalarSlice
from utils.interpolation import forward_price_interpolator, linear_interpolator


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

N_PATHS = 8

VAL_DATE = date(2025, 1, 2)

# Use ACT/365 with these specific dates so T_pay = 1.0 exactly:
#   ACT/365( date(2025,1,2), date(2026,1,2) ) = 365/365 = 1.0
AVG_DATE_1Y = date(2026, 1, 2)   # single averaging date, T ≈ 1.0 yr

FWD_PRICE = 80.0  # USD/barrel
FX_SPOT = 18.0    # ZAR per USD
DOM_RATE = 0.05       # ZAR-USD-BASIS spread (added on top of ZAR-SWAP)
FOR_RATE = 0.04       # USD-SOFR
MM_RATE = 0.05        # ZAR-SWAP
EFF_DOM_RATE = MM_RATE + DOM_RATE  # effective domestic rate = SWAP + basis spread = 0.10

STRIKE_USD = 75.0
NOTIONAL = 100.0  # barrels

TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0], dtype=np.float64)

# Excel serial dates (days since 1899-12-30) corresponding to the same tenors
# from VAL_DATE = date(2025, 1, 2) under ACT/365:
#   T=0.25 → 2025-04-03 (yf=0.2493)
#   T=0.5  → 2025-07-03 (yf=0.4986)
#   T=1.0  → 2026-01-02 (yf=1.0000) = AVG_DATE_1Y
#   T=2.0  → 2027-01-02 (yf=2.0000)
#   T=5.0  → 2030-01-01 (yf=5.0000)
FWD_TENORS = np.array([45750.0, 45841.0, 46024.0, 46389.0, 47484.0], dtype=np.float64)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flat_slice(rate: float) -> CurveSlice:
    """Rate/discount curve slice — year-fraction tenors."""
    return CurveSlice(
        values=np.full((N_PATHS, len(TENORS)), rate, dtype=np.float64),
        tenors=TENORS,
    )


def fwd_flat_slice(price: float) -> CurveSlice:
    """Forward price curve slice — Excel serial date tenors."""
    return CurveSlice(
        values=np.full((N_PATHS, len(FWD_TENORS)), price, dtype=np.float64),
        tenors=FWD_TENORS,
    )


def scalar_slice(value: float) -> ScalarSlice:
    return ScalarSlice(values=np.full(N_PATHS, value, dtype=np.float64))


def make_market_state(
    fwd_price: float = FWD_PRICE,
    fx_spot: float = FX_SPOT,
    dom_rate: float = DOM_RATE,
    for_rate: float = FOR_RATE,
    mm_rate: float = MM_RATE,
) -> dict:
    return {
        "FWD": fwd_flat_slice(fwd_price),
        "FX": scalar_slice(fx_spot),
        "DOM": flat_slice(dom_rate),
        "FOR": flat_slice(for_rate),
        "MM": flat_slice(mm_rate),
    }


def make_instrument(
    averaging_start: date = AVG_DATE_1Y,
    maturity_date: date = AVG_DATE_1Y,
    strike: float = STRIKE_USD,
    notional: float = NOTIONAL,
    is_composite: bool = False,
    direction: int = 1,
    pricing_lag: int = 0,
    payment_lag: int = 0,
    fx_settlement_lag: int = 0,
) -> CommodityAverageForward:
    """Construct a CommodityAverageForward with test defaults."""
    return CommodityAverageForward(
        name="TEST_CAF",
        averaging_start=averaging_start,
        maturity_date=maturity_date,
        strike=strike,
        notional=notional,
        is_composite=is_composite,
        forward_curve_name="FWD",
        fx_spot_name="FX",
        domestic_curve_name="DOM",
        foreign_curve_name="FOR",
        money_market_curve_name="MM",
        averaging_calendar="USD",
        payment_calendar="USD",
        lag_calendar="USD",
        direction=direction,
        forward_interpolator=forward_price_interpolator,
        domestic_interpolator=linear_interpolator,
        foreign_interpolator=linear_interpolator,
        money_market_interpolator=linear_interpolator,
        pricing_lag=pricing_lag,
        payment_lag=payment_lag,
        fx_settlement_lag=fx_settlement_lag,
    )


# ---------------------------------------------------------------------------
# Tests — lifecycle
# ---------------------------------------------------------------------------

class TestLifecycle:
    def test_past_payment_date_returns_zeros(self):
        """After the payment date the instrument is worth nothing."""
        inst = make_instrument(
            averaging_start=date(2024, 12, 1),
            maturity_date=date(2024, 12, 31),
            payment_lag=0,
        )
        ms = make_market_state()
        pv = inst.scenario_npvs(date(2025, 1, 5), ms)
        npt.assert_array_equal(pv, np.zeros(N_PATHS))

    def test_on_payment_date_not_expired(self):
        """On the payment date itself the contract is still live (> check)."""
        inst = make_instrument(
            averaging_start=AVG_DATE_1Y,
            maturity_date=AVG_DATE_1Y,
            payment_lag=0,
        )
        ms = make_market_state()
        pv = inst.scenario_npvs(AVG_DATE_1Y, ms)
        # T_pay = 0 → df_MM = 1, FX_fwd = FX_spot → PV_USD = (avg - K) * N
        expected = (FWD_PRICE - STRIKE_USD) * NOTIONAL  # 500
        npt.assert_allclose(pv, expected, rtol=1e-6)


# ---------------------------------------------------------------------------
# Tests — ZAR-CSA standard contract
# ---------------------------------------------------------------------------

class TestStandardContract:
    """All averaging dates in the future, no historical fixings."""

    def _expected_pv_usd(
        self,
        avg: float,
        T: float,
        fx: float = FX_SPOT,
        dom: float = DOM_RATE,
        for_: float = FOR_RATE,
        mm: float = MM_RATE,
        strike: float = STRIKE_USD,
        notional: float = NOTIONAL,
    ) -> float:
        """Closed-form standard PV under ZAR-CSA."""
        r_dom_eff = mm + dom   # effective domestic: ZAR-SWAP + basis spread
        df_dom = np.exp(-r_dom_eff * T)
        df_for = np.exp(-for_ * T)
        df_mm = np.exp(-mm * T)
        fx_fwd = fx * df_for / df_dom
        payoff_usd = (avg - strike) * notional
        pv_zar = payoff_usd * fx_fwd * df_mm
        return pv_zar / fx

    def test_single_averaging_date_atm_zero(self):
        """At-the-money forward → zero PV."""
        inst = make_instrument(strike=FWD_PRICE)
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv, 0.0, atol=1e-10)

    def test_single_averaging_date_analytical(self):
        """Standard PV matches closed-form ZAR-CSA formula at T=1."""
        inst = make_instrument()
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = 1.0  # ACT/365: 365 days
        expected = self._expected_pv_usd(FWD_PRICE, T)
        npt.assert_allclose(pv, expected, rtol=1e-6)

    def test_zar_csa_identity(self):
        """With zero basis spread, PV_USD = (avg - K) * N * df_for.

        The ZAR-CSA identity (PV_USD = payoff × df_for) holds when the effective
        domestic rate equals the MM rate, i.e. when the basis spread is zero.
        """
        inst = make_instrument()
        ms = make_market_state(dom_rate=0.0)  # zero basis spread → eff_dom = MM_RATE
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = 1.0
        expected_usd = (FWD_PRICE - STRIKE_USD) * NOTIONAL * np.exp(-FOR_RATE * T)
        npt.assert_allclose(pv, expected_usd, rtol=1e-6)

    def test_long_short_symmetry(self):
        """Long +100 bbl and short -100 bbl sum to zero."""
        ms = make_market_state()
        long_pv = make_instrument(notional=NOTIONAL).scenario_npvs(VAL_DATE, ms)
        short_pv = make_instrument(notional=-NOTIONAL).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(long_pv + short_pv, 0.0, atol=1e-12)


# ---------------------------------------------------------------------------
# Tests — direction parameter
# ---------------------------------------------------------------------------

class TestDirection:
    """direction=+1 (long) and direction=-1 (short) produce equal and opposite PVs."""

    def test_short_is_negative_of_long_standard(self):
        """Standard contract: direction=-1 flips the sign of PV."""
        ms = make_market_state()
        long_pv = make_instrument(direction=1).scenario_npvs(VAL_DATE, ms)
        short_pv = make_instrument(direction=-1).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(long_pv + short_pv, 0.0, atol=1e-12)

    def test_short_standard_analytical(self):
        """Short standard contract PV matches negated closed-form."""
        ms = make_market_state()
        T = 1.0
        df_dom = np.exp(-(MM_RATE + DOM_RATE) * T)
        df_for = np.exp(-FOR_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected_long = (FWD_PRICE - STRIKE_USD) * NOTIONAL * fx_fwd * df_mm / FX_SPOT
        pv = make_instrument(direction=-1).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv, -expected_long, rtol=1e-6)

    def test_short_is_negative_of_long_composite(self):
        """Composite contract: direction=-1 flips the sign of PV."""
        ms = make_market_state()
        long_pv = _composite_instrument(direction=1).scenario_npvs(VAL_DATE, ms)
        short_pv = _composite_instrument(direction=-1).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(long_pv + short_pv, 0.0, atol=1e-12)

    def test_short_is_negative_of_long_composite_cta(self):
        """Composite CTA contract: direction=-1 flips the sign of PV."""
        ms = make_market_state()
        long_pv = _composite_instrument(
            direction=1, convert_then_average=True,
        ).scenario_npvs(VAL_DATE, ms)
        short_pv = _composite_instrument(
            direction=-1, convert_then_average=True,
        ).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(long_pv + short_pv, 0.0, atol=1e-12)

    def test_default_direction_is_long(self):
        """Omitting direction gives the same result as direction=+1."""
        ms = make_market_state()
        default_pv = make_instrument().scenario_npvs(VAL_DATE, ms)
        explicit_long_pv = make_instrument(direction=1).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(default_pv, explicit_long_pv, rtol=1e-12)

    def test_path_independence_with_flat_curves(self):
        """Flat curves → all paths have identical PV."""
        inst = make_instrument()
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv, pv[0], rtol=1e-12)

    def test_higher_fwd_price_increases_pv(self):
        """PV increases monotonically with forward price (long position)."""
        inst = make_instrument()
        pv_low = inst.scenario_npvs(
            VAL_DATE, make_market_state(fwd_price=70.0),
        )[0]
        pv_high = inst.scenario_npvs(
            VAL_DATE, make_market_state(fwd_price=90.0),
        )[0]
        assert pv_high > pv_low

    def test_different_paths_with_different_fx(self):
        """Per-path FX spot variation propagates correctly."""
        n = N_PATHS
        fx_vals = np.linspace(16.0, 20.0, n)
        ms = make_market_state()
        ms["FX"] = ScalarSlice(values=fx_vals)

        inst = make_instrument()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        # Standard contract: PV_USD = payoff × FX_fwd × df_MM / FX_spot
        # FX_fwd / FX_spot = df_for / df_dom  (FX cancels).
        # So PV should be path-independent when only FX varies and the
        # commodity/rate curves are flat.
        T = 1.0
        df_for = np.exp(-FOR_RATE * T)
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        expected = (
            (FWD_PRICE - STRIKE_USD) * NOTIONAL * df_for / df_dom * df_mm
        )
        # Note: pv_zar / fx_spot → FX cancels in numerator/denominator.
        npt.assert_allclose(pv, expected, rtol=1e-6)


# ---------------------------------------------------------------------------
# Tests — composite contract
# ---------------------------------------------------------------------------

class TestCompositeContract:
    def test_analytical_composite(self):
        """Composite PV_ZAR matches closed-form formula."""
        # Choose strike in ZAR = 75 * 18 = 1350 so that the composite
        # contract has the same ATM level as the standard one.
        strike_zar = STRIKE_USD * FX_SPOT  # 1350
        inst = make_instrument(is_composite=True, strike=strike_zar)
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = 1.0
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_for = np.exp(-FOR_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom

        payoff_zar = (FWD_PRICE * fx_fwd - strike_zar) * NOTIONAL
        expected_zar = payoff_zar * df_mm

        npt.assert_allclose(pv, expected_zar, rtol=1e-6)

    def test_standard_vs_composite_relationship(self):
        """At the same USD strike, composite and standard should differ only
        by the ZAR discount adjustment (FX risk)."""
        strike_zar = STRIKE_USD * FX_SPOT
        ms = make_market_state()

        pv_std = make_instrument(
            is_composite=False, strike=STRIKE_USD,
        ).scenario_npvs(VAL_DATE, ms)

        pv_comp = make_instrument(
            is_composite=True, strike=strike_zar,
        ).scenario_npvs(VAL_DATE, ms)

        # Both should be positive (FWD_PRICE=80 > STRIKE=75 equivalent)
        assert np.all(pv_std > 0)
        assert np.all(pv_comp > 0)


# ---------------------------------------------------------------------------
# Tests — historical fixings
# ---------------------------------------------------------------------------

class TestHistoricalFixings:
    def test_all_past_fixings(self):
        """When all averaging dates are past and fixings are provided,
        the average is computed from the fixings alone."""
        # 2-day averaging window, both dates before val_date
        inst = make_instrument(
            averaging_start=date(2024, 12, 30),
            maturity_date=date(2024, 12, 31),
            payment_lag=2,
        )
        fixing_price = 82.0
        fixings = {
            ("FWD", date(2024, 12, 30)): np.full(N_PATHS, fixing_price),
            ("FWD", date(2024, 12, 31)): np.full(N_PATHS, fixing_price),
        }
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms, fixings=fixings)

        # Use the actual payment date computed by the instrument to build
        # the expected value (avoids hard-coding holiday-adjusted dates).
        from utils.ql_helpers import DAY_COUNTERS, to_ql_date
        dc = DAY_COUNTERS["ACT/365"]
        T_pay = float(dc.yearFraction(
            to_ql_date(VAL_DATE), to_ql_date(inst._payment_date),
        ))
        df_for = np.exp(-FOR_RATE * T_pay)
        df_dom = np.exp(-EFF_DOM_RATE * T_pay)
        df_mm = np.exp(-MM_RATE * T_pay)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected = (
            (fixing_price - STRIKE_USD) * NOTIONAL * fx_fwd * df_mm / FX_SPOT
        )
        npt.assert_allclose(pv, expected, rtol=1e-6)

    def test_mixed_fixings_and_future(self):
        """When some dates are past (with fixings) and some future,
        the weighted average is correct."""
        # 3-day averaging window
        d1 = date(2025, 1, 2)   # = VAL_DATE → treated as future
        d3 = date(2025, 1, 6)   # future

        val = date(2025, 1, 2)  # same as d1

        inst = make_instrument(
            averaging_start=d1,
            maturity_date=d3,
            payment_lag=0,
            pricing_lag=0,
        )

        # No fixings (all dates on/after val_date → all future)
        ms = make_market_state(fwd_price=80.0)
        pv_all_future = inst.scenario_npvs(val, ms)

        # Now test with val_date = d2 (so d1 is past, d2 and d3 are future)
        fixing_val = 78.0
        fixings = {
            ("FWD", d1): np.full(N_PATHS, fixing_val),
        }
        ms2 = make_market_state(fwd_price=80.0)
        pv_mixed = inst.scenario_npvs(date(2025, 1, 3), ms2, fixings=fixings)

        # Expected avg = (78 + 80 + 80) / 3 = 79.333...
        # (2025-01-03 = val_date → future, d3 = future)
        # Sanity: avg with past fixing < avg with all futures (78 < 80)
        assert float(pv_mixed[0]) < float(pv_all_future[0])

    def test_missing_fixing_falls_back_to_forward_curve(self):
        """When a past fixing is absent, the forward curve is used."""
        inst = make_instrument(
            averaging_start=date(2024, 12, 31),
            maturity_date=date(2024, 12, 31),
            payment_lag=2,
            pricing_lag=0,
        )
        # val_date = 2025-01-02, 2024-12-31 < val_date → past but no fixing
        ms = make_market_state(fwd_price=FWD_PRICE)
        pv_no_fixing = inst.scenario_npvs(VAL_DATE, ms, fixings=None)

        # With fixing at the same price as the forward curve → same result
        fixings = {("FWD", date(2024, 12, 31)): np.full(N_PATHS, FWD_PRICE)}
        pv_with_fixing = inst.scenario_npvs(VAL_DATE, ms, fixings=fixings)

        npt.assert_allclose(pv_no_fixing, pv_with_fixing, rtol=1e-6)


# ---------------------------------------------------------------------------
# Tests — averaging across multiple dates
# ---------------------------------------------------------------------------

class TestMultiDateAveraging:
    def test_flat_curve_average_equals_single_date(self):
        """With a flat forward curve, a multi-day averaging window gives
        the same price as a single-date window."""
        single = make_instrument(
            averaging_start=AVG_DATE_1Y,
            maturity_date=AVG_DATE_1Y,
        )
        # One-month window ending on same date
        multi = make_instrument(
            averaging_start=date(2025, 12, 1),
            maturity_date=AVG_DATE_1Y,
        )
        ms = make_market_state()
        pv_single = single.scenario_npvs(VAL_DATE, ms)
        pv_multi = multi.scenario_npvs(VAL_DATE, ms)

        # With a flat forward curve all daily prices are identical, so the
        # average equals the single-date value (T_pay differs slightly due
        # to payment_date, but both use payment_lag=0 → T_pay=T_maturity).
        # They may differ slightly because T_pay uses maturity_date for both,
        # so the only difference is avg_price (both = FWD_PRICE). Should match.
        npt.assert_allclose(pv_single, pv_multi, rtol=1e-6)

    def test_average_interpolates_forward_curve(self):
        """With a non-flat forward curve, the average uses prices at each
        lag-adjusted tenor, reflecting the actual term structure."""
        # Build a sloped forward curve: prices rise linearly from 78 to 88
        # over 5 years.
        n_tenors = len(TENORS)
        prices_sloped = np.tile(
            np.linspace(78.0, 88.0, n_tenors), (N_PATHS, 1),
        ).astype(np.float64)

        ms = make_market_state()
        ms["FWD"] = CurveSlice(values=prices_sloped, tenors=FWD_TENORS)

        inst = make_instrument(
            averaging_start=AVG_DATE_1Y,
            maturity_date=AVG_DATE_1Y,
            pricing_lag=0,
        )
        pv = inst.scenario_npvs(VAL_DATE, ms)

        # Single date T=1 → interpolated price = linear interp at T=1
        # TENORS = [0.25, 0.5, 1.0, 2.0, 5.0], values at T=1 = 3rd element
        expected_price = float(prices_sloped[0, 2])  # index 2 → T=1.0

        T = 1.0
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_for = np.exp(-FOR_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected_pv = (
            (expected_price - STRIKE_USD) * NOTIONAL
            * fx_fwd * df_mm / FX_SPOT
        )
        npt.assert_allclose(pv, expected_pv, rtol=1e-5)


# ---------------------------------------------------------------------------
# Tests — pricing lag
# ---------------------------------------------------------------------------

class TestPricingLag:
    def test_zero_lag_equals_no_lag(self):
        """pricing_lag=0 and explicit lag=0 give identical results."""
        ms = make_market_state()
        inst = make_instrument(pricing_lag=0)
        pv = inst.scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(pv, pv)  # trivially true; presence confirms no crash

    def test_lag_shifts_to_later_tenor(self):
        """A non-zero pricing lag uses a later tenor on the forward curve.
        With an upward-sloping curve, a longer lag → higher price → higher PV."""
        n_tenors = len(TENORS)
        prices_rising = np.tile(
            np.linspace(78.0, 88.0, n_tenors), (N_PATHS, 1),
        ).astype(np.float64)

        ms = make_market_state()
        ms["FWD"] = CurveSlice(values=prices_rising, tenors=FWD_TENORS)

        pv_lag0 = make_instrument(pricing_lag=0).scenario_npvs(
            VAL_DATE, ms,
        )
        pv_lag1 = make_instrument(pricing_lag=1).scenario_npvs(
            VAL_DATE, ms,
        )

        # Lag=1 advances the pricing date by 1 BD → slightly longer tenor
        # → slightly higher price on a rising curve → higher PV.
        assert float(pv_lag1[0]) > float(pv_lag0[0])


# ---------------------------------------------------------------------------
# Tests — FX settlement lag
# ---------------------------------------------------------------------------

class TestFXSettlementLag:
    def test_zero_settlement_lag(self):
        """fx_settlement_lag=0 matches the closed-form T+0 formula."""
        inst = make_instrument(fx_settlement_lag=0)
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = 1.0
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_for = np.exp(-FOR_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected = (
            (FWD_PRICE - STRIKE_USD) * NOTIONAL * fx_fwd * df_mm / FX_SPOT
        )
        npt.assert_allclose(pv, expected, rtol=1e-6)

    def test_settlement_lag_changes_pv(self):
        """A non-zero FX settlement lag produces a different (small) PV shift."""
        ms = make_market_state()
        pv_no_lag = make_instrument(fx_settlement_lag=0).scenario_npvs(
            VAL_DATE, ms,
        )
        pv_lag2 = make_instrument(fx_settlement_lag=2).scenario_npvs(
            VAL_DATE, ms,
        )

        # Values should differ (settlement lag adjusts the FX forward basis)
        # but the difference should be small (T_s ≈ 2/365 ≈ 0.005 yr)
        diff = np.abs(pv_lag2 - pv_no_lag)
        assert np.all(diff > 0.0)           # there is some difference
        assert np.all(diff < 1.0)           # but it is small relative to ~480


# ---------------------------------------------------------------------------
# Tests — averaging_dates / payment_date generation
# ---------------------------------------------------------------------------

class TestDateGeneration:
    def test_averaging_dates_are_business_days_only(self):
        """All pre-computed averaging dates should be USD business days."""
        from utils.ql_helpers import CALENDARS, to_ql_date

        inst = make_instrument(
            averaging_start=date(2025, 1, 2),
            maturity_date=date(2025, 2, 28),
        )
        cal = CALENDARS["USD"]
        for d in inst._averaging_dates:
            assert cal.isBusinessDay(to_ql_date(d)), (
                f"{d} is not a USD business day"
            )

    def test_payment_date_is_after_maturity(self):
        """payment_date >= maturity_date when payment_lag >= 0."""
        inst = make_instrument(
            maturity_date=date(2026, 1, 2),
            payment_lag=2,
        )
        assert inst._payment_date >= date(2026, 1, 2)

    def test_single_day_averaging_window(self):
        """averaging_start == maturity_date gives exactly one averaging date."""
        inst = make_instrument(
            averaging_start=date(2026, 1, 2),
            maturity_date=date(2026, 1, 2),
        )
        assert len(inst._averaging_dates) == 1
        assert inst._averaging_dates[0] == date(2026, 1, 2)


# ---------------------------------------------------------------------------
# Tests — forward price curve extrapolation
# ---------------------------------------------------------------------------

# Sloped pillar prices: [75, 77, 80, 83, 88] at TENORS = [0.25, 0.5, 1.0, 2.0, 5.0]
# Last-segment slope: (88 - 83) / (5.0 - 2.0) = 5/3 per year
_SLOPED_PRICES = np.array([75.0, 77.0, 80.0, 83.0, 88.0], dtype=np.float64)
_LAST_SLOPE = (_SLOPED_PRICES[-1] - _SLOPED_PRICES[-2]) / (TENORS[-1] - TENORS[-2])


def _sloped_market_state() -> dict:
    ms = make_market_state()
    ms["FWD"] = CurveSlice(
        values=np.tile(_SLOPED_PRICES, (N_PATHS, 1)),
        tenors=FWD_TENORS,
    )
    return ms


def _far_instrument(**kwargs) -> CommodityAverageForward:
    """Single-date instrument with averaging date beyond last pillar (T > 5)."""
    far_date = date(2031, 1, 2)  # ~6 yr from VAL_DATE
    defaults = dict(
        name="TEST_EXTRAP",
        averaging_start=far_date,
        maturity_date=far_date,
        strike=STRIKE_USD,
        notional=NOTIONAL,
        is_composite=False,
        forward_curve_name="FWD",
        fx_spot_name="FX",
        domestic_curve_name="DOM",
        foreign_curve_name="FOR",
        money_market_curve_name="MM",
        averaging_calendar="USD",
        payment_calendar="USD",
        lag_calendar="USD",
        pricing_lag=0,
        payment_lag=0,
        fx_settlement_lag=0,
    )
    defaults.update(kwargs)
    return CommodityAverageForward(**defaults)


class TestForwardExtrapolation:
    """Verify forward_price_interpolator extrapolation beyond pillar boundaries."""

    def _T(self, target_date: date) -> float:
        from utils.ql_helpers import DAY_COUNTERS, to_ql_date
        dc = DAY_COUNTERS["ACT/365"]
        return float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(target_date)))

    def test_linear_right_extrapolation_matches_formula(self):
        """Beyond last tenor, price = last_price + slope * (T - T_last)."""
        far_date = date(2031, 1, 2)
        inst = _far_instrument()
        ms = _sloped_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = self._T(far_date)
        expected_price = _SLOPED_PRICES[-1] + _LAST_SLOPE * (T - TENORS[-1])

        df_for = np.exp(-FOR_RATE * T)
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected_pv = (expected_price - STRIKE_USD) * NOTIONAL * fx_fwd * df_mm / FX_SPOT
        npt.assert_allclose(pv, expected_pv, rtol=1e-6)

    def test_linear_extrapolation_exceeds_flat_on_rising_curve(self):
        """Linear right-extrapolation yields a higher price than flat for a rising curve."""
        ms = _sloped_market_state()
        pv_linear = _far_instrument().scenario_npvs(VAL_DATE, ms)
        pv_flat = _far_instrument(
            forward_interpolator=linear_interpolator,
        ).scenario_npvs(VAL_DATE, ms)
        # Rising curve → linear extrapolation > last pillar price → higher PV
        assert np.all(pv_linear > pv_flat)

    def test_flat_right_extrapolation_with_linear_interpolator(self):
        """linear_interpolator holds the last pillar price past the last tenor."""
        far_date = date(2031, 1, 2)
        inst = _far_instrument(forward_interpolator=linear_interpolator)
        ms = _sloped_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = self._T(far_date)
        expected_price = _SLOPED_PRICES[-1]  # flat: last pillar

        df_for = np.exp(-FOR_RATE * T)
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected_pv = (expected_price - STRIKE_USD) * NOTIONAL * fx_fwd * df_mm / FX_SPOT
        npt.assert_allclose(pv, expected_pv, rtol=1e-6)

    def test_flat_left_extrapolation(self):
        """T before first pillar returns first pillar price (no left linear extrap)."""
        near_date = date(2025, 1, 10)  # T ≈ 8/365 ≈ 0.022 < TENORS[0]=0.25
        inst = CommodityAverageForward(
            name="TEST_LEFT",
            averaging_start=near_date,
            maturity_date=near_date,
            strike=STRIKE_USD,
            notional=NOTIONAL,
            is_composite=False,
            forward_curve_name="FWD",
            fx_spot_name="FX",
            domestic_curve_name="DOM",
            foreign_curve_name="FOR",
            money_market_curve_name="MM",
            averaging_calendar="USD",
            payment_calendar="USD",
            lag_calendar="USD",
            pricing_lag=0,
            payment_lag=0,
            fx_settlement_lag=0,
        )
        ms = _sloped_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = self._T(near_date)
        expected_price = _SLOPED_PRICES[0]  # flat left: first pillar = 75.0

        df_for = np.exp(-FOR_RATE * T)
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        expected_pv = (expected_price - STRIKE_USD) * NOTIONAL * fx_fwd * df_mm / FX_SPOT
        npt.assert_allclose(pv, expected_pv, rtol=1e-6)


# ---------------------------------------------------------------------------
# Tests — convert_then_average flag (composite contracts only)
# ---------------------------------------------------------------------------

# Use a ZAR strike that is at-the-money in USD terms so tests stay clean.
STRIKE_ZAR = STRIKE_USD * FX_SPOT  # 75 * 18 = 1350


def _composite_instrument(
    averaging_start: date = AVG_DATE_1Y,
    maturity_date: date = AVG_DATE_1Y,
    convert_then_average: bool = False,
    direction: int = 1,
    pricing_lag: int = 0,
    payment_lag: int = 0,
    fx_settlement_lag: int = 0,
) -> CommodityAverageForward:
    """Helper: composite instrument with optional convert_then_average."""
    return CommodityAverageForward(
        name="TEST_COMP",
        averaging_start=averaging_start,
        maturity_date=maturity_date,
        strike=STRIKE_ZAR,
        notional=NOTIONAL,
        is_composite=True,
        convert_then_average=convert_then_average,
        forward_curve_name="FWD",
        fx_spot_name="FX",
        domestic_curve_name="DOM",
        foreign_curve_name="FOR",
        money_market_curve_name="MM",
        averaging_calendar="USD",
        payment_calendar="USD",
        lag_calendar="USD",
        direction=direction,
        forward_interpolator=forward_price_interpolator,
        domestic_interpolator=linear_interpolator,
        foreign_interpolator=linear_interpolator,
        money_market_interpolator=linear_interpolator,
        pricing_lag=pricing_lag,
        payment_lag=payment_lag,
        fx_settlement_lag=fx_settlement_lag,
    )


class TestConvertThenAverage:
    """Tests for composite CTA vs ATC pricing."""

    def _T(self, d: date) -> float:
        from utils.ql_helpers import DAY_COUNTERS, to_ql_date
        dc = DAY_COUNTERS["ACT/365"]
        return float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(d)))

    def test_single_date_cta_equals_atc(self):
        """With one future averaging date and payment_lag=0, CTA == ATC."""
        ms = make_market_state()
        atc = _composite_instrument(convert_then_average=False)
        cta = _composite_instrument(convert_then_average=True)
        npt.assert_allclose(
            atc.scenario_npvs(VAL_DATE, ms),
            cta.scenario_npvs(VAL_DATE, ms),
            rtol=1e-8,
        )

    def test_flat_fx_curve_cta_equals_atc(self):
        """When dom_rate == for_rate, FX forward is flat → CTA == ATC."""
        start = date(2025, 12, 1)
        end = AVG_DATE_1Y
        # dom_rate == for_rate → FX_fwd(T) = FX_spot for all T
        ms = make_market_state(dom_rate=FOR_RATE, mm_rate=FOR_RATE)

        atc = _composite_instrument(
            averaging_start=start, maturity_date=end, convert_then_average=False,
        )
        cta = _composite_instrument(
            averaging_start=start, maturity_date=end, convert_then_average=True,
        )
        npt.assert_allclose(
            atc.scenario_npvs(VAL_DATE, ms),
            cta.scenario_npvs(VAL_DATE, ms),
            rtol=1e-8,
        )

    def test_multi_date_sloped_both_cta_differs_from_atc(self):
        """With sloped commodity AND sloped FX, CTA != ATC.

        ATC = mean(F_i) × mean(FX_i)
        CTA = mean(F_i × FX_i) = ATC + cov(F_i, FX_i)

        Both commodity prices and FX forwards increase with tenor here,
        so the covariance is positive → CTA > ATC.
        """
        start = date(2025, 3, 3)
        end = AVG_DATE_1Y
        # dom_rate > for_rate → FX_fwd(T) rises over time
        ms = make_market_state(dom_rate=0.08, for_rate=0.02, mm_rate=0.08)
        # Commodity prices also rise with tenor (use _SLOPED_PRICES)
        ms["FWD"] = CurveSlice(
            values=np.tile(_SLOPED_PRICES, (N_PATHS, 1)),
            tenors=FWD_TENORS,
        )

        atc = _composite_instrument(
            averaging_start=start, maturity_date=end, convert_then_average=False,
        )
        cta = _composite_instrument(
            averaging_start=start, maturity_date=end, convert_then_average=True,
        )
        pv_atc = atc.scenario_npvs(VAL_DATE, ms)
        pv_cta = cta.scenario_npvs(VAL_DATE, ms)

        # CTA > ATC because cov(F_i, FX_i) > 0 (both slope upward)
        assert np.all(pv_cta > pv_atc)

    def test_flat_commodity_atc_equals_cta(self):
        """When commodity prices are flat, cov(F_i, FX_i) = 0 → ATC == CTA."""
        start = date(2025, 3, 3)
        end = AVG_DATE_1Y
        # Sloped FX but flat commodity (FWD_PRICE constant for all tenors)
        ms = make_market_state(dom_rate=0.08, for_rate=0.02, mm_rate=0.08)

        atc = _composite_instrument(
            averaging_start=start, maturity_date=end, convert_then_average=False,
        )
        cta = _composite_instrument(
            averaging_start=start, maturity_date=end, convert_then_average=True,
        )
        npt.assert_allclose(
            atc.scenario_npvs(VAL_DATE, ms),
            cta.scenario_npvs(VAL_DATE, ms),
            rtol=1e-8,
        )

    def test_cta_analytical_single_date(self):
        """CTA PV matches closed-form for a single future date."""
        inst = _composite_instrument(convert_then_average=True)
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms)

        T = self._T(AVG_DATE_1Y)   # T_pay == T_avg (payment_lag=0)
        df_dom = np.exp(-EFF_DOM_RATE * T)
        df_for = np.exp(-FOR_RATE * T)
        df_mm = np.exp(-MM_RATE * T)
        fx_fwd = FX_SPOT * df_for / df_dom
        avg_zar = FWD_PRICE * fx_fwd
        expected = (avg_zar - STRIKE_ZAR) * NOTIONAL * df_mm

        npt.assert_allclose(pv, expected, rtol=1e-6)

    def test_cta_uses_historical_fx_fixings(self):
        """Past FX fixings keyed (fx_spot_name, date) are used in CTA."""
        obs_date = date(2024, 12, 31)
        inst = _composite_instrument(
            averaging_start=obs_date,
            maturity_date=obs_date,
            convert_then_average=True,
            payment_lag=2,
        )

        fwd_fix = 82.0
        fx_fix = 17.5   # historical FX rate differs from FX_SPOT=18
        fixings = {
            ("FWD", obs_date): np.full(N_PATHS, fwd_fix),
            ("FX",  obs_date): np.full(N_PATHS, fx_fix),
        }
        ms = make_market_state()
        pv = inst.scenario_npvs(VAL_DATE, ms, fixings=fixings)

        from utils.ql_helpers import DAY_COUNTERS, to_ql_date
        dc = DAY_COUNTERS["ACT/365"]
        T_pay = float(dc.yearFraction(to_ql_date(VAL_DATE), to_ql_date(inst._payment_date)))
        df_mm = np.exp(-MM_RATE * T_pay)
        expected = (fwd_fix * fx_fix - STRIKE_ZAR) * NOTIONAL * df_mm
        npt.assert_allclose(pv, expected, rtol=1e-6)

    def test_cta_missing_fx_fixing_falls_back_to_spot(self):
        """When past FX fixing is absent, current FX spot is used as fallback."""
        obs_date = date(2024, 12, 31)
        inst = _composite_instrument(
            averaging_start=obs_date,
            maturity_date=obs_date,
            convert_then_average=True,
            payment_lag=2,
        )

        fwd_fix = 82.0
        # No FX fixing: fallback = FX_SPOT
        fixings_no_fx = {("FWD", obs_date): np.full(N_PATHS, fwd_fix)}
        # FX fixing explicitly set to FX_SPOT → should produce same result
        fixings_spot = {
            ("FWD", obs_date): np.full(N_PATHS, fwd_fix),
            ("FX",  obs_date): np.full(N_PATHS, FX_SPOT),
        }
        ms = make_market_state()
        pv_fallback = inst.scenario_npvs(VAL_DATE, ms, fixings=fixings_no_fx)
        pv_explicit = inst.scenario_npvs(VAL_DATE, ms, fixings=fixings_spot)

        npt.assert_allclose(pv_fallback, pv_explicit, rtol=1e-8)

    def test_fx_settlement_lag_cancels_for_flat_curves(self):
        """Applying lag to both val_date and avg_date leaves the FX forward
        unchanged for flat continuously-compounded rate curves.

        FX_fwd([t+lag, T+lag]) = FX_spot × exp((r_d − r_f) × ((T+lag) − lag))
                                = FX_spot × exp((r_d − r_f) × T)
                                = FX_fwd([t, T])

        The old code computed FX_fwd([t+lag, T]) — a spurious lag-dependent
        result.  The new code correctly computes FX_fwd([t+lag, T+lag]),
        which is invariant to the lag under flat curves.
        """
        inst_lag0 = _composite_instrument(
            convert_then_average=True, fx_settlement_lag=0,
        )
        inst_lag2 = _composite_instrument(
            convert_then_average=True, fx_settlement_lag=2,
        )
        ms = make_market_state(dom_rate=0.08, for_rate=0.02, mm_rate=0.08)

        # The two must be identical: lag cancels when applied to both endpoints.
        npt.assert_allclose(
            inst_lag0.scenario_npvs(VAL_DATE, ms),
            inst_lag2.scenario_npvs(VAL_DATE, ms),
            rtol=1e-8,
        )

    def test_fx_settlement_dates_precomputed_correctly(self):
        """_fx_settlement_dates is avg_date advanced by fx_settlement_lag BDs."""
        from utils.ql_helpers import advance_business_days
        inst = _composite_instrument(
            fx_settlement_lag=2,
        )
        for avg_date, fx_settle_date in zip(
            inst._averaging_dates, inst._fx_settlement_dates,
        ):
            expected = advance_business_days(avg_date, 2, "USD")
            assert fx_settle_date == expected, (
                f"avg_date={avg_date}, expected {expected}, got {fx_settle_date}"
            )

    def test_zero_fx_settlement_lag_unchanged(self):
        """fx_settlement_lag=0 leaves _fx_settlement_dates equal to _averaging_dates."""
        inst = _composite_instrument(fx_settlement_lag=0)
        assert inst._fx_settlement_dates == inst._averaging_dates


# ---------------------------------------------------------------------------
# Tests — _compute_fixing_for_date (per-date historical state stamping)
# ---------------------------------------------------------------------------

class TestComputeFixingForDate:
    """_compute_fixing_for_date uses the supplied market_state, not a fallback."""

    def test_commodity_price_from_provided_market_state(self):
        """Forward price comes from the given market_state, not a default."""
        avg_date = date(2025, 1, 31)
        inst = make_instrument(
            averaging_start=avg_date, maturity_date=avg_date,
            pricing_lag=0, payment_lag=0,
        )
        ms_90 = make_market_state(fwd_price=90.0)
        result = inst._compute_fixing_for_date(
            avg_date, avg_date, avg_date, ms_90, scenario_date=date(2025, 1, 1),
        )
        npt.assert_allclose(result[(inst.forward_curve_name, avg_date)], 90.0)

    def test_different_market_states_give_different_fixings(self):
        """Two market states at the same scenario_date produce different fixings."""
        avg_date = date(2025, 1, 31)
        inst = make_instrument(
            averaging_start=avg_date, maturity_date=avg_date, pricing_lag=0,
        )
        scenario_date = date(2025, 1, 1)
        f_low = inst._compute_fixing_for_date(
            avg_date, avg_date, avg_date,
            make_market_state(fwd_price=70.0), scenario_date,
        )[(inst.forward_curve_name, avg_date)]
        f_high = inst._compute_fixing_for_date(
            avg_date, avg_date, avg_date,
            make_market_state(fwd_price=90.0), scenario_date,
        )[(inst.forward_curve_name, avg_date)]
        assert np.all(f_high > f_low)

    def test_composite_fx_equals_spot_when_scenario_equals_avg(self):
        """When scenario_date == avg_date and fx_settlement_lag=0, FX fixing = spot."""
        avg_date = date(2025, 1, 31)
        inst = CommodityAverageForward(
            name="T", averaging_start=avg_date, maturity_date=avg_date,
            strike=STRIKE_USD * FX_SPOT, notional=NOTIONAL, is_composite=True,
            forward_curve_name="FWD", fx_spot_name="FX",
            domestic_curve_name="DOM", foreign_curve_name="FOR",
            money_market_curve_name="MM",
            averaging_calendar="USD", payment_calendar="USD", lag_calendar="USD",
            pricing_lag=0, payment_lag=0, fx_settlement_lag=0,
        )
        ms = make_market_state(fx_spot=17.5)
        result = inst._compute_fixing_for_date(
            avg_date, avg_date, avg_date, ms, scenario_date=avg_date,
        )
        npt.assert_allclose(result[(inst.fx_spot_name, avg_date)], 17.5)

    def test_composite_fx_is_forward_when_scenario_before_avg(self):
        """When scenario_date < avg_date, FX fixing is the forward to avg_date."""
        scenario_date = date(2025, 1, 1)
        avg_date = date(2025, 7, 1)    # ~6 months ahead
        inst = CommodityAverageForward(
            name="T", averaging_start=avg_date, maturity_date=avg_date,
            strike=STRIKE_USD * FX_SPOT, notional=NOTIONAL, is_composite=True,
            forward_curve_name="FWD", fx_spot_name="FX",
            domestic_curve_name="DOM", foreign_curve_name="FOR",
            money_market_curve_name="MM",
            averaging_calendar="USD", payment_calendar="USD", lag_calendar="USD",
            pricing_lag=0, payment_lag=0, fx_settlement_lag=0,
        )
        ms = make_market_state(fx_spot=FX_SPOT, dom_rate=DOM_RATE,
                               for_rate=FOR_RATE, mm_rate=MM_RATE)
        result = inst._compute_fixing_for_date(
            avg_date, avg_date, avg_date, ms, scenario_date=scenario_date,
        )
        fx_rate = result[(inst.fx_spot_name, avg_date)]

        from utils.ql_helpers import DAY_COUNTERS, to_ql_date
        dc = DAY_COUNTERS["ACT/365"]
        T_fix = float(dc.yearFraction(to_ql_date(scenario_date), to_ql_date(avg_date)))
        eff_dom = MM_RATE + DOM_RATE
        expected = FX_SPOT * np.exp(-FOR_RATE * T_fix) / np.exp(-eff_dom * T_fix)
        npt.assert_allclose(fx_rate, expected, rtol=1e-5)

    def test_get_commodity_fixing_schedule_length(self):
        """get_commodity_fixing_schedule returns one entry per averaging date."""
        inst = make_instrument(
            averaging_start=date(2025, 1, 2),
            maturity_date=date(2025, 1, 31),
        )
        schedule = inst.get_commodity_fixing_schedule()
        assert len(schedule) == len(inst._averaging_dates)
        for (a, p, f), a2, p2, f2 in zip(
            schedule, inst._averaging_dates,
            inst._pricing_dates, inst._fx_settlement_dates,
        ):
            assert a == a2 and p == p2 and f == f2


# ---------------------------------------------------------------------------
# Tests — ExposureEngine interpolates scenario state at each fixing date
# ---------------------------------------------------------------------------

class TestEngineUsesHistoricalState:
    """_build_commodity_fixings linearly interpolates the scenario state at each
    pricing_date, mirroring RiskFlow's gather_scenario_interp pattern."""

    def _make_engine_and_states(self):
        """Two-step cube: Jan 2 fwd=70, Feb 3 fwd=90.  Averaging date Jan 15."""
        from market_data.scenario_cube import ScenarioCubeBuilder
        from pricing.exposure_engine import ExposureEngine

        s0 = date(2025, 1, 2)   # Thursday (business day)
        s1 = date(2025, 2, 3)   # Monday  (business day)
        scenario_dates = [s0, s1]

        n_t = len(FWD_TENORS)
        fwd_data = np.stack([
            np.full((N_PATHS, n_t), 70.0),
            np.full((N_PATHS, n_t), 90.0),
        ], axis=1)

        flat_data = np.zeros((N_PATHS, 2, len(TENORS)))

        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=s0)
        builder.add_curve_factor("FWD", fwd_data, FWD_TENORS,
                                 dates=tuple(scenario_dates))
        for name in ("DOM", "FOR", "MM"):
            builder.add_curve_factor(name, flat_data, TENORS,
                                     dates=tuple(scenario_dates))
        fx_data = np.zeros((N_PATHS, 2))
        builder.add_factor("FX", fx_data, dates=tuple(scenario_dates))
        cube = builder.build()

        ms0 = make_market_state(fwd_price=70.0)
        ms1 = make_market_state(fwd_price=90.0)
        all_states = [ms0, ms1]

        engine = ExposureEngine(cube)
        return engine, scenario_dates, all_states

    def test_fixing_uses_interpolated_scenario_state(self):
        """avg_date Jan 15 falls between Jan 2 and Feb 3 scenario dates.
        The fixing must be linearly interpolated between the two states.

        span = (Feb-3 - Jan-2).days = 32
        alpha = (Jan-15 - Jan-2).days / 32 = 13/32 = 0.40625
        fwd = 70 + 0.40625 * (90 - 70) = 78.125
        """
        engine, scenario_dates, all_states = self._make_engine_and_states()
        avg_date = date(2025, 1, 15)
        inst = make_instrument(
            averaging_start=avg_date, maturity_date=avg_date,
            pricing_lag=0, payment_lag=0,
        )

        cache: dict[int, dict] = {}
        result = engine._build_commodity_fixings(
            inst, date(2025, 2, 3), cache, scenario_dates, all_states,
        )
        key = (inst.forward_curve_name, avg_date)
        assert key in result
        # Interpolated: 70 + (13/32) * (90 - 70) = 78.125
        expected = 70.0 + (13 / 32) * (90.0 - 70.0)
        npt.assert_allclose(result[key], expected, rtol=1e-6)

    def test_fixing_locked_on_first_crossing_never_changes(self):
        """Once stamped, the fixing is immutable across subsequent sim steps."""
        engine, scenario_dates, all_states = self._make_engine_and_states()
        avg_date = date(2025, 1, 15)
        inst = make_instrument(
            averaging_start=avg_date, maturity_date=avg_date,
            pricing_lag=0, payment_lag=0,
        )

        cache: dict[int, dict] = {}
        # First crossing at Feb 3
        result1 = engine._build_commodity_fixings(
            inst, date(2025, 2, 3), cache, scenario_dates, all_states,
        )
        val_at_first = result1[(inst.forward_curve_name, avg_date)].copy()

        # Second call at same sim_date (or later) — value must not change
        result2 = engine._build_commodity_fixings(
            inst, date(2025, 2, 3), cache, scenario_dates, all_states,
        )
        npt.assert_array_equal(result2[(inst.forward_curve_name, avg_date)],
                               val_at_first)

    def test_avg_date_on_scenario_date_uses_that_state(self):
        """When avg_date == a scenario date, that scenario's state is used."""
        engine, scenario_dates, all_states = self._make_engine_and_states()
        # avg_date = Feb 3 == scenario_dates[1] (Monday), state at Feb 3 has fwd=90
        avg_date = date(2025, 2, 3)
        inst = make_instrument(
            averaging_start=avg_date, maturity_date=avg_date,
            pricing_lag=0, payment_lag=0,
        )

        cache: dict[int, dict] = {}
        result = engine._build_commodity_fixings(
            inst, date(2025, 2, 3), cache, scenario_dates, all_states,
        )
        npt.assert_allclose(result[(inst.forward_curve_name, avg_date)],
                            90.0, rtol=1e-6)

    def test_pricing_date_boundary_uses_later_state(self):
        """When avg_date is before a scenario date but pricing_date falls on it,
        the fixing must use the pricing_date's scenario state (fwd=90), not
        the stale prior state (fwd=70).

        This verifies the bisect uses pricing_date, not avg_date.
        Setup:  scenario_dates = [Jan 2, Jan 15, Feb 3]
                avg_date = Jan 14 (between Jan 2 and Jan 15)
                pricing_lag = 1 BD → pricing_date = Jan 15 (= scenario_dates[1])
        Old bisect (on avg_date Jan 14)  → Jan 2 state  → fwd = 70  (wrong)
        New bisect (on pricing_date Jan 15) → Jan 15 state → fwd = 85 (correct)
        """
        from market_data.scenario_cube import ScenarioCubeBuilder
        from pricing.exposure_engine import ExposureEngine

        s0 = date(2025, 1, 2)   # Thursday
        s1 = date(2025, 1, 15)  # Wednesday — pricing_date will land here
        s2 = date(2025, 2, 3)   # Monday

        scenario_dates = [s0, s1, s2]
        n_t = len(FWD_TENORS)

        fwd_data = np.stack([
            np.full((N_PATHS, n_t), 70.0),   # Jan 2 state
            np.full((N_PATHS, n_t), 85.0),   # Jan 15 state
            np.full((N_PATHS, n_t), 90.0),   # Feb 3 state
        ], axis=1)
        flat_data = np.zeros((N_PATHS, 3, len(TENORS)))
        fx_data = np.zeros((N_PATHS, 3))

        builder = ScenarioCubeBuilder(n_paths=N_PATHS, valuation_date=s0)
        builder.add_curve_factor("FWD", fwd_data, FWD_TENORS,
                                 dates=tuple(scenario_dates))
        for name in ("DOM", "FOR", "MM"):
            builder.add_curve_factor(name, flat_data, TENORS,
                                     dates=tuple(scenario_dates))
        builder.add_factor("FX", fx_data, dates=tuple(scenario_dates))
        cube = builder.build()
        engine = ExposureEngine(cube)

        all_states = [
            make_market_state(fwd_price=70.0),
            make_market_state(fwd_price=85.0),
            make_market_state(fwd_price=90.0),
        ]

        # avg_date = Jan 14 (between Jan 2 and Jan 15); pricing_lag=1 gives
        # pricing_date = Jan 15 (Wednesday → Wednesday + 1 BD = Thursday?).
        # Use pricing_lag=0 and move avg_date to Jan 14, pricing_date = Jan 14.
        # For the straddling test we need pricing_date == Jan 15, so
        # construct _pricing_dates manually via pricing_lag=1:
        #   avg_date=Jan 14 (Tue) + 1 BD = Jan 15 (Wed) ✓
        avg_date = date(2025, 1, 14)  # Tuesday — between Jan 2 and Jan 15
        inst = CommodityAverageForward(
            name="BOUNDARY",
            averaging_start=avg_date,
            maturity_date=avg_date,
            strike=STRIKE_USD,
            notional=NOTIONAL,
            is_composite=False,
            forward_curve_name="FWD",
            fx_spot_name="FX",
            domestic_curve_name="DOM",
            foreign_curve_name="FOR",
            money_market_curve_name="MM",
            averaging_calendar="USD",
            payment_calendar="USD",
            lag_calendar="USD",
            pricing_lag=1,   # pricing_date = Jan 14 + 1 BD = Jan 15
            payment_lag=0,
            fx_settlement_lag=0,
        )
        assert inst._pricing_dates[0] == s1, (
            f"Expected pricing_date={s1}, got {inst._pricing_dates[0]}"
        )

        cache: dict[int, dict] = {}
        # Discovered at the Jan 15 step (pricing_date has just passed)
        result = engine._build_commodity_fixings(
            inst, s1, cache, scenario_dates, all_states,
        )
        key = (inst.forward_curve_name, avg_date)
        assert key in result
        # Bisect on pricing_date=Jan 15 → Jan 15 state (fwd=85), not Jan 2 (fwd=70)
        npt.assert_allclose(result[key], 85.0, rtol=1e-6)
