from __future__ import annotations

import numpy as np

from market_data.yield_curve import YieldCurve


def fx_forward_price(
    fx_spot: np.ndarray,
    forecast_curve: YieldCurve,
    domestic_discount_curve: YieldCurve,
    foreign_discount_curve: YieldCurve,
    T: float,
    foreign_forecast_curve: YieldCurve | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute the FX forward price using basis-adjusted covered interest parity.

    Parameters
    ----------
    fx_spot : np.ndarray
        Spot FX rate (domestic per foreign), shape (n_paths,).
    forecast_curve : YieldCurve
        Domestic basis / forecast curve (e.g. ZAR-USD-BASIS for EURZAR).
    domestic_discount_curve : YieldCurve
        Domestic discount curve.
    foreign_discount_curve : YieldCurve
        Foreign discount curve.
    T : float
        Time to maturity in years.
    foreign_forecast_curve : YieldCurve, optional
        Foreign basis / forecast curve (e.g. EUR-USD-BASIS for EURZAR).
        When omitted its discount factor defaults to 1.

    Returns
    -------
    forward_fx : np.ndarray
        FX forward price, shape (n_paths,).
    df_dom : np.ndarray
        Domestic discount factor = exp(-r_dom * T), shape (n_paths,).
    """
    df_dom_forecast = forecast_curve.discount_factor(T)
    df_dom = domestic_discount_curve.discount_factor(T)
    df_for = (
        foreign_discount_curve.discount_factor(T)
        if foreign_discount_curve is not None
        else np.ones(df_dom.shape)
    )
    df_for_forecast = (
        foreign_forecast_curve.discount_factor(T)
        if foreign_forecast_curve is not None
        else 1.0
    )

    forward_fx = fx_spot * (df_for * df_for_forecast) / (df_dom * df_dom_forecast)

    return forward_fx, df_dom