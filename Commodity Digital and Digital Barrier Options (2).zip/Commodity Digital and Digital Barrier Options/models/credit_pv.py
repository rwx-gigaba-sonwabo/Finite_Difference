from __future__ import annotations

from datetime import date, timedelta
from typing import Callable

import numpy as np
import QuantLib as ql

from utils.ql_helpers import to_ql_date
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, RiskFactorSlice
from models.cashflow_pv import (
    filter_future_periods,
    compute_period_year_fractions,
    apply_fixings,
)


# ---------------------------------------------------------------------------
# Shared credit helpers
# ---------------------------------------------------------------------------

def compute_credit_quantities(
    t_starts: np.ndarray,
    t_ends: np.ndarray,
    discount_curve: YieldCurve,
    credit_curve: YieldCurve,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Compute discount factors, survival probabilities and default probs.

    Parameters
    ----------
    t_starts : np.ndarray, shape (n_periods,)
        Year fractions from val_date to period starts.
    t_ends : np.ndarray, shape (n_periods,)
        Year fractions from val_date to period ends.
    discount_curve : YieldCurve
        Discount curve for DF computation.
    credit_curve : YieldCurve
        Credit (hazard rate) curve for survival probabilities.

    Returns
    -------
    df_starts : (n_paths, n_periods)
    df_ends : (n_paths, n_periods)
    df_mids : (n_paths, n_periods)
    surv_starts : (n_paths, n_periods)
    surv_ends : (n_paths, n_periods)
    default_probs : (n_paths, n_periods)
    """
    df_starts = discount_curve.discount_factor(t_starts)
    df_ends = discount_curve.discount_factor(t_ends)
    df_mids = 0.5 * (df_starts + df_ends)

    # For the first period, if t_start <= 0 (period started before val_date),
    # survival to start is 1.0 by convention (already conditioned on survival).
    surv_starts = np.where(
        t_starts > 0,
        credit_curve.discount_factor(np.maximum(t_starts, 1e-10)),
        1.0,
    )
    surv_ends = credit_curve.discount_factor(t_ends)
    default_probs = surv_starts - surv_ends

    return df_starts, df_ends, df_mids, surv_starts, surv_ends, default_probs


def apply_premium_extra_day(
    accruals: np.ndarray,
    future: list[tuple[date, date, date, float]],
    day_counter: ql.DayCounter,
) -> tuple[np.ndarray, list[date]]:
    """Optionally add one extra day to the final premium period.

    Returns modified (prem_accruals, prem_end_dates).
    """
    prem_accruals = accruals.copy()
    prem_end_dates = [e for _, e, _, _ in future]
    if len(future) > 0:
        last_end = future[-1][1]
        ql_last = to_ql_date(last_end)
        next_day = to_ql_date(last_end + timedelta(days=1))
        extra = day_counter.yearFraction(ql_last, next_day)
        prem_accruals[-1] += extra
        prem_end_dates[-1] = last_end + timedelta(days=1)
    return prem_accruals, prem_end_dates


# ---------------------------------------------------------------------------
# Default / protection leg
# ---------------------------------------------------------------------------

def pv_defaultable_leg(
    df_mids: np.ndarray,
    default_probs: np.ndarray,
    recovery_rate: float,
) -> np.ndarray:
    """PV of the protection (default) leg of a CDS.

    Protection Leg PV = (1 - R) * Σ DF_mid_i * (S(t_start_i) - S(t_end_i))

    Parameters
    ----------
    df_mids : np.ndarray, shape (n_paths, n_periods)
        Midpoint discount factors.
    default_probs : np.ndarray, shape (n_paths, n_periods)
        Probability of default in each period.
    recovery_rate : float
        Recovery rate assumption.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        PV of the protection leg (unit notional).
    """
    return (1.0 - recovery_rate) * np.sum(df_mids * default_probs, axis=1)


# ---------------------------------------------------------------------------
# Credit-risky cashflow (premium) leg
# ---------------------------------------------------------------------------

def pv_credit_risky_cashflow_leg(
    future: list[tuple[date, date, date, float]],
    t_starts: np.ndarray,
    t_ends: np.ndarray,
    accruals: np.ndarray,
    df_ends: np.ndarray,
    df_mids: np.ndarray,
    surv_ends: np.ndarray,
    default_probs: np.ndarray,
    n_paths: int,
    coupon: float,
    floating_curve_name: str | None = None,
    market_state: dict[str, RiskFactorSlice] | None = None,
    interpolator: Callable | None = None,
    fixings: dict[tuple[str, date], np.ndarray] | None = None,
    premium_extra_day: bool = False,
    day_counter: ql.DayCounter | None = None,
) -> np.ndarray:
    """PV of a credit-risky cashflow (premium) leg.

    Handles both fixed and floating coupon CDS premium legs.

    Premium Leg PV =
        Σ coupon_i * accrual_i * DF(t_end_i) * S(t_end_i)          [scheduled]
      + Σ coupon_i * (accrual_i / 2) * DF_mid_i * (S_start - S_end) [accrued on default]

    Parameters
    ----------
    future : list of (start, end, accrual)
        Future schedule periods.
    t_starts, t_ends : np.ndarray, shape (n_periods,)
        Year fractions to period boundaries.
    accruals : np.ndarray, shape (n_periods,)
        Accrual fractions per period.
    df_ends : np.ndarray, shape (n_paths, n_periods)
        Discount factors at period ends.
    df_mids : np.ndarray, shape (n_paths, n_periods)
        Midpoint discount factors.
    surv_ends : np.ndarray, shape (n_paths, n_periods)
        Survival probabilities at period ends.
    default_probs : np.ndarray, shape (n_paths, n_periods)
        Default probabilities per period.
    n_paths : int
        Number of paths.
    coupon : float
        Fixed coupon rate, or spread added to floating rate.
    floating_curve_name : str or None
        If not None, the premium leg uses floating rates from this curve.
    market_state : dict or None
        Market state (required for floating legs).
    interpolator : callable or None
        Interpolator factory (required for floating legs).
    fixings : dict or None
        Fixings keyed by ``(curve_name, period_start)``.
    premium_extra_day : bool
        Whether to add one extra day to the final premium period accrual.
    day_counter : ql.DayCounter or None
        Day counter (required when premium_extra_day is True).

    Returns
    -------
    np.ndarray, shape (n_paths,)
        PV of the premium leg (unit notional).
    """
    # Optionally adjust accruals for extra day
    if premium_extra_day and day_counter is not None:
        prem_accruals, _ = apply_premium_extra_day(accruals, future, day_counter)
    else:
        prem_accruals = accruals

    if floating_curve_name is not None:
        # Floating coupon
        fwd_slice: CurveSlice = market_state[floating_curve_name]
        fwd_curve = YieldCurve(
            year_fracs=fwd_slice.tenors,
            rates=fwd_slice.values,
            interpolator=interpolator,
        )
        coupon_rates = fwd_curve.forward_rate(t_starts, t_ends)  # (n_paths, n_periods)

        coupon_rates = apply_fixings(
            coupon_rates, future, floating_curve_name, fixings,
        )

        coupon_rates = coupon_rates + coupon  # coupon acts as spread

        # scheduled: Σ rate_i * accrual_i * DF_end_i * S_end_i
        scheduled_pv = np.sum(
            coupon_rates * prem_accruals * df_ends * surv_ends, axis=1
        )
        # accrued on default: Σ (rate_i * accrual_i/2) * DF_mid_i * dS_i
        accrued_pv = np.sum(
            coupon_rates * (prem_accruals / 2.0) * df_mids * default_probs, axis=1
        )
    else:
        # Fixed coupon
        scheduled_pv = coupon * np.sum(
            prem_accruals * df_ends * surv_ends, axis=1
        )
        accrued_pv = coupon * np.sum(
            (prem_accruals / 2.0) * df_mids * default_probs, axis=1
        )

    return scheduled_pv + accrued_pv
