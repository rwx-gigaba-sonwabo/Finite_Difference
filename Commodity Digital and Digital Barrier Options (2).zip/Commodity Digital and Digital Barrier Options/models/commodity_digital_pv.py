from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from utils.maths import norm_cdf, norm_pdf

__all__ = [
    "black76_d1_d2",
    "black76_digital_price",
    "black76_digital_analytic_greeks",
    "skew_adjusted_digital_price",
    "implied_cost_of_carry",
    "barrier_touch_probability",
    "commodity_barrier_digital_price",
    "commodity_barrier_digital_analytic_greeks",
    "mc_digital_barrier_pv",
]


# ---------------------------------------------------------------------------
# European (cash-or-nothing / asset-or-nothing) commodity digital — Black-76
# ---------------------------------------------------------------------------
#
# Reference: "Commodity Digital and Digital Barrier Options in Front Arena -
# Development Document" (Nov 2025), Pricing Methodology section.
#
#   V = DF * N(phi * d2) * A          (cash-or-nothing)
#   d2 = [ln(F/K) - 0.5 * sigma^2 * T] / (sigma * sqrt(T))
#   phi = +1 for Call, -1 for Put
#
# Asset-or-nothing is the standard Black-76 complement (not spelled out in
# the document, added here for completeness since it was requested):
#
#   V = DF * N(phi * d1) * A          (asset-or-nothing, A = notional/quantity)
#   d1 = d2 + sigma * sqrt(T)


def black76_d1_d2(
    F: np.ndarray, K: float, vol: np.ndarray, T: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Black-76 d1, d2. Vol==0 is guarded (result unused where zero_vol applies)."""
    safe_vol = np.where(np.asarray(vol) == 0.0, 1.0, vol)
    safe_K = np.maximum(np.asarray(K, dtype=np.float64), 1e-12)
    sqrt_T = np.sqrt(T)
    d2 = (np.log(F / safe_K) - 0.5 * safe_vol ** 2 * T) / (safe_vol * sqrt_T)
    d1 = d2 + safe_vol * sqrt_T
    return d1, d2


def black76_digital_price(
    F: np.ndarray,
    K: float,
    vol: np.ndarray,
    df: np.ndarray,
    T: float,
    is_call: bool,
    digital_type: str = "cash",
    payout: float | np.ndarray = 1.0,
) -> np.ndarray:
    """Price a European commodity digital option under Black-76 on the forward.

    Parameters
    ----------
    F : np.ndarray, shape (n_paths,)
        Forward price of the commodity to the (spot-day adjusted) expiry.
    K : float
        Strike / event trigger level.
    vol : np.ndarray, shape (n_paths,)
        Black implied volatility.
    df : np.ndarray, shape (n_paths,)
        Discount factor to the settlement date.
    T : float
        Time to expiry in years (val_date -> maturity_date), must be >= 0.
    is_call : bool
        True: event is S_T >= K.  False: event is S_T <= K.
    digital_type : {"cash", "asset"}
        ``"cash"``  — pays a fixed cash amount ``payout`` if the event occurs
        (document's native product): ``V = DF * payout * N(phi*d2)``.
        ``"asset"`` — pays ``payout`` units of the underlying (valued at its
        forward price) if the event occurs: ``V = DF * payout * F * N(phi*d1)``.
    payout : float or np.ndarray
        Fixed cash amount (cash-or-nothing) or notional/quantity multiplier
        (asset-or-nothing).

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Present value per path.
    """
    phi = 1.0 if is_call else -1.0

    if T <= 0.0:
        # At/after expiry: the event has already resolved deterministically.
        hit = (F >= K) if is_call else (F <= K)
        payoff = np.where(hit, payout * (F if digital_type == "asset" else 1.0), 0.0)
        return df * payoff

    d1, d2 = black76_d1_d2(F, K, vol, T)
    zero_vol = np.asarray(vol) == 0.0

    if digital_type == "cash":
        price = df * payout * norm_cdf(phi * d2)
        intrinsic = df * payout * ((F >= K) if is_call else (F <= K)).astype(np.float64)
    elif digital_type == "asset":
        price = df * payout * F * norm_cdf(phi * d1)
        intrinsic = df * payout * F * ((F >= K) if is_call else (F <= K)).astype(np.float64)
    else:
        raise ValueError(f"digital_type must be 'cash' or 'asset', got {digital_type!r}")

    return np.where(zero_vol, intrinsic, price)


def black76_digital_analytic_greeks(
    F: np.ndarray,
    K: float,
    vol: np.ndarray,
    df: np.ndarray,
    T: float,
    is_call: bool,
    digital_type: str = "cash",
    payout: float | np.ndarray = 1.0,
    dF_dS: float | np.ndarray = 1.0,
) -> dict[str, np.ndarray]:
    """Closed-form Greeks for the European commodity digital (Black-76).

    Delta reproduces the document's stated formula exactly (with the
    call/put sign ``phi`` restored — required for a put to carry the
    opposite-sign delta of a call; the document's shorthand omits it):

        Delta = phi * DF * A * n(d2) / (F * sigma * sqrt(T)) * dF/dS0

    Vega reproduces the document's stated formula **literally**, as an
    unsigned magnitude approximation (the document defines it without a
    call/put sign):

        Vega  ~= DF * A * n(d2) * sqrt(T)

    This is *not* the exact analytic derivative (which is
    ``-phi * DF * A * n(d2) * d1 / sigma`` and does carry a call/put sign) —
    it is reproduced as-is because the document explicitly specifies it that
    way. Comparing it against the bump-and-reprice Vega is precisely the
    prudency check the model is designed to support.

    Gamma and Theta are not given explicit formulas in the document (only
    qualitative behaviour: "concentrate sharply near K as T decreases").
    The standard closed-form Black-76 digital completions are supplied here.
    Theta is the "model theta" — the sensitivity to T (val_date -> maturity)
    only, holding the discount curve fixed; it excludes discount-curve
    roll-down. Use bump-and-reprice (shift val_date by one day and re-price)
    for the full P&L theta including curve roll.

    For ``digital_type == "asset"`` the standard Black-76 asset-or-nothing
    closed-form Greeks are used (not covered by the document, added for
    completeness).

    Returns
    -------
    dict with keys "delta", "gamma", "vega", "theta" — each np.ndarray (n_paths,).
    """
    phi = 1.0 if is_call else -1.0
    A = payout

    if T <= 0.0:
        zeros = np.zeros_like(np.asarray(F, dtype=np.float64))
        return {"delta": zeros, "gamma": zeros, "vega": zeros, "theta": zeros}

    d1, d2 = black76_d1_d2(F, K, vol, T)
    n_d2 = norm_pdf(d2)
    n_d1 = norm_pdf(d1)
    sqrt_T = np.sqrt(T)
    safe_vol = np.where(np.asarray(vol) == 0.0, 1e-8, vol)
    safe_F = np.maximum(np.asarray(F, dtype=np.float64), 1e-12)
    safe_K = np.maximum(np.asarray(K, dtype=np.float64), 1e-12)

    if digital_type == "cash":
        delta = phi * df * A * n_d2 / (safe_F * safe_vol * sqrt_T) * dF_dS
        vega = df * A * n_d2 * sqrt_T  # document formula, literal (unsigned)
        gamma = -phi * df * A * n_d2 / (safe_F ** 2 * safe_vol * sqrt_T) \
            * (1.0 + d2 / (safe_vol * sqrt_T)) * dF_dS ** 2
        theta = df * A * n_d2 * (
            -np.log(safe_F / safe_K) / (2.0 * safe_vol * T * sqrt_T)
            - safe_vol / (4.0 * sqrt_T)
        )
    elif digital_type == "asset":
        delta = df * A * (norm_cdf(phi * d1) + phi * n_d1 / (safe_vol * sqrt_T)) * dF_dS
        gamma = df * A * phi * n_d1 / (safe_F * safe_vol * sqrt_T) \
            * (1.0 - d1 / (safe_vol * sqrt_T)) * dF_dS ** 2
        vega = df * A * safe_F * n_d1 * phi * (sqrt_T - d1 / safe_vol)
        d1_dT = (
            -np.log(safe_F / safe_K) / (2.0 * safe_vol * T * sqrt_T)
            - safe_vol / (4.0 * sqrt_T)
            + safe_vol / (2.0 * sqrt_T)
        )
        theta = df * A * safe_F * n_d1 * phi * d1_dT
    else:
        raise ValueError(f"digital_type must be 'cash' or 'asset', got {digital_type!r}")

    return {"delta": delta, "gamma": gamma, "vega": vega, "theta": theta}


# ---------------------------------------------------------------------------
# Skew-adjusted European digital — tight call/put-spread replication
# ---------------------------------------------------------------------------
#
# black76_digital_price above prices off a single (flat) vol at the strike,
# which is correct for the *level* of the smile but misses its *slope* --
# and a digital's fair value is exactly the strike-derivative of the vanilla
# price, so the slope term is first-order for a binary payoff (it is only a
# second-order convexity effect for vanilla options, which is why "just use
# vol-at-strike" is fine there but not for digitals).
#
# The standard, model-independent fix (the document's own "replication
# (tight call spreads)" language) is to differentiate the smile-consistent
# *vanilla* price curve C(K, sigma(K)) with respect to K directly:
#
#   Digital_call(K) = -dC/dK  ~= [C(K-h, sigma(K-h)) - C(K+h, sigma(K+h))] / (2h)
#   Digital_put(K)  =  dP/dK  ~= [P(K+h, sigma(K+h)) - P(K-h, sigma(K-h))] / (2h)
#
# which converges to black76_digital_price(..., vol=vol_fn(K)) exactly as
# h -> 0 when vol_fn is constant (flat smile) -- i.e. this is a strict
# generalisation of the flat-vol formula, not a different model.
#
# Asset-or-nothing reuses the exact put-call-style static replication
# identity (no extra strike bump needed, since it follows algebraically
# once the cash digital and the vanilla price at K are both known):
#
#   AssetDigitalCall(K) = C(K, sigma(K)) + K * CashDigitalCall(K)
#   AssetDigitalPut(K)  = K * CashDigitalPut(K) - P(K, sigma(K))


def skew_adjusted_digital_price(
    F: np.ndarray,
    K: float,
    vol_fn: Callable[[float], float | np.ndarray],
    df: np.ndarray,
    T: float,
    is_call: bool,
    digital_type: str = "cash",
    payout: float | np.ndarray = 1.0,
    strike_bump_frac: float = 1e-3,
) -> np.ndarray:
    """Skew-consistent European digital price via tight call/put-spread
    replication (see module-level comment above for the derivation).

    Parameters
    ----------
    F : np.ndarray, shape (n_paths,)
        Forward price to (spot-day adjusted) expiry.
    K : float
        Strike / event trigger level.
    vol_fn : callable
        ``vol_fn(strike) -> vol`` -- the local Black vol at an arbitrary
        strike, e.g. ``lambda k: vol_skew.get_vol(strike=k, tenor=T)``.
        Typically a :class:`~market_data.vol_surface.BenchmarkVolSkew` or
        :class:`~market_data.vol_surface.SimpleSkew` bound this way by the
        caller.
    df, T, is_call, digital_type, payout : as in
        :func:`black76_digital_price`.
    strike_bump_frac : float
        Relative strike bump used to build the replicating spread
        (default 0.1% of K).

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    from models.equity_pv import black76_euro_option

    if T <= 0.0:
        return black76_digital_price(F, K, np.zeros_like(F), df, T, is_call, digital_type, payout)

    h = max(abs(float(K)) * strike_bump_frac, 1e-6)
    vol_minus = np.broadcast_to(np.asarray(vol_fn(K - h), dtype=np.float64), F.shape)
    vol_plus = np.broadcast_to(np.asarray(vol_fn(K + h), dtype=np.float64), F.shape)

    if is_call:
        C_minus = black76_euro_option(F, K - h, vol_minus, df, T, True)
        C_plus = black76_euro_option(F, K + h, vol_plus, df, T, True)
        cash_digital = payout * (C_minus - C_plus) / (2.0 * h)
    else:
        P_minus = black76_euro_option(F, K - h, vol_minus, df, T, False)
        P_plus = black76_euro_option(F, K + h, vol_plus, df, T, False)
        cash_digital = payout * (P_plus - P_minus) / (2.0 * h)

    if digital_type == "cash":
        return cash_digital
    elif digital_type == "asset":
        vol_center = np.broadcast_to(np.asarray(vol_fn(K), dtype=np.float64), F.shape)
        if is_call:
            C_center = black76_euro_option(F, K, vol_center, df, T, True)
            return payout * C_center + K * cash_digital
        else:
            P_center = black76_euro_option(F, K, vol_center, df, T, False)
            return K * cash_digital - payout * P_center
    else:
        raise ValueError(f"digital_type must be 'cash' or 'asset', got {digital_type!r}")


# ---------------------------------------------------------------------------
# Cost of carry — sourcing for the barrier (spot-diffusion) formula
# ---------------------------------------------------------------------------
#
# The continuously-monitored barrier formula operates on the underlying
# SPOT diffusion (dS/S = b dt + sigma dW), whereas the market observable
# stored in the ScenarioCube is a forward curve. Following the document's
# worked examples (F0,T = S0 * exp(b*T)), an implied spot S0 and constant
# carry rate b are required. Three sourcing modes are supported by the
# calling instrument, in order of precedence:
#   1. an explicit scalar `cost_of_carry` (matches the document's worked
#      examples, where b is simply a given desk assumption),
#   2. a dedicated carry-curve risk factor (term-structure b(T)),
#   3. curve-implied: back out b from the forward curve's own near-dated
#      pillar and the target maturity pillar (no extra market data needed).


def implied_cost_of_carry(
    near_T: float, near_F: np.ndarray, far_T: float, far_F: np.ndarray,
) -> np.ndarray:
    """Implied continuously-compounded cost of carry between two curve pillars.

    b = ln(F_far / F_near) / (T_far - T_near)

    Falls back to 0.0 when the two tenors coincide (guards against
    division by a ~zero denominator).
    """
    dT = far_T - near_T
    if abs(dT) < 1e-8:
        return np.zeros_like(np.asarray(far_F, dtype=np.float64))
    near_F_safe = np.maximum(np.asarray(near_F, dtype=np.float64), 1e-12)
    return np.log(np.asarray(far_F, dtype=np.float64) / near_F_safe) / dT


# ---------------------------------------------------------------------------
# Continuously monitored digital barrier (One-Touch / No-Touch) — closed form
# ---------------------------------------------------------------------------
#
# Reference: document's "First-principles derivation of the up-and-in and
# up-and-out premiums" / down-and-in section.
#
# Underlying spot SDE (Black-Scholes, cost of carry b):  dS/S = b dt + sigma dW
# First hitting time: tau_H = inf{t >= 0 : S_t crosses H}
#
# Upper barrier (H > S0), a = ln(H/S0):
#   Q(tau_H <= T) = Phi((muT-a)/(sig*sqrtT)) + exp(2*mu*a/sig^2) * Phi((-muT-a)/(sig*sqrtT))
#
# Lower barrier (H < S0), a = ln(S0/H):
#   Q(tau_H <= T) = Phi((-muT-a)/(sig*sqrtT)) + exp(-2*mu*a/sig^2) * Phi((muT-a)/(sig*sqrtT))
#
# where mu = b - 0.5*sigma^2.
#
# Settlement convention (document): even if the barrier is hit before
# expiry, the fixed cashflow is paid on the contractual settlement date —
# so the payoff is NOT the standard rebate-at-hit-time American digital;
# it is DF(0,T_settle) * A * Q(tau_H<=T) for one-touch (pay at expiry),
# which is exactly what the document derives (V_UI, V_DI examples).


def barrier_touch_probability(
    S0: np.ndarray, H: float, mu: np.ndarray, sigma: np.ndarray, T: float,
    direction: str,
) -> np.ndarray:
    """Risk-neutral probability that a GBM(S0, mu, sigma) touches H within [0,T].

    Parameters
    ----------
    S0 : np.ndarray, shape (n_paths,)
        Implied spot (today, or at the start of the remaining monitoring
        window being priced).
    H : float
        Barrier level.
    mu : np.ndarray
        Drift of the log-process, ``b - 0.5*sigma**2``.
    sigma : np.ndarray
        Volatility.
    T : float
        Remaining time to expiry in years, must be > 0.
    direction : {"up", "down"}
        "up" — H is expected to be approached from below (H > S0 assumed).
        "down" — H is expected to be approached from above (H < S0 assumed).

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Touch probability in [0, 1].
    """
    sqrt_T = np.sqrt(T)
    sig_sqrt_T = sigma * sqrt_T
    lam = 2.0 * mu / sigma ** 2

    if direction == "up":
        a = np.log(H / S0)
        u1 = (mu * T - a) / sig_sqrt_T
        u2 = (-mu * T - a) / sig_sqrt_T
        return norm_cdf(u1) + np.exp(lam * a) * norm_cdf(u2)
    elif direction == "down":
        a = np.log(S0 / H)
        v1 = (-mu * T - a) / sig_sqrt_T
        v2 = (mu * T - a) / sig_sqrt_T
        return norm_cdf(v1) + np.exp(-lam * a) * norm_cdf(v2)
    else:
        raise ValueError(f"direction must be 'up' or 'down', got {direction!r}")


def commodity_barrier_digital_price(
    F: np.ndarray,
    H: float,
    sigma: np.ndarray,
    b: np.ndarray,
    df: np.ndarray,
    T: float,
    direction: str,
    touch: str,
    payout: float | np.ndarray = 1.0,
) -> np.ndarray:
    """PV of a continuously-monitored single-barrier cash-or-nothing digital.

    Parameters
    ----------
    F : np.ndarray, shape (n_paths,)
        Forward price to (spot-day adjusted) maturity — used to derive the
        implied spot ``S0 = F * exp(-b*T)`` driving the barrier diffusion.
    H : float
        Barrier level.
    sigma : np.ndarray
        Volatility.
    b : np.ndarray or float
        Cost of carry.
    df : np.ndarray
        Discount factor to the settlement date.
    T : float
        Time to expiry in years (val_date -> maturity_date), > 0.
    direction : {"up", "down"}
    touch : {"in", "out"}
        "in"  — One-Touch: pays ``payout`` if H is touched during [0,T].
        "out" — No-Touch: pays ``payout`` if H is never touched during [0,T].
    payout : float or np.ndarray
        Fixed cash amount.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    S0 = F * np.exp(-b * T)
    mu = b - 0.5 * sigma ** 2
    Q = barrier_touch_probability(S0, H, mu, sigma, T, direction)
    Q = np.clip(Q, 0.0, 1.0)

    if touch == "in":
        return payout * df * Q
    elif touch == "out":
        return payout * df * (1.0 - Q)
    else:
        raise ValueError(f"touch must be 'in' or 'out', got {touch!r}")


def commodity_barrier_digital_analytic_greeks(
    F: np.ndarray,
    H: float,
    sigma: np.ndarray,
    b: np.ndarray,
    df: np.ndarray,
    T: float,
    direction: str,
    touch: str,
    payout: float | np.ndarray = 1.0,
    dF_dS: float | np.ndarray = 1.0,
) -> dict[str, np.ndarray]:
    """Closed-form Delta, Vega, and (model) Theta for the continuously
    monitored single-barrier digital, derived from first principles by
    differentiating the first-passage probability ``Q(tau_H <= T)``.

    Not given in the document (which only makes qualitative statements for
    barrier Greeks: "Delta and gamma can change sharply...", "Vega is
    highly non-linear...", "Theta can be strongly path-dependent...").
    Derived here via the reflection-principle identity
    ``exp(lambda*a) * phi(u2) == phi(u1)`` (and its "down" analogue), which
    also self-validates the algebra (both sides collapse to the same
    clean expressions). Cross-checked numerically against bump-and-reprice
    in the test suite.

    Theta requires an extra chain-rule term beyond ``dQ/dT`` holding the
    implied spot fixed: because ``S0 = F * exp(-b*T)`` is itself a function
    of T (the forward is being carried back to an implied spot over a
    window that shrinks as time passes), the full derivative is
    ``dQ/dT = dQ/dT|_{S0 fixed} + dQ/dS0 * dS0/dT`` with
    ``dS0/dT = -b * S0``.

    Gamma is intentionally **not** provided in closed form here (the second
    derivative is algebraically unwieldy and a poor trade against the risk
    of a subtle sign error); use bump-and-reprice for Gamma, which is
    standard market practice for higher-order barrier Greeks in any case.

    Returns
    -------
    dict with keys "delta", "vega", "theta" — np.ndarray (n_paths,).
    """
    S0 = F * np.exp(-b * T)
    mu = b - 0.5 * sigma ** 2
    lam = 2.0 * mu / sigma ** 2
    sqrt_T = np.sqrt(T)
    sig_sqrt_T = sigma * sqrt_T
    sign = 1.0 if touch == "in" else -1.0

    if direction == "up":
        a = np.log(H / S0)
        u1 = (mu * T - a) / sig_sqrt_T
        u2 = (-mu * T - a) / sig_sqrt_T
        phi_u1 = norm_pdf(u1)
        Phi_u2 = norm_cdf(u2)

        dQ_dS0 = (1.0 / S0) * (2.0 * phi_u1 / sig_sqrt_T - lam * np.exp(lam * a) * Phi_u2)
        dQ_dsig = (2.0 * a / (sigma ** 2 * sqrt_T)) * phi_u1 \
            - (2.0 * a * (sigma ** 2 + 2.0 * mu) / sigma ** 3) * np.exp(lam * a) * Phi_u2
        dQ_dT_a_fixed = phi_u1 * a / (sigma * T * sqrt_T)
    elif direction == "down":
        a = np.log(S0 / H)
        v1 = (-mu * T - a) / sig_sqrt_T
        v2 = (mu * T - a) / sig_sqrt_T
        phi_v1 = norm_pdf(v1)
        Phi_v2 = norm_cdf(v2)

        dQ_dS0 = -(1.0 / S0) * (2.0 * phi_v1 / sig_sqrt_T + lam * np.exp(-lam * a) * Phi_v2)
        dQ_dsig = (2.0 * a / (sigma ** 2 * sqrt_T)) * phi_v1 \
            + (2.0 * a * (sigma ** 2 + 2.0 * mu) / sigma ** 3) * np.exp(-lam * a) * Phi_v2
        dQ_dT_a_fixed = phi_v1 * a / (sigma * T * sqrt_T)
    else:
        raise ValueError(f"direction must be 'up' or 'down', got {direction!r}")

    # S0 = F * exp(-b*T) is itself a function of T, so the total dQ/dT picks
    # up an extra term through dS0/dT = -b*S0 beyond the direct partial
    # (which holds a = ln(H/S0) or ln(S0/H) fixed). Omitting this term was
    # caught by the bump-and-reprice cross-check in the test suite.
    dS0_dT = -b * S0
    dQ_dT = dQ_dT_a_fixed + dQ_dS0 * dS0_dT

    # Chain rule: dS0/dF = exp(-b*T); overall Delta wrt the underlying spot
    # observable is scaled by dF_dS (~=1 for futures-style underlyings).
    dS0_dF = np.exp(-b * T)
    delta = sign * payout * df * dQ_dS0 * dS0_dF * dF_dS
    vega = sign * payout * df * dQ_dsig
    theta = sign * payout * df * dQ_dT  # model theta: dV/dT_opt only (see docstring)

    return {"delta": delta, "vega": vega, "theta": theta}


# ---------------------------------------------------------------------------
# Discretely monitored digital barrier — Monte Carlo
# ---------------------------------------------------------------------------
#
# Per the document: "If model support is not available for a given
# configuration (e.g. discrete monitoring), Monte Carlo ... may be used".
# This is the general-purpose engine: it also transparently covers double
# barriers and asset-or-nothing barrier payoffs, for which the document
# gives no closed form at all.


def mc_digital_barrier_pv(
    F0: np.ndarray,
    sigma: np.ndarray,
    b: np.ndarray,
    T: float,
    monitoring_t: np.ndarray,
    upper_barrier: float | None,
    lower_barrier: float | None,
    touch: str,
    digital_type: str,
    payout: float | np.ndarray,
    df: np.ndarray,
    rng: np.random.Generator,
    n_inner: int = 1000,
    already_touched: np.ndarray | None = None,
    vol_fn: Callable[[np.ndarray], np.ndarray] | None = None,
) -> np.ndarray:
    """Nested Monte Carlo price of a discretely-monitored digital barrier.

    For each outer scenario path (index into F0/sigma/b/df), simulates
    ``n_inner`` independent GBM sub-paths of the implied spot process
    ``dS/S = b dt + sigma dW`` sampled at each date in ``monitoring_t``
    (year fractions from val_date), checks the touch condition at every
    monitoring date (running boolean latch — O(n_outer*n_inner) memory,
    no full path storage), and averages the discounted payoff across the
    inner paths to estimate the conditional expectation at each outer
    scenario. This is a genuine nested simulation (the inner average is the
    valuation at each outer scenario) — not a single-draw payoff realisation.

    Cost is O(n_outer * n_inner * n_monitor); tune ``n_inner`` and the
    monitoring-date granularity when calling this inside a full XVA
    exposure-engine time-stepping loop.

    Parameters
    ----------
    F0 : np.ndarray, shape (n_outer,)
        Forward price anchor (spot-day adjusted) per outer scenario path.
    sigma, b : np.ndarray or float
        Volatility and cost of carry (broadcastable to (n_outer,)).
    T : float
        Time to expiry in years — used only to derive the implied spot
        ``S0 = F0 * exp(-b*T)``.
    monitoring_t : np.ndarray, shape (n_monitor,)
        Strictly increasing year fractions (from val_date) of each
        monitoring date remaining, monitoring_t[-1] should equal T
        (or the last observation before/at expiry).
    upper_barrier, lower_barrier : float or None
        At least one must be given. Both given => double barrier.
    touch : {"in", "out"}
    digital_type : {"cash", "asset"}
        "asset" pays ``payout`` units of the underlying valued at its
        *simulated* terminal spot (the last monitoring-date value).
    payout : float or np.ndarray
    df : np.ndarray, shape (n_outer,)
        Discount factor to the settlement date.
    rng : np.random.Generator
    n_inner : int
        Number of inner Monte Carlo draws per outer scenario.
    already_touched : np.ndarray of bool, shape (n_outer,), optional
        Per-path latch carried over from earlier valuation dates on this
        same simulated exposure path (see the calling instrument's
        ``compute_commodity_fixings`` hook). When set, those outer paths
        skip simulation entirely and resolve deterministically.
    vol_fn : callable, optional
        When given, diffuses with a **level-dependent local vol**
        ``sigma(S_t)`` read off a skew at each simulated path's *current*
        price at every monitoring step, instead of the flat ``sigma``
        array (which is ignored when ``vol_fn`` is supplied). Call
        signature: ``vol_fn(S) -> array_like(S.shape)``, e.g.
        ``lambda S: vol_skew.get_vol(strike=S, tenor=T)`` -- i.e. the
        smile is queried at the *current simulated level*, treated as if
        it were a strike. This is a practical "sticky-strike" local-vol
        proxy, **not** a rigorously calibrated Dupire local-vol surface
        (which would require inverting the smile's full ``d^2C/dK^2``
        term structure) -- adequate for skew-*consistent* barrier pricing
        without that machinery, but should not be read as delivering the
        same theoretical guarantees as a true local-vol/SLV model.

    Returns
    -------
    np.ndarray, shape (n_outer,)
    """
    if upper_barrier is None and lower_barrier is None:
        raise ValueError("At least one of upper_barrier/lower_barrier must be given.")

    n_outer = np.broadcast_to(np.asarray(F0, dtype=np.float64), np.shape(F0)).shape[0]
    sigma = np.broadcast_to(np.asarray(sigma, dtype=np.float64), (n_outer,)).copy()
    b = np.broadcast_to(np.asarray(b, dtype=np.float64), (n_outer,)).copy()
    F0 = np.asarray(F0, dtype=np.float64)

    S0 = F0 * np.exp(-b * T)
    S = np.repeat(S0[:, None], n_inner, axis=1)  # (n_outer, n_inner)
    touched = np.zeros((n_outer, n_inner), dtype=bool)

    if upper_barrier is not None:
        touched |= (S >= upper_barrier)
    if lower_barrier is not None:
        touched |= (S <= lower_barrier)

    t_prev = 0.0
    for t in monitoring_t:
        dt = float(t) - t_prev
        if dt <= 0.0:
            t_prev = float(t)
            continue
        Z = rng.standard_normal((n_outer, n_inner))
        if vol_fn is not None:
            local_sigma = np.asarray(vol_fn(S), dtype=np.float64)  # (n_outer, n_inner)
            drift = (b[:, None] - 0.5 * local_sigma ** 2) * dt
            diffusion = local_sigma * np.sqrt(dt)
        else:
            drift = ((b - 0.5 * sigma ** 2) * dt)[:, None]
            diffusion = (sigma * np.sqrt(dt))[:, None]
        S = S * np.exp(drift + diffusion * Z)
        if upper_barrier is not None:
            touched |= (S >= upper_barrier)
        if lower_barrier is not None:
            touched |= (S <= lower_barrier)
        t_prev = float(t)

    hit = touched if touch == "in" else ~touched

    if digital_type == "cash":
        payoff = np.where(hit, payout, 0.0)
    elif digital_type == "asset":
        payoff = np.where(hit, payout * S, 0.0)
    else:
        raise ValueError(f"digital_type must be 'cash' or 'asset', got {digital_type!r}")

    pv = payoff.mean(axis=1) * df

    if already_touched is not None:
        already_touched = np.asarray(already_touched, dtype=bool)
        deterministic = payout * df if touch == "in" else np.zeros_like(pv)
        pv = np.where(already_touched, deterministic, pv)

    return pv


# ---------------------------------------------------------------------------
# Generic bump-and-reprice Greeks (works for any of the above pricers, and
# for the discretely-monitored MC engine, via the calling Instrument's
# scenario_npvs). Shared by CommodityDigitalOption and
# CommodityDigitalBarrierOption.
# ---------------------------------------------------------------------------


def bump_and_reprice_greeks(
    price_fn: Callable[[np.ndarray, np.ndarray, date | None], np.ndarray],
    forward: np.ndarray,
    vol: np.ndarray,
    val_date,
    rel_bump_forward: float = 1e-4,
    abs_bump_vol: float = 1e-4,
    days_bump_theta: int = 1,
) -> dict[str, np.ndarray]:
    """Numerical Delta/Gamma/Vega/Theta via central-difference bump-and-reprice.

    Independent of (does not reuse) the analytic closed forms above — this
    is the "prudency" cross-check the document and the user asked for.

    Parameters
    ----------
    price_fn : callable(forward_bumped, vol_bumped, val_date_override) -> np.ndarray
        Re-prices the instrument given a bumped forward array, a bumped vol
        array, and an optional val_date override (None => use the base
        val_date). The caller is responsible for reconstructing whatever
        market_state / curve objects the bump implies and, for MC-priced
        instruments, for using common random numbers (the same rng seed)
        across all calls so the finite difference is not swamped by MC noise.
    forward, vol : np.ndarray, shape (n_paths,)
        Base-case forward and vol, used to size the relative/absolute bumps.
    val_date : date
        Base valuation date.
    rel_bump_forward : float
        Relative bump size applied to the forward (default 1bp).
    abs_bump_vol : float
        Absolute (vol-point) bump size (default 1bp of vol).
    days_bump_theta : int
        Calendar days to advance val_date for the theta bump.

    Returns
    -------
    dict with keys "delta", "gamma", "vega", "theta" — np.ndarray (n_paths,).
    """
    from datetime import timedelta

    h_F = np.maximum(np.abs(forward), 1.0) * rel_bump_forward
    h_vol = abs_bump_vol

    V0 = price_fn(forward, vol, None)
    V_Fu = price_fn(forward + h_F, vol, None)
    V_Fd = price_fn(forward - h_F, vol, None)
    V_volu = price_fn(forward, vol + h_vol, None)
    V_vold = price_fn(forward, np.maximum(vol - h_vol, 0.0), None)
    V_theta = price_fn(forward, vol, val_date + timedelta(days=days_bump_theta))

    delta = (V_Fu - V_Fd) / (2.0 * h_F)
    gamma = (V_Fu - 2.0 * V0 + V_Fd) / (h_F ** 2)
    vega = (V_volu - V_vold) / (2.0 * h_vol)
    theta = V_theta - V0  # raw 1-day decay; negative => value falls as time passes

    return {"delta": delta, "gamma": gamma, "vega": vega, "theta": theta, "base": V0}
