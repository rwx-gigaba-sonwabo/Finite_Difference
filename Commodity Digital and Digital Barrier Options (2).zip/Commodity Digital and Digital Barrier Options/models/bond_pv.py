from __future__ import annotations

from datetime import date

import numpy as np
import QuantLib as ql

from market_data.yield_curve import YieldCurve
from utils.ql_helpers import to_ql_date


def bond_pv(
    schedule: list[tuple[date, date, date, float]],
    coupon_rate: float,
    notional: float,
    val_date: date,
    discount_curve: YieldCurve,
    curve_day_counter: ql.DayCounter,
    cutoff_date: date | None = None,
    compounding: bool = False,
) -> np.ndarray:
    """PV of a fixed-coupon bond's remaining cashflows.

    Non-compounding (default): includes coupon payments
    (coupon_rate x accrual x notional) for each period whose accrual_end is
    strictly after *cutoff_date*, plus principal repayment at bond maturity.
    Discount factors are computed to the *payment_date* of each period, which
    may differ from the accrual_end when the coupon date falls on a weekend or
    public holiday (Following adjustment).

    Compounding: interest is not paid out periodically.  Each period's
    interest accumulates into the running balance exactly as RiskFlow's
    ``pv_fixed_cashflows`` does when ``Compounding='Yes'``:

        balance_k = balance_{k-1} + (balance_{k-1} + notional) * rate * accrual_k

    which is equivalent to ``notional * prod(1 + rate*a_k) - notional``.
    The entire compounded principal (interest + original notional) is paid
    as a single terminal cashflow discounted to the last period's payment_date.
    The full schedule (including pre-*cutoff_date* periods) is used to compute
    the terminal amount because compounding before delivery is embedded in it.

    Parameters
    ----------
    schedule : list of (accrual_start, accrual_end, payment_date, accrual_fraction)
        Bond coupon schedule from ScheduleConfig.build_bond_schedule().
        accrual_start / accrual_end are unadjusted calendar dates.
        payment_date is the Following-adjusted date on which the coupon is paid.
        accrual_fraction = coupon_frequency / 12 (constant simple-bond basis).
    coupon_rate : float
        Annual coupon rate (e.g. 0.08 for 8%).
    notional : float
        Face value.
    val_date : date
        Valuation date; year fractions are measured from here.
    discount_curve : YieldCurve
        Per-path discount curve, shape (n_paths, n_tenors).
        For bond forwards this should be the bond-specific curve (ZAR-BOND).
    curve_day_counter : ql.DayCounter
        Day count convention for curve year fractions.
    cutoff_date : date or None
        Only include cashflows whose accrual_end is strictly after this date.
        Defaults to val_date.
    compounding : bool
        When True, interest compounds each period rather than being paid
        out.  The full compounded principal is paid at bond maturity only.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Dirty PV of included cashflows.
    """
    cutoff = cutoff_date if cutoff_date is not None else val_date
    future = [(s, e, p, a) for s, e, p, a in schedule if e > cutoff]
    if not future:
        return np.zeros(discount_curve.rates.shape[0])

    ql_val = to_ql_date(val_date)
    # Bond maturity = last accrual end date (unadjusted); identifies the principal period.
    bond_maturity = max(e for _, e, _, _ in schedule)

    if compounding:
        # Replicate RiskFlow's accumulation: payments += (payments + notional) * int_k
        # Equivalent to: terminal = notional * prod(1 + coupon_rate * a_k) over ALL periods.
        # Pre-cutoff compounding is already embedded in the terminal amount.
        terminal = notional
        for _, _, _, a in schedule:
            terminal *= 1.0 + coupon_rate * a

        # Discount to the payment_date of the last (maturity) period.
        last_pay = max(p for _, _, p, _ in schedule)
        T_mat = float(curve_day_counter.yearFraction(ql_val, to_ql_date(last_pay)))
        df_mat = discount_curve.discount_factor(T_mat)  # (n_paths,)
        return df_mat * terminal

    # Non-compounding: periodic coupon + principal at maturity.
    # Discount factors are computed to each period's payment_date (not accrual_end).
    t_ends = np.array([
        curve_day_counter.yearFraction(ql_val, to_ql_date(p))
        for _, _, p, _ in future
    ])
    accruals = np.array([a for _, _, _, a in future])

    # (n_paths, n_periods)
    dfs = discount_curve.discount_factor(t_ends)

    # Coupon cashflows: scalar (n_periods,)
    coupon_cfs = notional * coupon_rate * accruals

    # Add principal to the period whose accrual_end is bond maturity.
    for i, (_, end_date, _, _) in enumerate(future):
        if end_date == bond_maturity:
            coupon_cfs[i] += notional
            break

    return dfs @ coupon_cfs  # (n_paths,)


def accrued_interest(
    schedule: list[tuple[date, date, date, float]],
    coupon_rate: float,
    query_date: date,
    day_counter: ql.DayCounter,
    ex_coupon_days: int = 0,
    calendar: ql.Calendar | None = None,
) -> float:
    """Accrued interest at *query_date*, expressed as a fraction of notional.

    Uses the coupon schedule's accrual day-count convention to measure
    the elapsed time from the last coupon start to *query_date*.

    Returns 0.0 when *query_date* falls before the first coupon period
    or exactly on a coupon accrual end date (accrual just reset).

    BESA CUMEX: when *ex_coupon_days* > 0 and *calendar* is provided, the
    function checks whether *query_date* falls inside the book-close window
    (i.e. within *ex_coupon_days* business days before the payment_date).
    In this case the buyer does not receive the next coupon, so accrued
    interest is negative: ``AI = -coupon_rate * yearFraction(query_date, payment_date)``.
    This matches the RiskFlow BESA CUMEX=0 convention exactly.

    Parameters
    ----------
    schedule : list of (accrual_start, accrual_end, payment_date, accrual_fraction)
        Bond coupon schedule from ScheduleConfig.build_bond_schedule().
    coupon_rate : float
    query_date : date
    day_counter : ql.DayCounter
        Must match the convention used to build the schedule.
    ex_coupon_days : int
        Number of business days before the coupon payment_date at which the
        bond goes ex-coupon (BESA nominal bonds: 10).  Defaults to 0
        (no ex-coupon period -- CUMEX always 1).
    calendar : ql.Calendar or None
        Business calendar used to measure *ex_coupon_days*.  Required when
        *ex_coupon_days* > 0; ignored otherwise.

    Returns
    -------
    float
        Accrued interest per unit of face value.  Negative inside the
        BESA book-close window (CUMEX=0).
    """
    ql_query = to_ql_date(query_date)
    for start, accrual_end, pay_date, _ in schedule:
        if start <= query_date < accrual_end:
            if ex_coupon_days > 0 and calendar is not None:
                # BESA book-close window measured from the payment date.
                ql_pay = to_ql_date(pay_date)
                bcd = calendar.advance(
                    ql_pay,
                    ql.Period(-ex_coupon_days, ql.Days),
                    ql.Preceding,
                )
                if ql_query >= bcd:
                    # CUMEX=0: buyer forgoes next coupon -- negative accrued
                    tau = float(day_counter.yearFraction(ql_query, ql_pay))
                    return -coupon_rate * tau
            tau = float(day_counter.yearFraction(to_ql_date(start), ql_query))
            return coupon_rate * tau
    return 0.0


def bond_forward_pv(
    schedule: list[tuple[date, date, date, float]],
    coupon_rate: float,
    notional: float,
    val_date: date,
    delivery_date: date,
    forward_clean_price: float,
    bond_curve: YieldCurve,
    day_counter: ql.DayCounter,
    curve_day_counter: ql.DayCounter,
    direction: int = 1,
    ex_coupon_days: int = 0,
    ql_calendar: ql.Calendar | None = None,
    settlement_amount: float | None = None,
    compounding: bool = False,
    repo_curve: YieldCurve | None = None,
    forward_curve: YieldCurve | None = None,
) -> np.ndarray:
    """MTM value of a fixed-coupon bond forward contract.

    Three-curve cash-and-carry formula
    -----------------------------------
    Each curve serves a distinct economic role:

    bond_curve (ZAR-BOND):
        Discounts the underlying bond's cashflows to compute its spot dirty
        price and the PV of post-delivery cashflows.

    repo_curve (ZAR-BOND-REPO):
        Carries the bond's dirty price forward to the delivery date.  This
        is the financing rate for holding the bond from val_date to delivery.
        In the formula below it appears as DF_repo(t, T).

    forward_curve (ZAR-SWAP):
        Discounts the forward payoff back to val_date.  This is typically
        the OIS or swap curve used for all forward contract discounting.
        In the formula below it appears as DF_fwd(t, T).

    NPV formula:

        NPV(t) = direction * [PV_after(t) * DF_fwd(t,T) / DF_repo(t,T)
                              - K_dirty * DF_fwd(t,T)]

    where:
    - PV_after(t)  = bond_pv(cutoff=delivery) using bond_curve
                   = spot dirty price - PV of pre-delivery coupons
    - DF_repo(t,T) = repo discount factor to delivery
    - DF_fwd(t,T)  = forward/swap discount factor to delivery
    - K_dirty      = settlement_amount if provided, else
                     (forward_clean_price + AI(delivery)) * notional

    When all three curves are identical the formula collapses to the
    standard single-curve result:

        NPV(t) = direction * [PV_after(t) - K_dirty * DF(t,T)]

    Strike priority (mirrors RiskFlow's CFFixedInterestListDeal):
    - *settlement_amount*: absolute currency amount used directly as K_dirty.
      Bypasses *forward_clean_price* and accrued-interest calculation.
    - *forward_clean_price*: clean price as a fraction of par; accrued
      interest at *delivery_date* is added internally.

    Parameters
    ----------
    schedule : list of (start, end, accrual_fraction)
    coupon_rate : float
    notional : float
    val_date : date
    delivery_date : date
        Forward settlement date.  Must be strictly before bond maturity.
    forward_clean_price : float
        Agreed clean forward price as a fraction of par (e.g. 0.985).
        Used only when *settlement_amount* is None.
    bond_curve : YieldCurve
        Bond-specific discount curve (ZAR-BOND).  Used to compute the
        PV of post-delivery bond cashflows.
    day_counter : ql.DayCounter
        Accrual day count (for accrued interest at delivery).
    curve_day_counter : ql.DayCounter
        Curve day count (for year fractions on the discount curves).
    direction : int
        +1 for buyer (long bond forward); -1 for seller (short).
    ex_coupon_days : int
        BESA book-close window in business days (default 0 = no CUMEX).
    ql_calendar : ql.Calendar or None
        Calendar for BESA CUMEX business-day counting.
    settlement_amount : float or None
        Pre-agreed dirty settlement price in absolute currency units.
        Takes priority over *forward_clean_price* + AI when provided.
    compounding : bool
        When True, the underlying bond compounds interest into a single
        terminal cashflow.  Passed through to bond_pv().
    repo_curve : YieldCurve or None
        Repo / carry curve (ZAR-BOND-REPO).  Used to carry the bond
        dirty price from val_date to delivery.  Defaults to *bond_curve*
        when None (single-curve fallback).
    forward_curve : YieldCurve or None
        Forward payoff discount curve (ZAR-SWAP).  Used to discount the
        forward payoff from delivery back to val_date.  Defaults to
        *bond_curve* when None (single-curve fallback).

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    n_paths = bond_curve.rates.shape[0]

    if val_date >= delivery_date:
        return np.zeros(n_paths)

    # Fallback to bond_curve when repo/forward curves are not supplied
    _repo = repo_curve if repo_curve is not None else bond_curve
    _fwd  = forward_curve if forward_curve is not None else bond_curve

    # PV of bond cashflows paid strictly after delivery (using bond curve)
    pv_after = bond_pv(
        schedule, coupon_rate, notional, val_date,
        bond_curve, curve_day_counter,
        cutoff_date=delivery_date,
        compounding=compounding,
    )

    # Agreed dirty forward price in currency units
    # settlement_amount (absolute) takes priority -- mirrors RiskFlow's Settlement_Amount field.
    if settlement_amount is not None:
        forward_dirty_abs = settlement_amount
    else:
        ai_frac = accrued_interest(
            schedule, coupon_rate, delivery_date, day_counter,
            ex_coupon_days=ex_coupon_days,
            calendar=ql_calendar,
        )
        forward_dirty_abs = (forward_clean_price + ai_frac) * notional

    # Discount factors to delivery from each curve: shape (n_paths,)
    T_del = float(curve_day_counter.yearFraction(
        to_ql_date(val_date), to_ql_date(delivery_date),
    ))
    df_repo = _repo.discount_factor(T_del)   # financing curve -- carries dirty price forward
    df_fwd  = _fwd.discount_factor(T_del)    # payoff discount curve -- discounts the payoff

    # Three-curve NPV:
    #   NPV = direction * [PV_after * (df_fwd / df_repo) - K_dirty * df_fwd]
    # When repo = fwd = bond_curve: df_fwd/df_repo = 1 -> reduces to single-curve formula.
    return direction * (pv_after * (df_fwd / df_repo) - forward_dirty_abs * df_fwd)
