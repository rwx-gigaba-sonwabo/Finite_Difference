from __future__ import annotations

import numpy as np

from market_data.yield_curve import YieldCurve
from utils.maths import norm_cdf


def equity_forward_price(
    spot: np.ndarray,
    carry_curve: YieldCurve,
    dividend_curve: YieldCurve,
    T: float,
    t0: float = 0.0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Equity forward price, carry discount factor, and spot carry rate.

    Parameters
    ----------
    spot : np.ndarray
        Spot prices, shape (n_paths,).
    carry_curve : YieldCurve
        Carry / funding rate curve.
    dividend_curve : YieldCurve
        Continuous dividend yield curve.
    T : float
        Delivery date as a year fraction from val_date.
    t0 : float
        Start of the carry period as a year fraction from val_date
        (default 0.0).  When > 0, forward carry/dividend discount
        factors for [t0, T] are used — required when a settlement lag
        shifts the effective carry start to val_settle rather than
        val_date.

    Returns
    -------
    F : np.ndarray
        Forward price, shape (n_paths,).
        t0=0: spot * exp((r - q) * T).
        t0>0: spot * fwd_div_df(t0, T) / fwd_carry_df(t0, T).
    df : np.ndarray
        Forward carry discount factor over [t0, T], shape (n_paths,).
    r : np.ndarray
        Spot carry rate at tenor T (kept for backward compatibility).
    """
    df_carry_T = carry_curve.discount_factor(T)
    df_div_T = dividend_curve.discount_factor(T)

    if t0 > 0.0:
        df_carry_t0 = carry_curve.discount_factor(t0)
        df_div_t0 = dividend_curve.discount_factor(t0)
        fwd_carry = df_carry_T / df_carry_t0
        fwd_div = df_div_T / df_div_t0
    else:
        fwd_carry = df_carry_T
        fwd_div = df_div_T

    F = spot * fwd_div / fwd_carry
    df = fwd_carry
    r = carry_curve.get_rate(T)  # spot rate; kept for backward compat

    return F, df, r


def black76_euro_option(
    forward: np.ndarray,
    strike: float,
    vol: np.ndarray,
    df: np.ndarray,
    T: float,
    is_call: bool,
) -> np.ndarray:
    """Price a European option using the Black-76 model on the forward price.

    Parameters
    ----------
    forward : np.ndarray
        Forward prices, shape (n_paths,).
    strike : float
        Option strike price.
    vol : np.ndarray
        Black implied volatility, shape (n_paths,).
    df : np.ndarray
        Discount factor to option expiry, shape (n_paths,).
    T : float
        Time to expiry in years (must be > 0).
    is_call : bool
        True for a call, False for a put.

    Returns
    -------
    np.ndarray
        Option price per path, shape (n_paths,).
    """
    if T <= 0.0:
        if is_call:
            return df * np.maximum(forward - strike, 0.0)
        else:
            return df * np.maximum(strike - forward, 0.0)

    sqrt_T = np.sqrt(T)

    # Discounted intrinsic value, returned where vol == 0
    if is_call:
        intrinsic = df * np.maximum(forward - strike, 0.0)
    else:
        intrinsic = df * np.maximum(strike - forward, 0.0)

    zero_vol = np.asarray(vol) == 0.0
    safe_vol = np.where(zero_vol, 1.0, vol)

    # Guard the log against zero or negative strike (K_eff can go negative for deep-ITM
    # Asian options once past_sum/n_total > K).  Use 1e-12 only inside the log so that
    # the original strike — including its sign — is preserved in the Black-76 formula
    # below.  When strike < 0: d1 → +∞, N(d1) = N(d2) → 1, and
    # black76 = df*(forward - strike) = df*(forward + |strike|), which is the correct
    # intrinsic value for a call that is guaranteed ITM.
    log_safe_strike = np.maximum(np.asarray(strike, dtype=np.float64), 1e-12)
    d1 = (np.log(forward / log_safe_strike) + 0.5 * safe_vol**2 * T) / (safe_vol * sqrt_T)
    d2 = d1 - safe_vol * sqrt_T

    if is_call:
        black76 = df * (forward * norm_cdf(d1) - strike * norm_cdf(d2))
    else:
        black76 = df * (strike * norm_cdf(-d2) - forward * norm_cdf(-d1))

    price = np.where(zero_vol, intrinsic, black76)

    return np.where(np.abs(price) <= 1e-6, 0.0, price)


def trs_return_leg_pv(
    spot: np.ndarray,
    carry_curve: YieldCurve,
    dividend_curve: YieldCurve,
    discount_curve: YieldCurve,
    t_starts: np.ndarray,
    t_ends: np.ndarray,
    quantity: float,
    initial_price: float | np.ndarray | None = None,
    nominal_scaling: str = "Price",
    notional_fixed: float | None = None,
    t_starts_fwd: np.ndarray | None = None,
    t_ends_fwd: np.ndarray | None = None,
    t_settle: float = 0.0,
) -> np.ndarray:
    """PV of the total return leg of an equity TRS.

    Supports two notional conventions controlled by *nominal_scaling*:

    ``"Price"`` (default):
        The effective notional resets each period to
        ``F(T_{i-1}) x quantity``, so the period payoff is the
        **absolute** forward price increment:

            PV = sum quantity * [F(T_i) - F(T_{i-1}) + d(T_{i-1},T_i)]
                               * DF(T_i)

    ``"Initial Price"``:
        The notional stays constant at
        ``notional_fixed = initial_price * quantity``.
        Each period's payoff is the **fractional** return on that
        fixed notional:

            PV = sum notional_fixed
                     * [F(T_i) - F(T_{i-1}) + d(T_{i-1},T_i)]
                     / F(T_{i-1}) * DF(T_i)

        For an in-progress period (T_{i-1} in the past),
        F(T_{i-1}) equals the stored *initial_price*, so the two
        modes give identical results for that period.

    Parameters
    ----------
    spot : np.ndarray
        Current equity spot prices, shape (n_paths,).
    carry_curve : YieldCurve
        Carry / funding rate curve for the equity.
    dividend_curve : YieldCurve
        Continuous dividend yield curve.
    discount_curve : YieldCurve
        Discount curve for the TRS currency.
    t_starts : np.ndarray
        Year fractions from val_date to each period start,
        shape (n_periods,).  May be <= 0 for the in-progress period.
    t_ends : np.ndarray
        Year fractions from val_date to each period end,
        shape (n_periods,).
    quantity : float
        Fixed number of shares / units.
    initial_price : float, np.ndarray, or None
        Equity reference price at the start of the current in-progress
        period.  Accepts a scalar or a per-path array (n_paths,).
        Only used when the first period has ``t_start <= 0``.
        If ``None``, current spot is used as a fallback.
    nominal_scaling : str
        ``"Price"`` for absolute increments (default);
        ``"Initial Price"`` for fractional returns on a fixed notional.
    notional_fixed : float or None
        Fixed notional for ``"Initial Price"`` scaling.
    t_starts_fwd : np.ndarray or None
        Year fractions from *val_settle* to each *T_start_settle*,
        shape (n_periods,).  Used with *t_settle* to compute forward
        carry/dividend rates anchored at val_settle.
        ``None`` → use ``t_starts`` unchanged.
    t_ends_fwd : np.ndarray or None
        Year fractions from *val_settle* to each *T_end_settle*,
        shape (n_periods,).  Used with *t_settle* to compute forward
        carry/dividend rates anchored at val_settle.
        ``None`` → use ``t_ends`` unchanged.
    t_settle : float
        Year fraction from val_date to val_settle (default 0.0).
        When > 0, forward carry/dividend rates for each period are
        computed as ratios of spot DFs at [t_settle, T_full], where
        T_full = t_settle + t_*_fwd.  This corrects both the curve
        anchor and the spot-vs-forward rate mismatch introduced by
        the settlement lag.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Present value of the return leg per path.
    """
    n_paths = spot.shape[0]
    pv = np.zeros(n_paths)

    # Resolve the fixed notional for "Initial Price" scaling once.
    # When nominal_scaling == "Price", n_fixed stays None.
    n_fixed: float | None = None
    if nominal_scaling == "Initial Price":
        if notional_fixed is not None:
            n_fixed = float(notional_fixed)
        elif initial_price is not None and np.ndim(initial_price) == 0:
            n_fixed = float(initial_price) * quantity

    # Precompute val_settle dividend DF for forward-rate correction.
    # When t_settle == 0 this stays None and the no-lag path is taken.
    df_div_t0 = (
        dividend_curve.discount_factor(t_settle)
        if t_settle > 0.0 else None
    )

    for i in range(len(t_starts)):
        t_s = float(t_starts[i])
        t_e = float(t_ends[i])

        # Settlement-adjusted forward tenors (fall back to raw when no lag).
        t_s_fwd = float(t_starts_fwd[i]) if t_starts_fwd is not None else t_s
        t_e_fwd = float(t_ends_fwd[i]) if t_ends_fwd is not None else t_e

        # Full tenors from val_date to the settlement-adjusted dates.
        # With t_settle > 0: T_full = t_settle + t_*_fwd (both from val_date).
        # With t_settle == 0: T_full == t_*_fwd (no adjustment needed).
        t_e_full = t_settle + t_e_fwd if t_settle > 0.0 else t_e_fwd
        t_s_full = t_settle + t_s_fwd if t_settle > 0.0 else t_s_fwd

        # Forward price and forward carry DF at period end.
        # equity_forward_price with t0=t_settle uses DF ratios so that
        # only the forward portion [t_settle, T_end_settle] is carried,
        # correcting both the curve-anchor and spot-vs-forward issues.
        F_end, carry_df_end, _ = equity_forward_price(
            spot, carry_curve, dividend_curve, t_e_full, t0=t_settle,
        )

        # Forward at period start, or historical reference if in-progress.
        # In-progress detection uses the settlement-adjusted tenor so that
        # the carry period begins at val_settle rather than val_date.
        if t_s < 0:
            ref = initial_price if initial_price is not None else spot
            F_start = (
                np.full(n_paths, ref, dtype=np.float64)
                if np.ndim(ref) == 0
                else np.asarray(ref, dtype=np.float64).copy()
            )
        else:
            F_start, _, _ = equity_forward_price(
                spot, carry_curve, dividend_curve, t_s_full, t0=t_settle,
            )

        if t_s < 0:
            # In-progress: T_{i-1}_settle is past relative to val_settle.
            #
            # payoff = (S_t + H_{T_{i-1}->t}) / carry_df_end - S_{T_{i-1}}
            #
            # H_past = dividend income from T_{i-1}_settle to val_settle
            # valued at val_settle, using current scenario rates as proxy:
            #
            #   H_past = F_start * (1 - div_df_past) / carry_df_past
            #
            # dt_past = elapsed carry time from period-start settlement.
            dt_past = -t_s_fwd
            carry_df_past = carry_curve.discount_factor(dt_past)
            div_df_past = dividend_curve.discount_factor(dt_past)
            H_past = F_start * (1.0 - div_df_past) / carry_df_past
            period_payoff = (spot + H_past) / carry_df_end - F_start
        else:
            # Future period: forward dividends in [T_s_settle, T_e_settle].
            # Use forward div DFs (divided by df_div_t0) so they are anchored
            # at val_settle, consistent with the forward carry DF.
            df_div_s = dividend_curve.discount_factor(t_s_full)
            df_div_e = dividend_curve.discount_factor(t_e_full)
            if df_div_t0 is not None:
                div_df_start = df_div_s / df_div_t0
                div_df_end = df_div_e / df_div_t0
            else:
                div_df_start = df_div_s
                div_df_end = df_div_e
            d_fv = spot * (div_df_start - div_df_end) / carry_df_end
            period_payoff = F_end - F_start + d_fv

        # Discount to T_end (the scheduled payment date).
        # The settlement lag shifts only the carry period [val_settle, T_end_settle];
        # the cash payment remains at T_end, matching RiskFlow's Payment_Date field.
        df = discount_curve.discount_factor(t_e)
        if n_fixed is not None:
            # "Initial Price": fractional return * fixed notional.
            pv += n_fixed * (period_payoff / F_start) * df
        else:
            # "Price": absolute increment * fixed share count.
            pv += quantity * period_payoff * df

    return pv
