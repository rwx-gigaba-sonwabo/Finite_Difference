from __future__ import annotations

import numpy as np

from market_data.yield_curve import YieldCurve


def fx_forward_rate(
    fx_spot: np.ndarray,
    dom_curve: YieldCurve,
    for_curve: YieldCurve,
    T_pay: float,
    fx_settlement_T: float = 0.0,
) -> np.ndarray:
    """FX forward rate from the FX settlement date to the payment date.

    Uses covered interest-rate parity with continuously-compounded zero
    rates from ``dom_curve`` (domestic, e.g. ZAR-USD-BASIS) and
    ``for_curve`` (foreign, e.g. USD-SOFR).

    For FX quoted as *domestic / foreign* (e.g. ZAR/USD):

        FX_fwd(T) = FX_spot * DF_for(T) / DF_dom(T)

    When the observed FX spot settles at ``fx_settlement_T`` (rather than
    T+0) the formula is adjusted:

        FX_fwd(T_pay) = FX_spot
                        * DF_for(T_pay) * DF_dom(T_s)
                        / (DF_for(T_s)  * DF_dom(T_pay))

    which equals the forward from the settlement date T_s to T_pay,
    consistent with standard cross-currency arbitrage conditions.

    Parameters
    ----------
    fx_spot : np.ndarray, shape (n_paths,)
        FX spot rate (domestic / foreign, e.g. ZAR/USD).
    dom_curve : YieldCurve
        Domestic yield curve (e.g. ZAR-USD-BASIS).
    for_curve : YieldCurve
        Foreign yield curve (e.g. USD-SOFR).
    T_pay : float
        Year fraction from val_date to the payment date.
    fx_settlement_T : float
        Year fraction from val_date to the FX spot settlement date
        (e.g. T+2 business days for most FX markets).  Set to 0 to
        treat the market observable as a T+0 rate.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        FX forward rate at T_pay.
    """
    df_dom_pay = dom_curve.discount_factor(T_pay)   # (n_paths,)
    df_for_pay = for_curve.discount_factor(T_pay)   # (n_paths,)

    if fx_settlement_T > 0.0:
        df_dom_s = dom_curve.discount_factor(fx_settlement_T)  # (n_paths,)
        df_for_s = for_curve.discount_factor(fx_settlement_T)  # (n_paths,)
        return fx_spot * (df_for_pay * df_dom_s) / (df_for_s * df_dom_pay)
    else:
        return fx_spot * df_for_pay / df_dom_pay


def commodity_average_forward_pv(
    avg_price: np.ndarray,
    strike: float,
    notional: float,
    is_composite: bool,
    fx_spot: np.ndarray,
    dom_curve: YieldCurve,
    for_curve: YieldCurve,
    mm_curve: YieldCurve,
    T_pay: float,
    fx_settlement_T: float = 0.0,
    direction: int = 1,
) -> np.ndarray:
    """PV of a commodity average forward under the ZAR-CSA discounting framework.

    All payoffs are discounted using the money-market (ZAR-SWAP) curve
    regardless of contract denomination.  The ZAR-CSA adjustment converts
    the USD payoff to ZAR via the FX forward, discounts at the ZAR money
    market rate, then converts back to USD — which under no-arbitrage
    equates to discounting the USD payoff at the USD rate.

    **Standard contract** (USD underlying, USD-denominated payoff):

        payoff_USD  = direction * (avg_price - strike) * notional
        PV_ZAR      = payoff_USD * FX_fwd(T_pay) * DF_MM(T_pay)
        PV_USD      = PV_ZAR / FX_spot

    **Composite contract** (USD underlying, ZAR-denominated payoff/strike):

        payoff_ZAR  = direction * (avg_price * FX_fwd(T_pay) - strike_ZAR) * notional
        PV_ZAR      = payoff_ZAR * DF_MM(T_pay)

    Parameters
    ----------
    avg_price : np.ndarray, shape (n_paths,)
        Arithmetic average of commodity forward prices in USD per unit.
    strike : float
        Strike price.  In USD for a standard contract; in ZAR for a
        composite contract.
    notional : float
        Quantity (e.g. number of barrels).
    is_composite : bool
        If ``True``, the payoff currency is domestic (ZAR) and the
        strike is quoted in ZAR.  If ``False``, the payoff currency is
        foreign (USD) with ZAR-CSA discounting applied.
    fx_spot : np.ndarray, shape (n_paths,)
        FX spot rate (ZAR/USD, i.e. domestic / foreign).
    dom_curve : YieldCurve
        Domestic curve used in the FX forward calculation
        (ZAR-USD-BASIS).
    for_curve : YieldCurve
        Foreign curve used in the FX forward calculation (USD-SOFR).
    mm_curve : YieldCurve
        Money-market curve used for discounting all payoffs (ZAR-SWAP).
    T_pay : float
        Year fraction from val_date to the payment date.
    fx_settlement_T : float
        Year fraction from val_date to the FX spot settlement date
        (default 0 = T+0 spot convention).
    direction : int
        ``+1`` for a long position (receive avg, pay strike) or ``-1``
        for a short position (pay avg, receive strike).  Default ``+1``.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Present value per path.
        In USD for a standard contract; in ZAR for a composite contract.
    """
    fx_fwd = fx_forward_rate(
        fx_spot, dom_curve, for_curve, T_pay, fx_settlement_T,
    )                                       # (n_paths,)
    df_mm = mm_curve.discount_factor(T_pay) # (n_paths,)

    if is_composite:
        # Payoff denominated in ZAR
        payoff = direction * (avg_price * fx_fwd - strike) * notional  # (n_paths,)
        return payoff * df_mm
    else:
        # Payoff denominated in USD; apply ZAR-CSA adjustment
        payoff_usd = direction * (avg_price - strike) * notional        # (n_paths,)
        pv_zar = payoff_usd * fx_fwd * df_mm                           # (n_paths,)
        return pv_zar / fx_spot
