"""Benchmark volatility skew surface for equities.

Implements the Front Arena benchmark skew model with 9 parameters and
6 piecewise polynomial regions.  Supports sticky-strike and sticky-delta
moneyness conventions.

Each skew parameter is supplied as a numpy array of shape (n, 2) where
each row is [year_frac, value], representing a term structure by expiry
tenor.  Parameters are linearly interpolated (flat-extrapolated) to the
requested option expiry.
"""

from __future__ import annotations

import numpy as np


class BenchmarkVolSkew:
    """Benchmark skew volatility surface.

    Parameters
    ----------
    v0 : array-like, shape (n, 2)
        ATM (forward) volatility term structure.
    s : array-like, shape (n, 2)
        Slope term structure.
    L : array-like, shape (n, 2)
        Left curvature term structure.
    R : array-like, shape (n, 2)
        Right curvature term structure.
    C : array-like, shape (n, 2)
        Left cutoff term structure (values must be < 0).
    D : array-like, shape (n, 2)
        Right cutoff term structure (values must be > 0).
    lam : array-like, shape (n, 2)
        Left wing term structure (values must be > 0).
    rho : array-like, shape (n, 2)
        Right wing term structure (values must be > 0).
    atm_ref : array-like, shape (n, 2)
        ATM reference quote term structure.
    """

    def __init__(
        self,
        v0: np.ndarray,
        s: np.ndarray,
        L: np.ndarray,
        R: np.ndarray,
        C: np.ndarray,
        D: np.ndarray,
        lam: np.ndarray,
        rho: np.ndarray,
        atm_ref: np.ndarray,
    ):
        self.v0_term = self._sort_by_tenor(v0)
        self.s_term = self._sort_by_tenor(s)
        self.L_term = self._sort_by_tenor(L)
        self.R_term = self._sort_by_tenor(R)
        self.C_term = self._sort_by_tenor(C)
        self.D_term = self._sort_by_tenor(D)
        self.lam_term = self._sort_by_tenor(lam)
        self.rho_term = self._sort_by_tenor(rho)
        self.atm_ref_term = self._sort_by_tenor(atm_ref)

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _sort_by_tenor(term) -> np.ndarray:
        """Convert to array and sort rows by ascending tenor (column 0)."""
        arr = np.atleast_2d(np.asarray(term, dtype=np.float64))
        return arr[arr[:, 0].argsort()]

    @staticmethod
    def _interp_param(term: np.ndarray, tenor: float) -> float:
        """Linearly interpolate a parameter term structure to *tenor*."""
        tenors = term[:, 0]
        values = term[:, 1]
        return float(np.interp(tenor, tenors, values))

    @staticmethod
    def _interp_variance(term: np.ndarray, tenor: float) -> float:
        """Interpolate volatility linearly in variance (sigma^2 * T) space.

        Converts to total variance at each pillar, interpolates linearly,
        then converts back to volatility at the target tenor.
        """
        tenors = term[:, 0]
        vols = term[:, 1]
        variances = vols**2 * tenors
        var_at_tenor = float(np.interp(tenor, tenors, variances))
        if tenor <= 0:
            return float(vols[0])
        return float(np.sqrt(var_at_tenor / tenor))

    def _params_at_tenor(self, tenor: float) -> dict[str, float]:
        """Interpolate all 9 skew parameters to a single expiry *tenor*."""
        return {
            "v0": self._interp_param(self.v0_term, tenor),
            "s": self._interp_param(self.s_term, tenor),
            "L": self._interp_param(self.L_term, tenor),
            "R": self._interp_param(self.R_term, tenor),
            "C": self._interp_param(self.C_term, tenor),
            "D": self._interp_param(self.D_term, tenor),
            "lam": self._interp_param(self.lam_term, tenor),
            "rho": self._interp_param(self.rho_term, tenor),
            "atm_ref": self._interp_param(self.atm_ref_term, tenor),
        }

    # ------------------------------------------------------------------
    # wing calibration
    # ------------------------------------------------------------------

    @staticmethod
    def _left_wing(v0: float, s: float, L: float, C: float, lam: float):
        """Solve for left-wing quadratic coefficients (alpha, beta, gamma).

        Continuity of v and v' at x = C, plus v'((1+lam)*C) = 0.
        """
        gamma = -(s + 2 * L * C) / (2 * lam * C)
        beta = -2 * gamma * (1 + lam) * C
        alpha = v0 + s * C + L * C**2 - beta * C - gamma * C**2
        return alpha, beta, gamma

    @staticmethod
    def _right_wing(v0: float, s: float, R: float, D: float, rho: float):
        """Solve for right-wing quadratic coefficients (varsigma, xi, zeta).

        Continuity of v and v' at x = D, plus v'((1+rho)*D) = 0.
        """
        zeta = -(s + 2 * R * D) / (2 * rho * D)
        xi = -2 * zeta * (1 + rho) * D
        varsigma = v0 + s * D + R * D**2 - xi * D - zeta * D**2
        return varsigma, xi, zeta

    # ------------------------------------------------------------------
    # moneyness
    # ------------------------------------------------------------------

    @staticmethod
    def log_moneyness(
        strike: float | np.ndarray,
        atm_ref: float,
        forward_skew: float | np.ndarray | None = None,
        forward_expiry: float | np.ndarray | None = None,
        sticky: str = "strike",
    ) -> float | np.ndarray:
        """Compute log-moneyness *x*.

        Parameters
        ----------
        strike : float or array
            Option strike(s).
        atm_ref : float
            ATM reference quote for this tenor.
        forward_skew : float or array, optional
            Risk-neutral forward at the skew tenor.  Required for
            ``sticky='delta'``.
        forward_expiry : float or array, optional
            Risk-neutral forward at option expiry.  Required for
            ``sticky='delta'``.
        sticky : {'strike', 'delta'}
            Moneyness convention.

        Returns
        -------
        x : float or np.ndarray
        """
        if sticky == "strike":
            return np.log(strike / atm_ref)
        elif sticky == "delta":
            if forward_skew is None or forward_expiry is None:
                raise ValueError(
                    "forward_skew and forward_expiry are required for sticky='delta'"
                )
            return np.log(strike / atm_ref * forward_skew / forward_expiry)
        else:
            raise ValueError(f"Unknown sticky rule: {sticky!r}")

    # ------------------------------------------------------------------
    # piecewise evaluation
    # ------------------------------------------------------------------

    @staticmethod
    def _evaluate(
        x: float | np.ndarray,
        v0: float,
        s: float,
        L: float,
        R: float,
        C: float,
        D: float,
        lam: float,
        rho: float,
    ) -> np.ndarray:
        """Evaluate the benchmark skew at log-moneyness *x*.

        Returns volatility as an ndarray broadcastable to the shape of *x*.
        """
        x = np.asarray(x, dtype=np.float64)
        scalar = x.ndim == 0
        x = np.atleast_1d(x)

        has_left_wing = (lam != 0) and (C != 0)
        has_right_wing = (rho != 0) and (D != 0)

        if has_left_wing:
            alpha, beta, gamma = BenchmarkVolSkew._left_wing(v0, s, L, C, lam)
            lam_C = (1 + lam) * C
        else:
            lam_C = C

        if has_right_wing:
            varsigma, xi, zeta = BenchmarkVolSkew._right_wing(v0, s, R, D, rho)
            rho_D = (1 + rho) * D
        else:
            rho_D = D

        vol = np.empty_like(x)

        if has_left_wing:
            # Region I:  x < (1+lam)*C  — flat left wing
            m1 = x < lam_C
            vol[m1] = alpha + beta * lam_C + gamma * lam_C**2

            # Region II: (1+lam)*C <= x < C
            m2 = (x >= lam_C) & (x < C)
            vol[m2] = alpha + beta * x[m2] + gamma * x[m2] ** 2
        else:
            # No wing — flat-extrapolate the left quadratic at C
            m1 = x < C
            vol[m1] = v0 + s * C + L * C**2

        # Region III: C <= x < 0
        m3 = (x >= C) & (x < 0)
        vol[m3] = v0 + s * x[m3] + L * x[m3] ** 2

        # Region IV: 0 <= x < D
        m4 = (x >= 0) & (x < D)
        vol[m4] = v0 + s * x[m4] + R * x[m4] ** 2

        if has_right_wing:
            # Region V: D <= x < (1+rho)*D
            m5 = (x >= D) & (x < rho_D)
            vol[m5] = varsigma + xi * x[m5] + zeta * x[m5] ** 2

            # Region VI: x >= (1+rho)*D  — flat right wing
            m6 = x >= rho_D
            vol[m6] = varsigma + xi * rho_D + zeta * rho_D**2
        else:
            # No wing — flat-extrapolate the right quadratic at D
            m6 = x >= D
            vol[m6] = v0 + s * D + R * D**2

        if scalar:
            return vol[0]
        return vol

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def _vol_from_params(
        self,
        strike: float | np.ndarray,
        params: dict[str, float],
        forward_skew: float | np.ndarray | None,
        forward_expiry: float | np.ndarray | None,
        sticky: str,
    ) -> np.ndarray:
        """Evaluate implied vol for *strike* given a fully-specified params dict."""
        x = self.log_moneyness(
            strike,
            params["atm_ref"],
            forward_skew=forward_skew,
            forward_expiry=forward_expiry,
            sticky=sticky,
        )
        return self._evaluate(
            x,
            v0=params["v0"],
            s=params["s"],
            L=params["L"],
            R=params["R"],
            C=params["C"],
            D=params["D"],
            lam=params["lam"],
            rho=params["rho"],
        )

    def get_vol(
        self,
        strike: float | np.ndarray,
        tenor: float,
        forward_skew: float | np.ndarray | None = None,
        forward_expiry: float | np.ndarray | None = None,
        sticky: str = "strike",
    ) -> np.ndarray:
        """Return implied volatility for a given strike and expiry tenor.

        The two skew-pillar dates that bracket *tenor* (from the v0 term
        structure) are used to build two complete skews.  Log-moneyness is
        computed separately for each pillar using its own ``atm_ref``.  The
        resulting pair of implied volatilities is then interpolated to
        *tenor* linearly in total-variance space.  When *tenor* falls
        exactly on a pillar date that pillar's skew is used directly with
        no interpolation.  Flat extrapolation is applied outside the pillar
        range.

        Parameters
        ----------
        strike : float or array
            Option strike price(s).
        tenor : float
            Time to expiry in year fractions.
        forward_skew : float or array, optional
            Risk-neutral forward at the skew tenor (needed for sticky delta).
        forward_expiry : float or array, optional
            Risk-neutral forward at option expiry (needed for sticky delta).
        sticky : {'strike', 'delta'}
            Stickiness convention.  Default ``'strike'``.

        Returns
        -------
        np.ndarray
            Implied volatility, same shape as *strike*.
        """
        pillar_tenors = self.v0_term[:, 0]
        idx = int(np.searchsorted(pillar_tenors, tenor))

        # Flat extrapolation before (or exactly on) the first pillar
        if idx == 0:
            p = self._params_at_tenor(pillar_tenors[0])
            return self._vol_from_params(strike, p, forward_skew, forward_expiry, sticky)

        # Flat extrapolation beyond the last pillar
        if idx == len(pillar_tenors):
            p = self._params_at_tenor(pillar_tenors[-1])
            return self._vol_from_params(strike, p, forward_skew, forward_expiry, sticky)

        t2 = float(pillar_tenors[idx])

        # Exactly on a pillar — no interpolation needed
        if np.isclose(tenor, t2):
            p = self._params_at_tenor(t2)
            return self._vol_from_params(strike, p, forward_skew, forward_expiry, sticky)

        # Tenor lies strictly between two pillars
        t1 = float(pillar_tenors[idx - 1])
        p1 = self._params_at_tenor(t1)
        p2 = self._params_at_tenor(t2)

        vol1 = self._vol_from_params(strike, p1, forward_skew, forward_expiry, sticky)
        vol2 = self._vol_from_params(strike, p2, forward_skew, forward_expiry, sticky)

        # Interpolate linearly in total-variance space
        var1 = vol1 ** 2 * t1
        var2 = vol2 ** 2 * t2
        w = (tenor - t1) / (t2 - t1)
        var_tenor = var1 + w * (var2 - var1)

        #ans = np.sqrt(np.maximum(var_tenor, 0.0) / tenor) # linear variance

        ans = vol1 + ((tenor - t1)*((vol2 - vol1)/(t2 - t1))) # linear volatility

        return ans

import numpy as np
from scipy.optimize import brentq
from scipy.stats import norm


class MalzVol:
    """FX volatility surface parameterized by market delta-quoted vols.

    Input is a list of [delta, tenor, vol] triples where delta is the
    option delta (e.g. 0.25 for 25-delta call, -0.25 for 25-delta put,
    ±0.5 for ATM).

    At construction the delta-quoted surface is converted to a
    log-moneyness x = ln(F/K) grid via Malz root-finding, matching the
    approach in riskflow's FXVol risk factor.  The resulting per-pillar
    grid is stored as (x_nodes, vols) and used at runtime.

    Interpolation scheme
    --------------------
    - **Moneyness** : linear in x = ln(F/K), flat-extrapolated at wings.
    - **Tenor**     : linear in total variance (sigma^2 * T), flat-extrapolated.

    Parameters
    ----------
    surface : list of [delta, tenor, vol]
        Market delta-quoted surface points.
    tol : float
        Maximum acceptable |sigma_exact - sigma_interp| error on the
        adaptive x-grid.  Defaults to 1e-4 (same as riskflow).
    """

    _INITIAL_X_GRID = np.array([-0.5, -0.25, -0.1, 0.0, 0.1, 0.25, 0.5])

    def __init__(self, surface: list, tol: float = 1e-4) -> None:
        arr = np.asarray(surface, dtype=np.float64)  # (N, 3): [delta, tenor, vol]
        self._tenors = np.unique(arr[:, 1])

        # Build per-expiry skew dicts from raw delta-quoted input
        malz_skews = {}
        for T in self._tenors:
            rows = arr[arr[:, 1] == T]
            idx = np.argsort(rows[:, 0])
            malz_skews[T] = self._prepare_malz_skew(
                {"delta": rows[idx, 0], "vol": rows[idx, 2].clip(min=1e-4)}, T
            )

        # Convert each expiry to a log-moneyness total-variance grid
        w_table = self._build_x_grid(malz_skews, self._tenors, tol)

        # Store per-pillar (x_nodes, vols) for runtime interpolation
        self._pillars: dict[float, tuple[np.ndarray, np.ndarray]] = {}
        for T in self._tenors:
            w = w_table[T]
            x_nodes = np.array(sorted(w.keys()))
            variance = np.array([w[x] for x in x_nodes])
            self._pillars[T] = (x_nodes, np.sqrt(variance / T))

    # ------------------------------------------------------------------
    # Malz inversion helpers  (offline, run once at construction)
    # ------------------------------------------------------------------

    @staticmethod
    def _prepare_malz_skew(skew: dict, T: float) -> dict:
        """Normalise a delta-quoted smile slice for one expiry.

        Identifies the ATM vol from the ±0.5 delta label, replaces it
        with the true forward-delta ATM magnitude, mirrors ATM to both
        wings if only one side was supplied, then splits into put/call
        arrays for use by _sigma_exact.
        """
        d = np.asarray(skew["delta"], dtype=float)
        v = np.asarray(skew["vol"],   dtype=float)

        p05 = np.where(np.isclose(d,  0.5))[0]
        m05 = np.where(np.isclose(d, -0.5))[0]
        if p05.size:
            sigma_atm = float(v[p05[0]])
        elif m05.size:
            sigma_atm = float(v[m05[0]])
        else:
            raise ValueError("Malz skew missing ATM label (delta = ±0.5).")

        # True pct-of-foreign forward-delta ATM: Δ_atm = 0.5 * exp(-0.5*σ²*T)
        delta_atm = 0.5 * np.exp(-0.5 * sigma_atm * sigma_atm * T)

        # Replace vendor ±0.5 labels with corrected ±delta_atm
        new_d, new_v = [], []
        for di, vi in zip(d, v):
            if np.isclose(di,  0.5):
                new_d.append(+delta_atm); new_v.append(vi)
            elif np.isclose(di, -0.5):
                new_d.append(-delta_atm); new_v.append(vi)
            else:
                new_d.append(di); new_v.append(vi)
        d, v = np.asarray(new_d), np.asarray(new_v)

        # Mirror ATM node to whichever wing was not supplied
        if not np.any(d < 0) or not np.any(np.isclose(d, -delta_atm)):
            d = np.append(d, -delta_atm); v = np.append(v, sigma_atm)
        if not np.any(d > 0) or not np.any(np.isclose(d, +delta_atm)):
            d = np.append(d, +delta_atm); v = np.append(v, sigma_atm)

        idx = np.argsort(d)
        d, v = d[idx], v[idx]

        return {
            "d_put":  d[d <= 0.0], "v_put":  v[d <= 0.0],
            "d_call": d[d >= 0.0], "v_call": v[d >= 0.0],
            "sigma_atm": sigma_atm,
            "delta_atm": delta_atm,
        }

    @staticmethod
    def _sigma_exact(skew: dict, T: float, x: float) -> float:
        """Implied vol at log-moneyness x = ln(F/K) via Malz root-finding.

        Solves for the delta δ* such that the pct-of-foreign forward delta
        computed from σ(δ*) equals δ* itself, giving the self-consistent
        implied vol at x.
        """
        sqrtT = np.sqrt(T)
        sigma_atm = skew["sigma_atm"]
        # ATM log-moneyness: x_atm = 0.5*σ_atm²*T  (d1 = d2 + σ√T, delta_atm = N(d2)*K/F)
        x_atm  = 0.5 * sigma_atm * sigma_atm * T
        is_call = x <= x_atm

        d_wing = skew["d_call"] if is_call else skew["d_put"]
        v_wing = skew["v_call"] if is_call else skew["v_put"]

        def sigma_from_delta(delta: float) -> float:
            return float(np.interp(delta, d_wing, v_wing))

        def fwd_delta(sigma: float) -> float:
            d1 = (x + 0.5 * sigma * sigma * T) / (sigma * sqrtT)
            d2 = d1 - sigma * sqrtT
            k_over_f = np.exp(-x)
            return k_over_f * norm.cdf(d2) if is_call else -k_over_f * norm.cdf(-d2)

        def residual(delta: float) -> float:
            return fwd_delta(sigma_from_delta(delta)) - delta

        a = max(0.0, d_wing.min()) if is_call else d_wing.min()
        b = d_wing.max()           if is_call else min(0.0, d_wing.max())

        fa, fb = residual(a), residual(b)
        if fa * fb > 0:
            delta_star = a if abs(fa) < abs(fb) else b
        else:
            delta_star = brentq(residual, a, b)

        return sigma_from_delta(delta_star)

    def _build_x_grid(
        self, malz_skews: dict, expiries: np.ndarray, tol: float
    ) -> dict:
        """Build an adaptive log-moneyness total-variance grid per expiry.

        Starts from _INITIAL_X_GRID and iteratively bisects intervals
        where the linear-in-variance interpolation error exceeds tol,
        matching riskflow's _build_maltz_x_grid.
        """
        # Seed total-variance table at initial x points for every expiry
        w_table: dict[float, dict] = {}
        for T in expiries:
            w_table[T] = {}
            for x in self._INITIAL_X_GRID:
                s = self._sigma_exact(malz_skews[T], T, x)
                w_table[T][x] = s * s * T

        for T in expiries:
            skew = malz_skews[T]
            w    = w_table[T]
            x_nodes = np.array(sorted(w))
            while True:
                # Midpoints and their exact vols
                candidates = np.array([
                    [0.5 * (xl + xr), self._sigma_exact(skew, T, 0.5 * (xl + xr))]
                    for xl, xr in zip(x_nodes[:-1], x_nodes[1:])
                ])
                # Compare exact vols against linear-in-variance interpolation
                x_sorted = np.array(sorted(w))
                w_sorted = np.array([w[xi] for xi in x_sorted])
                var_interp  = np.interp(candidates[:, 0], x_sorted, w_sorted)
                sigma_interp = np.sqrt(np.maximum(var_interp, 0.0) / T)
                err = np.abs(candidates[:, 1] - sigma_interp)

                if err.max() <= tol:
                    break

                for xm, sm in candidates[err > tol]:
                    w[xm] = sm * sm * T
                x_nodes = np.array(sorted(w))

        return w_table

    # ------------------------------------------------------------------
    # Runtime interpolation helpers
    # ------------------------------------------------------------------

    def _vol_at_pillar(self, t: float, x: np.ndarray) -> np.ndarray:
        """Linear interp (flat-extrapolate) in log-moneyness at tenor pillar t."""
        x_nodes, vols = self._pillars[t]
        return np.interp(x, x_nodes, vols)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_vol(
        self,
        strike:  float | np.ndarray,
        forward: float | np.ndarray,
        tenor:   float,
    ) -> float | np.ndarray:
        """Return implied volatility by 2-D interpolation.

        Parameters
        ----------
        strike  : option strike price(s)
        forward : risk-neutral forward price(s) at expiry
        tenor   : time to expiry in year fractions

        Returns
        -------
        Implied volatility, same shape as *strike* / *forward*.
        """
        x = np.log(np.asarray(forward, dtype=float) / np.asarray(strike, dtype=float))

        tenors = self._tenors
        idx    = int(np.searchsorted(tenors, tenor))

        # Flat extrapolation outside the pillar range
        if idx == 0:
            return self._vol_at_pillar(float(tenors[0]), x)
        if idx == len(tenors):
            return self._vol_at_pillar(float(tenors[-1]), x)

        t2 = float(tenors[idx])
        if np.isclose(tenor, t2):
            return self._vol_at_pillar(t2, x)

        t1   = float(tenors[idx - 1])
        vol1 = self._vol_at_pillar(t1, x)
        vol2 = self._vol_at_pillar(t2, x)

        # Linear interpolation in total-variance space (riskflow Malz branch)
        var1  = vol1 ** 2 * t1
        var2  = vol2 ** 2 * t2
        alpha = (tenor - t1) / (t2 - t1)
        var   = var1 * (1.0 - alpha) + var2 * alpha

        return np.sqrt(np.maximum(var, 0.0) / tenor)


class IRVol:
    """Interest rate volatility surface for swaptions and caps/floors.

    Input data is a list of [moneyness, swaption_expiry, swap_maturity, vol] quads.

    Interpolation order: swap_maturity → swaption_expiry → moneyness.
    All interpolation is linear on volatility with flat extrapolation outside
    the surface range.

    Parameters
    ----------
    vol_data : list of [moneyness, swaption_expiry, swap_maturity, vol]
        Surface quotes.  Moneyness convention is caller-defined (e.g. absolute
        strike, log-moneyness, or offset from ATM) — IRVol treats it as an
        opaque numeric axis.
    """

    def __init__(self, vol_data: list) -> None:
        arr = np.asarray(vol_data, dtype=np.float64)  # (N, 4)
        self._maturities = np.unique(arr[:, 2])

        # {maturity: {expiry: (moneyness_nodes, vol_nodes)}}
        self._surface: dict[float, dict[float, tuple[np.ndarray, np.ndarray]]] = {}

        for mat in self._maturities:
            mat_rows = arr[np.isclose(arr[:, 2], mat)]
            expiries = np.unique(mat_rows[:, 1])
            self._surface[float(mat)] = {}
            for exp in expiries:
                exp_rows = mat_rows[np.isclose(mat_rows[:, 1], exp)]
                order = np.argsort(exp_rows[:, 0])
                self._surface[float(mat)][float(exp)] = (
                    exp_rows[order, 0],
                    exp_rows[order, 3],
                )

    # ------------------------------------------------------------------
    # Internal helpers — each interpolates one fewer dimension
    # ------------------------------------------------------------------

    def _vol_at_expiry_maturity(
        self,
        moneyness: float | np.ndarray,
        expiry: float,
        maturity: float,
    ) -> np.ndarray:
        """Linear interp in moneyness (flat-extrapolate) at exact (expiry, maturity)."""
        m_nodes, v_nodes = self._surface[maturity][expiry]
        return np.interp(np.asarray(moneyness, dtype=float), m_nodes, v_nodes)

    def _vol_at_maturity(
        self,
        moneyness: float | np.ndarray,
        swaption_expiry: float,
        maturity: float,
    ) -> np.ndarray:
        """Linear interp in swaption_expiry → moneyness at an exact maturity."""
        expiries = np.array(sorted(self._surface[maturity].keys()))
        idx = int(np.searchsorted(expiries, swaption_expiry))

        if idx == 0:
            return self._vol_at_expiry_maturity(moneyness, float(expiries[0]), maturity)
        if idx == len(expiries):
            return self._vol_at_expiry_maturity(moneyness, float(expiries[-1]), maturity)

        e2 = float(expiries[idx])
        if np.isclose(swaption_expiry, e2):
            return self._vol_at_expiry_maturity(moneyness, e2, maturity)

        e1 = float(expiries[idx - 1])
        v1 = self._vol_at_expiry_maturity(moneyness, e1, maturity)
        v2 = self._vol_at_expiry_maturity(moneyness, e2, maturity)
        w = (swaption_expiry - e1) / (e2 - e1)
        return v1 + w * (v2 - v1)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_vol(
        self,
        moneyness: float | np.ndarray,
        swaption_expiry: float,
        swap_maturity: float,
    ) -> float | np.ndarray:
        """Return interpolated swaption / cap / floor volatility.

        Parameters
        ----------
        moneyness : float or array
            Strike moneyness (convention matches the input data).
        swaption_expiry : float
            Time to swaption expiry in year fractions.
        swap_maturity : float
            Underlying swap (or caplet) maturity in year fractions.

        Returns
        -------
        float or np.ndarray
            Implied volatility, same shape as *moneyness*.
        """
        maturities = self._maturities
        idx = int(np.searchsorted(maturities, swap_maturity))

        if idx == 0:
            return self._vol_at_maturity(moneyness, swaption_expiry, float(maturities[0]))
        if idx == len(maturities):
            return self._vol_at_maturity(moneyness, swaption_expiry, float(maturities[-1]))

        m2 = float(maturities[idx])
        if np.isclose(swap_maturity, m2):
            return self._vol_at_maturity(moneyness, swaption_expiry, m2)

        m1 = float(maturities[idx - 1])
        v1 = self._vol_at_maturity(moneyness, swaption_expiry, m1)
        v2 = self._vol_at_maturity(moneyness, swaption_expiry, m2)
        w = (swap_maturity - m1) / (m2 - m1)
        return v1 + w * (v2 - v1)


class NonPreciousCommodityVol:
    """Volatility surface for non-precious commodity options.

    Input data is a list of [moneyness, tenor, vol] triples where moneyness
    is defined as (K - F(t)) / F(t).

    Interpolation order: tenor → moneyness.  Both dimensions use linear
    interpolation on volatility with flat extrapolation outside the surface.

    Parameters
    ----------
    vol_data : list of [moneyness, tenor, vol]
        Surface quotes.
    """

    def __init__(self, vol_data: list) -> None:
        arr = np.asarray(vol_data, dtype=np.float64)  # (N, 3)
        self._tenors = np.unique(arr[:, 1])

        # {tenor: (moneyness_nodes, vol_nodes)}
        self._pillars: dict[float, tuple[np.ndarray, np.ndarray]] = {}
        for t in self._tenors:
            rows = arr[np.isclose(arr[:, 1], t)]
            order = np.argsort(rows[:, 0])
            self._pillars[float(t)] = (rows[order, 0], rows[order, 2])

    def _vol_at_tenor(
        self,
        moneyness: float | np.ndarray,
        tenor: float,
    ) -> np.ndarray:
        """Linear interp in moneyness (flat-extrapolate) at an exact tenor."""
        m_nodes, v_nodes = self._pillars[tenor]
        return np.interp(np.asarray(moneyness, dtype=float), m_nodes, v_nodes)

    def get_vol(
        self,
        strike: float | np.ndarray,
        forward: float | np.ndarray,
        tenor: float,
    ) -> float | np.ndarray:
        """Return interpolated implied volatility.

        Parameters
        ----------
        strike : float or array
            Option strike(s).
        forward : float or array
            Forward price(s) F(t) at the option expiry.
        tenor : float
            Time to expiry in year fractions.

        Returns
        -------
        float or np.ndarray
            Implied volatility, same shape as *strike* / *forward*.
        """
        moneyness = (np.asarray(strike, dtype=float) - np.asarray(forward, dtype=float)) / np.asarray(forward, dtype=float)

        tenors = self._tenors
        idx = int(np.searchsorted(tenors, tenor))

        if idx == 0:
            return self._vol_at_tenor(moneyness, float(tenors[0]))
        if idx == len(tenors):
            return self._vol_at_tenor(moneyness, float(tenors[-1]))

        t2 = float(tenors[idx])
        if np.isclose(tenor, t2):
            return self._vol_at_tenor(moneyness, t2)

        t1 = float(tenors[idx - 1])
        v1 = self._vol_at_tenor(moneyness, t1)
        v2 = self._vol_at_tenor(moneyness, t2)
        w = (tenor - t1) / (t2 - t1)
        return v1 + w * (v2 - v1)


class SimpleSkew:
    """Lightweight (strike, vol) smile -- linear interpolation in strike
    space with flat extrapolation beyond the quoted range.

    For desks that don't maintain a full calibrated :class:`BenchmarkVolSkew`
    surface (9 parameters, term structure) for every commodity: pass as few
    as two or three (strike, vol) quotes -- e.g. an ATM vol plus one wing
    point either side -- and get a usable local skew slope out of it. This
    is deliberately single-tenor (build one ``SimpleSkew`` per tenor bucket
    relevant to the trade; it does not interpolate across tenors -- no
    market convention was specified for blending smiles across expiries at
    this weight class of input).

    ``get_vol(strike, tenor=None)`` matches :meth:`BenchmarkVolSkew.get_vol`'s
    calling convention exactly (``tenor`` accepted and ignored, purely for
    duck-type interchangeability at existing call sites such as
    ``instruments.commodity_digital_option.CommodityDigitalOption`` and
    ``instruments.commodity_digital_barrier_option.CommodityDigitalBarrierOption``,
    which always call ``vol_skew.get_vol(strike=K, tenor=T)``).

    Parameters
    ----------
    strikes : array-like
        Quoted strikes, strictly increasing.
    vols : array-like
        Implied volatility at each strike (same convention as
        ``BenchmarkVolSkew`` -- annualised Black vol, e.g. 0.30 for 30%).
    """

    def __init__(self, strikes, vols) -> None:
        self.strikes = np.asarray(strikes, dtype=np.float64)
        self.vols = np.asarray(vols, dtype=np.float64)
        if self.strikes.shape != self.vols.shape:
            raise ValueError(
                f"strikes ({self.strikes.shape}) and vols ({self.vols.shape}) "
                "must have the same shape"
            )
        if self.strikes.size < 1:
            raise ValueError("SimpleSkew needs at least one (strike, vol) quote")
        if self.strikes.size > 1 and not np.all(np.diff(self.strikes) > 0):
            raise ValueError("strikes must be strictly increasing")

    def get_vol(
        self,
        strike: float | np.ndarray,
        tenor: float | None = None,
    ) -> float | np.ndarray:
        """Interpolated implied volatility at *strike*.

        ``tenor`` is accepted for interface compatibility with
        ``BenchmarkVolSkew.get_vol`` and ignored (single-tenor by design).
        """
        strike_arr = np.asarray(strike, dtype=np.float64)
        result = np.interp(strike_arr, self.strikes, self.vols)
        if np.isscalar(strike) or strike_arr.ndim == 0:
            return float(result)
        return result