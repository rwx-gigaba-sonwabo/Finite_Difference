from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Union

import numpy as np


class RiskFactorType(Enum):
    SCALAR = "scalar"
    CURVE = "curve"
    SURFACE = "surface"


@dataclass(frozen=True)
class ScalarSlice:
    """A scalar risk factor at one time step: shape (n_paths,)."""
    values: np.ndarray

    def __post_init__(self):
        object.__setattr__(self, 'values', np.atleast_1d(np.asarray(self.values, dtype=np.float64)))


@dataclass(frozen=True)
class CurveSlice:
    """A curve risk factor at one time step: shape (n_paths, n_tenors).

    Accepts 1D input (n_tenors,) for standalone / single-path use — normalised
    to (1, n_tenors) automatically so downstream pricing code is unchanged.
    """
    values: np.ndarray
    tenors: np.ndarray

    def __post_init__(self):
        object.__setattr__(self, 'values', np.atleast_2d(np.asarray(self.values, dtype=np.float64)))


@dataclass(frozen=True)
class SurfaceSlice:
    """A surface risk factor at one time step: shape (n_paths, n_tenors, n_strikes)."""
    values: np.ndarray
    tenors: np.ndarray
    strikes: np.ndarray


RiskFactorSlice = Union[ScalarSlice, CurveSlice, SurfaceSlice]


@dataclass(frozen=True)
class FactorSpec:
    """Metadata about a stored risk factor in the ScenarioCube."""
    factor_type: RiskFactorType
    tenors: np.ndarray | None = None
    strikes: np.ndarray | None = None
