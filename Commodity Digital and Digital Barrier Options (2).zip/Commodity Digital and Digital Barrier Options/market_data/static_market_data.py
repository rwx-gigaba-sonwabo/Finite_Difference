from __future__ import annotations

from dataclasses import dataclass, field

from market_data.risk_factor import RiskFactorSlice


@dataclass
class StaticMarketData:
    """Path-invariant market data that supplements a ScenarioCube.

    Contains deterministic risk factors (e.g. recovery rates, basis
    spreads) that are **frozen** across all simulation dates — the same
    slice is merged into every time step.

    When merged into a time slice, stochastic cube factors take
    precedence on name collision.

    .. note::
        For deterministic curves that need to **evolve through time**
        (e.g. a credit/hazard curve rolled forward to each simulation
        date), use ``generate_static_curve_scenarios`` from
        ``market_data.static_curve`` and add the result to the
        ScenarioCube via ``add_curve_factor``.  That ensures the curve
        is correctly forward-rolled at each time step.

    Parameters
    ----------
    factors : dict[str, RiskFactorSlice]
        Mapping from factor name to its static slice.
        CurveSlice values can be 1D (n_tenors,) — they are
        automatically normalised to (1, n_tenors) and numpy
        broadcasting handles the path dimension.
    """

    factors: dict[str, RiskFactorSlice] = field(default_factory=dict)
