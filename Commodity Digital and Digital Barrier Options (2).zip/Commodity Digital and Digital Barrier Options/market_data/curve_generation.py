"""
Static (deterministic) curve scenario generator.

Generates forward curves at each simulation date by rolling forward
on a given zero-rate / hazard-rate term structure.  All paths receive
the same curve (no stochastic variation).

Typical use case: credit (hazard rate) curves that are not simulated
stochastically but still need to be present in the ScenarioCube so the
CDS pricer can consume them.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from market_data.yield_curve import YieldCurve


def hazard_rates_from_default_probs(
    default_prob_curve: list[list[float]] | np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Convert cumulative default probabilities to continuous hazard rates.

    Parameters
    ----------
    default_prob_curve : list or array, shape (n_tenors, 2)
        Each row is [year_fraction, cumulative_default_probability].
        E.g. [[0.25, 0.001], [0.5, 0.003], [1.0, 0.008], ...]

    Returns
    -------
    tenors : np.ndarray, shape (n_tenors,)
        Pillar year fractions (sorted ascending).
    rates : np.ndarray, shape (n_tenors,)
        Continuous hazard rates at each pillar, suitable for
        ``generate_static_curve_scenarios``.
    """
    arr = np.asarray(default_prob_curve, dtype=np.float64)
    tenors = arr[:, 0]
    pds = arr[:, 1]

    # Sort by tenor
    order = np.argsort(tenors)
    tenors = tenors[order]
    pds = pds[order]

    # Drop t=0 point (no information; avoids division by zero)
    positive = tenors > 0.0
    tenors = tenors[positive]
    pds = pds[positive]

    if len(tenors) == 0:
        raise ValueError("No positive tenors after removing t=0 point")
    # S(t) = 1 - PD(t) = exp(-h(t) * t)  =>  h(t) = -ln(1 - PD(t)) / t
    rates = -np.log(1.0 - pds) / tenors

    return tenors, rates


def hazard_rates_from_ht(
    ht_curve: list[list[float]] | np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Convert continuous hazard-rate * year-fraction values to hazard rates.

    Parameters
    ----------
    ht_curve : list or array, shape (n_tenors, 2)
        Each row is [year_fraction, h(t)*t] where h(t) is the continuous
        Act/365 hazard rate and t is the year fraction.
        E.g. [[0.25, 0.0004], [0.5, 0.0015], [1.0, 0.008], ...]

    Returns
    -------
    tenors : np.ndarray, shape (n_tenors,)
        Pillar year fractions (sorted ascending).
    rates : np.ndarray, shape (n_tenors,)
        Continuous hazard rates at each pillar, suitable for
        ``generate_static_curve_scenarios``.
    """
    arr = np.asarray(ht_curve, dtype=np.float64)
    tenors = arr[:, 0]
    ht = arr[:, 1]

    # Sort by tenor
    order = np.argsort(tenors)
    tenors = tenors[order]
    ht = ht[order]

    # Drop t=0 point (no information; avoids division by zero)
    positive = tenors > 0.0
    tenors = tenors[positive]
    ht = ht[positive]

    if len(tenors) == 0:
        raise ValueError("No positive tenors after removing t=0 point")

    # h(t) * t is given directly, so h(t) = (h(t)*t) / t
    rates = ht / tenors

    return tenors, rates


def generate_static_curve_scenarios(
    rates: np.ndarray,
    tenors: np.ndarray,
    simulation_dates: tuple[date, ...],
    valuation_date: date,
    output_tenors: np.ndarray,
    n_paths: int,
    interpolator: Callable,
    day_count: str = "ACT/365",
    frozen: bool = False,
) -> tuple[np.ndarray, np.ndarray, tuple[date, ...]]:
    """
    Roll a zero-rate curve forward to each simulation date (deterministic).

    Given continuous zero rates r(t) at pillar tenors from the valuation
    date, compute forward zero rates at each simulation date T:

        r_fwd(τ) = (r(T+τ)·(T+τ) − r(T)·T) / τ

    where τ is the output tenor.  The result is broadcast identically
    across all paths.

    Parameters
    ----------
    rates : np.ndarray, shape (n_tenors,)
        Continuous zero rates (e.g. hazard rates) at each pillar tenor,
        as of valuation_date.
    tenors : np.ndarray, shape (n_tenors,)
        Pillar year fractions corresponding to *rates* (ACT/365).
    simulation_dates : tuple[date, ...]
        Dates at which to generate the forward curve.
    valuation_date : date
        Reference date for the input curve.
    output_tenors : np.ndarray, shape (n_output_tenors,)
        Year fractions at which to report the forward curve at each
        simulation date.
    n_paths : int
        Number of paths (all identical).
    interpolator : callable
        Interpolation factory with signature (year_fracs, rates) -> callable.
    day_count : str
        Day-count convention for computing year fractions to simulation
        dates.  Default ``"ACT/365"``.
    frozen : bool
        If True, the same spot curve is returned at every simulation date
        (no forward-rate roll).  Useful for keeping a credit/survival
        curve static through time.  Default ``False``.

    Returns
    -------
    paths : np.ndarray, shape (n_paths, n_times, n_output_tenors)
        Forward zero rates, ready for ``ScenarioCubeBuilder.add_curve_factor``.
    output_tenors : np.ndarray, shape (n_output_tenors,)
        The output tenor grid (pass-through for convenience).
    simulation_dates : tuple[date, ...]
        The simulation dates (pass-through for convenience).
    """
    tenors = np.asarray(tenors, dtype=np.float64)
    rates_1d = np.asarray(rates, dtype=np.float64)
    output_tenors = np.asarray(output_tenors, dtype=np.float64)

    # Build a 1-path curve handler for interpolation
    rates_2d = rates_1d[np.newaxis, :]  # (1, n_tenors)
    curve = YieldCurve(
        year_fracs=tenors,
        rates=rates_2d,
        interpolator=interpolator,
    )

    # Year fractions from valuation_date to each simulation date
    _DAY_COUNTS = {"ACT/365": 365.0, "ACT/360": 360.0}
    denom = _DAY_COUNTS[day_count]
    val_np = np.datetime64(valuation_date)

    n_times = len(simulation_dates)
    n_out = len(output_tenors)
    fwd_rates = np.empty((n_times, n_out), dtype=np.float64)

    if frozen:
        # Return the original spot curve at every simulation date
        r_spot = curve.get_rate(output_tenors)  # (1, n_out)
        fwd_rates[:] = r_spot[0, :]
    else:
        for i, sim_date in enumerate(simulation_dates):
            T = (np.datetime64(sim_date) - val_np).astype("timedelta64[D]").astype(np.float64) / denom

            if T <= 0.0:
                # At or before valuation: forward curve = spot curve
                r_out = curve.get_rate(output_tenors)  # (1, n_out)
                fwd_rates[i, :] = r_out[0, :]
            else:
                # r(T) · T
                r_T = curve.get_rate(T)  # (1,)
                rT_T = r_T[0] * T

                # r(T + τ) · (T + τ) for each output tenor τ
                total_t = T + output_tenors  # (n_out,)
                r_total = curve.get_rate(total_t)  # (1, n_out)
                rT_total = r_total[0, :] * total_t

                # Forward rate: (r(T+τ)(T+τ) - r(T)T) / τ
                fwd_rates[i, :] = (rT_total - rT_T) / output_tenors

    # Broadcast across all paths: (n_paths, n_times, n_output_tenors)
    paths = np.broadcast_to(fwd_rates[np.newaxis, :, :], (n_paths, n_times, n_out)).copy()

    return paths, output_tenors, simulation_dates
