"""
Scenario cube for storing Monte Carlo simulation results.

Supports scalar, curve, and surface risk factors with
immutable storage and efficient access by path, time, and factor.
"""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass
from datetime import date

import numpy as np

from market_data.risk_factor import (
    CurveSlice,
    FactorSpec,
    RiskFactorSlice,
    RiskFactorType,
    ScalarSlice,
    SurfaceSlice,
)


@dataclass(frozen=True)
class ScenarioCube:
    """
    Immutable storage for Monte Carlo simulation results.

    Stores simulated values organized by risk factor, path, and time.
    Risk factors can be scalar (2D), curve (3D), or surface (4D).

    Attributes:
        data: Factor name -> numpy array.
              Scalar: (n_paths, n_times)
              Curve:  (n_paths, n_times, n_tenors)
              Surface:(n_paths, n_times, n_tenors, n_strikes)
        factor_specs: Factor name -> FactorSpec with type and pillar metadata.
        factor_names: Ordered tuple of factor names.
        n_paths: Number of Monte Carlo paths.
        n_times: Number of time points.
        dates: Simulation dates.
        year_fractions: Year fractions from valuation date per time point.
        valuation_date: Reference date for the simulation.
    """

    data: dict[str, np.ndarray]
    factor_specs: dict[str, FactorSpec]
    factor_names: tuple[str, ...]
    n_paths: int
    n_times: int
    dates: tuple[date, ...]
    year_fractions: np.ndarray
    valuation_date: date

    def __post_init__(self):
        for arr in self.data.values():
            arr.flags.writeable = False
        object.__setattr__(
            self, "year_fractions", self.year_fractions.copy()
        )
        self.year_fractions.flags.writeable = False

    def get_time_slice(self, time_index: int) -> dict[str, RiskFactorSlice]:
        """
        Get all factor values at a specific time point across all paths.

        Returns dict mapping factor name to a typed slice:
        - ScalarSlice  with values shape (n_paths,)
        - CurveSlice   with values shape (n_paths, n_tenors)
        - SurfaceSlice with values shape (n_paths, n_tenors, n_strikes)
        """
        if not 0 <= time_index < self.n_times:
            raise IndexError(
                f"time_index {time_index} out of range [0, {self.n_times})"
            )

        result: dict[str, RiskFactorSlice] = {}
        for name in self.factor_names:
            spec = self.factor_specs[name]
            arr = self.data[name]

            if spec.factor_type == RiskFactorType.SCALAR:
                result[name] = ScalarSlice(values=arr[:, time_index])

            elif spec.factor_type == RiskFactorType.CURVE:
                result[name] = CurveSlice(
                    values=arr[:, time_index, :],
                    tenors=spec.tenors,
                )

            elif spec.factor_type == RiskFactorType.SURFACE:
                result[name] = SurfaceSlice(
                    values=arr[:, time_index, :, :],
                    tenors=spec.tenors,
                    strikes=spec.strikes,
                )

        return result

    def get_paths(self, factor_name: str) -> np.ndarray:
        """Get the raw array for a factor. Shape depends on factor type."""
        if factor_name not in self.data:
            raise KeyError(
                f"Factor '{factor_name}' not found. "
                f"Available factors: {list(self.factor_names)}"
            )
        return self.data[factor_name]

    def get_path_slice(self, path_index: int) -> dict[str, np.ndarray]:
        """
        Get all factor values for a specific path across all times.

        Returns dict mapping factor name to array with time as the first axis.
        """
        if not 0 <= path_index < self.n_paths:
            raise IndexError(
                f"path_index {path_index} out of range [0, {self.n_paths})"
            )
        return {
            name: self.data[name][path_index] for name in self.factor_names
        }


class ScenarioCubeBuilder:
    """Builder for constructing ScenarioCube instances incrementally.

    Each factor is added with its own dates.  At :meth:`build` time,
    the builder intersects all date sets, keeps only the common dates,
    and slices every factor's time axis accordingly.
    """

    def __init__(
        self,
        n_paths: int,
        valuation_date: date,
    ):
        self._n_paths = n_paths
        self._valuation_date = valuation_date
        self._data: dict[str, np.ndarray] = {}
        self._factor_dates: dict[str, tuple[date, ...]] = {}
        self._factor_specs: dict[str, FactorSpec] = {}
        self._factor_names: list[str] = []
        self._built = False

    def _check_not_built(self, factor_name: str):
        if self._built:
            raise RuntimeError("Cannot modify builder after build()")
        if factor_name in self._data:
            raise ValueError(f"Factor '{factor_name}' already added")

    def add_factor(
        self,
        factor_name: str,
        paths: np.ndarray,
        dates: tuple[date, ...],
    ) -> ScenarioCubeBuilder:
        """Add a scalar factor. paths shape: (n_paths, n_times)."""
        self._check_not_built(factor_name)

        if paths.shape[0] != self._n_paths:
            raise ValueError(
                f"Paths has {paths.shape[0]} paths, expected {self._n_paths}"
            )
        if paths.shape[1] != len(dates):
            raise ValueError(
                f"Paths has {paths.shape[1]} time steps but {len(dates)} dates given"
            )

        self._data[factor_name] = paths.copy()
        self._factor_dates[factor_name] = dates
        self._factor_specs[factor_name] = FactorSpec(
            factor_type=RiskFactorType.SCALAR,
        )
        self._factor_names.append(factor_name)
        return self

    def add_curve_factor(
        self,
        factor_name: str,
        paths: np.ndarray,
        tenors: np.ndarray,
        dates: tuple[date, ...],
    ) -> ScenarioCubeBuilder:
        """
        Add a curve factor.

        Parameters
        ----------
        paths : shape (n_paths, n_times, n_tenors)
        tenors : shape (n_tenors,) — pillar year fractions.
        dates : simulation dates for this factor.
        """
        self._check_not_built(factor_name)

        tenors = np.asarray(tenors, dtype=np.float64)
        if paths.shape[0] != self._n_paths:
            raise ValueError(
                f"Paths has {paths.shape[0]} paths, expected {self._n_paths}"
            )
        if paths.shape[1] != len(dates):
            raise ValueError(
                f"Paths has {paths.shape[1]} time steps but {len(dates)} dates given"
            )
        if paths.ndim < 3 or paths.shape[2] != len(tenors):
            raise ValueError(
                f"Paths tenor dimension {paths.shape[2] if paths.ndim >= 3 else 'missing'} "
                f"does not match {len(tenors)} tenors"
            )

        self._data[factor_name] = paths.copy()
        self._factor_dates[factor_name] = dates
        self._factor_specs[factor_name] = FactorSpec(
            factor_type=RiskFactorType.CURVE,
            tenors=tenors.copy(),
        )
        self._factor_names.append(factor_name)
        return self

    def add_surface_factor(
        self,
        factor_name: str,
        paths: np.ndarray,
        tenors: np.ndarray,
        strikes: np.ndarray,
        dates: tuple[date, ...],
    ) -> ScenarioCubeBuilder:
        """
        Add a surface factor.

        Parameters
        ----------
        paths : shape (n_paths, n_times, n_tenors, n_strikes)
        tenors : shape (n_tenors,)
        strikes : shape (n_strikes,)
        dates : simulation dates for this factor.
        """
        self._check_not_built(factor_name)

        tenors = np.asarray(tenors, dtype=np.float64)
        strikes = np.asarray(strikes, dtype=np.float64)
        if paths.shape[0] != self._n_paths:
            raise ValueError(
                f"Paths has {paths.shape[0]} paths, expected {self._n_paths}"
            )
        if paths.shape[1] != len(dates):
            raise ValueError(
                f"Paths has {paths.shape[1]} time steps but {len(dates)} dates given"
            )

        self._data[factor_name] = paths.copy()
        self._factor_dates[factor_name] = dates
        self._factor_specs[factor_name] = FactorSpec(
            factor_type=RiskFactorType.SURFACE,
            tenors=tenors.copy(),
            strikes=strikes.copy(),
        )
        self._factor_names.append(factor_name)
        return self

    def build(self) -> ScenarioCube:
        """Build the immutable ScenarioCube.

        Takes the union of all factor date sets as the cube time grid.
        For any factor whose own simulation dates do not extend to a union
        date, the last available value is carried forward (forward-fill).
        This is safe because factors clipped short belong to already-expired
        trades whose scenario_npvs returns zero at those dates; the
        forward-filled values are never consumed by a live pricing call.
        The previous intersection behaviour silently truncated the cube to
        the shortest factor grid, zeroing out longer-dated trades.
        """
        if self._built:
            raise RuntimeError("Builder can only be used once")
        if not self._data:
            raise ValueError("Cannot build empty ScenarioCube")

        self._built = True

        # Union of all factor date sets, sorted chronologically.
        all_dates: set[date] = set()
        for factor_dates in self._factor_dates.values():
            all_dates |= set(factor_dates)

        union_dates = tuple(sorted(all_dates))
        n_times = len(union_dates)

        # For each factor, map every union date to the nearest prior factor
        # date index (bisect forward-fill).  Exact matches resolve directly;
        # dates beyond the factor's last date reuse the last index.
        sliced_data: dict[str, np.ndarray] = {}
        for name in self._factor_names:
            factor_date_list = sorted(self._factor_dates[name])
            indices = [
                min(max(bisect_right(factor_date_list, d) - 1, 0),
                    len(factor_date_list) - 1)
                for d in union_dates
            ]
            sliced_data[name] = self._data[name][:, indices]

        # Compute year fractions for the union dates.
        val_np = np.datetime64(self._valuation_date)
        dates_np = np.array([np.datetime64(d) for d in union_dates])
        year_fractions = (dates_np - val_np).astype("timedelta64[D]").astype(np.float64) / 365.0

        return ScenarioCube(
            data=sliced_data,
            factor_specs=self._factor_specs,
            factor_names=tuple(self._factor_names),
            n_paths=self._n_paths,
            n_times=n_times,
            dates=union_dates,
            year_fractions=year_fractions,
            valuation_date=self._valuation_date,
        )
