from __future__ import annotations

from typing import Callable

import numpy as np

from utils.interpolation import forward_price_interpolator
from market_data.yield_curve import YieldCurve


class ForwardPriceCurve:
    """Path-wise commodity forward price curve.

    Stores stochastic futures prices (per simulation path) across a tenor
    grid and provides interpolation to arbitrary maturities.

    This is intentionally distinct from :class:`~market_data.yield_curve.YieldCurve`
    because forward prices must be interpolated directly in *price* space
    (not in rate or r*t space), and the ``discount_factor`` transformation
    must never be applied to price values.

    Parameters
    ----------
    tenors : np.ndarray, shape (n_tenors,)
        Year fractions from the current valuation date to each futures
        contract expiry.  Must be sorted ascending.
    prices : np.ndarray, shape (n_paths, n_tenors)
        Futures prices (e.g. USD/barrel) at each pillar per path.
    interpolator : callable
        Factory with signature ``(tenors, prices) -> callable``.
        Defaults to :func:`~utils.interpolation.forward_price_interpolator`,
        which performs linear interpolation between pillars, flat
        left-extrapolation, and linear right-extrapolation using the
        gradient of the last two pillar points.
    """

    def __init__(
        self,
        tenors: np.ndarray,
        prices: np.ndarray,
        interpolator: Callable = forward_price_interpolator,
    ) -> None:
        self._yc = YieldCurve(tenors, prices, interpolator)

    def get_price(self, T: float | np.ndarray) -> np.ndarray:
        """Interpolated futures price at year fraction(s) *T*.

        Parameters
        ----------
        T : float or np.ndarray
            Year fraction(s) from val_date to the target date(s).

        Returns
        -------
        np.ndarray
            Shape ``(n_paths,)`` for scalar *T*,
            ``(n_paths, n_queries)`` for array *T*.
        """
        return self._yc.get_rate(T)
