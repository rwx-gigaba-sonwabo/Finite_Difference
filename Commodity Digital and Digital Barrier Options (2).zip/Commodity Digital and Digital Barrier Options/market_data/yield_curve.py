from __future__ import annotations

from typing import Callable

import numpy as np


class YieldCurve:
    """
    Yield curve handler for vectorised multi-path discount factor computation.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Pillar year fractions (must be sorted ascending).
    rates : np.ndarray, shape (n_paths, n_tenors)
        Annualized zero rates at each pillar. Each row is one path's curve.
    interpolator : callable
        Function with signature (year_fracs, rates) -> callable.
        The returned callable must accept a query array t and return
        interpolated rates of shape (n_paths,) for scalar t,
        or (n_paths, len(t)) for array t.
    """

    def __init__(
        self,
        year_fracs: np.ndarray,
        rates: np.ndarray,
        interpolator: Callable,
    ):
        self.year_fracs = np.asarray(year_fracs, dtype=np.float64)
        self.rates = np.atleast_2d(np.asarray(rates, dtype=np.float64))
        self._interp = interpolator(self.year_fracs, self.rates)

    def get_rate(self, t: float | np.ndarray) -> np.ndarray:
        """
        Interpolated zero rate at year fraction(s) t.

        Returns
        -------
        np.ndarray
            (n_paths,) for scalar t, (n_paths, n_queries) for array t.
        """
        return self._interp(t)

    def discount_factor(self, t: float | np.ndarray) -> np.ndarray:
        """Discount factor(s) at year fraction(s) t: exp(-r(t) * t)."""
        r = self.get_rate(t)
        return np.exp(-r * t)

    def compounded_overnight_rate(
        self,
        t_schedule: np.ndarray,
        tau: float | np.ndarray,
    ) -> np.ndarray:
        """Aggregate simply-compounded rate from daily overnight forward factors.

        For each consecutive business-day pair (t_i, t_{i+1}) in t_schedule,
        the one-day forward factor is:

            F_i = DF(t_i) / DF(t_{i+1})

        All factors are compounded:

            CF = F_0 * F_1 * ... * F_{n-1}  =  DF(t_start) / DF(t_end)

        and converted to a simply-compounded rate over the full accrual period:

            R = (CF - 1) / tau

        The telescoping identity means this equals ``forward_rate(t_start,
        t_end, tau)``, but the daily loop preserves the explicit overnight
        structure needed for lockout / lookback extensions and makes the
        SOFR compounding convention transparent.

        Parameters
        ----------
        t_schedule : np.ndarray, shape (n_business_days + 1,)
            Year fractions from val_date to each business day in the accrual
            period, inclusive of both period start and period end.
            Built by :func:`~models.cashflow_pv._build_overnight_tenors`.
        tau : float or np.ndarray
            Accrual day-count fraction for the full period (ACT/360 for SOFR).

        Returns
        -------
        np.ndarray, shape (n_paths,)
        """
        dfs = self.discount_factor(t_schedule)          # (n_paths, n_days+1)
        fwd_factors = dfs[:, :-1] / dfs[:, 1:]          # (n_paths, n_days)
        compound_factor = np.prod(fwd_factors, axis=1)  # (n_paths,)
        return (compound_factor - 1.0) / tau

    def forward_compounded_overnight_rate(
        self,
        t_sched_to_start: np.ndarray,
        t_sched_to_end: np.ndarray,
        tau: float | np.ndarray,
    ) -> np.ndarray:
        """Forward compounded overnight rate between two future dates.

        Derives the forward rate from two cumulative (spot) compound factors,
        both measured from val_date:

            CF(val_date → t_start) = DF(val_date) / DF(t_start)
            CF(val_date → t_end)   = DF(val_date) / DF(t_end)

        The forward compound factor for the period [t_start, t_end] is:

            CF_fwd = CF(val_date → t_end) / CF(val_date → t_start)
                   = DF(t_start) / DF(t_end)

        Converted to a simply-compounded rate over tau:

            R_fwd = (CF_fwd - 1) / tau

        When t_start = val_date, t_sched_to_start contains only one element
        so its product of forward factors is empty (= 1) and the result
        reduces to a standard spot compounded overnight rate.

        Parameters
        ----------
        t_sched_to_start : np.ndarray, shape (n1,)
            Year fracs from val_date to each business day in
            [val_date, period_start], built by
            ``_build_overnight_tenors(val_date, period_start, val_date, ...)``.
        t_sched_to_end : np.ndarray, shape (n2,)
            Year fracs from val_date to each business day in
            [val_date, period_end].
        tau : float or np.ndarray
            Accrual day-count fraction for the forward period (ACT/360 for
            SOFR).

        Returns
        -------
        np.ndarray, shape (n_paths,)
        """
        # Cumulative compound factors from val_date to each boundary.
        # np.prod over an empty axis-1 (when t_sched has one entry) returns 1,
        # correctly handling the t_start = val_date special case.
        dfs_s = self.discount_factor(t_sched_to_start)          # (n_paths, n1)
        cf_to_start = np.prod(dfs_s[:, :-1] / dfs_s[:, 1:], axis=1)  # (n_paths,)

        dfs_e = self.discount_factor(t_sched_to_end)             # (n_paths, n2)
        cf_to_end = np.prod(dfs_e[:, :-1] / dfs_e[:, 1:], axis=1)    # (n_paths,)

        # Forward CF = ratio of cumulative compound factors
        return (cf_to_end / cf_to_start - 1.0) / tau

    def forward_rate(
        self,
        t_start: float | np.ndarray,
        t_end: float | np.ndarray,
        tau: float | np.ndarray | None = None,
    ) -> np.ndarray:
        """
        Simply-compounded forward rate between t_start and t_end.

        F(t1, t2) = (DF(t1) / DF(t2) - 1) / tau

        Parameters
        ----------
        t_start : float or np.ndarray
            Year fraction(s) to period start(s), in the curve day-count
            convention (used for discount-factor look-up).
        t_end : float or np.ndarray
            Year fraction(s) to period end(s), in the curve day-count
            convention (used for discount-factor look-up).
        tau : float or np.ndarray or None
            Year fraction(s) for the accrual period in the *rate*
            day-count convention (e.g. ACT/360).  When None the
            default ``t_end - t_start`` is used, which is correct only
            when the rate convention matches the curve convention.

        Returns
        -------
        np.ndarray
            Shape (n_paths,) for scalar inputs,
            (n_paths, n_periods) for array inputs.
        """
        df_start = self.discount_factor(t_start)
        df_end = self.discount_factor(t_end)
        if tau is None:
            tau = np.asarray(t_end) - np.asarray(t_start)
        else:
            tau = np.asarray(tau)
        return (df_start / df_end - 1.0) / tau
