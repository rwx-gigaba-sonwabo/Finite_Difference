"""Running one base valuation, comparing it with a second value, and reporting the result."""
