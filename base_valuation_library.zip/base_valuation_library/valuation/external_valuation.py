"""Optional: get the comparison value by running an installed valuation package.

A validation compares two numbers for the same trade and the same market data. One comes
from this library. The other comes from the system being validated. That second number
can be typed into a run script, read from a file, or produced on the spot by this module.

This module loads a valuation package by its import name and asks it to value the trade
JSON file. Nothing in this library depends on that package. If the package is not
installed the run scripts still work with a typed or file based comparison value.

What the package must offer
---------------------------
* ``Context()`` creates a session.
* ``Context.load_json(path)`` loads a trade JSON file.
* ``Context.Base_Valuation(overrides)`` returns ``(calculation, output)`` where
  ``output["Results"]["mtm"]`` is a table of values.

Two table layouts are understood. A table with ``Reference`` and ``Value`` columns holds
one row per deal. Any other table is read as values by date, and its first row is summed.
"""

from __future__ import annotations

import importlib
from pathlib import Path

import pandas as pd


def run_external_base_valuation(
    package_name: str,
    trade_json_path: str | Path,
    trade_reference: str | None = None,
    overrides: dict | None = None,
) -> float:
    """Value a trade JSON file with an installed valuation package.

    Parameters
    ----------
    package_name : str
        Import name of the valuation package.
    trade_json_path : str or Path
        The trade JSON file to value.
    trade_reference : str, optional
        ``Reference`` of the deal whose value is wanted. When ``None`` the values of all
        deals are added together.
    overrides : dict, optional
        Calculation settings passed to the package, for example the number of simulations.

    Returns
    -------
    float
        The value in the reporting currency of the trade file.
    """
    try:
        package = importlib.import_module(package_name)
    except ImportError as error:
        raise ImportError(
            f"The valuation package {package_name!r} is not installed in this environment. "
            f"Install it, or give the comparison value by hand or from a file.") from error

    session = package.Context()
    session.load_json(str(trade_json_path))
    _, output = session.Base_Valuation(overrides=overrides or {})
    table = output["Results"]["mtm"]
    table = table if isinstance(table, pd.DataFrame) else pd.DataFrame(table)

    if {"Reference", "Value"} <= set(table.columns):
        if trade_reference is None:
            return float(table.loc[table["Reference"] != "root", "Value"].sum())
        rows = table.loc[table["Reference"] == trade_reference, "Value"]
        if rows.empty:
            raise KeyError(
                f"The valuation package returned no value for {trade_reference!r}. "
                f"Deals valued: {sorted(table['Reference'])}")
        return float(rows.iloc[0])
    return float(table.iloc[0].sum())
