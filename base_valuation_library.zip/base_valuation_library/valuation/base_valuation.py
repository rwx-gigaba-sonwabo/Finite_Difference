"""Base valuation of one trade and comparison with a second value.

A base valuation is the value of a trade on the valuation date, off the market data of
that date. This module holds the steps every validation run script shares:

1. price the instrument once,
2. find the comparison value,
3. compare the two against a tolerance,
4. print the result and save it to file.

The run scripts in ``validation_runs/`` build the instrument and then call
:func:`run_base_valuation`.

Tolerance test
--------------
The two values agree when either test passes:

* the absolute difference is at most ``absolute_tolerance``, or
* the absolute difference divided by the size of the comparison value is at most
  ``relative_tolerance``.

Using both tests keeps small trades from failing on rounding and large trades from passing
on a difference that is small only in relative terms.
"""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import RiskFactorSlice


@dataclass
class BaseValuationResult:
    """Outcome of one base valuation and its comparison.

    Attributes
    ----------
    trade_reference : str
        Identifier of the trade.
    instrument_type : str
        Kind of instrument, for example ``"Commodity digital option"``.
    valuation_date : date
        Date the trade was valued on.
    reporting_currency : str
        Currency of both values.
    library_value : float
        Value calculated by this library.
    comparison_value : float or None
        Value from the system being validated. ``None`` when none was given.
    comparison_source : str
        Where the comparison value came from.
    difference : float or None
        ``library_value - comparison_value``.
    relative_difference : float or None
        ``difference / abs(comparison_value)``. ``None`` when the comparison value is zero.
    absolute_tolerance, relative_tolerance : float
        The tolerances used for the test.
    within_tolerance : bool or None
        ``True`` when the values agree. ``None`` when there was nothing to compare.
    details : dict
        Intermediate numbers of the valuation, for review.
    notes : list of str
        Remarks on the inputs, such as the interpolation used for each curve.
    """

    trade_reference: str
    instrument_type: str
    valuation_date: date
    reporting_currency: str
    library_value: float
    comparison_value: float | None = None
    comparison_source: str = "none given"
    difference: float | None = None
    relative_difference: float | None = None
    absolute_tolerance: float = 0.0
    relative_tolerance: float = 0.0
    within_tolerance: bool | None = None
    details: dict = field(default_factory=dict)
    notes: list = field(default_factory=list)

    @property
    def outcome(self) -> str:
        """``"PASS"``, ``"FAIL"`` or ``"NOT COMPARED"``."""
        if self.within_tolerance is None:
            return "NOT COMPARED"
        return "PASS" if self.within_tolerance else "FAIL"


def value_instrument(
    instrument: Instrument,
    valuation_date: date,
    market_state: dict[str, RiskFactorSlice],
    fixings: dict | None = None,
) -> float:
    """Price one instrument once and return its value as a single number."""
    values = instrument.scenario_npvs(valuation_date, market_state, fixings)
    return float(np.atleast_1d(values)[0])


def compare_values(
    library_value: float,
    comparison_value: float,
    absolute_tolerance: float,
    relative_tolerance: float,
) -> tuple[float, float | None, bool]:
    """Compare two values and say whether they agree.

    Returns
    -------
    difference : float
        ``library_value - comparison_value``.
    relative_difference : float or None
        ``difference / abs(comparison_value)``, or ``None`` when the comparison value is zero.
    within_tolerance : bool
        ``True`` when the absolute test or the relative test passes.
    """
    difference = library_value - comparison_value
    relative = difference / abs(comparison_value) if comparison_value != 0.0 else None
    passes_absolute = abs(difference) <= absolute_tolerance
    passes_relative = relative is not None and abs(relative) <= relative_tolerance
    return difference, relative, bool(passes_absolute or passes_relative)


def read_comparison_value(csv_path: str | Path, trade_reference: str) -> float:
    """Read the comparison value of one trade from a CSV file.

    The file needs a column named ``Reference`` and a column named ``Value``. Other
    columns are ignored.
    """
    with open(csv_path, newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            if (row.get("Reference") or "").strip() == trade_reference:
                return float(row["Value"])
    raise KeyError(f"No row with Reference = {trade_reference!r} in {csv_path}")


def resolve_comparison_value(
    trade_reference: str,
    trade_json_path: str | Path,
    typed_value: float | None = None,
    csv_path: str | Path | None = None,
    package_name: str | None = None,
    package_overrides: dict | None = None,
) -> tuple[float | None, str]:
    """Find the comparison value, trying the three sources in a fixed order.

    1. ``typed_value``, a number set in the run script.
    2. ``csv_path``, a file of values by trade reference.
    3. ``package_name``, an installed valuation package that is run on the trade file.

    Returns the value and a short description of where it came from. Returns
    ``(None, "none given")`` when no source is set.
    """
    if typed_value is not None:
        return float(typed_value), "typed into the run script"
    if csv_path is not None:
        return read_comparison_value(csv_path, trade_reference), f"file {Path(csv_path).name}"
    if package_name is not None:
        from valuation.external_valuation import run_external_base_valuation
        value = run_external_base_valuation(
            package_name, trade_json_path, trade_reference, package_overrides)
        return value, f"calculated by the package {package_name}"
    return None, "none given"


def run_base_valuation(
    instrument: Instrument,
    market_state: dict[str, RiskFactorSlice],
    valuation_date: date,
    trade_reference: str,
    instrument_type: str,
    reporting_currency: str,
    comparison_value: float | None = None,
    comparison_source: str = "none given",
    absolute_tolerance: float = 0.01,
    relative_tolerance: float = 1e-6,
    fixings: dict | None = None,
    notes: list | None = None,
) -> BaseValuationResult:
    """Price one instrument and compare the value with the comparison value.

    Parameters
    ----------
    instrument : Instrument
        The instrument to price.
    market_state : dict
        Market data on the valuation date, keyed by the names the instrument expects.
    valuation_date : date
        Date to value on.
    trade_reference, instrument_type, reporting_currency : str
        Labels carried into the report.
    comparison_value : float, optional
        Value from the system being validated.
    comparison_source : str
        Where the comparison value came from.
    absolute_tolerance, relative_tolerance : float
        Tolerances of the test. See the module notes.
    fixings : dict, optional
        Past observations the instrument needs, such as realised averages.
    notes : list of str, optional
        Remarks to carry into the report.

    Returns
    -------
    BaseValuationResult
    """
    if hasattr(instrument, "valuation_details"):
        details = instrument.valuation_details(valuation_date, market_state)
        library_value = float(np.atleast_1d(details["present_value"])[0])
    else:
        details = {}
        library_value = value_instrument(instrument, valuation_date, market_state, fixings)

    result = BaseValuationResult(
        trade_reference=trade_reference, instrument_type=instrument_type,
        valuation_date=valuation_date, reporting_currency=reporting_currency,
        library_value=library_value, comparison_value=comparison_value,
        comparison_source=comparison_source, absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance, details=_plain(details), notes=list(notes or []))
    if comparison_value is not None:
        (result.difference, result.relative_difference,
         result.within_tolerance) = compare_values(
            library_value, comparison_value, absolute_tolerance, relative_tolerance)
    return result


def _plain(value: Any) -> Any:
    """Turn numpy values into plain Python values so they print and save cleanly."""
    if isinstance(value, dict):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, np.ndarray):
        flat = value.reshape(-1)
        return _plain(flat[0]) if flat.size == 1 else [_plain(item) for item in flat]
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, date):
        return value.isoformat()
    return value


def format_report(result: BaseValuationResult) -> str:
    """Lay the result out as text for the console and the log file."""
    lines = [
        "=" * 78,
        f"BASE VALUATION  |  {result.instrument_type}",
        "=" * 78,
        f"Trade reference      : {result.trade_reference}",
        f"Valuation date       : {result.valuation_date.isoformat()}",
        f"Reporting currency   : {result.reporting_currency}",
        "",
        f"Library value        : {result.library_value:>22,.6f}",
    ]
    if result.comparison_value is None:
        lines.append("Comparison value     : none given, so no comparison was made")
    else:
        relative = ("n/a" if result.relative_difference is None
                    else f"{result.relative_difference:.3e}")
        lines += [
            f"Comparison value     : {result.comparison_value:>22,.6f}   ({result.comparison_source})",
            f"Difference           : {result.difference:>22,.6f}",
            f"Relative difference  : {relative:>22}",
            f"Tolerance            : absolute {result.absolute_tolerance:g} or "
            f"relative {result.relative_tolerance:g}",
        ]
    lines += ["", f"OUTCOME              : {result.outcome}"]
    if result.details:
        lines += ["", "Calculation steps", "-" * 78]
        for key, value in result.details.items():
            label = key.replace("_", " ")
            shown = f"{value:,.10g}" if isinstance(value, float) else str(value)
            lines.append(f"  {label:<36}: {shown}")
    if result.notes:
        lines += ["", "Notes on inputs", "-" * 78]
        lines += [f"  {note}" for note in result.notes]
    lines.append("=" * 78)
    return "\n".join(lines)


def write_report(result: BaseValuationResult, output_dir: str | Path) -> dict[str, Path]:
    """Save the result as a text report, a one row CSV summary and a JSON file.

    Returns
    -------
    dict
        ``{"text": path, "csv": path, "json": path}``.
    """
    folder = Path(output_dir)
    folder.mkdir(parents=True, exist_ok=True)
    stem = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in result.trade_reference)
    paths = {kind: folder / f"{stem}_base_valuation.{ext}"
             for kind, ext in (("text", "txt"), ("csv", "csv"), ("json", "json"))}

    paths["text"].write_text(format_report(result) + "\n", encoding="utf-8")

    summary = {
        "trade_reference": result.trade_reference, "instrument_type": result.instrument_type,
        "valuation_date": result.valuation_date.isoformat(),
        "reporting_currency": result.reporting_currency, "library_value": result.library_value,
        "comparison_value": result.comparison_value, "comparison_source": result.comparison_source,
        "difference": result.difference, "relative_difference": result.relative_difference,
        "absolute_tolerance": result.absolute_tolerance,
        "relative_tolerance": result.relative_tolerance, "outcome": result.outcome,
    }
    with open(paths["csv"], "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary))
        writer.writeheader()
        writer.writerow(summary)

    record = _plain(asdict(result))
    record["outcome"] = result.outcome
    paths["json"].write_text(json.dumps(record, indent=2), encoding="utf-8")
    return paths
