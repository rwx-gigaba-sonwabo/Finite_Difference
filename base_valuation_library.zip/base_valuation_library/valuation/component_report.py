"""Comparison report for a trade that is valued as several lines.

Some trades are booked as more than one deal, or are valued partly by simulation. An
autocallable swap is one example. Its swap is valued by Monte Carlo simulation and its put
leg is booked as four option deals. Each line then has its own value and its own
comparison value.

Two kinds of line are compared in two different ways.

Closed form line
    The value comes from a formula, so it has no sampling noise. The two values agree when
    the absolute difference or the relative difference is inside its tolerance.

Simulated line
    The value is an average over random paths, so it carries a standard error. The
    difference is divided by the standard error to give a z score. The two values agree when
    the z score is at most the tolerance. A z score of 3 means the difference is three
    standard errors wide, which chance alone rarely produces.
"""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from datetime import date
from pathlib import Path


@dataclass
class ComponentLine:
    """One valued line of a trade and its comparison.

    Attributes
    ----------
    reference : str
        Identifier of the line. It is the key used to look up the comparison value.
    description : str
        Plain description of what the line is.
    method : str
        ``"closed form"`` or ``"simulation"``.
    library_value : float
        Value calculated by this library, in the reporting currency.
    standard_error : float
        Standard error of a simulated value. Zero for a closed form line.
    comparison_value : float or None
        Value of the same line from the system being validated.
    """

    reference: str
    description: str
    method: str
    library_value: float
    standard_error: float = 0.0
    comparison_value: float | None = None
    difference: float | None = None
    relative_difference: float | None = None
    z_score: float | None = None
    within_tolerance: bool | None = None

    @property
    def outcome(self) -> str:
        """``"PASS"``, ``"FAIL"`` or ``"NOT COMPARED"``."""
        if self.within_tolerance is None:
            return "NOT COMPARED"
        return "PASS" if self.within_tolerance else "FAIL"


@dataclass
class ComponentReport:
    """All lines of one trade, with the settings used to compare them."""

    title: str
    valuation_date: date
    reporting_currency: str
    lines: list = field(default_factory=list)
    absolute_tolerance: float = 0.01
    relative_tolerance: float = 1e-6
    z_score_tolerance: float = 3.0
    notes: list = field(default_factory=list)

    @property
    def outcome(self) -> str:
        """``"FAIL"`` if any line fails, ``"PASS"`` if every compared line passes."""
        outcomes = {line.outcome for line in self.lines}
        if "FAIL" in outcomes:
            return "FAIL"
        return "PASS" if "PASS" in outcomes else "NOT COMPARED"


def compare_line(line: ComponentLine, absolute_tolerance: float, relative_tolerance: float,
                 z_score_tolerance: float) -> ComponentLine:
    """Fill in the difference, the z score and the outcome of one line.

    A closed form line passes on the absolute or the relative tolerance. A simulated line
    passes when ``abs(difference) / standard_error`` is at most ``z_score_tolerance``. A
    simulated line also passes on the absolute or relative tolerance, so that a line with
    almost no noise is not failed on a negligible difference.
    """
    if line.comparison_value is None:
        return line
    line.difference = line.library_value - line.comparison_value
    line.relative_difference = (line.difference / abs(line.comparison_value)
                                if line.comparison_value != 0.0 else None)
    passes = abs(line.difference) <= absolute_tolerance or (
        line.relative_difference is not None
        and abs(line.relative_difference) <= relative_tolerance)
    if line.method == "simulation" and line.standard_error > 0.0:
        line.z_score = abs(line.difference) / line.standard_error
        passes = passes or line.z_score <= z_score_tolerance
    line.within_tolerance = bool(passes)
    return line


def format_component_report(report: ComponentReport) -> str:
    """Lay the report out as text for the console and the log file."""
    width = 118
    lines = ["=" * width, f"BASE VALUATION  |  {report.title}", "=" * width,
             f"Valuation date       : {report.valuation_date.isoformat()}",
             f"Reporting currency   : {report.reporting_currency}",
             f"Tolerance            : closed form lines absolute {report.absolute_tolerance:g} or "
             f"relative {report.relative_tolerance:g}. Simulated lines z score {report.z_score_tolerance:g}.",
             "",
             f"{'Line':<30}{'Method':<13}{'Library value':>18}{'Std error':>13}"
             f"{'Comparison':>18}{'Difference':>14}{'z score':>9}  Outcome",
             "-" * width]
    for line in report.lines:
        comparison = "" if line.comparison_value is None else f"{line.comparison_value:,.2f}"
        difference = "" if line.difference is None else f"{line.difference:,.2f}"
        z_score = "" if line.z_score is None else f"{line.z_score:.2f}"
        error = "" if line.standard_error == 0.0 else f"{line.standard_error:,.2f}"
        lines.append(f"{line.reference[:29]:<30}{line.method:<13}{line.library_value:>18,.2f}"
                     f"{error:>13}{comparison:>18}{difference:>14}{z_score:>9}  {line.outcome}")
    lines += ["-" * width, f"OUTCOME              : {report.outcome}"]
    if report.notes:
        lines += ["", "Notes on inputs", "-" * width] + [f"  {note}" for note in report.notes]
    lines.append("=" * width)
    return "\n".join(lines)


def write_component_report(report: ComponentReport, output_dir: str | Path, file_stem: str) -> dict:
    """Save the report as a text file, a CSV file with one row per line, and a JSON file."""
    folder = Path(output_dir)
    folder.mkdir(parents=True, exist_ok=True)
    paths = {kind: folder / f"{file_stem}_base_valuation.{suffix}"
             for kind, suffix in (("text", "txt"), ("csv", "csv"), ("json", "json"))}
    paths["text"].write_text(format_component_report(report) + "\n", encoding="utf-8")
    rows = [dict(asdict(line), outcome=line.outcome) for line in report.lines]
    with open(paths["csv"], "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["reference"])
        writer.writeheader()
        writer.writerows(rows)
    payload = {"title": report.title, "valuation_date": report.valuation_date.isoformat(),
               "reporting_currency": report.reporting_currency, "outcome": report.outcome,
               "absolute_tolerance": report.absolute_tolerance,
               "relative_tolerance": report.relative_tolerance,
               "z_score_tolerance": report.z_score_tolerance, "lines": rows, "notes": report.notes}
    paths["json"].write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return paths
