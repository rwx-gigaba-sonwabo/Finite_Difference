"""Steps that every validation run script performs after its instrument is built.

Each run script reads the trade file, builds one instrument and its market data, and then
calls :func:`compare_and_report`. That function gets the comparison value, values the
instrument, compares the two numbers, prints the report and saves it.
"""

from __future__ import annotations

from pathlib import Path

from instruments.instrument import Instrument
from trade_data.base_market import BaseMarket
from trade_data.trade_file import TradeFile
from valuation.base_valuation import (
    BaseValuationResult,
    format_report,
    resolve_comparison_value,
    run_base_valuation,
    write_report,
)


def compare_and_report(
    instrument: Instrument,
    market_state: dict,
    trade_file: TradeFile,
    market: BaseMarket,
    trade_reference: str,
    instrument_type: str,
    comparison_value: float | None = None,
    comparison_values_csv: str | Path | None = None,
    comparison_package: str | None = None,
    absolute_tolerance: float = 0.01,
    relative_tolerance: float = 1e-6,
    output_folder: str | Path | None = None,
    fixings: dict | None = None,
    notes: list | None = None,
    reporting_currency: str | None = None,
) -> BaseValuationResult:
    """Value the instrument, compare with the comparison value, print and save the report.

    Parameters
    ----------
    instrument : Instrument
        The instrument built by the run script.
    market_state : dict
        Market data on the valuation date, keyed by the names the instrument reads.
    trade_file : TradeFile
        The loaded trade file. Gives the valuation date and the reporting currency.
    market : BaseMarket
        The market built from the trade file. Its interpolation notes go into the report.
    trade_reference : str
        Identifier of the trade. Also the key used to look up the comparison value.
    instrument_type : str
        Plain name of the instrument for the report heading.
    comparison_value, comparison_values_csv, comparison_package
        The three possible sources of the comparison value. The first one set is used.
    absolute_tolerance, relative_tolerance : float
        Tolerances of the comparison.
    output_folder : str or Path, optional
        Folder for the report files. ``None`` prints only.
    fixings : dict, optional
        Past observations the instrument needs.
    notes : list of str, optional
        Extra remarks for the report.
    reporting_currency : str, optional
        Currency of the value. The trade file's reporting currency when not given.

    Returns
    -------
    BaseValuationResult
    """
    value, source = resolve_comparison_value(
        trade_reference, trade_file.path,
        typed_value=comparison_value,
        csv_path=comparison_values_csv,
        package_name=comparison_package,
    )
    all_notes = [f"{curve}: {note}" for curve, note in market.interpolation_notes.items()]
    all_notes += list(notes or [])
    result = run_base_valuation(
        instrument=instrument,
        market_state=market_state,
        valuation_date=trade_file.valuation_date,
        trade_reference=trade_reference,
        instrument_type=instrument_type,
        reporting_currency=reporting_currency or trade_file.reporting_currency,
        comparison_value=value,
        comparison_source=source,
        absolute_tolerance=absolute_tolerance,
        relative_tolerance=relative_tolerance,
        fixings=fixings,
        notes=all_notes,
    )
    print(format_report(result))
    if output_folder is not None:
        saved = write_report(result, output_folder)
        print(f"Report files saved in {saved['text'].parent}")
    return result
