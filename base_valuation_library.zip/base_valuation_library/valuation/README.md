# Valuation

The steps that every validation run shares: value the trade, find the comparison value,
compare the two, print the report and save it.

A trade valued as one number uses `base_valuation.py`. A trade valued as several lines, some
of them by simulation, uses `component_report.py`. See `docs/comparison_method.md` for how
the two values are compared.

## Files

| File | What it holds |
|---|---|
| `base_valuation.py` | Base valuation of one trade and comparison with a second value. |
| `component_report.py` | Comparison report for a trade that is valued as several lines. |
| `external_valuation.py` | Optional: get the comparison value by running an installed valuation package. |
| `run_script_support.py` | Steps that every validation run script performs after its instrument is built. |
