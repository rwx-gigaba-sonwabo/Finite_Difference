# Base valuation library

This library values a trade once, on one date, off one set of market data. That single
number is called the base valuation. The library exists to check the base valuations of
another valuation system. Throughout the code and the documents that other system is called
the **target system**, and its number is called the **comparison value**.

For each type of trade there is one run script. A run script reads a trade JSON file, values
the trade with this library, gets the comparison value, compares the two and writes a report.

## What is in the library

| Folder | What it holds | Guide |
|---|---|---|
| `validation_runs/` | One folder per type of trade, with its run script and a sample trade file | [validation_runs/README.md](validation_runs/README.md) |
| `instruments/` | One file per type of trade. Holds the trade terms and the valuation steps | [instruments/README.md](instruments/README.md) |
| `models/` | The pricing formulas | [models/README.md](models/README.md) |
| `market_data/` | Curves, volatility surfaces and the containers that carry them | [market_data/README.md](market_data/README.md) |
| `trade_data/` | Reading a trade JSON file and building the market from it | [trade_data/README.md](trade_data/README.md) |
| `valuation/` | Valuing, comparing and reporting | [valuation/README.md](valuation/README.md) |
| `utils/` | Interpolation, dates, schedules and small helpers | [utils/README.md](utils/README.md) |
| `autocall_pricer/` | Monte Carlo pricing of autocallable swaps and their booked put leg | [autocall_pricer/README.md](autocall_pricer/README.md) |
| `tests/` | Unit tests | [tests/README.md](tests/README.md) |
| `docs/` | Method notes and the validation status | see below |

Method notes in `docs/`:

| Document | What it covers |
|---|---|
| [docs/commodity_digital_option.md](docs/commodity_digital_option.md) | How a European commodity digital option is valued |
| [docs/commodity_barrier_option.md](docs/commodity_barrier_option.md) | How a commodity barrier option is valued |
| [docs/autocall_swap.md](docs/autocall_swap.md) | How an autocallable swap and its put leg are valued |
| [docs/trade_file_format.md](docs/trade_file_format.md) | Layout of the trade JSON file |
| [docs/comparison_method.md](docs/comparison_method.md) | How two values are compared and what PASS means |
| [docs/validation_status.md](docs/validation_status.md) | What has been compared so far, and what was found |

## Install

Tested with Python 3.13. From the root folder of the library:

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows. On macOS or Linux: source .venv/bin/activate
pip install -r requirements-dev.txt
```

| File | Installs | Use it for |
|---|---|---|
| `requirements.txt` | numpy, pandas, scipy, QuantLib, python-dateutil | Running the validation runs |
| `requirements-dev.txt` | the above plus pytest | Running the tests as well |
| `requirements-optional.txt` | torch | Only for the Sobol random number option of the autocall simulation |

There is no package to install. Run every script from the root folder of the library.

## Run a validation

```bash
python validation_runs/commodity_digital_option/run_commodity_digital_option_validation.py
```

As delivered, every run script points at the sample trade file in its own folder. To run
your own trade:

1. Open the run script and go to the block marked `SETTINGS`.
2. Set `TRADE_JSON_PATH` to your trade JSON file.
3. Set `TRADE_REFERENCE` to the `Reference` field of the deal.
4. Check the market data names and the trade terms. Each one has a comment that says what it is.
5. Give the comparison value. See the next section.
6. Run the script. The report prints on the screen and is saved in the `output` folder next
   to the script.

## Where the comparison value comes from

Every run script accepts the comparison value in three ways. The first one that is set is used.

1. **Typed in.** Put the number in `COMPARISON_VALUE`.
2. **From a file.** Point `COMPARISON_VALUES_CSV` at a CSV file with the columns `Reference`
   and `Value`.
3. **Calculated on the spot.** Put the import name of an installed valuation package in
   `COMPARISON_PACKAGE`. The package is run on the same trade file. Nothing in this library
   depends on that package. See `valuation/external_valuation.py` for what the package must offer.

With none of the three set, the script still values the trade and reports `NOT COMPARED`.

## Run the tests

```bash
pytest
```

Expected result: 306 passed, 2 expected failures. The two expected failures are explained in
[tests/README.md](tests/README.md).

## Words used in this library

| Word | Meaning |
|---|---|
| Base valuation | The value of a trade on the valuation date, off that date's market data |
| Target system | The valuation system whose numbers are being checked |
| Comparison value | The target system's value for the same trade and the same market data |
| Library value | The value calculated by this library |
| Trade JSON file | One file that holds the trades, the market data and the valuation settings |
| Deal | One trade in the trade JSON file |
| Price factor | One piece of market data in the trade JSON file, such as a curve |
| Reporting currency | The currency both values are stated in |
| Tolerance | How far apart the two values may be and still count as agreeing |
| z score | A difference divided by the standard error of a simulated value |

## What this library does not do

It does not simulate future market scenarios, and it does not calculate exposure profiles or
valuation adjustments. It values each trade once, on the valuation date.
