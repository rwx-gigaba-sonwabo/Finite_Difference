"""Closed form value of a single barrier option, used by the FX barrier option.

The building blocks A to F of the standard barrier formulas and the rule that picks which
of them make up each option type.
"""

from __future__ import annotations

import numpy as np

from utils.maths import norm_cdf


def barrier_factors(
    S: np.ndarray | float,
    carry: np.ndarray | float,
    r: np.ndarray | float,
    T: float,
    X: float,
    sigma: np.ndarray | float,
    H: float,
    K: float,
    is_call: bool,
    is_up: bool,
) -> dict[str, np.ndarray]:
    """Reiner-Rubinstein building blocks A..F for a continuously monitored single barrier.

    Each intermediate is returned by name so the calculation can be
    checked step by step.

    Parameters
    ----------
    S : spot (domestic per foreign), scalar or (n_paths,)
    carry : cost of carry b (r_dom - r_for for FX), scalar or (n_paths,)
    r : discount rate, scalar or (n_paths,)
    T : time to expiry in years (> 0)
    X : strike
    sigma : volatility, scalar or (n_paths,)
    H : barrier level
    K : cash rebate
    is_call : True for call (phi = 1), False for put (phi = -1)
    is_up : True for up barrier (eta = -1), False for down barrier (eta = 1)
    """
    phi = 1.0 if is_call else -1.0
    eta = -1.0 if is_up else 1.0

    sqrtT = np.sqrt(T)
    sigRT = sigma * sqrtT
    ebmt = np.exp((carry - r) * T)  # e^{(b-r)T}
    erT = np.exp(-r * T)            # e^{-rT}

    mu = (carry - 0.5 * sigma ** 2) / sigma ** 2
    lam = np.sqrt(mu ** 2 + 2.0 * r / sigma ** 2)

    x1 = np.log(S / X) / sigRT + (1.0 + mu) * sigRT
    x2 = np.log(S / H) / sigRT + (1.0 + mu) * sigRT
    y1 = np.log(H ** 2 / (S * X)) / sigRT + (1.0 + mu) * sigRT
    y2 = np.log(H / S) / sigRT + (1.0 + mu) * sigRT
    z = np.log(H / S) / sigRT + lam * sigRT

    HS = H / S
    HS_pow_2mu1 = HS ** (2.0 * (mu + 1.0))
    HS_pow_2mu = HS ** (2.0 * mu)

    A = phi * S * ebmt * norm_cdf(phi * x1) - phi * X * erT * norm_cdf(phi * (x1 - sigRT))
    B = phi * S * ebmt * norm_cdf(phi * x2) - phi * X * erT * norm_cdf(phi * (x2 - sigRT))
    C = (phi * S * ebmt * HS_pow_2mu1 * norm_cdf(eta * y1)
         - phi * X * erT * HS_pow_2mu * norm_cdf(eta * (y1 - sigRT)))
    D = (phi * S * ebmt * HS_pow_2mu1 * norm_cdf(eta * y2)
         - phi * X * erT * HS_pow_2mu * norm_cdf(eta * (y2 - sigRT)))

    # E: rebate paid at expiry if the barrier is NOT hit
    E = K * erT * (norm_cdf(eta * (x2 - sigRT)) - HS_pow_2mu * norm_cdf(eta * (y2 - sigRT)))
    # F: rebate paid at the moment the barrier IS hit
    F = K * (HS ** (mu + lam) * norm_cdf(eta * z)
             + HS ** (mu - lam) * norm_cdf(eta * (z - 2.0 * lam * sigRT)))

    return {
        "x1": x1, "x2": x2, "y1": y1, "y2": y2, "z": z, "mu": mu, "lam": lam,
        "A": A, "B": B, "C": C, "D": D, "E": E, "F": F, "erT": erT,
    }


def single_barrier_price(
    S: np.ndarray | float,
    carry: np.ndarray | float,
    r: np.ndarray | float,
    T: float,
    X: float,
    sigma: np.ndarray | float,
    H: float,
    is_call: bool,
    is_up: bool,
    is_knock_in: bool,
    K: float = 0.0,
    rebate_at_hit: bool = True,
    crossed: np.ndarray | bool = False,
    strike_above: bool | None = None,
) -> np.ndarray:
    """Price a single barrier option per unit of underlying (Reiner-Rubinstein / Haug).

    Vectorised over paths: S, carry, r, sigma and crossed may be (n_paths,) arrays.

    Parameters
    ----------
    is_knock_in : True for knock-in, False for knock-out
    K : cash rebate
    rebate_at_hit : True -> rebate paid when barrier hit (F),
                    False -> rebate paid at expiry (E-based)
    crossed : barrier already crossed (per path). Replaces the Excel
              ``barrier_status`` flag ("crossed" vs blank / "not_crossed").
    strike_above : which formula branch to use (X > H). Defaults to comparing X
                   with H; pass it explicitly when H is a per-path shifted barrier.

    Returns
    -------
    np.ndarray
        Option value per unit of underlying, discounted to today.
    """
    if T <= 0.0 or np.any(np.asarray(sigma) <= 0.0):
        raise ValueError("sigma and T must be positive.")

    f = barrier_factors(S, carry, r, T, X, sigma, H, K, is_call, is_up)
    A, B, C, D, E, F, erT = f["A"], f["B"], f["C"], f["D"], f["E"], f["F"], f["erT"]
    if strike_above is None:
        strike_above = X > H

    # ---- barrier not yet crossed ----
    if is_knock_in:
        rebate_leg = F if rebate_at_hit else E
        if is_call and not is_up:    # down-and-in call
            base = C if strike_above else A - B + D
        elif is_call and is_up:      # up-and-in call
            base = A if strike_above else B - C + D
        elif not is_up:              # down-and-in put
            base = B - C + D if strike_above else A
        else:                        # up-and-in put
            base = A - B + D if strike_above else C
    else:
        rebate_leg = F if rebate_at_hit else K * erT - E
        if is_call and not is_up:    # down-and-out call
            base = A - C if strike_above else B - D
        elif is_call and is_up:      # up-and-out call
            base = 0.0 * A if strike_above else A - B + C - D
        elif not is_up:              # down-and-out put
            base = A - B + C - D if strike_above else 0.0 * A
        else:                        # up-and-out put
            base = B - D if strike_above else A - C

    alive_value = base + rebate_leg

    # ---- barrier already crossed ----
    if is_knock_in:
        crossed_value = A                         # activated -> vanilla
    else:
        crossed_value = K if rebate_at_hit else K * erT  # knocked out -> rebate only
    crossed_value = crossed_value + 0.0 * alive_value    # broadcast to path shape

    return np.where(crossed, crossed_value, alive_value)
