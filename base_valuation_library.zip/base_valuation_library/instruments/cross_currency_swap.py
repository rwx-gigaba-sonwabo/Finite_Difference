"""Cross currency swap with a notional that resets to the market FX rate.

Two legs in two currencies exchange interest and notional amounts. This instrument is still
being developed and has no validation run.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np
import QuantLib as ql

from instruments.components.cashflow_leg import CashflowLeg, LegType
from instruments.components.schedule_config import ScheduleConfig
from instruments.instrument import Instrument
from market_data.risk_factor import RiskFactorSlice, ScalarSlice, CurveSlice
from market_data.yield_curve import YieldCurve
from models.cashflow_pv import (
    leg_pv,
    apply_fixings,
    filter_future_periods,
    compute_period_year_fractions,
    _calc_forward_rates,
    _compute_forward_tenors,
    _build_overnight_tenors,
)
from utils.ql_helpers import to_ql_date


# ---------------------------------------------------------------------------
# MtM leg pricer
# ---------------------------------------------------------------------------

def _mtm_leg_pv(
    schedule: list[tuple[date, date, float]],
    leg: CashflowLeg,
    static_notional: float,
    val_date: date,
    market_state: dict[str, RiskFactorSlice],
    mtm_disc_curve: YieldCurve,
    static_disc_curve: YieldCurve,
    fwd_fx_spot: np.ndarray,
    n_paths: int,
    interpolator: Callable,
    day_counter: ql.DayCounter,
    curve_day_counter: ql.DayCounter,
    calendar: ql.Calendar,
    known_notional: float | None = None,
    past_notionals: dict[date, np.ndarray] | None = None,
    include_on_val_date: bool = False,
    fixings: dict[tuple[str, date], np.ndarray] | None = None,
    static_basis_curves: list[YieldCurve] | None = None,
) -> np.ndarray:
    """PV of a mark-to-market floating leg, in the MtM leg's own currency.

    The notional of this leg is reset to the market FX rate at the start
    of every period.

    The resetting notional for period i is:

        P_i = fwd_fx_spot * static_notional

    where ``fwd_fx_spot`` is the simulated FX spot (MtM-currency per
    static-currency) taken directly from the market state.  The Monte Carlo
    process already embeds the forward drift, so no DF-ratio adjustment is
    applied here.

    Total PV (from the perspective of the leg's receiver, in MtM currency):

        PV = sum_i [ P_i * (L_i + spread) * alpha_i  +  A_i ] * DF_mtm(t_i)

    where
        A_i = P_i - P_{i+1}   for i < n   (intermediate notional settlement)
        A_n = P_n              for i = n   (final notional repayment)

    The caller is responsible for converting the result to a common reporting
    currency before combining with the static leg.

    Parameters
    ----------
    schedule : list of (accrual_start, accrual_end, accrual_fraction)
    leg : CashflowLeg
        Definition of the MtM (resetting) leg.
    static_notional : float
        Notional of the *other* (non-resetting) leg, in its own currency.
        The MtM notional is derived from this via the forward FX.
    val_date : date
    market_state : dict
    mtm_disc_curve : YieldCurve
        Discount curve of the MtM (resetting) leg.  Used to discount all
        cash flows and as the numerator of the FX forward formula.
    static_disc_curve : YieldCurve
        Discount curve of the static (non-resetting) leg.  Used as the
        denominator of the FX forward formula.
    fwd_fx_spot : np.ndarray, shape (n_paths,)
        Current FX spot rate expressed as *MtM-currency per static-currency*.
        For ``mtm_leg="pay"``:   pass ``1 / fx_spot``  (pay per receive).
        For ``mtm_leg="receive"``: pass ``fx_spot``      (receive per pay).
    n_paths : int
    interpolator : Callable
        Interpolator factory for the MtM leg's forward projection curve.
    day_counter : ql.DayCounter
    curve_day_counter : ql.DayCounter
    calendar : ql.Calendar
    known_notional : float or None
        If the first period has already reset and the actual notional is known,
        supply it here (in MtM-leg currency).  Overrides the spot-FX fallback
        for period 0 only.
    include_on_val_date : bool

    Returns
    -------
    np.ndarray, shape (n_paths,)
        PV in the MtM leg's own currency, from the perspective of its receiver.
    """
    future = filter_future_periods(schedule, val_date, include_on_val_date)
    if not future:
        return np.zeros(n_paths)

    t_starts, t_ends, _t_pays, accruals = compute_period_year_fractions(
        future, val_date, curve_day_counter,
    )
    n_periods = len(future)

    # ------------------------------------------------------------------
    # Path-varying notionals  (n_paths, n_periods)
    # P_i = F(t, t_{i-1}) * static_notional
    #      = fwd_fx_spot * DF_static(t_{i-1}) / DF_mtm(t_{i-1}) * static_notional
    # ------------------------------------------------------------------
    notionals = np.empty((n_paths, n_periods))
    for i in range(n_periods):
        t_reset = t_starts[i]
        period_start = future[i][0]
        if i == 0 and known_notional is not None and t_reset <= 0.0:
            # First period: use the scalar known rate supplied from the JSON.
            notionals[:, i] = known_notional
        elif t_reset <= 0.0 and past_notionals is not None and period_start in past_notionals:
            # Past reset: use the actual simulated FX captured at the reset date.
            notionals[:, i] = past_notionals[period_start]
        elif t_reset <= 0.0:
            # Past reset with no historical value available: fall back to current spot.
            notionals[:, i] = fwd_fx_spot * static_notional
        else:
            # Future reset: forward FX via covered interest rate parity.
            df_mtm = mtm_disc_curve.discount_factor(t_reset)       # (n_paths,)
            df_static = static_disc_curve.discount_factor(t_reset)  # (n_paths,)
            if static_basis_curves:
                for bc in static_basis_curves:
                    df_static = df_static * bc.discount_factor(t_reset)
            notionals[:, i] = fwd_fx_spot * (df_static / df_mtm) * static_notional

    # ------------------------------------------------------------------
    # Discount factors at payment dates, MtM leg's own curve
    # ------------------------------------------------------------------
    dfs = mtm_disc_curve.discount_factor(t_ends)   # (n_paths, n_periods)

    # ------------------------------------------------------------------
    # Forward rates from the MtM leg's projection curve
    # ------------------------------------------------------------------
    fwd_slice: CurveSlice = market_state[leg.curve_name]
    fwd_curve = YieldCurve(fwd_slice.tenors, fwd_slice.values, interpolator)

    fwd_t_starts, fwd_t_ends, fwd_tau = _compute_forward_tenors(
        future, leg, t_ends, val_date, day_counter, curve_day_counter, calendar,
    )

    in_progress = t_starts[0] < 0

    if in_progress and leg.overnight_compounding:
        # _build_overnight_tenors produces an empty schedule when period_start < val_date,
        # so _calc_forward_rates would silently compute a spot rate from val_date instead
        # of the full-period forward rate from period_start.  As in leg_pv:
        # use DF extrapolated to negative time as a proxy for CF_realized.
        #
        #   rate = (DF(t_period_start) / DF(t_period_end) - 1) / tau
        #
        # DF(t_period_start) = exp(-r * t) with t < 0 gives exp(r * |t|) ≈ CF_realized.
        # Note: t_starts[0] is the raw accrual-start year fraction (not spot-shifted),
        # which is correct here, we want the DF at the actual period start for CF_realized.
        df_start = fwd_curve.discount_factor(t_starts[0])    # (n_paths,) > 1 for past dates
        df_end   = fwd_curve.discount_factor(fwd_t_ends[0])  # (n_paths,)
        r_eff    = (df_start / df_end - 1.0) / fwd_tau[0]    # (n_paths,)
        first_col = r_eff.reshape(n_paths, 1)

        if n_periods > 1:
            rest = _calc_forward_rates(
                fwd_curve, fwd_t_starts[1:], fwd_t_ends[1:], fwd_tau[1:],
            )
            forward_rates = np.hstack([first_col, rest])
        else:
            forward_rates = first_col
    else:
        forward_rates = _calc_forward_rates(
            fwd_curve, fwd_t_starts, fwd_t_ends, fwd_tau,
        )   # (n_paths, n_periods)

    if fixings:
        if in_progress and leg.overnight_compounding:
            # Column 0 was set via DF extrapolation, don't let a Category B rate
            # fixing overwrite it.  Apply fixings only to the remaining columns.
            if n_periods > 1:
                apply_fixings(forward_rates[:, 1:], future[1:], leg.curve_name, fixings)
        else:
            apply_fixings(forward_rates, future, leg.curve_name, fixings)
    forward_rates = forward_rates + leg.spread

    # ------------------------------------------------------------------
    # Coupon PV:  P_i * (L_i + spread) * alpha_i * DF_mtm(t_i)
    # ------------------------------------------------------------------
    coupon_pv = np.sum(notionals * forward_rates * accruals * dfs, axis=1)

    # ------------------------------------------------------------------
    # Notional exchange PV:  A_i * DF_mtm(t_i)
    # A_i = P_i - P_{i+1}  (i < n),   A_n = P_n
    # ------------------------------------------------------------------
    A = np.empty_like(notionals)
    A[:, :-1] = notionals[:, :-1] - notionals[:, 1:]
    A[:, -1] = notionals[:, -1]

    notional_exchange_pv = np.sum(A * dfs, axis=1)

    return coupon_pv + notional_exchange_pv



# ---------------------------------------------------------------------------
# Instrument
# ---------------------------------------------------------------------------

class CrossCurrencySwap(Instrument):
    """Cross-currency swap with optional mark-to-market notional resetting.

    Supports two modes controlled by *mtm_leg*:

    **Standard CCS** (``mtm_leg=None``, default)
        Both notionals are fixed at inception.  Principal is exchanged once
        at the start (optional) and once at maturity.

    **MtM CCS** (``mtm_leg="pay"`` or ``"receive"``)
        The nominated leg's notional is reset each period.  The swap is
        valued as two legs:

        - **MtM leg** (floating interest with a resetting notional):
          notional resets to ``F(t, t_{i-1}) * static_notional`` each period,
          where ``F`` is the forward FX in the MtM leg's currency per unit of
          the static leg's currency.  Intermediate notional settlements
          (A_i = P_i - P_{i+1}) and the final repayment (A_n = P_n) are
          embedded in ``_mtm_leg_pv``, which returns a PV in the MtM leg's
          own currency.
        - **Static leg** (floating interest with a fixed notional):
          standard ``leg_pv`` with a single fixed final notional exchange.

        The NPV is assembled in receive currency:

            mtm_leg="pay":     NPV = static_receive_pv  −  mtm_pay_pv × fx_spot
            mtm_leg="receive": NPV = mtm_receive_pv     −  static_pay_pv × fx_spot

        where ``fx_spot`` is expressed as receive per pay throughout.

    Parameters
    ----------
    name : str
    effective_date : date
    maturity_date : date
    receive_notional : float
    pay_notional : float
    receive_leg : CashflowLeg
    pay_leg : CashflowLeg
    receive_curve : str
        Risk factor name for the receive-leg discount curve.
    pay_curve : str
        Risk factor name for the pay-leg discount curve.
    fx_spot_name : str
        FX spot rate key: receive currency per one unit of pay currency.
    receive_curve_interpolator : Callable
    pay_curve_interpolator : Callable
    schedule_config : ScheduleConfig or None
    pay_known_fx_rate : float or None
        FX rate (pay per receive) already fixed at the first MtM reset date.
        Only used when ``mtm_leg="pay"`` and the first period has already reset.
    receive_known_fx_rate : float or None
        FX rate (receive per pay) already fixed at the first MtM reset date.
        Only used when ``mtm_leg="receive"`` and the first period has already reset.
    exchange_initial_notional : bool
    mtm_leg : {"pay", "receive"} or None
    report_fx_name : str or None
    pre_payment : bool
    receive_basis1 : str or None
        Risk factor name for the first receive-leg basis spread curve.
    receive_basis2 : str or None
        Risk factor name for the second receive-leg basis spread curve.
    pay_basis : str or None
        Risk factor name for the pay-leg basis spread curve.
    receive_basis_interpolator1 : Callable or None
    receive_basis_interpolator2 : Callable or None
    pay_basis_interpolator : Callable or None
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        receive_notional: float,
        pay_notional: float,
        receive_leg: CashflowLeg,
        pay_leg: CashflowLeg,
        receive_curve: str,
        pay_curve: str,
        fx_spot_name: str,
        receive_curve_interpolator: Callable,
        pay_curve_interpolator: Callable,
        schedule_config: ScheduleConfig | None = None,
        receive_schedule_config: ScheduleConfig | None = None,
        pay_schedule_config: ScheduleConfig | None = None,
        pay_known_fx_rate: float | None = None,
        receive_known_fx_rate: float | None = None,
        exchange_initial_notional: bool = True,
        mtm_leg: str | None = None,
        report_fx_name: str | None = None,
        pre_payment: bool = True,
        receive_fx_name: str | None = None,
        pay_fx_name: str | None = None,
        receive_basis1: str | None = None,
        receive_basis2: str | None = None,
        pay_basis: str | None = None,
        receive_basis_interpolator1: Callable | None = None,
        receive_basis_interpolator2: Callable | None = None,
        pay_basis_interpolator: Callable | None = None,
    ):
        super().__init__(name)
        if mtm_leg is not None and mtm_leg not in ("pay", "receive"):
            raise ValueError("mtm_leg must be 'pay', 'receive', or None")
        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.receive_notional = receive_notional
        self.pay_notional = pay_notional
        self.receive_leg = receive_leg
        self.pay_leg = pay_leg
        self.receive_curve = receive_curve
        self.pay_curve = pay_curve
        self.fx_spot_name = fx_spot_name
        self.receive_curve_interpolator = receive_curve_interpolator
        self.pay_curve_interpolator = pay_curve_interpolator
        self.pay_known_fx_rate = pay_known_fx_rate
        self.receive_known_fx_rate = receive_known_fx_rate
        self.exchange_initial_notional = exchange_initial_notional
        self.mtm_leg = mtm_leg
        self.report_fx_name = report_fx_name
        self.pre_payment = pre_payment
        self.receive_fx_name = receive_fx_name
        self.pay_fx_name = pay_fx_name
        self.receive_basis1 = receive_basis1
        self.receive_basis2 = receive_basis2
        self.pay_basis = pay_basis
        self.receive_basis_interpolator1 = receive_basis_interpolator1
        self.receive_basis_interpolator2 = receive_basis_interpolator2
        self.pay_basis_interpolator = pay_basis_interpolator
        self.schedule_config = schedule_config or ScheduleConfig()
        self.receive_schedule_config = receive_schedule_config or self.schedule_config
        self.pay_schedule_config = pay_schedule_config or self.schedule_config
        self._generate_schedules()

    # ------------------------------------------------------------------
    # Cashflow dates
    # ------------------------------------------------------------------

    @property
    def effective_maturity(self) -> date:
        """Last cashflow date. A caller can check that its market data reaches this date."""
        return self.maturity_date

    def cashflow_dates(self) -> set[date]:
        """All coupon payment dates plus the maturity date (notional exchange).

        A caller that values the trade on a grid of dates can add these
        cashflow dates to its grid, so that no cashflow falls between
        two valuation dates.
        """
        dates: set[date] = set()
        for _, end, _pay, _ in self.receive_schedule:
            dates.add(end)
        for _, end, _pay, _ in self.pay_schedule:
            dates.add(end)
        dates.add(self.maturity_date)
        return dates

    # ------------------------------------------------------------------
    # Schedule generation
    # ------------------------------------------------------------------

    def _generate_schedules(self):
        self.receive_schedule = self.receive_schedule_config.build(
            self.effective_date, self.maturity_date, self.receive_leg.frequency,
        )
        self.pay_schedule = self.pay_schedule_config.build(
            self.effective_date, self.maturity_date, self.pay_leg.frequency,
        )

    # ------------------------------------------------------------------
    # FX spot helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _combined_df(
        primary: YieldCurve,
        basis_curves: list[YieldCurve],
        t,
    ) -> np.ndarray:
        df = primary.discount_factor(t)
        for bc in basis_curves:
            df = df * bc.discount_factor(t)
        return df

    def _get_fx_spot(self, market_state: dict[str, RiskFactorSlice]) -> np.ndarray:
        """Return fx_spot (receive per pay) from market state.

        When receive_fx_name and pay_fx_name are set, triangulates through USD:
            fx_spot = receive_fx / pay_fx  (e.g. ZAR/USD ÷ AUD/USD = ZAR/AUD)
        Otherwise reads fx_spot_name directly from the cube.
        """
        if self.receive_fx_name and self.pay_fx_name:
            rec: ScalarSlice = market_state[self.receive_fx_name]
            pay: ScalarSlice = market_state[self.pay_fx_name]
            return rec.values / pay.values
        fx_slice: ScalarSlice = market_state[self.fx_spot_name]
        return fx_slice.values

    # ------------------------------------------------------------------
    # Reset dates and fixings
    # ------------------------------------------------------------------

    def get_reset_dates(self) -> list[tuple]:
        """Return all floating-rate and MtM FX reset dates.

        Each entry is a 5-tuple:
            (reset_date, curve_name, period_start, period_end, is_overnight)

        ``is_overnight=True`` tells the caller to route this reset
        through the OIS CF_realized accumulation path rather than the LIBOR
        compute-once path.  MtM FX resets always use ``is_overnight=False``.
        """
        resets: list[tuple] = []
        for schedule, leg in [
            (self.receive_schedule, self.receive_leg),
            (self.pay_schedule, self.pay_leg),
        ]:
            if leg.leg_type != LegType.FLOATING:
                continue
            for start, end, _pay, _ in schedule:
                resets.append((start, leg.curve_name, start, end, leg.overnight_compounding))

        if self.mtm_leg == "pay":
            for start, end, _pay, _ in self.pay_schedule:
                resets.append((start, self.fx_spot_name, start, end, False))
        elif self.mtm_leg == "receive":
            for start, end, _pay, _ in self.receive_schedule:
                resets.append((start, self.fx_spot_name, start, end, False))

        return resets

    def compute_fixings(
        self,
        resets: list[tuple[date, str, date, date]],
        time_slice: dict[str, RiskFactorSlice],
        scenario_date: date,
    ) -> dict[tuple[str, date], np.ndarray]:
        """Compute forward rates / FX values for given resets from a historical scenario.

        Used to capture the fixings at each
        reset date so that in-progress periods use the rate that was set at
        their start, not a zeroed placeholder.
        """
        fixings: dict[tuple[str, date], np.ndarray] = {}
        ql_scenario = to_ql_date(scenario_date)
        sc = self.schedule_config

        for _reset_date, curve_name, p_start, p_end in resets:
            # FX fixing for MtM notional resets
            if curve_name == self.fx_spot_name:
                if self.receive_fx_name and self.pay_fx_name:
                    rec: ScalarSlice = time_slice[self.receive_fx_name]
                    pay: ScalarSlice = time_slice[self.pay_fx_name]
                    fixings[(curve_name, p_start)] = rec.values / pay.values
                else:
                    fx_slice: ScalarSlice = time_slice[curve_name]
                    fixings[(curve_name, p_start)] = fx_slice.values
                continue

            # Floating rate fixing, find the right interpolator for this curve
            if (self.receive_leg.leg_type == LegType.FLOATING
                    and curve_name == self.receive_leg.curve_name):
                interpolator = self.receive_curve_interpolator
            elif (self.pay_leg.leg_type == LegType.FLOATING
                    and curve_name == self.pay_leg.curve_name):
                interpolator = self.pay_curve_interpolator
            else:
                continue

            fwd_slice: CurveSlice = time_slice[curve_name]
            fwd_curve = YieldCurve(fwd_slice.tenors, fwd_slice.values, interpolator)
            t_start = sc.curve_day_counter.yearFraction(ql_scenario, to_ql_date(p_start))
            t_end = sc.curve_day_counter.yearFraction(ql_scenario, to_ql_date(p_end))
            fixings[(curve_name, p_start)] = fwd_curve.forward_rate(t_start, t_end)

        return fixings

    def compute_cf_increment(
        self,
        curve_name: str,
        t_start: date,
        t_end: date,
        market_slice: dict[str, RiskFactorSlice],
    ) -> np.ndarray:
        """Overnight compound factor for the inter-pillar slice [t_start, t_end].

        Call this on each valuation date to advance
        the running CF_realized product by one step.  Uses the curve from
        ``market_slice`` (the scenario state at ``t_start``) so that the
        rates applied are those seen at the start of the step, the
        forward-looking convention.

        The curve tenors in ``market_slice`` are year fractions measured from
        the scenario date, which equals ``t_start`` here, so setting
        ``val_date = t_start`` in ``_build_overnight_tenors`` keeps the
        two on the same time axis.

        Returns
        -------
        np.ndarray, shape (n_paths,)
            Compound factor (> 1.0) for [t_start, t_end], e.g. 1.0041.
        """
        if (self.receive_leg.leg_type == LegType.FLOATING
                and curve_name == self.receive_leg.curve_name):
            interpolator = self.receive_curve_interpolator
            sc = self.receive_schedule_config
        elif (self.pay_leg.leg_type == LegType.FLOATING
                and curve_name == self.pay_leg.curve_name):
            interpolator = self.pay_curve_interpolator
            sc = self.pay_schedule_config
        else:
            raise ValueError(
                f"compute_cf_increment: curve '{curve_name}' does not match "
                "any overnight floating leg"
            )

        fwd_slice: CurveSlice = market_slice[curve_name]
        fwd_curve = YieldCurve(fwd_slice.tenors, fwd_slice.values, interpolator)

        # Both schedules measured from t_start (= val_date = scenario origin).
        # t_to_start collapses to a single point [0.0]; its compound factor
        # product is the empty product = 1, so forward_compounded_overnight_rate
        # reduces to a spot overnight rate from t_start.
        t_to_start = _build_overnight_tenors(
            t_start, t_start, t_start, sc.ql_calendar, sc.curve_day_counter,
        )
        t_to_end = _build_overnight_tenors(
            t_start, t_end, t_start, sc.ql_calendar, sc.curve_day_counter,
        )
        tau = sc.day_counter.yearFraction(to_ql_date(t_start), to_ql_date(t_end))

        rate = fwd_curve.forward_compounded_overnight_rate(t_to_start, t_to_end, tau=tau)
        return 1.0 + rate * tau

    def get_ois_initial_cf(self, *_) -> float | None:
        """Seed compound factor for OIS periods that pre-date the simulation grid.

        Signature: (curve_name: str, p_start: date) -> float | None

        When an overnight period started before the first valuation date,
        this is called to initialise CF_realized with the actual
        published compound factor from the real period start up to the first
        pillar date.

        Returns ``None`` by default, and the factor then starts at 1.0, which is
        correct for periods whose start falls on or after the first valuation date.
        Override this method (or supply a subclass) to inject real historical
        ZARONIA fixings when the period pre-dates the grid.
        """
        return None

    # ------------------------------------------------------------------
    # Pricing
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
        pre_payment: bool | None = None,
    ) -> np.ndarray:
        if pre_payment is None:
            pre_payment = self.pre_payment

        fx_spot = self._get_fx_spot(market_state)
        n_paths = fx_spot.shape[0]

        expired = val_date > self.maturity_date if pre_payment else val_date >= self.maturity_date
        if expired:
            return np.zeros(n_paths)

        ql_val = to_ql_date(val_date)

        # Per-leg schedule configs, carry their own day_counter, curve_day_counter
        # and calendar so that (e.g.) a USD ACT/360 receive leg and a ZAR ACT/365
        # pay leg each use the correct day-count for forward-rate projection (fwd_tau)
        # as well as for accrual fractions.  The notional-exchange discount-factor
        # lookups (t_mat, t_eff) use the receive-leg curve_day_counter as the shared
        # time axis, in practice both legs are calibrated on the same ACT/365 grid.
        rec_sc = self.receive_schedule_config
        pay_sc = self.pay_schedule_config

        rec_disc_slice: CurveSlice = market_state[self.receive_curve]
        rec_disc_curve = YieldCurve(
            rec_disc_slice.tenors, rec_disc_slice.values, self.receive_curve_interpolator,
        )

        pay_disc_slice: CurveSlice = market_state[self.pay_curve]
        pay_disc_curve = YieldCurve(
            pay_disc_slice.tenors, pay_disc_slice.values, self.pay_curve_interpolator,
        )

        rec_basis_curves: list[YieldCurve] = []
        if self.receive_basis1 is not None:
            s = market_state[self.receive_basis1]
            rec_basis_curves.append(YieldCurve(s.tenors, s.values, self.receive_basis_interpolator1))
        if self.receive_basis2 is not None:
            s = market_state[self.receive_basis2]
            rec_basis_curves.append(YieldCurve(s.tenors, s.values, self.receive_basis_interpolator2))

        pay_basis_curves: list[YieldCurve] = []
        if self.pay_basis is not None:
            s = market_state[self.pay_basis]
            pay_basis_curves.append(YieldCurve(s.tenors, s.values, self.pay_basis_interpolator))

        # Shared scalar quantities (path count, fixings, market state)
        _shared = dict(
            val_date=val_date,
            market_state=market_state,
            n_paths=n_paths,
            fixings=fixings,
        )

        # Per-leg kwargs: each leg uses its own day_counter / curve_day_counter
        # / calendar for accrual and forward-rate projection computations.
        rec_common = dict(
            **_shared,
            day_counter=rec_sc.day_counter,
            curve_day_counter=rec_sc.curve_day_counter,
            calendar=rec_sc.ql_calendar,
        )
        pay_common = dict(
            **_shared,
            day_counter=pay_sc.day_counter,
            curve_day_counter=pay_sc.curve_day_counter,
            calendar=pay_sc.ql_calendar,
        )

        # ---------------------------------------------------------------
        # MtM CCS
        # ---------------------------------------------------------------
        if self.mtm_leg is not None:
            return self._price_mtm(
                val_date, ql_val, rec_sc, pay_sc, market_state, fx_spot, n_paths,
                rec_disc_curve, pay_disc_curve,
                rec_basis_curves, pay_basis_curves,
                rec_common, pay_common, pre_payment,
            )

        # ---------------------------------------------------------------
        # Standard fixed-notional CCS
        # ---------------------------------------------------------------
        dom_coupon_pv = leg_pv(
            self.receive_schedule, self.receive_leg,
            notional=self.receive_notional,
            discount_curve=rec_disc_curve,
            interpolator=self.receive_curve_interpolator,
            basis_curves=rec_basis_curves or None,
            include_on_val_date=pre_payment,
            **rec_common,
        )
        for_coupon_pv = leg_pv(
            self.pay_schedule, self.pay_leg,
            notional=self.pay_notional,
            discount_curve=pay_disc_curve,
            interpolator=self.pay_curve_interpolator,
            basis_curves=pay_basis_curves or None,
            include_on_val_date=pre_payment,
            **pay_common,
        )

        nominal_pv = np.zeros(n_paths)
        if self.exchange_initial_notional and (
            val_date < self.effective_date
            or (pre_payment and val_date == self.effective_date)
        ):
            t_eff = rec_sc.curve_day_counter.yearFraction(
                ql_val, to_ql_date(self.effective_date),
            )
            df_rec_eff = self._combined_df(rec_disc_curve, rec_basis_curves, t_eff)
            df_pay_eff = self._combined_df(pay_disc_curve, pay_basis_curves, t_eff)
            nominal_pv += (
                -self.receive_notional * df_rec_eff
                + self.pay_notional * df_pay_eff * fx_spot
            )

        t_mat = rec_sc.curve_day_counter.yearFraction(
            ql_val, to_ql_date(self.maturity_date),
        )
        df_rec_mat = self._combined_df(rec_disc_curve, rec_basis_curves, t_mat)
        df_pay_mat = self._combined_df(pay_disc_curve, pay_basis_curves, t_mat)
        nominal_pv += (
            self.receive_notional * df_rec_mat
            - self.pay_notional * df_pay_mat * fx_spot
        )

        npv = dom_coupon_pv - for_coupon_pv * fx_spot + nominal_pv
        if self.report_fx_name is not None:
            npv = npv / fx_spot
        return npv

    # ------------------------------------------------------------------
    # MtM pricing path
    # ------------------------------------------------------------------

    def _price_mtm(
        self,
        val_date, ql_val, rec_sc, pay_sc,
        market_state, fx_spot, n_paths,
        rec_disc_curve, pay_disc_curve,
        rec_basis_curves, pay_basis_curves,
        rec_common, pay_common, pre_payment,
    ) -> np.ndarray:
        """Price an MtM CCS.

        Each leg is computed in its own
        currency then combine using FX sign scalars, no duplicated branches.

        ``mtm_sign`` converts the MtM PV to receive currency.
        ``sta_sign`` converts the static PV to receive currency.

            mtm_leg="pay":     mtm_sign = -fx_spot,  sta_sign = +1.0
            mtm_leg="receive": mtm_sign = +1.0,       sta_sign = -fx_spot

        Each leg uses its own schedule config (``rec_sc`` / ``pay_sc``) so that
        per-leg day-count conventions (e.g. USD ACT/360, ZAR ACT/365) are
        respected in both forward-rate projection and accrual computation.
        """
        # Notional-exchange DF lookups use the receive-leg curve_day_counter
        # as the shared time axis (both discount curves are on the same grid).
        t_mat = rec_sc.curve_day_counter.yearFraction(
            ql_val, to_ql_date(self.maturity_date),
        )
        fixings: dict | None = rec_common.get("fixings")

        if self.mtm_leg == "pay":
            mtm_sched, mtm_leg_def, mtm_disc, mtm_interp = (
                self.pay_schedule, self.pay_leg, pay_disc_curve, self.pay_curve_interpolator)
            sta_sched, sta_leg_def, sta_disc, sta_interp, sta_notional = (
                self.receive_schedule, self.receive_leg, rec_disc_curve,
                self.receive_curve_interpolator, self.receive_notional)
            fwd_fx = 1.0 / fx_spot   # pay per receive
            mtm_sign, sta_sign = -fx_spot, 1.0
            sta_basis_curves = rec_basis_curves
            mtm_sc, sta_common = pay_sc, rec_common
            # known_notional in pay currency: pay_known_fx_rate (pay/receive) × receive_notional
            known_notional = (
                self.pay_known_fx_rate * self.receive_notional
                if self.pay_known_fx_rate is not None else None
            )
        else:  # receive
            mtm_sched, mtm_leg_def, mtm_disc, mtm_interp = (
                self.receive_schedule, self.receive_leg, rec_disc_curve, self.receive_curve_interpolator)
            sta_sched, sta_leg_def, sta_disc, sta_interp, sta_notional = (
                self.pay_schedule, self.pay_leg, pay_disc_curve,
                self.pay_curve_interpolator, self.pay_notional)
            fwd_fx = fx_spot         # receive per pay
            mtm_sign, sta_sign = 1.0, -fx_spot
            sta_basis_curves = pay_basis_curves
            mtm_sc, sta_common = rec_sc, pay_common
            # known_notional in receive currency: receive_known_fx_rate (receive/pay) × pay_notional
            known_notional = (
                self.receive_known_fx_rate * self.pay_notional
                if self.receive_known_fx_rate is not None else None
            )

        static_pv = (
            leg_pv(
                sta_sched, sta_leg_def,
                notional=sta_notional,
                discount_curve=sta_disc,
                interpolator=sta_interp,
                basis_curves=sta_basis_curves or None,
                include_on_val_date=pre_payment,
                **sta_common,
            )
            + sta_notional * self._combined_df(sta_disc, sta_basis_curves, t_mat)
        )

        # Build past_notionals from fixings: the caller stores historical FX
        # (receive/pay convention) under (fx_spot_name, period_start).
        # Convert to MtM-leg currency and multiply by static notional here.
        past_notionals: dict[date, np.ndarray] | None = None
        if fixings:
            past: dict[date, np.ndarray] = {}
            for start, _, _ in mtm_sched:
                key = (self.fx_spot_name, start)
                if key in fixings:
                    fx_hist = np.asarray(fixings[key], dtype=np.float64)  # receive/pay
                    fwd_fx_hist = (1.0 / fx_hist) if self.mtm_leg == "pay" else fx_hist
                    past[start] = fwd_fx_hist * sta_notional
            if past:
                past_notionals = past

        mtm_pv = _mtm_leg_pv(
            mtm_sched, mtm_leg_def,
            static_notional=sta_notional,
            val_date=val_date,
            market_state=market_state,
            mtm_disc_curve=mtm_disc,
            static_disc_curve=sta_disc,
            fwd_fx_spot=fwd_fx,
            n_paths=n_paths,
            interpolator=mtm_interp,
            day_counter=mtm_sc.day_counter,
            curve_day_counter=mtm_sc.curve_day_counter,
            calendar=mtm_sc.ql_calendar,
            known_notional=known_notional,
            past_notionals=past_notionals,
            include_on_val_date=pre_payment,
            fixings=fixings,
            static_basis_curves=sta_basis_curves or None,
        )

        npv = mtm_pv * mtm_sign + static_pv * sta_sign

        # Initial exchange: the MtM leg settles -Pi_1 at the start and the static
        # leg pays out its capital at the start.
        # Pi_1 = FX_fwd(t_eff) × sta_notional  (path-varying via CIP).
        # By CIP: Pi_1 × DF_mtm(t_eff) × (-mtm_sign) = sta_notional × DF_sta(t_eff)
        # so the two legs net to zero for a fairly-struck deal on every path.
        if self.exchange_initial_notional and (
            val_date < self.effective_date
            or (pre_payment and val_date == self.effective_date)
        ):
            t_eff = rec_sc.curve_day_counter.yearFraction(
                ql_val, to_ql_date(self.effective_date),
            )
            df_sta_eff = self._combined_df(sta_disc, sta_basis_curves, t_eff)  # (n_paths,)
            df_mtm_eff = mtm_disc.discount_factor(t_eff)                       # (n_paths,)
            # FX-forward-adjusted initial MtM notional (same CIP formula as _mtm_leg_pv)
            pi_1 = fwd_fx * (df_sta_eff / df_mtm_eff) * sta_notional  # (n_paths,)
            npv += (
                pi_1 * df_mtm_eff * (-mtm_sign)          # MtM leg: receive Pi_1 at t_eff
                - sta_notional * df_sta_eff * sta_sign    # static leg: give sta_notional at t_eff
            )

        if self.report_fx_name is not None:
            npv = npv / fx_spot
        return npv
