"""Asian option on a commodity price.

A call or put on the average of the commodity price over a set of sampling dates, valued
with a lognormal approximation to the distribution of the average.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, cast

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.equity_pv import black76_euro_option
from models.fx_pv import fx_forward_price
from utils.interpolation import (
    forward_price_interpolator,
    linear_interpolator,
    get_forward_price_from_slice,
    excel_serials_to_year_fracs,
)
from utils.ql_helpers import (
    DAY_COUNTERS,
    advance_business_days,
    generate_business_days,
    to_ql_date,
)


class CommodityAsian(Instrument):
    """Arithmetically averaged Asian commodity option priced via moment matching.

    Daily fixing dates are generated as business days in [period_start, period_end].
    The arithmetic average of future forward prices is matched to a log-normal
    distribution using the first two moments, producing a single adjusted
    volatility used in a Black-76 European option formula.

    When some fixings have already been observed the strike is adjusted to
    account for the realised average so far, and only the remaining m future
    fixings enter the moment-matching calculation.

    Pricing model (m future fixings)
    ---------------------------------
    Let F(i) = forward price at fixing i, vol(i) = vol at (K_eff, F(i), t(i)),
    t(i) = year fraction from val_date to averaging date i.

        M1 = (1/m) Σᵢ F(i)

        M2 = (1/m²) [ Σᵢ F(i)² exp(vol(i)² t(i))
                       + 2 Σⱼ Σᵢ<ⱼ F(i) F(j) exp(vol(i)² t(i)) ]

        σ_adj = sqrt( (ln M2 − 2 ln M1) / T_expiry )

        PV = direction × Black76(M1, K_eff, σ_adj, df(T_settle), T_expiry, is_call)
             × notional × (m / n_total  if past fixings exist)

    Strike adjustment for past fixings (n_past past, m future, n_total = n_past + m):

        K_eff = (n_total / m) × K − (n_past / m) × S̄_past

    where S̄_past is the arithmetic mean of realised past prices.
    Vol moneyness is computed using K_eff when past fixings are present.

    Composite (USDZAR) mode
    -----------------------
    When ``quanto=True`` each averaging-date forward is:

        F(i) = F_commodity(i) × F_USDZAR(i)

    where F_USDZAR is computed via :func:`fx_forward_price` using basis-adjusted
    covered interest parity.  The per-date volatility is:

        σ(i) = sqrt(σ_comm(i)² + σ_fx_atm(i)² + 2 ρ σ_comm(i) σ_fx_atm(i))

    where σ_fx_atm is the Malz ATM vol (strike = forward) at tenor t(i) and ρ
    is the constant commodity/FX correlation.  All fixings, K_eff, and the
    Black-76 payoff are expressed in the domestic (ZAR) currency.

    Parameters
    ----------
    name : str
        Trade identifier.
    period_start : date
        First date of the averaging window.
    period_end : date
        Last date of the averaging window (option expiry for moment-matching).
    settlement_date : date
        Date on which the settled payoff is paid; used only for discounting.
    strike : float
        Option strike.  In domestic (ZAR) currency when ``quanto=True``.
    notional : float
        Contract notional (number of units).
    is_call : bool
        True for a call (buyer benefits when average > strike).
    vol_surface : NonPreciousCommodityVol | MalzVol
        Commodity volatility surface.
    forward_curve_name : str
        Risk-factor name for the commodity forward CurveSlice.
    discount_curve_name : str
        Risk-factor name for the discount CurveSlice (domestic ZAR when composite).
    averaging_calendar : str
        Calendar key used to enumerate business days in the averaging window.
    lag_calendar : str
        Calendar key used to advance each averaging date by ``pricing_lag``
        business days to obtain the effective forward-curve lookup date.
    forward_interpolator : callable
        Interpolator factory for the forward curve (default: forward-price
        log-linear).
    discount_interpolator : callable
        Interpolator factory for the discount curve (default: linear).
    pricing_lag : int
        Business-day lag for forward-curve lookup (1 for ICE Brent,
        2 for NYMEX WTI).  Default 1.
    day_count : str
        Day-count convention key (default ``"ACT/365"``).
    direction : int
        ``+1`` for long, ``-1`` for short.  Default ``+1``.
    quanto : bool
        When ``True`` apply composite (USDZAR) pricing.  Default ``False``.
    fx_spot_name : str, optional
        Risk-factor name for the domestic/USD FX scalar (e.g. ``"FxRate.USD-ZAR"``
        in USD-per-ZAR convention so that 1/fx_spot gives the USDZAR rate).
    domestic_basis : str, optional
        Risk-factor name for the domestic (ZAR) basis / forecast curve.
    domestic_basis_interpolator : callable, optional
        Interpolator factory for the domestic basis curve.
    domestic_curve : str, optional
        Risk-factor name for the domestic (ZAR) discount curve.
    domestic_curve_interpolator : callable, optional
        Interpolator factory for the domestic discount curve.
    foreign_curve : str, optional
        Risk-factor name for the foreign (USD) discount curve.
    foreign_curve_interpolator : callable, optional
        Interpolator factory for the foreign discount curve.
    correlation : float, optional
        Constant commodity / FX return correlation ρ.  Default 0.
    fx_vol_surface : MalzVol, optional
        Malz FX vol surface for the USDZAR pair.
    """

    def __init__(
        self,
        name: str,
        period_start: date,
        period_end: date,
        settlement_date: date,
        strike: float,
        notional: float,
        is_call: bool,
        vol_surface,
        forward_curve_name: str,
        discount_curve_name: str,
        averaging_calendar: str,
        lag_calendar: str,
        forward_interpolator: Callable = forward_price_interpolator,
        discount_interpolator: Callable = linear_interpolator,
        pricing_lag: int = 1,
        day_count: str = "ACT/365",
        direction: int = 1,
        quanto: bool = False,
        fx_spot_name: str | None = None,
        domestic_basis: str | None = None,
        domestic_basis_interpolator: Callable | None = None,
        domestic_curve: str | None = None,
        domestic_curve_interpolator: Callable | None = None,
        foreign_curve: str | None = None,
        foreign_curve_interpolator: Callable | None = None,
        correlation: float = 0.0,
        fx_vol_surface=None,
    ) -> None:
        super().__init__(name)
        self.period_start = period_start
        self.period_end = period_end
        self.settlement_date = settlement_date
        self.strike = strike
        self.notional = notional
        self.is_call = is_call
        self.vol_surface = vol_surface
        self.forward_curve_name = forward_curve_name
        self.discount_curve_name = discount_curve_name
        self.forward_interpolator = forward_interpolator
        self.discount_interpolator = discount_interpolator
        self.pricing_lag = pricing_lag
        self.direction = direction
        self._dc = DAY_COUNTERS[day_count]
        self.quanto = quanto
        self.fx_spot_name = fx_spot_name
        self.domestic_basis = domestic_basis
        self.domestic_basis_interpolator = domestic_basis_interpolator
        self.domestic_curve = domestic_curve
        self.domestic_curve_interpolator = domestic_curve_interpolator
        self.foreign_curve = foreign_curve
        self.foreign_curve_interpolator = foreign_curve_interpolator
        self.correlation = correlation
        self.fx_vol_surface = fx_vol_surface

        self._averaging_dates: list[date] = generate_business_days(
            period_start, period_end, averaging_calendar,
        )
        self._pricing_dates: list[date] = [
            advance_business_days(d, pricing_lag, lag_calendar)
            for d in self._averaging_dates
        ]

    # ------------------------------------------------------------------
    # Pricing
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Compute per-path NPV of the Asian commodity option.

        Parameters
        ----------
        val_date : date
            Current valuation date.
        market_state : dict
            Mapping from risk-factor name to RiskFactorSlice.
        fixings : dict or None
            Realised forward prices for past averaging dates.
            Key: ``(forward_curve_name, averaging_date)`` →
            ``np.ndarray (n_paths,)`` or scalar.
        rng : ignored.

        Returns
        -------
        np.ndarray, shape (n_paths,)
        """
        disc_slice = cast(CurveSlice, market_state[self.discount_curve_name])
        n_paths = disc_slice.values.shape[0]

        if val_date > self.settlement_date:
            return np.zeros(n_paths)

        disc_curve = YieldCurve(
            disc_slice.tenors, disc_slice.values, self.discount_interpolator,
        )
        T_settle = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.settlement_date),
        ))
        df = disc_curve.discount_factor(T_settle)

        fwd_slice = cast(CurveSlice, market_state[self.forward_curve_name])
        fwd_tenors_yf = excel_serials_to_year_fracs(
            fwd_slice.tenors, val_date, self._dc,
        )
        right_extrap = (
            "flat"
            if self.forward_interpolator is linear_interpolator
            else "linear"
        )

        # ------------------------------------------------------------------
        # Composite: build FX curves once for the whole pricing call
        # ------------------------------------------------------------------
        if self.quanto:
            fx_spot_slice = cast(ScalarSlice, market_state[self.fx_spot_name])
            fx_spot = fx_spot_slice.values  # USD/ZAR, 1/fx_spot = USDZAR

            dom_basis_slice = cast(CurveSlice, market_state[self.domestic_basis])
            dom_basis_curve = YieldCurve(
                dom_basis_slice.tenors, dom_basis_slice.values,
                self.domestic_basis_interpolator,
            )
            dom_slice = cast(CurveSlice, market_state[self.domestic_curve])
            dom_curve = YieldCurve(
                dom_slice.tenors, dom_slice.values,
                self.domestic_curve_interpolator,
            )
            for_slice_q = cast(CurveSlice, market_state[self.foreign_curve])
            for_curve = YieldCurve(
                for_slice_q.tenors, for_slice_q.values,
                self.foreign_curve_interpolator,
            )

        _fix: dict = fixings if fixings is not None else {}
        n_total = len(self._averaging_dates)

        def _get_price(avg_date: date, pricing_date: date) -> np.ndarray:
            key = (self.forward_curve_name, avg_date)
            if key in _fix:
                f = np.asarray(_fix[key], dtype=np.float64)
                return np.full(n_paths, float(f)) if f.ndim == 0 else f
            return get_forward_price_from_slice(
                curve_serial_tenors=fwd_slice.tenors,
                curve_values=fwd_slice.values,
                value_date=val_date,
                target_date=pricing_date,
                day_counter=self._dc,
                right_extrapolation=right_extrap,
                left_extrapolation="flat",
                _precomputed_tenors_yf=fwd_tenors_yf,
            )

        # ------------------------------------------------------------------
        # At or past period end: all fixings realised, intrinsic payoff
        # Uses full average and original strike K (no adjusted-strike formula).
        # ------------------------------------------------------------------
        if val_date >= self.period_end:
            price_sum = np.zeros(n_paths)
            for avg_date, pricing_date in zip(self._averaging_dates, self._pricing_dates):
                price_sum += _get_price(avg_date, pricing_date)
            S_avg = price_sum / n_total
            if self.is_call:
                payoff = np.maximum(S_avg - self.strike, 0.0)
            else:
                payoff = np.maximum(self.strike - S_avg, 0.0)
            return self.direction * payoff * self.notional * df

        # ------------------------------------------------------------------
        # Accumulate realised prices for past averaging dates (pre-expiry)
        # ------------------------------------------------------------------
        past_sum = np.zeros(n_paths)
        n_past = 0

        for avg_date, pricing_date in zip(self._averaging_dates, self._pricing_dates):
            if avg_date >= val_date:
                break
            n_past += 1
            past_sum += _get_price(avg_date, pricing_date)

        n_future = n_total - n_past

        # ------------------------------------------------------------------
        # Effective strike adjusted for any past fixings
        # ------------------------------------------------------------------
        if n_past > 0:
            S_avg_past = past_sum / n_past
            # K_eff is the Black-76 strike that reproduces the correct payoff.
            # K_eff is per-path (n_paths,) when S_avg_past is path-dependent.
            K_eff: float | np.ndarray = (
                (n_total / n_future) * self.strike
                - (n_past / n_future) * S_avg_past
            )
            # strike_bar is used only for vol-surface moneyness lookups.
            # It equals K - accumulated_past_weighted_avg = K - past_sum/n_total,
            # that is strike_bar = Strike - average, where
            # average = Σ past_weight_i * F_i with weight = 1/n_total).
            # K_eff = (n_total/n_future) * strike_bar, so using K_eff for vol
            # moneyness inflates the effective moneyness by n_total/n_future and
            # gives a wrong volatility once averaging starts.
            strike_for_vol: float | np.ndarray = self.strike - past_sum / n_total
        else:
            K_eff = float(self.strike)
            strike_for_vol = K_eff

        T_expiry = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.period_end),
        ))

        # ------------------------------------------------------------------
        # Moment matching over future fixing dates
        # ------------------------------------------------------------------
        M1_sum = np.zeros(n_paths)
        M2_diag = np.zeros(n_paths)
        M2_cross = np.zeros(n_paths)
        # Running sum Σᵢ<ⱼ F(i) exp(vol(i)² t(i)), updated as j advances
        running_weighted = np.zeros(n_paths)

        for avg_date, pricing_date in zip(self._averaging_dates, self._pricing_dates):
            if avg_date < val_date:
                continue

            t_i = float(self._dc.yearFraction(
                to_ql_date(val_date), to_ql_date(avg_date),
            ))
            F_comm = get_forward_price_from_slice(
                curve_serial_tenors=fwd_slice.tenors,
                curve_values=fwd_slice.values,
                value_date=val_date,
                target_date=pricing_date,
                day_counter=self._dc,
                right_extrapolation=right_extrap,
                left_extrapolation="flat",
                _precomputed_tenors_yf=fwd_tenors_yf,
            )  # (n_paths,)

            if self.quanto:
                F_fx, _ = fx_forward_price(
                    fx_spot, dom_basis_curve, dom_curve, for_curve, t_i,
                )
                F_i = F_comm * F_fx

                vol_comm = np.asarray(
                    self.vol_surface.get_vol(strike_for_vol, F_i, t_i),
                    dtype=np.float64,
                )
                if vol_comm.ndim == 0:
                    vol_comm = np.full(n_paths, float(vol_comm))

                # ATM FX vol: strike == forward → moneyness = 0
                vol_fx_atm = float(self.fx_vol_surface.get_vol(
                    strike=1.0, forward=1.0, tenor=t_i,
                ))
                vol_i = np.sqrt(
                    vol_comm ** 2
                    + vol_fx_atm ** 2
                    + 2.0 * self.correlation * vol_comm * vol_fx_atm
                )
            else:
                F_i = F_comm
                vol_i = np.asarray(
                    self.vol_surface.get_vol(strike_for_vol, F_i, t_i),
                    dtype=np.float64,
                )
                if vol_i.ndim == 0:
                    vol_i = np.full(n_paths, float(vol_i))

            exp_var_i = np.exp(vol_i ** 2 * t_i)   # exp(σᵢ² tᵢ)

            # Cross terms: F(j) × Σᵢ<ⱼ [F(i) exp(σᵢ² tᵢ)]
            M2_cross += F_i * running_weighted
            running_weighted += F_i * exp_var_i     # update for next j

            M2_diag += F_i ** 2 * exp_var_i
            M1_sum += F_i

        M1 = M1_sum / n_future
        M2 = (M2_diag + 2.0 * M2_cross) / (n_future ** 2)

        # Adjusted vol, guard against numerical edge cases
        safe_M1 = np.maximum(M1, 1e-12)
        log_ratio = np.log(np.maximum(M2, safe_M1 ** 2)) - 2.0 * np.log(safe_M1)
        log_ratio = np.maximum(log_ratio, 0.0)
        adjusted_vol = (
            np.sqrt(log_ratio / T_expiry) if T_expiry > 0.0 else np.zeros(n_paths)
        )

        option_pv = black76_euro_option(
            forward=M1,
            strike=K_eff,
            vol=adjusted_vol,
            df=df,
            T=T_expiry,
            is_call=self.is_call,
        )

        pv = self.direction * option_pv * self.notional
        if n_past > 0:
            pv = pv * (n_future / n_total)

        return pv

    # ------------------------------------------------------------------
    # Simulation grid requirements
    # ------------------------------------------------------------------

    def required_sim_dates(self) -> list[date]:
        """Return averaging dates that must appear in the simulation grid."""
        return list(self._averaging_dates)

    # ------------------------------------------------------------------
    # Commodity fixing interface (called by the code that runs the valuation)
    # ------------------------------------------------------------------

    def compute_commodity_fixings(
        self,
        market_state: dict[str, RiskFactorSlice],
        sim_date: date,
        existing_fixings: dict | None = None,
    ) -> dict:
        """Stamp realised forward prices for newly past averaging dates.

        Call this before scenario_npvs when the trade is valued on several dates in turn.
        Returns only the new fixings stamped at this date;
        the caller merges them into its accumulator.

        Each averaging date is stamped exactly once, at the first sim step
        where avg_date <= sim_date, using the forward curve from that step.
        Subsequent steps skip it, locking realised prices into the path.
        """
        _existing = existing_fixings or {}
        new_fixings: dict = {}

        if not self._averaging_dates or self._averaging_dates[0] > sim_date:
            return {}

        fwd_slice = cast(CurveSlice, market_state[self.forward_curve_name])
        fwd_tenors_yf = excel_serials_to_year_fracs(
            fwd_slice.tenors, sim_date, self._dc,
        )
        right_extrap = (
            "flat"
            if self.forward_interpolator is linear_interpolator
            else "linear"
        )

        # For composite deals, also resolve the spot USDZAR = 1 / fx_spot so
        # that realised fixings are stored in the domestic (ZAR) currency.
        # At T=0 all discount factors are 1, so USDZAR = 1 / (USD/ZAR scalar).
        if self.quanto:
            fx_spot_slice = cast(ScalarSlice, market_state[self.fx_spot_name])
            usdzar = 1.0 / np.maximum(fx_spot_slice.values, 1e-12)

        for avg_date, pricing_date in zip(self._averaging_dates, self._pricing_dates):
            if avg_date > sim_date:
                break

            key = (self.forward_curve_name, avg_date)
            if key in _existing:
                continue

            F_comm = get_forward_price_from_slice(
                curve_serial_tenors=fwd_slice.tenors,
                curve_values=fwd_slice.values,
                value_date=sim_date,
                target_date=pricing_date,
                day_counter=self._dc,
                right_extrapolation=right_extrap,
                left_extrapolation="flat",
                _precomputed_tenors_yf=fwd_tenors_yf,
            )
            new_fixings[key] = F_comm * usdzar if self.quanto else F_comm

        return new_fixings
