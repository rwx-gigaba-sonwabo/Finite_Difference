"""Base class that every instrument follows.

It fixes the calls an instrument must offer, so that any instrument can be valued the same
way.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import TYPE_CHECKING, Sequence

import numpy as np

from market_data.risk_factor import RiskFactorSlice

if TYPE_CHECKING:
    pass


class Instrument(ABC):
    """Base class for all priceable instruments.

    Concrete subclasses hold all trade parameters (notional, rates,
    schedules, etc.) and implement :meth:`scenario_npvs` which values the
    instrument across simulation paths, and :meth:`precompute` for any
    offline preparation required before the simulation loop.
    """

    def __init__(self, name: str):
        self.name = name

    @property
    def effective_maturity(self) -> date | None:
        """Latest date on which this instrument can have a non-zero NPV.

        A caller can use this to check that its market data
        extends far enough to price this instrument.  Returns the first of:
        ``_effective_maturity`` (QL-adjusted, set by schedule-based instruments),
        ``maturity_date``, ``expiry_date``, ``delivery_date``, ``end_date``.
        Returns None for instruments that do not define any of these.
        """
        for attr in ("_effective_maturity", "maturity_date", "expiry_date",
                     "delivery_date", "end_date"):
            val = getattr(self, attr, None)
            if val is not None:
                return val
        return None

    def cashflow_dates(self) -> set[date]:
        """Return all cashflow payment dates for sub-grid interpolation.

        Override in concrete subclasses.  The default returns an empty set
        (instruments with no deterministic payment schedule, e.g. options).

        Note: no caller consumes this yet.  It is the extension point for
        interpolating market states at cashflow dates falling between
        valuation dates.
        """
        return set()

    def precompute(
        self,
        market_states: Sequence[dict[str, RiskFactorSlice]],
        dates: Sequence[date],
    ) -> None:
        """
        Called once per instrument before the simulation loop begins.

        Override this method for instruments whose pricing requires pre-computation
        against the full set of simulation scenarios, for example:

        - Finite difference / PDE pricers: solve the PDE offline on a representative
          curve and store a price surface for fast lookup at runtime.
        - Regression-based American MC (LSM): train exercise boundaries against the
          simulation paths before the valuation loop.
        - Surrogate / proxy models: fit a polynomial or Gaussian process to the
          scenario grid for cheap per-path evaluation.

        Parameters
        ----------
        market_states : sequence of dict[str, RiskFactorSlice]
            One market state per simulation date, in date order.
            Equivalent to [cube.get_time_slice(t) for t in range(cube.n_times)].
        dates : sequence of date
            The corresponding simulation dates.

        The default implementation is a no-op. Vanilla closed-form instruments
        (IRSwap, CDS) do not need to override this.
        """
        pass

    @abstractmethod
    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """
        Compute NPV for all paths at a single simulation date.

        Parameters
        ----------
        val_date : date
            The simulation date.
        market_state : dict[str, RiskFactorSlice]
            Factor values at this time step. Each key is a factor name,
            each value is a typed slice (ScalarSlice, CurveSlice, or
            SurfaceSlice). Comes from ScenarioCube.get_time_slice().
        fixings : dict or None
            Pre-computed Category B fixings. Keys are
            (curve_name, period_start_date), values are (n_paths,) arrays.
        rng : np.random.Generator or None
            Optional random number generator for instruments that use inner
            Monte Carlo simulation (e.g. Bermudan swaptions, exotics).
            Vanilla closed-form instruments ignore this parameter.

        Returns
        -------
        np.ndarray, shape (n_paths,)
            NPV per path.
        """
        pass

    def scenario_cashflows(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Return net settlement cashflow paid/received on *val_date*.

        Positive = received by us; negative = paid by us.
        Default: no cashflows (returns zeros).

        Override for instruments that make lump-sum payments at maturity
        or on specific dates (equity forwards, FX forwards, etc.).

        Returns
        -------
        np.ndarray, shape (n_paths,)
        """
        for v in market_state.values():
            return np.zeros(v.values.shape[0])
        return np.zeros(1)

    def npv(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
    ) -> float:
        """
        Compute NPV for a single market state (standalone / deterministic use).

        Wraps :meth:`scenario_npvs` for convenience when pricing outside a
        simulation context. Pass 1D curve values in market_state; CurveSlice
        normalises them to (1, n_tenors) automatically.

        Returns
        -------
        float
            Scalar NPV.
        """
        return float(self.scenario_npvs(val_date, market_state, fixings)[0])
