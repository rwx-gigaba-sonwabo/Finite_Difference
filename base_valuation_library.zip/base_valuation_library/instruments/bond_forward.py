"""Forward on a fixed rate bond.

The buyer agrees today to buy a bond on a delivery date at an agreed price. The value is the
bond's remaining coupons and principal after delivery, less the agreed price, discounted.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from instruments.instrument import Instrument
from instruments.components.schedule_config import ScheduleConfig
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, RiskFactorSlice
from models.bond_pv import bond_forward_pv
from utils.ql_helpers import advance_business_days


class BondForward(Instrument):
    """Forward contract on a fixed-coupon bond.

    Three-curve pricing framework
    ------------------------------
    Bond forwards require three distinct yield curves, each serving a
    separate economic role:

    bond_curve_name (e.g. "ZAR-BOND"):
        Discounts the underlying bond's cashflows (coupons + principal)
        to compute the spot dirty price and the PV of post-delivery
        cashflows.  This is the bond-market curve, typically derived
        from traded government bonds.

    repo_curve_name (e.g. "ZAR-BOND-REPO"):
        Carries the bond's dirty price forward from val_date to
        delivery_date.  This is the financing (repo) rate at which the
        bond is borrowed or lent against collateral.

    forward_curve_name (e.g. "ZAR-SWAP"):
        Discounts the forward payoff from delivery_date back to val_date.
        This is the OIS or swap curve used for all derivative discounting
        under the relevant CSA.

    T+3 settlement convention
    --------------------------
    South African bond transactions settle T+3 business days after the
    booking date (BESA convention).  *delivery_date* is the booking /
    fixing date; the actual cash-and-securities exchange happens at

        delivery_settle = delivery_date + settlement_lag business days

    All calculations, PV_after cutoff, accrued-interest at delivery,
    repo carry and swap discounting, are performed to *delivery_settle*,
    not *delivery_date*.  The forward remains live in simulation until
    *val_date >= delivery_settle*, so the value over the settlement period
    [delivery_date, delivery_settle] is not lost.

    NPV formula:

        NPV(t) = direction * [PV_after(t, T_s) * DF_swap(t, T_s) / DF_repo(t, T_s)
                              - K_dirty * DF_swap(t, T_s)]

    where T_s = delivery_settle and PV_after discounts only cashflows
    with payment_date strictly after T_s using the bond curve.  When all
    three curve names are identical the formula reduces to the standard
    single-curve cash-and-carry result.

    Strike priority:
    - *settlement_amount*: pre-specified dirty price in absolute currency
      units (e.g. ZAR 9,850,000).  When set, it is used directly as
      K_dirty and *forward_clean_price* is ignored.
    - *forward_clean_price*: clean price as a fraction of par.  Accrued
      interest at delivery_settle is added internally to produce K_dirty.

    After delivery settlement (*val_date >= delivery_settle*) the forward
    has settled and scenario_npvs returns zeros.

    Parameters
    ----------
    name : str
        Trade identifier.
    effective_date : date
        Bond issue / start date.
    maturity_date : date
        Bond maturity date.
    delivery_date : date
        Forward delivery / settlement date.  Must be strictly before
        *maturity_date*.
    coupon_rate : float
        Annual coupon rate (e.g. 0.08 for 8 %).
    coupon_frequency : int
        Coupon frequency in months (e.g. 6 = semi-annual, 12 = annual).
    notional : float
        Bond face value.
    forward_clean_price : float
        Agreed clean forward price as a fraction of par
        (e.g. 0.985 means 98.5 per 100 face value).  Used only when
        *settlement_amount* is None.
    bond_curve_name : str
        Key in *market_state* for the bond discount curve (ZAR-BOND).
        Used to compute the PV of post-delivery bond cashflows.
    interpolator : callable
        Interpolator factory ``(tenors, rates) -> callable`` used for the
        **bond curve** (ZAR-BOND).  Also serves as the default for the
        repo and forward curves when their own interpolator is not given.
        See :mod:`utils.interpolation`.
    repo_interpolator : callable or None
        Interpolator for the **repo curve** (ZAR-BOND-REPO).  Defaults to
        *interpolator* when None.  Repo curves are typically flat or
        piecewise-linear over short tenors, so a different scheme from the
        bond curve may be appropriate.
    forward_interpolator : callable or None
        Interpolator for the **forward / swap curve** (ZAR-SWAP).  Defaults
        to *interpolator* when None.  Swap curves are often interpolated
        with cubic or log-linear schemes that differ from the bond curve.
    direction : int
        +1 for buyer (long forward); -1 for seller (short forward).
    ex_coupon_days : int
        BESA book-close window in business days (default 0 = no CUMEX).
        When > 0, accrued interest is negative inside the window.
    settlement_amount : float or None
        Pre-agreed dirty settlement price in absolute currency units
        (e.g. ZAR 9_850_000 for a ZAR 10M notional bond at 98.5 dirty).
        When provided this is used directly as the forward strike,
        bypassing *forward_clean_price* and the accrued-interest
        calculation.  Recommended for compounding bonds
        where accrued interest has no standard definition.
    compounding : bool
        When True, the underlying bond does not pay periodic coupons.
        Interest is added to the balance each period
        and is paid as a single terminal cashflow at bond maturity.
        Combine with *settlement_amount* to specify the delivery strike.
    repo_curve_name : str or None
        Key in *market_state* for the repo / carry curve (ZAR-BOND-REPO).
        Used to carry the bond dirty price from val_date to delivery.
        Defaults to *bond_curve_name* when None (single-curve fallback).
    forward_curve_name : str or None
        Key in *market_state* for the payoff discount curve (ZAR-SWAP).
        Used to discount the forward payoff from delivery back to
        val_date.  Defaults to *bond_curve_name* when None.
    schedule_config : ScheduleConfig or None
        Full schedule configuration object.  When ``None``, the legacy
        flat keyword parameters below are used to construct one.
    calendar : str
        Calendar name (default ``"ZAR"``).  Ignored when
        *schedule_config* is provided.
    business_convention : str
        Business day convention.  Ignored when *schedule_config* is
        provided.
    termination_business_convention : str
        Termination convention.  Ignored when *schedule_config* is
        provided.
    date_generation : str
        Date generation rule (``"Backward"`` or ``"Forward"``).
        Ignored when *schedule_config* is provided.
    day_count : str
        Accrual day count convention (default ``"ACT/365"``).  Used for
        schedule cashflow fractions and accrued-interest computation.
        Ignored when *schedule_config* is provided.
    curve_day_count : str
        Day count for curve year fractions (default ``"ACT/365"``).
        Ignored when *schedule_config* is provided.
    end_of_month : bool
        End-of-month rule.  Ignored when *schedule_config* is provided.
    settlement_lag : int
        Business-day settlement lag (default 3 for BESA T+3).  The actual
        cash-and-securities exchange happens at
        ``delivery_settle = delivery_date + settlement_lag BD``.
        Pass 0 to revert to the old no-lag behaviour.

    Raises
    ------
    ValueError
        If *delivery_date* is not strictly before *maturity_date*, or if
        the computed *delivery_settle* date is not strictly before
        *maturity_date*.
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        delivery_date: date,
        coupon_rate: float,
        coupon_frequency: int,
        notional: float,
        forward_clean_price: float,
        bond_curve_name: str,
        interpolator: Callable,
        direction: int = 1,
        ex_coupon_days: int = 0,
        settlement_amount: float | None = None,
        compounding: bool = False,
        repo_curve_name: str | None = None,
        forward_curve_name: str | None = None,
        repo_interpolator: Callable | None = None,
        forward_interpolator: Callable | None = None,
        schedule_config: ScheduleConfig | None = None,
        calendar: str = "ZAR",
        business_convention: str = "ModifiedFollowing",
        termination_business_convention: str = "ModifiedFollowing",
        date_generation: str = "Backward",
        day_count: str = "ACT/365",
        curve_day_count: str = "ACT/365",
        end_of_month: bool = False,
        settlement_lag: int = 3,
        first_date: date | None = None,
        next_to_last_date: date | None = None,
    ):
        super().__init__(name)

        if delivery_date >= maturity_date:
            raise ValueError(
                f"delivery_date ({delivery_date}) must be strictly before "
                f"maturity_date ({maturity_date})"
            )

        self.settlement_lag = settlement_lag
        # Actual cash-and-securities exchange date: delivery_date + settlement_lag BD.
        # All PV, carry, and discounting calculations are anchored here, not at delivery_date.
        _cal = (schedule_config.calendar if schedule_config is not None else calendar)
        self._delivery_settle: date = advance_business_days(delivery_date, settlement_lag, _cal)
        if self._delivery_settle >= maturity_date:
            raise ValueError(
                f"delivery settlement date ({self._delivery_settle}, "
                f"delivery_date + {settlement_lag} BD) must be strictly before "
                f"maturity_date ({maturity_date})"
            )

        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.delivery_date = delivery_date
        self.coupon_rate = coupon_rate
        self.coupon_frequency = coupon_frequency
        self.notional = notional
        self.forward_clean_price = forward_clean_price
        self.bond_curve_name = bond_curve_name
        self.interpolator = interpolator
        self.direction = direction
        self.ex_coupon_days = ex_coupon_days
        self.settlement_amount = settlement_amount
        self.compounding = compounding
        self.repo_curve_name = repo_curve_name
        self.forward_curve_name = forward_curve_name
        # Per-curve interpolators; fall back to bond interpolator when not supplied.
        self.bond_interpolator = interpolator
        self.repo_interpolator = repo_interpolator if repo_interpolator is not None else interpolator
        self.forward_interpolator = forward_interpolator if forward_interpolator is not None else interpolator

        self.schedule_config = schedule_config or ScheduleConfig(
            calendar=calendar,
            business_convention=business_convention,
            termination_business_convention=termination_business_convention,
            date_generation=date_generation,
            day_count=day_count,
            curve_day_count=curve_day_count,
            end_of_month=end_of_month,
        )

        self._schedule = self.schedule_config.build_bond_schedule(
            self.effective_date, self.maturity_date, self.coupon_frequency,
            first_date=first_date,
            next_to_last_date=next_to_last_date,
        )

    @property
    def discount_curve_name(self) -> str:
        """Name of the curve the payoff is discounted on.

        Returns *forward_curve_name* when set (the payoff discount curve),
        otherwise falls back to *bond_curve_name*.  A caller can read this
        attribute when it needs to know which curve discounts the trade.
        """
        return self.forward_curve_name or self.bond_curve_name

    # ------------------------------------------------------------------
    # Instrument interface
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Per-path NPV of the bond forward at *val_date*.

        Parameters
        ----------
        val_date : date
            Simulation date.
        market_state : dict[str, RiskFactorSlice]
            Must contain *bond_curve_name* as a CurveSlice.
            *repo_curve_name* and *forward_curve_name* are looked up
            if set; otherwise bond_curve is used for all three roles.
        fixings : ignored
        rng : ignored

        Returns
        -------
        np.ndarray, shape (n_paths,)
            NPV per path.  Zero for all paths once *val_date* reaches
            *delivery_date*.
        """
        bond_slice: CurveSlice = market_state[self.bond_curve_name]
        n_paths = bond_slice.values.shape[0]

        # Zero after delivery settlement (T+settlement_lag BD), not at delivery_date itself.
        # This keeps the forward live through the [delivery_date, delivery_settle] stub window,
        # so the trade still has a value on those days.
        if val_date >= self._delivery_settle:
            return np.zeros(n_paths)

        bond_curve = YieldCurve(
            year_fracs=bond_slice.tenors,
            rates=bond_slice.values,
            interpolator=self.bond_interpolator,
        )

        repo_curve = None
        if self.repo_curve_name and self.repo_curve_name in market_state:
            repo_slice: CurveSlice = market_state[self.repo_curve_name]
            repo_curve = YieldCurve(
                year_fracs=repo_slice.tenors,
                rates=repo_slice.values,
                interpolator=self.repo_interpolator,
            )

        fwd_curve = None
        if self.forward_curve_name and self.forward_curve_name in market_state:
            fwd_slice: CurveSlice = market_state[self.forward_curve_name]
            fwd_curve = YieldCurve(
                year_fracs=fwd_slice.tenors,
                rates=fwd_slice.values,
                interpolator=self.forward_interpolator,
            )

        sc = self.schedule_config

        return bond_forward_pv(
            schedule=self._schedule,
            coupon_rate=self.coupon_rate,
            notional=self.notional,
            val_date=val_date,
            delivery_date=self._delivery_settle,   # T+settlement_lag BD
            forward_clean_price=self.forward_clean_price,
            bond_curve=bond_curve,
            day_counter=sc.day_counter,
            curve_day_counter=sc.curve_day_counter,
            direction=self.direction,
            ex_coupon_days=self.ex_coupon_days,
            ql_calendar=sc.ql_calendar,
            settlement_amount=self.settlement_amount,
            compounding=self.compounding,
            repo_curve=repo_curve,
            forward_curve=fwd_curve,
        )
