"""Asian option on an equity price.

A call or put on the average of the equity price over a set of sampling dates, valued with a
lognormal approximation to the distribution of the average.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, TYPE_CHECKING, cast

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.equity_pv import black76_euro_option
from utils.ql_helpers import (
    DAY_COUNTERS,
    generate_business_days,
    to_ql_date,
)

if TYPE_CHECKING:
    from market_data.vol_surface import BenchmarkVolSkew


class EquityAsian(Instrument):
    """Arithmetically averaged Asian equity option priced via moment matching.

    Daily fixing dates are generated as business days in [period_start, period_end].
    Each fixing's risk-neutral forward price is computed analytically from spot,
    carry, and dividend curves via :func:`equity_forward_price`.  The arithmetic
    average of future forwards is matched to a log-normal distribution using the
    first two moments, producing a single adjusted volatility for a Black-76
    European option.

    When some fixings have already been observed the strike is adjusted to
    account for the realised average so far, and only the remaining m future
    fixings enter the moment-matching calculation.  Realised fixings are stored
    as spot prices at each averaging date.

    Pricing model (m future fixings)
    ---------------------------------
    Let F(i) = equity_forward_price at fixing i,
        vol(i) = BenchmarkVolSkew.get_vol(strike_for_vol, t(i)),
        t(i)   = year fraction from val_date to averaging date i.

        M1 = (1/m) Σᵢ F(i)

        M2 = (1/m²) [ Σᵢ F(i)² exp(vol(i)² t(i))
                       + 2 Σⱼ Σᵢ<ⱼ F(i) F(j) exp(vol(i)² t(i)) ]

        σ_adj = sqrt( (ln M2 − 2 ln M1) / T_expiry )

        PV = direction × Black76(M1, K_eff, σ_adj, df(T_settle), T_expiry, is_call)
             × notional × (m / n_total  if past fixings exist)

    Strike adjustment for past fixings (n_past past, m future, n_total = n_past + m):

        K_eff        = (n_total / m) × K − (n_past / m) × S̄_past
        strike_for_vol = K_eff

    Parameters
    ----------
    name : str
        Trade identifier.
    period_start : date
        First date of the averaging window.
    period_end : date
        Last date of the averaging window (option expiry for moment-matching).
    settlement_date : date
        Date on which the settled payoff is paid; used only for discounting.
    strike : float
        Option strike.
    notional : float
        Contract notional.
    is_call : bool
        True for a call (buyer benefits when average > strike).
    vol_surface : BenchmarkVolSkew
        Equity implied-vol skew surface.
    spot_name : str
        Risk-factor name for the equity spot price (scalar).
    carry_curve_name : str
        Risk-factor name for the carry / funding curve.
    discount_curve_name : str
        Risk-factor name for the discount curve.
    dividend_curve_name : str
        Risk-factor name for the continuous dividend yield curve.
    averaging_calendar : str
        Calendar key used to enumerate business days in the averaging window.
    carry_interpolator : callable
        Interpolator factory for the carry curve.
    dividend_interpolator : callable
        Interpolator factory for the dividend yield curve.
    discount_interpolator : callable
        Interpolator factory for the discount curve.
    day_count : str
        Day-count convention key (default ``"ACT/365"``).
    direction : int
        ``+1`` for long, ``-1`` for short.  Default ``+1``.
    sticky : str
        Stickiness convention passed to ``vol_surface.get_vol``
        (``'strike'`` or ``'delta'``).  Default ``'strike'``.
    div_date : date, optional
        Date of a discrete dividend paid within the averaging period.
        When provided, the dividend yield is interpolated at this date
        and applied to all averaging dates strictly before it; the yield
        at ``period_end`` is applied to all averaging dates from
        ``div_date`` onward.  When omitted, the yield at ``period_end``
        is used for all fixing dates.
    """

    def __init__(
        self,
        name: str,
        period_start: date,
        period_end: date,
        settlement_date: date,
        strike: float,
        notional: float,
        is_call: bool,
        vol_surface: BenchmarkVolSkew,
        spot_name: str,
        carry_curve_name: str,
        discount_curve_name: str,
        dividend_curve_name: str,
        averaging_calendar: str,
        carry_interpolator: Callable,
        dividend_interpolator: Callable,
        discount_interpolator: Callable,
        day_count: str = "ACT/365",
        direction: int = 1,
        sticky: str = "strike",
        div_date: date | None = None,
    ) -> None:
        super().__init__(name)
        self.period_start = period_start
        self.period_end = period_end
        self.settlement_date = settlement_date
        self.strike = strike
        self.notional = notional
        self.is_call = is_call
        self.vol_surface = vol_surface
        self.spot_name = spot_name
        self.carry_curve_name = carry_curve_name
        self.discount_curve_name = discount_curve_name
        self.dividend_curve_name = dividend_curve_name
        self.carry_interpolator = carry_interpolator
        self.dividend_interpolator = dividend_interpolator
        self.discount_interpolator = discount_interpolator
        self.direction = direction
        self.sticky = sticky
        self.div_date = div_date
        self._dc = DAY_COUNTERS[day_count]

        self._averaging_dates: list[date] = generate_business_days(
            period_start, period_end, averaging_calendar,
        )

    # ------------------------------------------------------------------
    # Pricing
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Compute per-path NPV of the Asian equity option.

        Parameters
        ----------
        val_date : date
            Current valuation date.
        market_state : dict
            Mapping from risk-factor name to RiskFactorSlice.
        fixings : dict or None
            Realised spot prices for past averaging dates.
            Key: ``(spot_name, averaging_date)`` →
            ``np.ndarray (n_paths,)`` or scalar.
        rng : ignored.

        Returns
        -------
        np.ndarray, shape (n_paths,)
        """
        spot_slice = cast(ScalarSlice, market_state[self.spot_name])
        spot = spot_slice.values  # (n_paths,)
        n_paths = spot.shape[0]

        if val_date > self.settlement_date:
            return np.zeros(n_paths)

        carry_slice = cast(CurveSlice, market_state[self.carry_curve_name])
        carry_curve = YieldCurve(
            carry_slice.tenors, carry_slice.values, self.carry_interpolator,
        )

        div_slice = cast(CurveSlice, market_state[self.dividend_curve_name])
        div_curve = YieldCurve(
            div_slice.tenors, div_slice.values, self.dividend_interpolator,
        )

        disc_slice = cast(CurveSlice, market_state[self.discount_curve_name])
        disc_curve = YieldCurve(
            disc_slice.tenors, disc_slice.values, self.discount_interpolator,
        )

        T_settle = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.settlement_date),
        ))
        df = disc_curve.discount_factor(T_settle)

        T_expiry = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.period_end),
        ))

        # ------------------------------------------------------------------
        # Dividend yield setup: if div_date is supplied, interpolate q at
        # that date (applied to averaging dates strictly before it) and q at
        # expiry (applied from div_date onward).  Otherwise use q(T_expiry)
        # as a single constant across all fixing dates.
        # ------------------------------------------------------------------
        if self.div_date is not None:
            T_div = float(self._dc.yearFraction(
                to_ql_date(val_date), to_ql_date(self.div_date),
            ))
            q_pre  = div_curve.get_rate(T_div)     # (n_paths,), yield at dividend date
            q_post = div_curve.get_rate(T_expiry)  # (n_paths,), yield at expiry
        else:
            T_div  = None
            q_post = div_curve.get_rate(T_expiry)  # (n_paths,), constant for all dates

        _fix: dict = fixings if fixings is not None else {}
        n_total = len(self._averaging_dates)

        def _get_fixing(avg_date: date) -> np.ndarray:
            """Return realised spot price for a past averaging date."""
            key = (self.spot_name, avg_date)
            if key in _fix:
                f = np.asarray(_fix[key], dtype=np.float64)
                return np.full(n_paths, float(f)) if f.ndim == 0 else f
            return spot.copy()

        # ------------------------------------------------------------------
        # At or past period end: all fixings realised, intrinsic payoff
        # ------------------------------------------------------------------
        if val_date >= self.period_end:
            price_sum = np.zeros(n_paths)
            for avg_date in self._averaging_dates:
                price_sum += _get_fixing(avg_date)
            S_avg = price_sum / n_total
            if self.is_call:
                payoff = np.maximum(S_avg - self.strike, 0.0)
            else:
                payoff = np.maximum(self.strike - S_avg, 0.0)
            return self.direction * payoff * self.notional * df

        # ------------------------------------------------------------------
        # Accumulate realised spot prices for past averaging dates
        # ------------------------------------------------------------------
        past_sum = np.zeros(n_paths)
        n_past = 0

        for avg_date in self._averaging_dates:
            if avg_date >= val_date:
                break
            n_past += 1
            past_sum += _get_fixing(avg_date)

        n_future = n_total - n_past

        # ------------------------------------------------------------------
        # Effective strike adjusted for any past fixings
        # ------------------------------------------------------------------
        if n_past > 0:
            K_eff: float | np.ndarray = (
                (n_total / n_future) * self.strike
                - (n_past / n_future) * (past_sum / n_past)
            )
            # K_eff (= strike_bar / normalize) is passed to the moneyness lookup
            # raw for a Sticky_Strike surface.  The surface then
            # computes log(K_eff / atm_ref).
            strike_for_vol: float | np.ndarray = K_eff
        else:
            K_eff = float(self.strike)
            strike_for_vol = float(self.strike)

        strike_for_vol = np.maximum(strike_for_vol, 1e-12)

        # ------------------------------------------------------------------
        # Moment matching over future fixing dates
        # ------------------------------------------------------------------
        M1_sum = np.zeros(n_paths)
        M2_diag = np.zeros(n_paths)
        M2_cross = np.zeros(n_paths)
        running_weighted = np.zeros(n_paths)

        for avg_date in self._averaging_dates:
            if avg_date < val_date:
                continue

            t_i = float(self._dc.yearFraction(
                to_ql_date(val_date), to_ql_date(avg_date),
            ))

            # Forward price using constant or stepped dividend yield.
            # q is pre-dividend for dates before T_div, post-dividend after.
            r_i = carry_curve.get_rate(t_i)
            q_i = q_pre if (self.div_date is not None and avg_date < self.div_date) else q_post
            F_i = spot * np.exp((r_i - q_i) * t_i)

            vol_i = np.asarray(
                self.vol_surface.get_vol(
                    strike=strike_for_vol,
                    tenor=t_i,
                    forward_skew=F_i if self.sticky == "delta" else None,
                    forward_expiry=F_i if self.sticky == "delta" else None,
                    sticky=self.sticky,
                ),
                dtype=np.float64,
            )
            if vol_i.ndim == 0:
                vol_i = np.full(n_paths, float(vol_i))

            exp_var_i = np.exp(vol_i ** 2 * t_i)

            M2_cross += F_i * running_weighted
            running_weighted += F_i * exp_var_i

            M2_diag += F_i ** 2 * exp_var_i
            M1_sum += F_i


        M1 = M1_sum / n_future
        M2 = (M2_diag + 2.0 * M2_cross) / (n_future ** 2)

        safe_M1 = np.maximum(M1, 1e-12)
        log_ratio = np.log(np.maximum(M2, safe_M1 ** 2)) - 2.0 * np.log(safe_M1)
        log_ratio = np.maximum(log_ratio, 0.0)
        adjusted_vol = (
            np.sqrt(log_ratio / T_expiry) if T_expiry > 0.0 else np.zeros(n_paths)
        )

        option_pv = black76_euro_option(
            forward=M1,
            strike=K_eff,
            vol=adjusted_vol,
            df=df,
            T=T_expiry,
            is_call=self.is_call,
        )

        pv = self.direction * option_pv * self.notional
        if n_past > 0:
            pv = pv * (n_future / n_total)

        return pv

    # ------------------------------------------------------------------
    # Simulation grid requirements
    # ------------------------------------------------------------------

    def required_sim_dates(self) -> list[date]:
        """Return averaging dates that must appear in the simulation grid.

        A caller that values the trade on a grid of dates should call this
        before building the grid so that each averaging date receives
        its own spot.
        Without these dates in the grid, all fixings within a
        gap are stamped with the same spot, collapsing the Asian
        into a European payoff.
        """
        return list(self._averaging_dates)

    # ------------------------------------------------------------------
    # Fixing interface (called by the code that runs the valuation)
    # ------------------------------------------------------------------

    def compute_commodity_fixings(
        self,
        market_state: dict[str, RiskFactorSlice],
        sim_date: date,
        existing_fixings: dict | None = None,
    ) -> dict:
        """Stamp realised spot prices for newly past averaging dates.

        Call this before scenario_npvs when the trade is valued on several dates in turn.
        Returns only the new fixings stamped at this step; the caller merges
        them into its accumulator.

        Each averaging date is stamped exactly once, at the first sim step
        where avg_date <= sim_date, locking the realised spot price into the
        path.
        """
        _existing = existing_fixings or {}
        new_fixings: dict = {}

        if not self._averaging_dates or self._averaging_dates[0] > sim_date:
            return {}

        spot_slice = cast(ScalarSlice, market_state[self.spot_name])
        spot = spot_slice.values  # (n_paths,)

        for avg_date in self._averaging_dates:
            if avg_date > sim_date:
                break

            key = (self.spot_name, avg_date)
            if key in _existing:
                continue

            new_fixings[key] = spot.copy()

        return new_fixings
