"""European option on an equity price.

A call or put valued with the Black model on the equity forward price.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, TYPE_CHECKING

import numpy as np

from instruments.instrument import Instrument
from utils.ql_helpers import DAY_COUNTERS
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice
from models.equity_pv import equity_forward_price, black76_euro_option

if TYPE_CHECKING:
    from market_data.vol_surface import BenchmarkVolSkew


class EquityOption(Instrument):
    """European equity option priced with Black-76 on the equity forward.

    The forward is built from spot, carry curve, and dividend curve via
    :func:`equity_forward_price`.  The option is then valued with
    :func:`black76_euro_option`.

    Parameters
    ----------
    name : str
        Trade identifier.
    expiry_date : date
        Option expiry / exercise date.
    strike : float
        Strike price.
    is_call : bool
        True for a call, False for a put.
    nominal : float
        Notional amount.
    spot_name : str
        Risk factor name for the equity spot price (scalar).
    carry_curve_name : str
        Risk factor name for the carry / funding curve (used to build the
        forward price).
    dividend_curve_name : str
        Risk factor name for the continuous dividend yield curve.
    vol_name : str
        Risk factor name for the Black implied volatility (scalar).
        Ignored when *vol_skew* is provided.
    carry_interpolator : callable
        Interpolator factory for the carry curve.
    dividend_interpolator : callable
        Interpolator factory for the dividend yield curve.
    discount_curve_name : str, optional
        Risk factor name for the discount curve.  When omitted the carry
        curve is used for discounting (original behaviour).
    discount_interpolator : callable, optional
        Interpolator factory for the discount curve.  Required when
        *discount_curve_name* is provided.
    vol_skew : BenchmarkVolSkew, optional
        Benchmark volatility skew surface.  When supplied, implied vol is
        read from the skew (using *strike* and remaining tenor) instead of
        from the market state.
    sticky : {'strike', 'delta'}
        Stickiness convention used with *vol_skew* (default ``'strike'``).
    day_count : str
        Day count convention for year fractions (default "ACT/365").
    """

    def __init__(
        self,
        name: str,
        expiry_date: date,
        strike: float,
        is_call: bool,
        nominal: float,
        spot_name: str,
        carry_curve_name: str,
        dividend_curve_name: str,
        vol_name: str = "",
        carry_interpolator: Callable = None,
        dividend_interpolator: Callable = None,
        discount_curve_name: str = "",
        discount_interpolator: Callable = None,
        vol_skew: BenchmarkVolSkew | None = None,
        sticky: str = "strike",
        day_count: str = "ACT/365",
    ):
        super().__init__(name)
        self.expiry_date = expiry_date
        self.strike = strike
        self.is_call = is_call
        self.nominal = nominal
        self.spot_name = spot_name
        self.carry_curve_name = carry_curve_name
        self.dividend_curve_name = dividend_curve_name
        self.vol_name = vol_name
        self.carry_interpolator = carry_interpolator
        self.dividend_interpolator = dividend_interpolator
        self.discount_curve_name = discount_curve_name
        self.discount_interpolator = discount_interpolator
        self.vol_skew = vol_skew
        self.sticky = sticky
        self._dc = DAY_COUNTERS[day_count]

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        # Past expiry: worth nothing
        if val_date > self.expiry_date:
            spot_slice = market_state[self.spot_name]
            n_paths = spot_slice.values.shape[0]
            return np.zeros(n_paths)

        from utils.ql_helpers import to_ql_date

        T = self._dc.yearFraction(to_ql_date(val_date), to_ql_date(self.expiry_date))

        # Spot
        spot_slice: ScalarSlice = market_state[self.spot_name]
        spot = spot_slice.values  # (n_paths,)

        # Carry curve
        carry_slice: CurveSlice = market_state[self.carry_curve_name]
        carry_curve = YieldCurve(
            carry_slice.tenors, carry_slice.values, self.carry_interpolator,
        )

        # Dividend yield curve
        div_slice: CurveSlice = market_state[self.dividend_curve_name]
        div_curve = YieldCurve(
            div_slice.tenors, div_slice.values, self.dividend_interpolator,
        )

        # Forward price (carry-based df is only used when no separate discount curve)
        F, carry_df, _ = equity_forward_price(spot, carry_curve, div_curve, T)

        # Discount factor
        if self.discount_curve_name:
            disc_slice: CurveSlice = market_state[self.discount_curve_name]
            disc_curve = YieldCurve(
                disc_slice.tenors, disc_slice.values, self.discount_interpolator,
            )
            df = disc_curve.discount_factor(T)
        else:
            df = carry_df

        # Volatility
        if self.vol_skew is not None:
            vol = self.vol_skew.get_vol(
                strike=self.strike,
                tenor=T,
                forward_skew=F if self.sticky == "delta" else None,
                forward_expiry=F if self.sticky == "delta" else None,
                sticky=self.sticky,
            )
        else:
            vol_slice: ScalarSlice = market_state[self.vol_name]
            vol = vol_slice.values  # (n_paths,)

        # Black-76 option value
        option_pv = black76_euro_option(F, self.strike, vol, df, T, self.is_call)

        return option_pv * self.nominal
