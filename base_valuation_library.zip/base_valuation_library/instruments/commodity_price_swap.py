"""Swap of two commodity price legs.

Each period one leg pays a fixed price and the other a floating price, both on a fixed
quantity. The value is the receive leg less the pay leg.
"""

from __future__ import annotations

from bisect import bisect_right
from datetime import date
from typing import Callable

import numpy as np

from instruments.components.commodity_price_leg import (
    CommodityLegType,
    CommodityPriceLeg,
)
from instruments.components.schedule_config import ScheduleConfig
from instruments.instrument import Instrument
from market_data.risk_factor import RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.commodity_pv import commodity_leg_forward_price, commodity_price_leg_pv
from utils.ql_helpers import advance_business_days


class CommodityPriceSwap(Instrument):
    """Commodity Price Swap (CPS) priced against a ScenarioCube.

    Generalises the Commodity Price Swap / Emission Credit Price Swap
    model theory to a single instrument: each leg's period cashflow is
    ``price_i * quantity * D_discount(t, T_i)``, where ``price_i`` is
    either a constant (FIXED leg, the usual swap strike) or a
    stochastic reference price (FLOATING leg) built one of two ways,
    selected per leg via :class:`~instruments.components.commodity_price_leg.PriceConstruction`:

    CURVE : the market-observed forward price, linearly interpolated
        from a listed forward/futures price curve, the same mechanic
        used by :class:`~instruments.commodity_forward.CommodityForward`.
    CARRY : a theoretical forward price synthesised from the spot price
        rolled forward at the cost of financing the position (spot
        divided by the carry-curve discount-factor ratio, plus a
        spread), a cash-and-carry replication of the curve leg.

    Combining a FIXED leg with a FLOATING leg gives the standard
    fixed-for-float commodity swap; two FLOATING legs (e.g. CURVE vs
    CARRY) give the float-for-float structure used to isolate the
    curve-vs-carry basis (as in the Emission Credit Price Swap).  Set
    ``frequency=0`` on a leg for a zero-coupon (single bullet period at
    maturity) structure, used when the underlying is only listed with a
    handful of maturities and each leg therefore settles once.

    Schedules are generated once at construction via QuantLib, mirroring
    :class:`~instruments.ir_swap.IRSwap`.  ``receive_leg`` and
    ``pay_leg`` follow the same convention: NPV = receive_leg PV − pay_leg
    PV.

    **Fixing lifecycle**

    FLOATING-leg prices for periods whose settlement date has already
    been crossed must stop fluctuating with the (later) live market
    state, otherwise a realised price would keep changing with every
    subsequent valuation step, both economically wrong (the cashflow has
    already fixed) and a source of spurious path variance (the same
    issue solved for CommodityForward / CommodityAverageForward via
    a fixing cache kept by the caller).  Because a swap can mix
    two independently-keyed FLOATING legs, this instrument freezes its
    own fixings via :meth:`precompute` rather than the single-curve-name
    caller hook: for each period whose settlement date falls
    within the simulated horizon, the reference price is computed once
    from the market state at the nearest scenario date ≤ that
    settlement date and cached.  ``scenario_npvs`` then prefers this
    frozen price over recomputing it live.  When used standalone (no
    caller, ``precompute`` never called), every FLOATING price
    is computed live from the current market state, the same fallback
    CommodityForward applies pre-delivery.

    Parameters
    ----------
    name : str
        Trade identifier.
    effective_date : date
        Swap start date.
    maturity_date : date
        Swap end date.
    receive_leg : CommodityPriceLeg
        Leg received by the instrument holder.
    pay_leg : CommodityPriceLeg
        Leg paid by the instrument holder.
    discount_curve_name : str
        Risk-factor name for the discount curve (single currency).
    discount_interpolator : callable
        Interpolator factory for the discount curve.
    schedule_config : ScheduleConfig or None
        Reusable schedule configuration.  When omitted, one is built
        from the legacy flat parameters below.
    calendar, business_convention, termination_business_convention,
    date_generation, day_count, curve_day_count, end_of_month :
        Legacy flat schedule parameters, used only when
        ``schedule_config`` is not supplied.
    include_sim_date_cashflows : bool
        When True, cashflows due exactly on val_date are always
        included (by default only
        forced on for the final period, at the effective maturity).
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        receive_leg: CommodityPriceLeg,
        pay_leg: CommodityPriceLeg,
        discount_curve_name: str,
        discount_interpolator: Callable,
        schedule_config: ScheduleConfig | None = None,
        calendar: str = "TARGET",
        business_convention: str = "ModifiedFollowing",
        termination_business_convention: str = "ModifiedFollowing",
        date_generation: str = "Backward",
        day_count: str = "ACT/365",
        curve_day_count: str = "ACT/365",
        end_of_month: bool = False,
        include_sim_date_cashflows: bool = False,
    ) -> None:
        super().__init__(name)
        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.receive_leg = receive_leg
        self.pay_leg = pay_leg
        self.discount_curve_name = discount_curve_name
        self.discount_interpolator = discount_interpolator
        self.include_sim_date_cashflows = include_sim_date_cashflows

        self.schedule_config = schedule_config or ScheduleConfig(
            calendar=calendar,
            business_convention=business_convention,
            termination_business_convention=termination_business_convention,
            date_generation=date_generation,
            day_count=day_count,
            curve_day_count=curve_day_count,
            end_of_month=end_of_month,
        )

        self._frozen_fixings: dict[tuple[str, date], np.ndarray] = {}
        self._generate_schedules()

    # ------------------------------------------------------------------
    # schedule generation
    # ------------------------------------------------------------------

    def _generate_schedules(self) -> None:
        self.receive_schedule = self.schedule_config.build(
            self.effective_date, self.maturity_date, self.receive_leg.frequency,
        )
        self.pay_schedule = self.schedule_config.build(
            self.effective_date, self.maturity_date, self.pay_leg.frequency,
        )
        self.receive_settle_dates = self._compute_settle_dates(
            self.receive_schedule, self.receive_leg,
        )
        self.pay_settle_dates = self._compute_settle_dates(
            self.pay_schedule, self.pay_leg,
        )
        self._effective_maturity: date = max(
            max(p for _, _, p, _ in self.receive_schedule),
            max(p for _, _, p, _ in self.pay_schedule),
        )

        # (fixing_key_name, accrual_end) -> settle_date, used by scenario_npvs
        # to gate a frozen fixing on val_date having actually reached it, 
        # precompute() freezes prices for the *whole* simulated horizon up
        # front, so without this gate a period whose settlement date is still
        # ahead of a given val_date would incorrectly use a price realised
        # later along the path instead of the live market_state at val_date.
        self._settle_date_by_key: dict[tuple[str, date], date] = {}
        for schedule, settle_dates, leg in (
            (self.receive_schedule, self.receive_settle_dates, self.receive_leg),
            (self.pay_schedule, self.pay_settle_dates, self.pay_leg),
        ):
            if leg.leg_type != CommodityLegType.FLOATING:
                continue
            for (_, end, _, _), settle_date in zip(schedule, settle_dates):
                self._settle_date_by_key[(leg.fixing_key_name, end)] = settle_date

    def _compute_settle_dates(
        self,
        schedule: list[tuple[date, date, date, float]],
        leg: CommodityPriceLeg,
    ) -> list[date]:
        """Settlement-lag-adjusted T_settle for each period, aligned by index."""
        if leg.leg_type != CommodityLegType.FLOATING or leg.settlement_lag == 0:
            return [end for _, end, _, _ in schedule]
        return [
            advance_business_days(end, leg.settlement_lag, leg.lag_calendar)
            for _, end, _, _ in schedule
        ]

    # ------------------------------------------------------------------
    # fixing lifecycle
    # ------------------------------------------------------------------

    def precompute(
        self,
        market_states: list[dict[str, RiskFactorSlice]],
        dates: list[date],
    ) -> None:
        """Freeze each FLOATING period's reference price once its
        settlement date falls within the simulated horizon.

        Uses the market state at the nearest scenario date ≤ the
        period's settlement date (grid-snapped, the same precision
        tier as CommodityForward's standalone ``compute_commodity_fixings``
        convenience method).
        """
        self._frozen_fixings = {}
        if not dates:
            return
        horizon_end = dates[-1]

        for schedule, settle_dates, leg in (
            (self.receive_schedule, self.receive_settle_dates, self.receive_leg),
            (self.pay_schedule, self.pay_settle_dates, self.pay_leg),
        ):
            if leg.leg_type != CommodityLegType.FLOATING:
                continue
            for (_, end, _, _), settle_date in zip(schedule, settle_dates):
                if settle_date > horizon_end:
                    continue
                idx = max(bisect_right(dates, settle_date) - 1, 0)
                as_of_date = dates[idx]
                price = commodity_leg_forward_price(
                    leg, market_states[idx], as_of_date, settle_date,
                    self.schedule_config.curve_day_counter,
                )
                self._frozen_fixings[(leg.fixing_key_name, end)] = np.asarray(
                    price, dtype=np.float64,
                )

    # ------------------------------------------------------------------
    # pricing
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        disc_slice = market_state[self.discount_curve_name]
        n_paths = disc_slice.values.shape[0]

        if val_date > self._effective_maturity:
            return np.zeros(n_paths)

        discount_curve = YieldCurve(
            year_fracs=disc_slice.tenors,
            rates=disc_slice.values,
            interpolator=self.discount_interpolator,
        )

        include_on_date = (
            self.include_sim_date_cashflows
            or val_date == self._effective_maturity
        )
        # Only honour a frozen fixing once val_date has actually reached its
        # settlement date, precompute() freezes the whole horizon up front,
        # so a period whose settlement date is still ahead of val_date must
        # fall back to the live market_state instead of a value realised
        # later along the path (see _settle_date_by_key construction).
        eligible_frozen = {
            key: value
            for key, value in self._frozen_fixings.items()
            if self._settle_date_by_key[key] <= val_date
        }
        merged_fixings = {**eligible_frozen, **(fixings or {})}
        day_counter = self.schedule_config.curve_day_counter

        rec_pv = commodity_price_leg_pv(
            self.receive_schedule, self.receive_settle_dates, self.receive_leg,
            val_date, market_state, discount_curve, n_paths, day_counter,
            fixings=merged_fixings, include_on_val_date=include_on_date,
        )
        pay_pv = commodity_price_leg_pv(
            self.pay_schedule, self.pay_settle_dates, self.pay_leg,
            val_date, market_state, discount_curve, n_paths, day_counter,
            fixings=merged_fixings, include_on_val_date=include_on_date,
        )

        return rec_pv - pay_pv
