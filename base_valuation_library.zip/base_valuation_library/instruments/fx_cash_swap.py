"""FX swap as two fixed cash amounts in two currencies.

Each amount is discounted on its own curve and the foreign amount is converted at spot.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from instruments.instrument import Instrument
from utils.ql_helpers import to_ql_date, DAY_COUNTERS
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice


class FXCashSwap(Instrument):
    """FX cash swap (forward-forward).

    Two FX forwards: a near-leg exchange at ``near_fx_rate`` on the
    effective date and a far-leg reverse exchange at ``far_fx_rate``
    on the maturity date.

    Priced from the perspective of the party that **buys foreign** on
    the near leg and **sells foreign** on the far leg:

        Near leg:  pay  domestic_notional,  receive foreign_notional
        Far  leg:  receive domestic_notional × (far / near),  pay foreign_notional

    where ``domestic_notional = foreign_notional × near_fx_rate``.

    NPV is reported in the domestic currency.

    Parameters
    ----------
    name : str
        Trade identifier.
    effective_date : date
        Near-leg settlement date.
    maturity_date : date
        Far-leg settlement date.
    foreign_notional : float
        Notional in the foreign currency (exchanged on both legs).
    near_fx_rate : float
        Agreed FX rate for the near leg (domestic per 1 foreign).
    far_fx_rate : float
        Agreed FX rate for the far leg (domestic per 1 foreign).
    domestic_discount_curve_name : str
        Risk factor name for the domestic discount curve.
    foreign_discount_curve_name : str
        Risk factor name for the foreign discount curve.
    fx_spot_name : str
        Risk factor name for the FX spot rate (domestic per 1 foreign).
    domestic_interpolator : callable
        Interpolator factory for the domestic discount curve.
    foreign_interpolator : callable
        Interpolator factory for the foreign discount curve.
    day_count : str
        Day count convention for year fractions (default "ACT/365").
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        foreign_notional: float,
        near_fx_rate: float,
        far_fx_rate: float,
        domestic_discount_curve_name: str,
        foreign_discount_curve_name: str,
        fx_spot_name: str,
        domestic_interpolator: Callable,
        foreign_interpolator: Callable,
        day_count: str = "ACT/365",
    ):
        super().__init__(name)
        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.foreign_notional = foreign_notional
        self.near_fx_rate = near_fx_rate
        self.far_fx_rate = far_fx_rate
        self.domestic_discount_curve_name = domestic_discount_curve_name
        self.foreign_discount_curve_name = foreign_discount_curve_name
        self.fx_spot_name = fx_spot_name
        self.domestic_interpolator = domestic_interpolator
        self.foreign_interpolator = foreign_interpolator
        self._dc = DAY_COUNTERS[day_count]

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        fx_slice: ScalarSlice = market_state[self.fx_spot_name]
        fx_spot = fx_slice.values  # (n_paths,)
        n_paths = fx_spot.shape[0]

        if val_date > self.maturity_date:
            return np.zeros(n_paths)

        ql_val = to_ql_date(val_date)

        # Discount curves
        dom_slice: CurveSlice = market_state[self.domestic_discount_curve_name]
        dom_curve = YieldCurve(
            dom_slice.tenors, dom_slice.values, self.domestic_interpolator,
        )

        for_slice: CurveSlice = market_state[self.foreign_discount_curve_name]
        for_curve = YieldCurve(
            for_slice.tenors, for_slice.values, self.foreign_interpolator,
        )

        N_for = self.foreign_notional
        pv = np.zeros(n_paths)

        # Near leg (if still future): pay domestic, receive foreign
        if val_date < self.effective_date:
            t_near = self._dc.yearFraction(ql_val, to_ql_date(self.effective_date))
            pv += (
                N_for * for_curve.discount_factor(t_near) * fx_spot
                - N_for * self.near_fx_rate * dom_curve.discount_factor(t_near)
            )

        # Far leg: receive domestic, pay foreign
        t_far = self._dc.yearFraction(ql_val, to_ql_date(self.maturity_date))
        pv += (
            N_for * self.far_fx_rate * dom_curve.discount_factor(t_far)
            - N_for * for_curve.discount_factor(t_far) * fx_spot
        )

        return pv
