"""FX forward.

An agreement to exchange an amount of one currency for an amount of another on a
settlement date. The forward FX rate comes from the two interest rate curves.
"""

from __future__ import annotations

from datetime import date
from typing import Callable
import numpy as np
from instruments.instrument import Instrument
from utils.ql_helpers import to_ql_date, DAY_COUNTERS
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice


class FXForward(Instrument):
    """FX forward instrument.

    At maturity the holder receives the agreed domestic amount and pays the
    market-implied forward equivalent, valued using the two-basis-curve
    covered-interest-parity formula.

    Trade economics
    ---------------
    The FX forward rate is computed as::

        F(t, T) = (df_for * df_for_forecast) / (S(t) * df_dom * df_dom_forecast)

    NPV (in domestic currency) is::

        NPV = N * (agreed_rate - F(t, T)) * df_dom

    An optional *report_fx_name* converts the result to a reporting currency.

    Parameters
    ----------
    name : str
        Trade identifier.
    effective_date : date
        Near-leg / spot settlement date (stored for reference; does not
        enter the forward calculation).
    maturity_date : date
        Far-leg settlement date.
    initial_spot : float
        FX spot rate at trade inception (domestic per 1 foreign).
    notional : float
        Notional in the foreign currency.
    agreed_rate : float
        Pre-agreed forward FX rate (domestic per 1 foreign), fixed at inception.
    domestic_basis : str
        Risk factor name for the domestic basis / forecast curve
        (e.g. ``"ZAR-USD-BASIS"``).
    domestic_curve : str
        Risk factor name for the domestic discount curve
        (e.g. ``"InterestRate.ZAR-SWAP"``).
    domestic_interpolator : callable, optional
        Interpolator factory for the domestic discount curve.
    domestic_basis_interpolator : callable, optional
        Interpolator factory for the domestic basis curve.
    foreign_basis : str, optional
        Risk factor name for the foreign basis / forecast curve
        (e.g. ``"EUR-USD-BASIS"``).  When omitted its discount factor
        defaults to 1.
    foreign_curve : str, optional
        Risk factor name for the foreign discount curve.
    foreign_interpolator : callable, optional
        Interpolator factory for the foreign discount curve.
    foreign_basis_interpolator : callable, optional
        Interpolator factory for the foreign basis curve.
    fx_spot_name : str, optional
        Risk factor name for the FX spot rate (domestic per 1 foreign).
        Used when *domestic_fx_name* / *foreign_fx_name* are not set.
    day_count : str
        Day count convention for year fractions (default ``"ACT/365"``).
    domestic_fx_name : str, optional
        Risk factor name for the domestic-vs-USD spot rate.  When both
        *domestic_fx_name* and *foreign_fx_name* are provided the spot is
        triangulated as ``domestic_fx / foreign_fx``.
    foreign_fx_name : str, optional
        Risk factor name for the foreign-vs-USD spot rate.
    report_fx_name : str, optional
        Risk factor name for the reporting-currency FX rate.  When supplied
        the NPV is divided by this rate to convert to the reporting currency.
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        initial_spot: float,
        notional: float,
        agreed_rate: float,
        domestic_basis: str,
        domestic_curve: str,
        domestic_interpolator: Callable = None,
        domestic_basis_interpolator: Callable = None,
        foreign_basis: str| None = None,
        foreign_curve:  str| None = None,
        foreign_interpolator: Callable = None,
        foreign_basis_interpolator: Callable = None,
        fx_spot_name: str | None = None,
        day_count: str = "ACT/365",
        domestic_fx_name: str | None = None,
        foreign_fx_name: str | None = None,
        report_fx_name: str | None = None,

    ):
        super().__init__(name)
        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.initial_spot = initial_spot
        self.notional = notional
        self.agreed_rate = agreed_rate
        self.domestic_basis = domestic_basis
        self.domestic_curve = domestic_curve
        self.domestic_interpolator = domestic_interpolator
        self.domestic_basis_interpolator = domestic_basis_interpolator
        self.foreign_basis = foreign_basis
        self.foreign_curve = foreign_curve
        self.foreign_interpolator = foreign_interpolator
        self.foreign_basis_interpolator = foreign_basis_interpolator
        self.fx_spot_name = fx_spot_name
        self.domestic_fx_name = domestic_fx_name
        self.foreign_fx_name = foreign_fx_name
        self.report_fx_name = report_fx_name
        self._dc = DAY_COUNTERS[day_count]

    def _get_fx_spot(
        self, market_state: dict[str, RiskFactorSlice]
    ) -> np.ndarray:
        """Return fx_spot (domestic per foreign) from market state.

        When domestic_fx_name and foreign_fx_name are set, triangulates through
        USD: fx_spot = domestic_fx / foreign_fx (e.g. ZAR/USD ÷ EUR/USD =
        ZAR/EUR). Otherwise reads fx_spot_name directly.
        """
        if self.domestic_fx_name and self.foreign_fx_name:
            dom: ScalarSlice = market_state[self.domestic_fx_name]
            fgn: ScalarSlice = market_state[self.foreign_fx_name]
            return dom.values / fgn.values
        fx_slice: ScalarSlice = market_state[self.fx_spot_name]
        return fx_slice.values

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        fx_spot = self._get_fx_spot(market_state)  # (n_paths,)
        n_paths = fx_spot.shape[0]

        if val_date > self.maturity_date:
            return np.zeros(n_paths)

        ql_val = to_ql_date(val_date)
        t_mat = self._dc.yearFraction(
            ql_val, to_ql_date(self.maturity_date)
        )


        dom_forecast_slice: CurveSlice = market_state[self.domestic_basis]
        dom_basis = YieldCurve(
            dom_forecast_slice.tenors,
            dom_forecast_slice.values,
            self.domestic_basis_interpolator,
        )

        dom_slice: CurveSlice = market_state[self.domestic_curve]
        dom_curve = YieldCurve(
            dom_slice.tenors, dom_slice.values, self.domestic_interpolator,
        )

        for_slice: CurveSlice = market_state[self.foreign_curve]
        for_curve = YieldCurve(
            for_slice.tenors, for_slice.values, self.foreign_interpolator,
        )

        N = self.notional
        df_dom = dom_curve.discount_factor(t_mat)
        df_for = for_curve.discount_factor(t_mat)
        df_dom_forecast = dom_basis.discount_factor(t_mat)

        if self.foreign_basis is not None:
            for_forecast_slice: CurveSlice = market_state[self.foreign_basis]
            for_basis = YieldCurve(
                for_forecast_slice.tenors,
                for_forecast_slice.values,
                self.foreign_basis_interpolator,
            )
            df_for_forecast = for_basis.discount_factor(t_mat)
            forward_fx = 1 / (fx_spot * ((df_dom * df_dom_forecast) / (df_for_forecast * df_for)))
        else:
            forward_fx = 1 / (fx_spot * ((df_dom * df_dom_forecast) / df_for))

        npv = (N * self.agreed_rate - N * forward_fx) * df_dom

        if self.report_fx_name is not None:
            report_slice: ScalarSlice = market_state[self.report_fx_name]
            npv = npv / report_slice.values

        return npv
