"""Forward on the average of a commodity price.

The payoff is the average price over a set of sampling dates less an agreed price, times a
number of units. Prices that have already set are taken as known.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, cast

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.commodity_pv import commodity_average_forward_pv, fx_forward_rate
from utils.interpolation import (
    forward_price_interpolator,
    linear_interpolator,
    get_forward_price_from_slice,
    excel_serials_to_year_fracs,
)
from utils.ql_helpers import (
    DAY_COUNTERS,
    advance_business_days,
    generate_business_days,
    to_ql_date,
)


class CommodityAverageForward(Instrument):
    """Average-price commodity forward under ZAR-CSA discounting.

    The instrument averages daily commodity *forward* prices (read from a
    stochastic futures curve) over the averaging window ``[averaging_start,
    maturity_date]``, subtracts the strike, and applies the ZAR-CSA
    discounting framework.

    **Pricing lag**
    For each business day *d* in the averaging window the applicable futures
    price is looked up at the lag-adjusted date *d + pricing_lag* business
    days (using ``lag_calendar``).  This reflects the T+1 / T+2 settlement
    convention of most commodity exchanges.

    **Historical fixings**
    When ``val_date`` falls within the averaging period, past realised
    prices are supplied via the ``fixings`` argument to
    :meth:`scenario_npvs` as::

        fixings[(forward_curve_name, averaging_date)] = np.ndarray (n_paths,)

    where ``averaging_date`` is the *observation* date (not the
    lag-adjusted pricing date).  If a past fixing is absent, the current
    forward curve is used as a fallback (useful for back-testing or when
    prices are not yet published).

    **ZAR-CSA discounting**
    All payoffs, regardless of contract denomination, are discounted at
    the money-market (ZAR-SWAP) curve.

    *Standard contract* (USD underlying and USD payoff):

        PV_USD = (avg_USD - strike_USD) × notional
                 × FX_fwd(T_pay) × DF_MM(T_pay) / FX_spot

    *Composite contract* (USD underlying, ZAR payoff / ZAR strike):

        PV_ZAR = (avg_USD × FX_fwd(T_pay) - strike_ZAR) × notional
                 × DF_MM(T_pay)

    Parameters
    ----------
    name : str
        Trade identifier.
    averaging_start : date
        First date of the averaging window.
    maturity_date : date
        Last date of the averaging window (contract expiry).
    strike : float
        Strike price.  In USD for a standard contract; in ZAR for a
        composite contract.
    notional : float
        Quantity (e.g. number of barrels or metric tonnes).
    direction : int
        ``+1`` for a long position, payoff is ``(avg_price - strike)``.
        ``-1`` for a short position, payoff is ``(strike - avg_price)``.
        Default ``+1``.
    is_composite : bool
        ``True`` → payoff in ZAR (domestic), strike quoted in ZAR.
        ``False`` → payoff in USD with ZAR-CSA discounting applied.
    fx_is_inverted : bool
        ``True`` when the FX spot stored in the market state is quoted
        as foreign/domestic (e.g. USD/ZAR) rather than the expected
        domestic/foreign (ZAR/USD).  When set, ``fx_spot`` is inverted
        before entering any FX forward calculation or ZAR-CSA adjustment.
        Standard (non-composite) contracts are insensitive to this flag
        because the wrong-direction spot cancels in ``pv_zar / fx_spot``.
        Composite contracts require the correct direction.  Default
        ``False``.
    convert_then_average : bool
        Only meaningful when ``is_composite=True``.

        ``False`` (default), **average-then-convert**: the daily USD
        forward prices are averaged and the applicable per-date FX rates
        are averaged independently; the two averages are then multiplied
        to produce the theoretical ZAR value of the contract.

            avg_USD = mean(F_USD_i)
            avg_FX  = mean(FX_rate_i)
            avg_ZAR = avg_USD × avg_FX
            payoff  = (avg_ZAR − K_ZAR) × notional

        ``True``, **convert-then-average**: each daily USD price is
        individually converted to ZAR using the FX rate applicable to
        that observation date, and the resulting ZAR prices are averaged.

            avg_ZAR = mean(F_USD_i × FX_rate_i)
            payoff  = (avg_ZAR − K_ZAR) × notional

        In both cases ``FX_rate_i`` equals ``FX_fwd(T_i)`` for future
        observation dates, ``fixings[(fx_spot_name, obs_date)]`` for past
        dates when a fixing is available, or the current FX spot as a
        fallback.
    forward_curve_name : str
        Risk-factor name for the commodity forward price
        :class:`~market_data.risk_factor.CurveSlice` in the market state.
        Tenors are year fractions from val_date to each futures expiry;
        values are futures prices (USD per unit) per path.
    fx_spot_name : str
        Risk-factor name for the FX spot
        :class:`~market_data.risk_factor.ScalarSlice`.
        Expected as domestic/foreign (ZAR/USD) unless ``fx_is_inverted``
        is ``True``.
    domestic_curve_name : str
        Risk-factor name for the ZAR-USD-BASIS
        :class:`~market_data.risk_factor.CurveSlice` used in the FX
        forward calculation.
    foreign_curve_name : str
        Risk-factor name for the USD-SOFR
        :class:`~market_data.risk_factor.CurveSlice` used in the FX
        forward calculation.
    money_market_curve_name : str
        Risk-factor name for the ZAR-SWAP
        :class:`~market_data.risk_factor.CurveSlice` used to discount
        all payoffs.
    averaging_calendar : str
        Calendar name (key in :data:`~utils.ql_helpers.CALENDARS`) used
        to enumerate the daily averaging dates.
    payment_calendar : str
        Calendar name used to compute the payment date (maturity +
        ``payment_lag`` business days) and, optionally, the FX
        settlement date.
    lag_calendar : str
        Calendar name used to advance each averaging date by
        ``pricing_lag`` business days to obtain the effective pricing
        date on the forward curve.
    forward_interpolator : callable
        Factory ``(tenors, prices) -> callable`` for interpolating the
        commodity forward price curve.  Defaults to
        :func:`~utils.interpolation.linear_interpolator`.
    domestic_interpolator : callable
        Interpolator factory for the domestic (ZAR-USD-BASIS) curve.
    foreign_interpolator : callable
        Interpolator factory for the foreign (USD-SOFR) curve.
    money_market_interpolator : callable
        Interpolator factory for the money-market (ZAR-SWAP) curve.
    pricing_lag : int
        Number of business days (in ``lag_calendar``) to advance each
        averaging date when looking up the forward price.  Typically 1
        (ICE Brent) or 2 (NYMEX WTI).
    payment_lag : int
        Number of business days (in ``payment_calendar``) after
        ``maturity_date`` at which the contract settles / pays.
        Default 2 (typical FX/commodity settlement).
    fx_settlement_lag : int
        Number of business days (in ``payment_calendar``) after
        ``val_date`` at which the observed FX spot settles.  Set to 0
        when the scenario FX spot is already a T+0 rate; use 2 for
        standard ZAR/USD T+2 spot conventions.  Default 2.
    day_count : str
        Day-count convention key in
        :data:`~utils.ql_helpers.DAY_COUNTERS` (default ``"ACT/365"``).
    """

    def __init__(
        self,
        name: str,
        averaging_start: date,
        maturity_date: date,
        strike: float,
        notional: float,
        is_composite: bool,
        forward_curve_name: str,
        fx_spot_name: str,
        domestic_curve_name: str,
        foreign_curve_name: str,
        money_market_curve_name: str,
        averaging_calendar: str,
        payment_calendar: str,
        lag_calendar: str,
        direction: int = 1,
        forward_interpolator: Callable = forward_price_interpolator,
        domestic_interpolator: Callable = linear_interpolator,
        foreign_interpolator: Callable = linear_interpolator,
        money_market_interpolator: Callable = linear_interpolator,
        pricing_lag: int = 1,
        payment_lag: int = 2,
        fx_settlement_lag: int = 2,
        day_count: str = "ACT/365",
        convert_then_average: bool = False,
        fx_is_inverted: bool = False,
    ) -> None:
        super().__init__(name)
        self.averaging_start = averaging_start
        self.maturity_date = maturity_date
        self.strike = strike
        self.notional = notional
        self.is_composite = is_composite
        self.direction = direction
        self.convert_then_average = convert_then_average
        self.fx_is_inverted = fx_is_inverted
        self.forward_curve_name = forward_curve_name
        self.fx_spot_name = fx_spot_name
        self.domestic_curve_name = domestic_curve_name
        self.foreign_curve_name = foreign_curve_name
        self.money_market_curve_name = money_market_curve_name
        self.forward_interpolator = forward_interpolator
        self.domestic_interpolator = domestic_interpolator
        self.foreign_interpolator = foreign_interpolator
        self.money_market_interpolator = money_market_interpolator
        self.pricing_lag = pricing_lag
        self.fx_settlement_lag = fx_settlement_lag
        self._dc = DAY_COUNTERS[day_count]

        # Pre-compute static date lists once at construction time.
        # Year fractions cannot be pre-computed because they depend on
        # val_date, which changes across simulation time steps.
        self._averaging_dates: list[date] = generate_business_days(
            averaging_start, maturity_date, averaging_calendar,
        )
        # Lag-adjusted pricing dates (the tenors used on the forward curve).
        self._pricing_dates: list[date] = [
            advance_business_days(d, pricing_lag, lag_calendar)
            for d in self._averaging_dates
        ]
        # FX settlement dates: each averaging date advanced by
        # fx_settlement_lag business days.  The FX forward for date d settles
        # at d + fx_settlement_lag, mirroring the spot's settlement at
        # val_date + fx_settlement_lag.  When fx_settlement_lag == 0 these
        # equal the averaging dates themselves.
        self._fx_settlement_dates: list[date] = [
            advance_business_days(d, fx_settlement_lag, payment_calendar)
            if fx_settlement_lag > 0 else d
            for d in self._averaging_dates
        ]
        # Payment date: maturity + payment_lag business days.
        self._payment_date: date = advance_business_days(
            maturity_date, payment_lag, payment_calendar,
        )
        self._payment_calendar = payment_calendar

    # ------------------------------------------------------------------
    # Instrument interface
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Compute per-path NPV of the average commodity forward.

        Parameters
        ----------
        val_date : date
            Current valuation date.
        market_state : dict
            Mapping from risk-factor name to
            :class:`~market_data.risk_factor.RiskFactorSlice`.
        fixings : dict or None
            Historical fixings.  Two conventions are supported:

            **Per-date fixings** (standard):
                ``(forward_curve_name, averaging_date)`` →
                ``np.ndarray (n_paths,)``, realised USD futures price on
                that observation date.  For composite contracts,
                ``(fx_spot_name, averaging_date)`` may also be provided.

            **Accumulated realised-sum** (a shortcut for a caller that
            keeps one running total per path):
                Instead of one entry per past observation date, supply the
                running total of all settled prices directly:

                * ``(forward_curve_name, "realized_sum")``, sum of
                  realised USD forward prices for all
                  ``avg_date <= val_date``.  Used by standard and
                  composite ATC contracts.
                * ``(fx_spot_name, "realized_sum")``, sum of realised FX
                  rates for all ``avg_date <= val_date``.  Required
                  together with the forward realised sum for composite ATC.
                * For composite CTA, ``(forward_curve_name,
                  "realized_sum")`` stores the sum of
                  ``F_USD_i × FX_rate_i`` for each past observation.

                Each value is ``np.ndarray (n_paths,)`` or a scalar.
                When present the per-date historical loop is bypassed,
                eliminating the flat-left-extrapolation fallback and
                correctly capturing path-specific realised prices.

        rng : ignored
            Included for interface compatibility.

        Returns
        -------
        np.ndarray, shape (n_paths,)
            NPV per path.  Units: USD for a standard contract, ZAR for
            a composite contract.
        """
        # Retrieve n_paths from FX spot (always present)
        fx_slice = cast(ScalarSlice, market_state[self.fx_spot_name])
        n_paths = fx_slice.values.shape[0]

        # Past payment date: instrument has settled
        if val_date > self._payment_date:
            return np.zeros(n_paths)

        # Year fraction to payment date
        T_pay = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self._payment_date),
        ))

        # Build all curves before the loop (needed for convert_then_average)
        fwd_slice = cast(CurveSlice, market_state[self.forward_curve_name])
        fwd_tenors_yf = excel_serials_to_year_fracs(
            fwd_slice.tenors, val_date, self._dc,
        )
        # "flat": linear_interpolator, "linear": forward_price_interpolator.
        right_extrap = (
            "flat"
            if self.forward_interpolator is linear_interpolator
            else "linear"
        )

        for_slice = cast(CurveSlice, market_state[self.foreign_curve_name])
        for_curve = YieldCurve(
            for_slice.tenors, for_slice.values, self.foreign_interpolator,
        )
        mm_slice = cast(
            CurveSlice, market_state[self.money_market_curve_name],
        )
        mm_curve = YieldCurve(
            mm_slice.tenors, mm_slice.values, self.money_market_interpolator,
        )

        # The domestic (ZAR-USD-BASIS) curve contains only the cross-currency
        # basis spreads.  These are additive
        # zero-rate spreads layered on top of the ZAR-SWAP (money-market) base
        # curve to form the full domestic curve used in the FX forward formula:
        #   r_dom(T) = r_ZAR_SWAP(T) + basis_spread(T)
        basis_slice = cast(
            CurveSlice, market_state[self.domestic_curve_name],
        )
        swap_rates_at_basis = mm_curve.get_rate(basis_slice.tenors)
        combined_dom_rates = (
            swap_rates_at_basis
            + np.asarray(basis_slice.values, dtype=np.float64)
        )
        dom_curve = YieldCurve(
            basis_slice.tenors, combined_dom_rates,
            self.domestic_interpolator,
        )

        fx_spot = fx_slice.values  # (n_paths,)
        if self.fx_is_inverted:
            fx_spot = 1.0 / fx_spot  # foreign/domestic → domestic/foreign

        fx_settlement_T = 0.0
        if self.fx_settlement_lag > 0:
            settle_date = advance_business_days(
                val_date, self.fx_settlement_lag, self._payment_calendar,
            )
            fx_settlement_T = float(self._dc.yearFraction(
                to_ql_date(val_date), to_ql_date(settle_date),
            ))

        n_total = len(self._averaging_dates)
        # Plain untyped dict alias so "realized_sum" string keys are
        # accepted alongside the standard tuple[str, date] keys.
        _fix: dict = fixings if fixings is not None else {}

        if self.is_composite and self.convert_then_average:
            # -----------------------------------------------------------
            # Convert-then-average: convert each daily USD price to ZAR
            # using the FX rate applicable to that observation date, then
            # average the resulting ZAR prices.
            #
            #   avg_ZAR = mean( F_USD_i × FX_rate_i )
            #   payoff  = (avg_ZAR − K_ZAR) × notional
            #   PV_ZAR  = payoff × DF_MM(T_pay)
            #
            # For future dates  : FX_rate_i = FX_fwd(T_i)
            # For past dates    : FX_rate_i = fixings[(fx_spot_name, date)]
            #                     or current FX spot as fallback.
            # -----------------------------------------------------------
            price_zar_sum = np.zeros(n_paths)

            # Load pre-accumulated realised sum when the simulation runner
            # provides it (avoids flat-left fallback for settled dates).
            # Key stores sum(F_USD_i * FX_rate_i) for avg_date <= val_date.
            rsum_raw = _fix.get((self.forward_curve_name, "realized_sum"))
            if rsum_raw is not None:
                price_zar_sum = (
                    np.full(n_paths, float(rsum_raw), dtype=np.float64)
                    if np.ndim(rsum_raw) == 0
                    else np.asarray(rsum_raw, dtype=np.float64).copy()
                )

            for avg_date, pricing_date, fx_settle_date in zip(
                self._averaging_dates, self._pricing_dates,
                self._fx_settlement_dates,
            ):
                if pricing_date <= val_date:  # settled: exchange has fixed the price
                    if rsum_raw is not None:
                        continue  # already accumulated in price_zar_sum
                    # USD forward price for this settled date
                    key_fwd = (self.forward_curve_name, avg_date)
                    if fixings is not None and key_fwd in fixings:
                        f_usd = fixings[key_fwd]
                    else:
                        f_usd = get_forward_price_from_slice(
                                    curve_serial_tenors=fwd_slice.tenors,
                                    curve_values=fwd_slice.values,
                                    value_date=val_date,
                                    target_date=pricing_date,
                                    day_counter=self._dc,
                                    right_extrapolation=right_extrap,
                                    left_extrapolation="flat",
                                    _precomputed_tenors_yf=fwd_tenors_yf,
                                )
                    # FX rate for this settled date
                    key_fx = (self.fx_spot_name, avg_date)
                    if fixings is not None and key_fx in fixings:
                        fx_rate_i = fixings[key_fx]
                    else:
                        fx_rate_i = fx_spot
                else:
                    # Future date: USD forward price from the forward curve
                    f_usd = get_forward_price_from_slice(
                                curve_serial_tenors=fwd_slice.tenors,
                                curve_values=fwd_slice.values,
                                value_date=val_date,
                                target_date=pricing_date,
                                day_counter=self._dc,
                                right_extrapolation=right_extrap,
                                left_extrapolation="flat",
                                _precomputed_tenors_yf=fwd_tenors_yf,
                            )
                    # FX rate: forward from [val+lag, avg+lag]
                    T_i = float(self._dc.yearFraction(
                        to_ql_date(val_date), to_ql_date(fx_settle_date),
                    ))
                    fx_rate_i = fx_forward_rate(
                        fx_spot, dom_curve, for_curve, T_i, fx_settlement_T,
                    )

                price_zar_sum += f_usd * fx_rate_i

            avg_price_zar = price_zar_sum / n_total
            df_mm = mm_curve.discount_factor(T_pay)
            payoff = (avg_price_zar - self.strike) * self.notional
            return self.direction * payoff * df_mm

        elif self.is_composite:
            # -----------------------------------------------------------
            # Average-then-convert (composite, default): average the
            # daily USD forward prices and the applicable per-date FX
            # rates independently, then multiply the two averages.
            #
            #   avg_USD = mean( F_USD_i )
            #   avg_FX  = mean( FX_rate_i )
            #   avg_ZAR = avg_USD × avg_FX
            #   payoff  = (avg_ZAR − K_ZAR) × notional
            #   PV_ZAR  = payoff × DF_MM(T_pay)
            # -----------------------------------------------------------
            price_usd_sum = np.zeros(n_paths)
            fx_rate_sum = np.zeros(n_paths)

            # Load pre-accumulated realised sums when the simulation runner
            # provides them (avoids flat-left fallback for settled dates).
            # Both keys must be present to use the shortcut.
            rsum_fwd_raw = _fix.get(
                (self.forward_curve_name, "realized_sum")
            )
            rsum_fx_raw = _fix.get(
                (self.fx_spot_name, "realized_sum")
            )
            if rsum_fwd_raw is not None and rsum_fx_raw is not None:
                price_usd_sum = (
                    np.full(n_paths, float(rsum_fwd_raw), dtype=np.float64)
                    if np.ndim(rsum_fwd_raw) == 0
                    else np.asarray(rsum_fwd_raw, dtype=np.float64).copy()
                )
                fx_rate_sum = (
                    np.full(n_paths, float(rsum_fx_raw), dtype=np.float64)
                    if np.ndim(rsum_fx_raw) == 0
                    else np.asarray(rsum_fx_raw, dtype=np.float64).copy()
                )
                has_atc_rsums = True
            else:
                has_atc_rsums = False

            for avg_date, pricing_date, fx_settle_date in zip(
                self._averaging_dates, self._pricing_dates,
                self._fx_settlement_dates,
            ):
                if pricing_date <= val_date:  # settled: exchange has fixed the price
                    if has_atc_rsums:
                        continue  # already accumulated in both sums
                    # USD forward price for this settled date
                    key_fwd = (self.forward_curve_name, avg_date)
                    if fixings is not None and key_fwd in fixings:
                        f_usd = fixings[key_fwd]
                    else:
                        f_usd = get_forward_price_from_slice(
                                    curve_serial_tenors=fwd_slice.tenors,
                                    curve_values=fwd_slice.values,
                                    value_date=val_date,
                                    target_date=pricing_date,
                                    day_counter=self._dc,
                                    right_extrapolation=right_extrap,
                                    left_extrapolation="flat",
                                    _precomputed_tenors_yf=fwd_tenors_yf,
                                )
                    # FX rate for this settled date
                    key_fx = (self.fx_spot_name, avg_date)
                    if fixings is not None and key_fx in fixings:
                        fx_rate_i = fixings[key_fx]
                    else:
                        fx_rate_i = fx_spot
                else:
                    # Future date: USD forward price from the forward curve
                    f_usd = get_forward_price_from_slice(
                                curve_serial_tenors=fwd_slice.tenors,
                                curve_values=fwd_slice.values,
                                value_date=val_date,
                                target_date=pricing_date,
                                day_counter=self._dc,
                                right_extrapolation=right_extrap,
                                left_extrapolation="flat",
                                _precomputed_tenors_yf=fwd_tenors_yf,
                            )
                    # FX rate: forward from [val+lag, avg+lag]
                    T_i = float(self._dc.yearFraction(
                        to_ql_date(val_date), to_ql_date(fx_settle_date),
                    ))
                    fx_rate_i = fx_forward_rate(
                        fx_spot, dom_curve, for_curve, T_i, fx_settlement_T,
                    )

                price_usd_sum += f_usd
                fx_rate_sum += fx_rate_i

            avg_usd = price_usd_sum / n_total
            avg_fx = fx_rate_sum / n_total
            df_mm = mm_curve.discount_factor(T_pay)
            payoff = (avg_usd * avg_fx - self.strike) * self.notional
            return self.direction * payoff * df_mm

        else:
            # -----------------------------------------------------------
            # Standard non-composite contract: average USD prices, then
            # apply ZAR-CSA discounting.
            #
            #   avg_USD = mean( F_USD_i )
            #   payoff  = (avg_USD − K_USD) × notional
            #   PV_USD  = payoff × FX_fwd(T_pay) × DF_MM(T_pay) / FX_spot
            # -----------------------------------------------------------
            price_sum = np.zeros(n_paths)

            # Load pre-accumulated realised sum when the simulation runner
            # provides it (avoids flat-left fallback for settled dates).
            # Key stores sum(F_USD_i) for avg_date <= val_date.
            rsum_raw = _fix.get(  # type: ignore[arg-type]
                (self.forward_curve_name, "realized_sum"),
            )
            if rsum_raw is not None:
                price_sum = (
                    np.full(n_paths, float(rsum_raw), dtype=np.float64)
                    if np.ndim(rsum_raw) == 0
                    else np.asarray(rsum_raw, dtype=np.float64).copy()
                )

            for avg_date, pricing_date in zip(
                self._averaging_dates, self._pricing_dates,
            ):
                if pricing_date <= val_date:  # settled: exchange has fixed the price
                    if rsum_raw is not None:
                        continue  # already accumulated in price_sum
                    key = (self.forward_curve_name, avg_date)
                    if fixings is not None and key in fixings:
                        price_sum += fixings[key]
                    else:
                        price_sum += get_forward_price_from_slice(
                                        curve_serial_tenors=fwd_slice.tenors,
                                        curve_values=fwd_slice.values,
                                        value_date=val_date,
                                        target_date=pricing_date,
                                        day_counter=self._dc,
                                        right_extrapolation=right_extrap,
                                        left_extrapolation="flat",
                                        _precomputed_tenors_yf=fwd_tenors_yf,
                                    )
                else:
                    price_sum += get_forward_price_from_slice(
                                    curve_serial_tenors=fwd_slice.tenors,
                                    curve_values=fwd_slice.values,
                                    value_date=val_date,
                                    target_date=pricing_date,
                                    day_counter=self._dc,
                                    right_extrapolation=right_extrap,
                                    left_extrapolation="flat",
                                    _precomputed_tenors_yf=fwd_tenors_yf,
                                )

            avg_price = price_sum / n_total

            return commodity_average_forward_pv(
                avg_price=avg_price,
                strike=self.strike,
                notional=self.notional,
                is_composite=False,
                fx_spot=fx_spot,
                dom_curve=dom_curve,
                for_curve=for_curve,
                mm_curve=mm_curve,
                T_pay=T_pay,
                fx_settlement_T=fx_settlement_T,
                direction=self.direction,
            )

    # ------------------------------------------------------------------
    # Commodity fixing interface (called by the code that runs the valuation)
    # ------------------------------------------------------------------

    def get_commodity_fixing_schedule(self) -> list[tuple[date, date, date]]:
        """Return (avg_date, pricing_date, fx_settle_date) for each averaging observation."""
        return list(zip(
            self._averaging_dates, self._pricing_dates, self._fx_settlement_dates,
        ))

    def _compute_fixing_for_date(
        self,
        avg_date: date,
        pricing_date: date,
        fx_settle_date: date,
        market_state: dict[str, RiskFactorSlice],
        scenario_date: date,
    ) -> dict:
        """Compute realised fixings for a single averaging date.

        Uses ``market_state`` as observed at ``scenario_date``.  All year
        fractions are measured from ``scenario_date`` so the forward curve
        is read consistently with the simulation step that produced it.

        For composite instruments the FX rate is the forward from
        ``scenario_date``'s spot-settlement to ``fx_settle_date``
        (avg_date + settlement lag).  When ``scenario_date == avg_date``
        the forward collapses to the current spot.
        """
        fwd_slice = cast(CurveSlice, market_state[self.forward_curve_name])
        fwd_tenors_yf = excel_serials_to_year_fracs(
            fwd_slice.tenors, scenario_date, self._dc,
        )
        right_extrap = (
            "flat" if self.forward_interpolator is linear_interpolator else "linear"
        )
        f_usd = get_forward_price_from_slice(
            curve_serial_tenors=fwd_slice.tenors,
            curve_values=fwd_slice.values,
            value_date=scenario_date,
            target_date=pricing_date,
            day_counter=self._dc,
            right_extrapolation=right_extrap,
            left_extrapolation="flat",
            _precomputed_tenors_yf=fwd_tenors_yf,
        )
        result: dict = {(self.forward_curve_name, avg_date): f_usd}

        if self.is_composite:
            fx_slice = cast(ScalarSlice, market_state[self.fx_spot_name])
            fx_spot = fx_slice.values
            if self.fx_is_inverted:
                fx_spot = 1.0 / fx_spot
            T_fix = float(self._dc.yearFraction(
                to_ql_date(scenario_date), to_ql_date(fx_settle_date),
            ))
            if T_fix > 1e-8:
                for_slice = cast(CurveSlice, market_state[self.foreign_curve_name])
                for_curve = YieldCurve(
                    for_slice.tenors, for_slice.values, self.foreign_interpolator,
                )
                mm_slice = cast(CurveSlice, market_state[self.money_market_curve_name])
                mm_curve_tmp = YieldCurve(
                    mm_slice.tenors, mm_slice.values, self.money_market_interpolator,
                )
                basis_slice = cast(CurveSlice, market_state[self.domestic_curve_name])
                swap_at_basis = mm_curve_tmp.get_rate(basis_slice.tenors)
                combined_dom = (
                    swap_at_basis + np.asarray(basis_slice.values, dtype=np.float64)
                )
                dom_curve = YieldCurve(
                    basis_slice.tenors, combined_dom, self.domestic_interpolator,
                )
                fx_settlement_T = 0.0
                if self.fx_settlement_lag > 0:
                    val_settle = advance_business_days(
                        scenario_date, self.fx_settlement_lag, self._payment_calendar,
                    )
                    fx_settlement_T = float(self._dc.yearFraction(
                        to_ql_date(scenario_date), to_ql_date(val_settle),
                    ))
                fx_rate_i = fx_forward_rate(
                    fx_spot, dom_curve, for_curve, T_fix, fx_settlement_T,
                )
            else:
                fx_rate_i = fx_spot.copy()
            result[(self.fx_spot_name, avg_date)] = fx_rate_i

        return result

    def compute_commodity_fixings(
        self,
        market_state: dict[str, RiskFactorSlice],
        sim_date: date,
        existing_fixings: dict | None = None,
    ) -> dict:
        """Stamp realised prices for newly past averaging dates.

        Standalone convenience method: uses ``sim_date``'s ``market_state``
        as the approximation for all newly crossed averaging dates.

        A caller gets better
        accuracy by calling ``_compute_fixing_for_date`` directly with the
        market state at the nearest scenario date ≤ each avg_date (bisect
        lookup), rather than the single crossing-step state used here.

        Each averaging date is stamped exactly once, ``existing_fixings``
        de-duplication prevents re-evaluation at later steps.
        """
        if not self._pricing_dates or self._pricing_dates[0] > sim_date:
            return {}

        _existing = existing_fixings or {}
        new_fixings: dict = {}
        for avg_date, pricing_date, fx_settle_date in self.get_commodity_fixing_schedule():
            if pricing_date > sim_date:
                break
            if (self.forward_curve_name, avg_date) in _existing:
                continue
            new_fixings.update(
                self._compute_fixing_for_date(
                    avg_date, pricing_date, fx_settle_date, market_state, sim_date,
                )
            )
        return new_fixings
