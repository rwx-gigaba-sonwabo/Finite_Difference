"""European digital option on a commodity reference price.

What the trade is
-----------------
On the expiry date the option looks at one commodity reference price, the fixing.
A call is in the money when the fixing is above the strike. A put is in the money when
the fixing is below the strike. When in the money the option pays on the settlement date:

``cash`` payout style
    a fixed amount of currency, ``payoff_amount``.
``asset`` payout style
    ``payoff_amount`` units of the commodity, worth ``payoff_amount * fixing``.

Out of the money it pays nothing.

How it is valued
----------------
1. **Forward price.** The fixing on the expiry date is the price of one delivery date.
   The forward price ``F`` for that delivery date is read off the commodity forward
   price curve. No drift is assumed beyond what the curve already holds.
2. **Volatility.** The volatility ``sigma`` is read off the commodity volatility surface
   at the option's moneyness and time to expiry ``T``.
3. **Digital value before discounting**, per unit of payout, with ``w = +1`` for a call
   and ``-1`` for a put:

   * closed form, used when ``relative_digital_spread`` is zero:
     cash ``N(w * d2)`` and asset ``F * N(w * d1)``;
   * strike spread, used when ``relative_digital_spread`` is ``eps > 0``:
     cash ``w * (V(K * (1 - eps)) - V(K * (1 + eps))) / (2 * eps * K)`` where ``V`` is the
     Black value of a vanilla option and each strike uses its own volatility,
     and asset ``w * V(K) + K * cash``.

4. **Present value.** ``sign * payoff_amount * digital * DF(settlement) * FX`` where
   ``sign`` is +1 for a bought option and -1 for a sold option, ``DF`` is the discount
   factor to the settlement date, and ``FX`` converts the payout currency into the
   reporting currency at today's spot rate.

Payout in another currency
--------------------------
When the payout currency differs from the currency the commodity is quoted in, the
``payoff_type`` says how the two are linked. ``X`` is the FX rate in payout currency per
unit of commodity currency.

``standard``
    No adjustment. The digital is valued in the commodity currency and the result is
    simply read as an amount of payout currency.
``quanto``
    The strike is a level in commodity currency. The payout is converted at a fixed rate
    of one. The forward price is multiplied by ``exp(-rho * sigma_S * sigma_X * T)`` where
    ``sigma_S`` and ``sigma_X`` are the at the money volatilities of the commodity and of
    ``X`` and ``rho`` is their correlation. The volatility is not changed.
``composite``
    The option is written on the commodity price converted into payout currency,
    ``S * X``. The strike is a level in payout currency. The forward price becomes
    ``F * X_forward(T)``. The volatility becomes
    ``sqrt(sigma_S**2 + 2 * rho * sigma_S * sigma_X + sigma_X**2)``, where ``sigma_S`` is read
    off the commodity surface at the strike converted back to commodity currency,
    ``K / X_forward(T)``.

After expiry
------------
Between expiry and settlement the fixing is known. Pass it as ``expiry_fixing``. The value
is then the known payout, discounted to the settlement date. After settlement it is zero.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, Sequence

import numpy as np

from instruments.components.commodity_option_market import (
    PAYOFF_TYPES,
    CrossCurrencyPayoff,
    at_the_money_moneyness,
    forward_price_for_delivery,
    scalar_value,
    summed_zero_rate,
)
from instruments.instrument import Instrument
from market_data.risk_factor import RiskFactorSlice
from models.digital_option_pv import (
    asset_digital_by_strike_spread_undiscounted,
    black_asset_digital_undiscounted,
    black_cash_digital_undiscounted,
    cash_digital_by_strike_spread_undiscounted,
    composite_volatility,
    strike_spread_strikes,
)

PAYOFF_STYLES = ("cash", "asset")


class CommodityDigitalOption(Instrument):
    """European cash or asset digital option on a commodity reference price.

    Parameters
    ----------
    name : str
        Trade identifier, used in reports.
    expiry_date : date
        Date the reference price is observed and the option is decided.
    strike : float
        Strike price. In commodity currency, except for a composite payout where it is in
        payout currency.
    payoff_amount : float
        Cash amount paid (``cash`` style) or number of commodity units paid (``asset``
        style) when the option expires in the money. Must not be zero.
    is_call : bool
        ``True`` pays when the fixing is above the strike. ``False`` pays when below.
    forward_curve_name : str
        Key of the commodity forward price curve in ``market_state``. Its tenors are Excel
        serial dates of the delivery dates.
    delivery_serial : float
        Excel serial of the delivery date the expiry fixing reads on the forward curve.
    discount_curve_names : str or sequence of str
        Key of the discount curve in ``market_state``. Give several names to add spread
        curves on top of the first.
    vol_surface : object
        Commodity volatility surface with ``moneyness_of(underlying, strike)`` and
        ``get_vol(moneyness, expiry)``.
    is_buy : bool
        ``True`` when the option was bought, ``False`` when it was sold.
    payoff_style : {"cash", "asset"}
        What is paid when in the money.
    settlement_date : date, optional
        Date the payout is paid. The expiry date when not given.
    relative_digital_spread : float
        Half width of the replicating strike spread, as a fraction of the strike. Zero
        selects the closed form.
    payoff_type : {"standard", "quanto", "composite"}
        How a payout in another currency is treated. See the module notes.
    cross_currency : CrossCurrencyPayoff, optional
        FX inputs. Needed for ``quanto`` and ``composite``.
    payoff_fx_name, report_fx_name : str, optional
        Keys of the FX spot factors of the payout currency and the reporting currency in
        ``market_state``. Leave both ``None`` to report in the payout currency.
    curve_interpolators : dict, optional
        ``{curve name: interpolator factory}`` for the rate curves. Linear when not given.
    forward_extrapolation : {"flat", "linear"}
        Treatment of delivery dates outside the forward curve's pillars.
    days_in_year : float
        Divisor that turns calendar days into years for time to expiry and discounting.
    expiry_fixing : float, optional
        The observed fixing, for a valuation date after the expiry date.
    """

    def __init__(
        self,
        name: str,
        expiry_date: date,
        strike: float,
        payoff_amount: float,
        is_call: bool,
        forward_curve_name: str,
        delivery_serial: float,
        discount_curve_names: str | Sequence[str],
        vol_surface,
        is_buy: bool = True,
        payoff_style: str = "cash",
        settlement_date: date | None = None,
        relative_digital_spread: float = 0.0,
        payoff_type: str = "standard",
        cross_currency: CrossCurrencyPayoff | None = None,
        payoff_fx_name: str | None = None,
        report_fx_name: str | None = None,
        curve_interpolators: dict[str, Callable] | None = None,
        forward_extrapolation: str = "flat",
        days_in_year: float = 365.0,
        expiry_fixing: float | None = None,
    ) -> None:
        super().__init__(name)
        if payoff_style not in PAYOFF_STYLES:
            raise ValueError(f"payoff_style must be one of {PAYOFF_STYLES}, got {payoff_style!r}")
        if payoff_type not in PAYOFF_TYPES:
            raise ValueError(f"payoff_type must be one of {PAYOFF_TYPES}, got {payoff_type!r}")
        if payoff_type != "standard" and cross_currency is None:
            raise ValueError(f"payoff_type {payoff_type!r} needs the cross_currency inputs")
        if payoff_amount == 0.0:
            raise ValueError("payoff_amount must not be zero")
        if strike <= 0.0:
            raise ValueError("strike must be positive")
        if relative_digital_spread < 0.0 or relative_digital_spread >= 1.0:
            raise ValueError("relative_digital_spread must be at least 0 and below 1")

        self.expiry_date = expiry_date
        self.settlement_date = settlement_date or expiry_date
        if self.settlement_date < expiry_date:
            raise ValueError("settlement_date cannot be before expiry_date")
        self.strike = float(strike)
        self.payoff_amount = float(payoff_amount)
        self.is_call = bool(is_call)
        self.is_buy = bool(is_buy)
        self.payoff_style = payoff_style
        self.forward_curve_name = forward_curve_name
        self.delivery_serial = float(delivery_serial)
        self.discount_curve_names = (
            (discount_curve_names,) if isinstance(discount_curve_names, str)
            else tuple(discount_curve_names))
        self.vol_surface = vol_surface
        self.relative_digital_spread = float(relative_digital_spread)
        self.payoff_type = payoff_type
        self.cross_currency = cross_currency
        self.payoff_fx_name = payoff_fx_name
        self.report_fx_name = report_fx_name
        self.curve_interpolators = dict(curve_interpolators or {})
        self.forward_extrapolation = forward_extrapolation
        self.days_in_year = float(days_in_year)
        self.expiry_fixing = expiry_fixing

    # ------------------------------------------------------------- valuation
    def valuation_details(
        self, val_date: date, market_state: dict[str, RiskFactorSlice],
    ) -> dict[str, np.ndarray | float | str]:
        """Value the option and return every intermediate number.

        Each array has one entry per market scenario in ``market_state``. The entry
        ``"present_value"`` is what :meth:`scenario_npvs` returns. The other entries let a
        reviewer follow the calculation step by step.
        """
        expiry = (self.expiry_date - val_date).days / self.days_in_year
        settlement = (self.settlement_date - val_date).days / self.days_in_year
        sign = 1.0 if self.is_buy else -1.0
        report_fx = np.asarray(scalar_value(market_state, self.payoff_fx_name), dtype=float) / np.asarray(
            scalar_value(market_state, self.report_fx_name), dtype=float)

        forward_local = forward_price_for_delivery(
            market_state[self.forward_curve_name], self.delivery_serial, self.forward_extrapolation)
        details: dict[str, np.ndarray | float | str] = {
            "time_to_expiry": expiry, "time_to_settlement": settlement,
            "forward_price_curve_read": forward_local, "fx_to_reporting_currency": report_fx,
        }

        if settlement < 0.0:
            details.update(method="settled", present_value=0.0 * forward_local)
            return details

        if expiry < 0.0:
            # Decided but not yet paid. The payout is known from the observed fixing.
            if self.expiry_fixing is None:
                raise ValueError(
                    f"{self.name}: the valuation date is after the expiry date "
                    f"{self.expiry_date}. Give the observed fixing as expiry_fixing.")
            if self.payoff_type == "composite":
                raise NotImplementedError(
                    f"{self.name}: a composite payout that has expired needs the fixing of "
                    f"the commodity price in payout currency, which is not supported.")
            forward = np.full_like(forward_local, float(self.expiry_fixing))
            volatility = np.zeros_like(forward)
            expiry_used = 0.0
        else:
            forward, volatility = forward_local, None
            expiry_used = expiry

        strike = self.strike
        fx_forward = 1.0
        fx_vol = None
        rho = None
        if self.payoff_type != "standard" and expiry_used > 0.0:
            cross = self.cross_currency
            fx_vol = cross.fx_at_the_money_vol(expiry_used)
            rho = cross.correlation
            details.update(fx_volatility=fx_vol, correlation=rho)
        if self.payoff_type == "composite" and expiry_used > 0.0:
            fx_forward = self.cross_currency.fx_forward(
                market_state, self.curve_interpolators, expiry_used)
            details["fx_forward"] = fx_forward

        # Strike on the scale of the commodity surface. A composite strike is in payout
        # currency, so it is converted back at the FX forward.
        local_strike = strike / fx_forward

        def surface_vol(strike_level):
            moneyness = self.vol_surface.moneyness_of(forward_local, strike_level)
            return np.asarray(self.vol_surface.get_vol(moneyness, expiry_used), dtype=float)

        def payout_vol(local_vol):
            if self.payoff_type == "composite":
                return composite_volatility(local_vol, fx_vol, rho)
            return local_vol

        if volatility is None:
            volatility = payout_vol(surface_vol(local_strike)) if expiry_used > 0.0 else np.zeros_like(forward)

        if expiry_used > 0.0 and self.payoff_type == "quanto":
            atm_vol = float(self.vol_surface.get_vol(
                at_the_money_moneyness(self.vol_surface), expiry_used))
            quanto_drift = -rho * atm_vol * fx_vol
            forward = forward_local * np.exp(quanto_drift * expiry_used)
            details.update(commodity_at_the_money_volatility=atm_vol, quanto_drift=quanto_drift)
        elif expiry_used > 0.0 and self.payoff_type == "composite":
            forward = forward_local * fx_forward

        eps = self.relative_digital_spread
        if eps > 0.0 and expiry_used > 0.0:
            strike_low, strike_high = strike_spread_strikes(strike, eps)
            vol_low = payout_vol(surface_vol(strike_low / fx_forward))
            vol_high = payout_vol(surface_vol(strike_high / fx_forward))
            if self.payoff_style == "cash":
                digital = cash_digital_by_strike_spread_undiscounted(
                    forward, strike, vol_low, vol_high, expiry_used, self.is_call, eps)
            else:
                digital = asset_digital_by_strike_spread_undiscounted(
                    forward, strike, volatility, vol_low, vol_high, expiry_used, self.is_call, eps)
            details.update(method="strike spread", lower_strike=strike_low, upper_strike=strike_high,
                           lower_strike_volatility=vol_low, upper_strike_volatility=vol_high)
        else:
            pricer = (black_cash_digital_undiscounted if self.payoff_style == "cash"
                      else black_asset_digital_undiscounted)
            digital = pricer(forward, strike, volatility, expiry_used, self.is_call)
            details["method"] = "closed form" if expiry_used > 0.0 else "payoff at expiry"

        zero_rate = (summed_zero_rate(market_state, self.discount_curve_names,
                                      self.curve_interpolators, settlement)
                     if settlement > 0.0 else np.zeros_like(forward))
        discount_factor = np.exp(-zero_rate * settlement)
        present_value = sign * self.payoff_amount * digital * discount_factor * report_fx

        details.update(
            forward_price=forward, strike=strike, volatility=volatility,
            undiscounted_digital_per_unit=digital, discount_zero_rate=zero_rate,
            discount_factor=discount_factor, present_value=present_value)
        return details

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Present value in the reporting currency, one entry per market scenario."""
        value = self.valuation_details(val_date, market_state)["present_value"]
        return np.atleast_1d(np.asarray(value, dtype=float))
