"""Strip of expected dividend payments on a share.

The value is the sum of the dividend cashflows that fall before an end date, discounted.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from instruments.instrument import Instrument
from utils.ql_helpers import DAY_COUNTERS, to_ql_date
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, RiskFactorSlice


class DividendOption(Instrument):
    """Present value of future dividend cashflows up to an expiry date.

    Each cashflow is included only if its payment date falls strictly
    before *expiry_date* and strictly after the valuation date.  The NPV
    is the sum of discounted fixed amounts across all qualifying cashflows.

    Parameters
    ----------
    name : str
        Trade identifier.
    expiry_date : date
        Option expiry / observation cut-off date.  Dividends on or after
        this date are excluded.
    div_data : list of dict
        Cashflow records as returned by :func:`pull_div_cashflows`.  Each
        entry must contain:
        ``{'Payment_Date': {'.Timestamp': 'YYYY-MM-DD'}, 'Fixed_Amount': float}``
    discount_curve_name : str
        Risk factor name for the discount curve.
    discount_interpolator : callable
        Interpolator factory for the discount curve.
    day_count : str
        Day count convention for year fractions (default ``"ACT/365"``).
    """

    def __init__(
        self,
        name: str,
        expiry_date: date,
        div_data: list[dict],
        discount_curve_name: str,
        discount_interpolator: Callable,
        day_count: str = "ACT/365",
    ):
        super().__init__(name)
        self.expiry_date = expiry_date
        self.discount_curve_name = discount_curve_name
        self.discount_interpolator = discount_interpolator
        self._dc = DAY_COUNTERS[day_count]

        # Parse and filter cashflows once at construction time
        self._cashflows: list[tuple[date, float]] = []
        for item in div_data:
            raw_date = item["Payment_Date"]
            if isinstance(raw_date, date):
                pay_date = raw_date
            else:
                ts = raw_date[".Timestamp"] if isinstance(raw_date, dict) else raw_date
                pay_date = date.fromisoformat(str(ts).strip())
            if pay_date < expiry_date:
                self._cashflows.append((pay_date, float(item["Fixed_Amount"])))

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        disc_slice: CurveSlice = market_state[self.discount_curve_name]
        n_paths = disc_slice.values.shape[0]

        disc_curve = YieldCurve(
            disc_slice.tenors, disc_slice.values, self.discount_interpolator,
        )

        ql_val = to_ql_date(val_date)
        pv = np.zeros(n_paths)

        for pay_date, amount in self._cashflows:
            if pay_date <= val_date:
                continue
            T = self._dc.yearFraction(ql_val, to_ql_date(pay_date))
            df = disc_curve.discount_factor(T)
            pv += amount * df

        return pv
