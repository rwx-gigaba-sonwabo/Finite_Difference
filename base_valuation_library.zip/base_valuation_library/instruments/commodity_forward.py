"""Forward on a commodity price for one delivery date.

The forward price is read off the commodity forward price curve. The payoff is the forward
price less the agreed price, times a number of units, discounted.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, cast

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.commodity_pv import commodity_average_forward_pv, fx_forward_rate
from utils.interpolation import (
    forward_price_interpolator,
    linear_interpolator,
    get_forward_price_from_slice,
    excel_serials_to_year_fracs,
)
from utils.ql_helpers import (
    DAY_COUNTERS,
    advance_business_days,
    to_ql_date,
)


class CommodityForward(Instrument):
    """Single-delivery-date commodity forward under ZAR-CSA discounting.

    Same pricing mechanics as CommodityAverageForward but with no
    averaging window.  The forward price fixes at *delivery_date* and the
    contract settles at *payment_date* (delivery_date + payment_lag
    business days).  The trade keeps a value until payment_date, so the
    settlement period is included.

    **ZAR-CSA discounting**

    *Standard contract* (USD underlying, USD payoff):

        payoff_USD = direction * (F(T_del) - strike) * notional
        PV_USD     = payoff_USD * FX_fwd(T_pay) * DF_MM(T_pay) / FX_spot

    *Composite contract* (USD underlying, ZAR payoff / ZAR strike):

        payoff_ZAR = direction * (F(T_del) * FX_fwd(T_pay) - strike_ZAR) * notional
        PV_ZAR     = payoff_ZAR * DF_MM(T_pay)

    **Fixing lifecycle**

    Before delivery_date : F(T_del) is read from the stochastic forward
                           curve at the lag-adjusted pricing_date.
    After delivery_date  : F is the realised price stamped by the
                           caller via compute_commodity_fixings;
                           the ZAR/USD rate still moves the value
                           until payment.
    After payment_date   : scenario_npvs returns zeros.

    **Domestic curve construction**

    The domestic curve (ZAR-USD-BASIS) stores additive zero-rate basis
    spreads on top of the ZAR-SWAP money-market curve, matching the
    convention used in CommodityAverageForward::

        r_dom(T) = r_ZAR_SWAP(T) + basis_spread(T)

    Parameters
    ----------
    name : str
        Trade identifier.
    delivery_date : date
        Date on which the forward price fixes (observation / expiry date).
    strike : float
        Strike price.  USD for a standard contract; ZAR for composite.
    notional : float
        Quantity (e.g. number of barrels or metric tonnes).
    is_composite : bool
        ``True`` → ZAR-denominated payoff with ZAR strike.
        ``False`` → USD-denominated payoff with ZAR-CSA discounting.
    forward_curve_name : str
        Risk-factor key for the commodity forward price CurveSlice.
        Tenors are Excel serial dates; values are USD prices per path.
    fx_spot_name : str
        Risk-factor key for the FX spot ScalarSlice.  Expected as
        domestic/foreign (ZAR/USD) unless ``fx_is_inverted`` is ``True``.
    domestic_curve_name : str
        Risk-factor key for the ZAR-USD-BASIS CurveSlice (basis spreads
        added on top of ZAR-SWAP to form the effective domestic curve).
    foreign_curve_name : str
        Risk-factor key for the USD-SOFR CurveSlice.
    money_market_curve_name : str
        Risk-factor key for the ZAR-SWAP CurveSlice used for discounting.
    payment_calendar : str
        Calendar for advancing delivery_date by payment_lag and
        fx_settlement_lag business days.
    lag_calendar : str
        Calendar for advancing delivery_date by pricing_lag business days
        to obtain the pricing_date (the forward-curve tenor to read).
    direction : int
        ``+1`` long (receive forward, pay strike); ``-1`` short.
        Default ``+1``.
    forward_interpolator : callable
        Interpolator factory for the commodity forward price curve.
        Defaults to :func:`~utils.interpolation.forward_price_interpolator`
        (linear between pillars, linear right-extrapolation).
    domestic_interpolator : callable
        Interpolator factory for the ZAR-USD-BASIS curve.
    foreign_interpolator : callable
        Interpolator factory for the USD-SOFR curve.
    money_market_interpolator : callable
        Interpolator factory for the ZAR-SWAP curve.
    pricing_lag : int
        Business days to advance delivery_date to obtain the pricing_date.
        Default 1.
    payment_lag : int
        Business days after delivery_date at which the contract settles.
        Default 2.
    fx_settlement_lag : int
        Business days after val_date at which the observed FX spot settles.
        Default 2.  Set to 0 for a T+0 FX convention.
    fx_is_inverted : bool
        ``True`` when the FX spot in the market state is quoted as
        foreign/domestic (e.g. USD/ZAR) rather than domestic/foreign
        (ZAR/USD).  When set, ``fx_spot`` is inverted before entering
        the FX forward calculation.  Standard contracts are insensitive
        to this flag (the wrong direction cancels in ``pv_zar / fx_spot``);
        composite contracts require the correct direction.  Default
        ``False``.
    day_count : str
        Day-count convention key in DAY_COUNTERS (default ``"ACT/365"``).
    """

    def __init__(
        self,
        name: str,
        delivery_date: date,
        strike: float,
        notional: float,
        is_composite: bool,
        forward_curve_name: str,
        fx_spot_name: str,
        domestic_curve_name: str,
        foreign_curve_name: str,
        money_market_curve_name: str,
        payment_calendar: str,
        lag_calendar: str,
        direction: int = 1,
        forward_interpolator: Callable = forward_price_interpolator,
        domestic_interpolator: Callable = linear_interpolator,
        foreign_interpolator: Callable = linear_interpolator,
        money_market_interpolator: Callable = linear_interpolator,
        pricing_lag: int = 1,
        payment_lag: int = 2,
        fx_settlement_lag: int = 2,
        fx_is_inverted: bool = False,
        day_count: str = "ACT/365",
    ) -> None:
        super().__init__(name)
        self.delivery_date = delivery_date
        self.strike = strike
        self.notional = notional
        self.is_composite = is_composite
        self.direction = direction
        self.forward_curve_name = forward_curve_name
        self.fx_spot_name = fx_spot_name
        self.domestic_curve_name = domestic_curve_name
        self.foreign_curve_name = foreign_curve_name
        self.money_market_curve_name = money_market_curve_name
        self.forward_interpolator = forward_interpolator
        self.domestic_interpolator = domestic_interpolator
        self.foreign_interpolator = foreign_interpolator
        self.money_market_interpolator = money_market_interpolator
        self.fx_settlement_lag = fx_settlement_lag
        self.fx_is_inverted = fx_is_inverted
        self._dc = DAY_COUNTERS[day_count]
        self._payment_calendar = payment_calendar

        # Pre-computed static dates
        self._pricing_date: date = advance_business_days(
            delivery_date, pricing_lag, lag_calendar,
        )
        self._payment_date: date = advance_business_days(
            delivery_date, payment_lag, payment_calendar,
        )
        self._fx_settlement_date: date = (
            advance_business_days(delivery_date, fx_settlement_lag, payment_calendar)
            if fx_settlement_lag > 0
            else delivery_date
        )

    # ------------------------------------------------------------------
    # Instrument interface
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Per-path NPV of the commodity forward at val_date.

        Parameters
        ----------
        val_date : date
            Current simulation date.
        market_state : dict
            Must contain all five curve/spot risk factors.
        fixings : dict or None
            May contain ``(forward_curve_name, delivery_date)`` →
            ``np.ndarray (n_paths,)``, the realised forward price stamped
            by the caller once delivery_date is crossed.  When absent,
            the current forward curve is used (pre-delivery pricing).
        rng : ignored
        """
        fx_slice = cast(ScalarSlice, market_state[self.fx_spot_name])
        n_paths = fx_slice.values.shape[0]

        if val_date > self._payment_date:
            return np.zeros(n_paths)

        T_pay = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self._payment_date),
        ))
        fx_spot = fx_slice.values  # (n_paths,)
        if self.fx_is_inverted:
            fx_spot = 1.0 / fx_spot  # foreign/domestic → domestic/foreign

        # --- Yield curves (identical construction to CommodityAverageForward) ---
        for_slice = cast(CurveSlice, market_state[self.foreign_curve_name])
        for_curve = YieldCurve(
            for_slice.tenors, for_slice.values, self.foreign_interpolator,
        )
        mm_slice = cast(CurveSlice, market_state[self.money_market_curve_name])
        mm_curve = YieldCurve(
            mm_slice.tenors, mm_slice.values, self.money_market_interpolator,
        )
        basis_slice = cast(CurveSlice, market_state[self.domestic_curve_name])
        swap_rates_at_basis = mm_curve.get_rate(basis_slice.tenors)
        combined_dom_rates = (
            swap_rates_at_basis
            + np.asarray(basis_slice.values, dtype=np.float64)
        )
        dom_curve = YieldCurve(
            basis_slice.tenors, combined_dom_rates, self.domestic_interpolator,
        )

        # --- FX settlement adjustment ---
        fx_settlement_T = 0.0
        if self.fx_settlement_lag > 0:
            val_settle = advance_business_days(
                val_date, self.fx_settlement_lag, self._payment_calendar,
            )
            fx_settlement_T = float(self._dc.yearFraction(
                to_ql_date(val_date), to_ql_date(val_settle),
            ))

        # --- Forward price ---
        # Post-delivery: the caller stamps the realised price under
        # (forward_curve_name, delivery_date) in the fixings dict.
        # Pre-delivery: read from the stochastic forward curve.
        _fix: dict = fixings if fixings is not None else {}
        key = (self.forward_curve_name, self.delivery_date)

        if key in _fix:
            f_price = np.asarray(_fix[key], dtype=np.float64)
            if f_price.ndim == 0:
                f_price = np.full(n_paths, float(f_price))
        else:
            fwd_slice = cast(CurveSlice, market_state[self.forward_curve_name])
            right_extrap = (
                "flat"
                if self.forward_interpolator is linear_interpolator
                else "linear"
            )
            fwd_tenors_yf = excel_serials_to_year_fracs(
                fwd_slice.tenors, val_date, self._dc,
            )
            f_price = get_forward_price_from_slice(
                curve_serial_tenors=fwd_slice.tenors,
                curve_values=fwd_slice.values,
                value_date=val_date,
                target_date=self._pricing_date,
                day_counter=self._dc,
                right_extrapolation=right_extrap,
                left_extrapolation="flat",
                _precomputed_tenors_yf=fwd_tenors_yf,
            )

        return commodity_average_forward_pv(
            avg_price=f_price,
            strike=self.strike,
            notional=self.notional,
            is_composite=self.is_composite,
            fx_spot=fx_spot,
            dom_curve=dom_curve,
            for_curve=for_curve,
            mm_curve=mm_curve,
            T_pay=T_pay,
            fx_settlement_T=fx_settlement_T,
            direction=self.direction,
        )

    # ------------------------------------------------------------------
    # Commodity fixing interface (called by the code that runs the valuation)
    # ------------------------------------------------------------------

    def get_commodity_fixing_schedule(self) -> list[tuple[date, date, date]]:
        """Return [(delivery_date, pricing_date, fx_settlement_date)]."""
        return [(self.delivery_date, self._pricing_date, self._fx_settlement_date)]

    def _compute_fixing_for_date(
        self,
        delivery_date: date,
        pricing_date: date,
        _fx_settle_date: date,
        market_state: dict[str, RiskFactorSlice],
        scenario_date: date,
    ) -> dict:
        """Compute the realised delivery price using market_state at scenario_date.

        Year fractions are measured from ``scenario_date`` so the forward
        curve is read consistently with the simulation step that produced it.
        ``_fx_settle_date`` is accepted for interface uniformity but unused here
        (the FX leg remains live until payment and is priced in scenario_npvs).
        """
        fwd_slice = cast(CurveSlice, market_state[self.forward_curve_name])
        right_extrap = (
            "flat" if self.forward_interpolator is linear_interpolator else "linear"
        )
        fwd_tenors_yf = excel_serials_to_year_fracs(
            fwd_slice.tenors, scenario_date, self._dc,
        )
        f_price = get_forward_price_from_slice(
            curve_serial_tenors=fwd_slice.tenors,
            curve_values=fwd_slice.values,
            value_date=scenario_date,
            target_date=pricing_date,
            day_counter=self._dc,
            right_extrapolation=right_extrap,
            left_extrapolation="flat",
            _precomputed_tenors_yf=fwd_tenors_yf,
        )
        return {(self.forward_curve_name, delivery_date): f_price}

    def compute_commodity_fixings(
        self,
        market_state: dict[str, RiskFactorSlice],
        sim_date: date,
        existing_fixings: dict | None = None,
    ) -> dict:
        """Stamp the realised delivery price when delivery_date is first crossed.

        Standalone convenience method: uses ``sim_date``'s ``market_state``.
        A caller gets better
        accuracy by calling ``_compute_fixing_for_date`` with the market state
        at the nearest scenario date ≤ delivery_date.
        """
        if self._pricing_date > sim_date:
            return {}
        key = (self.forward_curve_name, self.delivery_date)
        if key in (existing_fixings or {}):
            return {}
        return self._compute_fixing_for_date(
            self.delivery_date, self._pricing_date, self._fx_settlement_date,
            market_state, sim_date,
        )
