"""Single barrier option on a commodity reference price, with the barrier watched all the time.

What the trade is
-----------------
A European call or put on a commodity reference price, on ``units`` of the commodity,
with one barrier level.

``knock out``
    The option stops existing the first time the reference price touches the barrier.
    If a cash rebate is agreed it is paid when that happens.
``knock in``
    The option only starts existing once the reference price touches the barrier. If a
    cash rebate is agreed it is paid at expiry when the barrier was never touched.

The barrier is ``up`` when it sits above the price and ``down`` when it sits below.

How it is valued
----------------
1. **Price today and forward price.** The reference price observed on any date is the
   forward price of the delivery date that date fixes against. So the price today, ``S``,
   is read off the forward price curve at today's delivery date. The forward price to
   expiry, ``F``, is read at the expiry's delivery date.
2. **Cost of carry.** ``b = ln(F / S) / T`` with ``T`` the time to expiry in years. This
   makes the model's forward ``S * exp(b * T)`` equal to the curve's forward.
3. **Discount rate.** ``r`` is the zero rate to expiry off the discount curve.
4. **Volatility.** ``sigma`` is read off the commodity volatility surface at the strike
   and floored at 5%. One constant volatility is used for the whole life.
5. **Value.** The closed form for single barrier options in
   :mod:`models.barrier_option_pv` gives the value per unit. It is multiplied by
   ``units``, by +1 for a bought and -1 for a sold option, and by the FX rate into the
   reporting currency.

Barrier already touched
-----------------------
If the price today is strictly beyond the barrier, or the barrier is flagged as touched
before the valuation date, the option has already changed state. A knock out is then
worth its rebate. A knock in is worth the plain European option.

Barrier checked at intervals
----------------------------
Set ``monitoring_interval_years`` above zero when the barrier is only checked at fixed
intervals. The barrier used in the formula is then moved away from the price by
``exp(0.5826 * sigma * sqrt(interval))``.

Payout in another currency
--------------------------
``X`` is the FX rate in payout currency per unit of commodity currency.

``standard``
    No adjustment.
``quanto``
    Strike and barrier are levels in commodity currency. The cost of carry is reduced by
    ``rho * sigma_S * sigma_X`` using at the money volatilities.
``composite``
    The option is written on ``S * X``. Strike and barrier are levels in payout currency.
    ``S`` is multiplied by the FX spot, ``F`` by the FX forward, and the volatility becomes
    ``sqrt(sigma_S**2 + 2 * rho * sigma_S * sigma_X + sigma_X**2)``.

Limits of the model
-------------------
One constant volatility and one constant carry are used, so the term structure of
volatility and the shape of the forward curve between today and expiry are not seen by
the barrier. The reference price must not roll from one futures contract to the next
before expiry, because the price would then jump at the roll. The constructor checks this.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, Sequence

import numpy as np

from instruments.components.commodity_option_market import (
    PAYOFF_TYPES,
    CrossCurrencyPayoff,
    at_the_money_moneyness,
    forward_price_for_delivery,
    scalar_value,
    summed_zero_rate,
)
from instruments.instrument import Instrument
from market_data.risk_factor import RiskFactorSlice
from models.barrier_option_pv import (
    MIN_BARRIER_VOLATILITY,
    barrier_formula_label,
    barrier_is_breached,
    monitoring_adjusted_barrier,
    single_barrier_option_value,
)
from models.digital_option_pv import composite_volatility

EXCEL_EPOCH = date(1899, 12, 30)
VOLATILITY_MONEYNESS_BASES = ("spot", "forward")


class CommodityBarrierOption(Instrument):
    """Single barrier call or put on a commodity reference price.

    Parameters
    ----------
    name : str
        Trade identifier, used in reports.
    expiry_date : date
        Date the option expires and the final fixing is observed.
    strike : float
        Strike price. In commodity currency, or in payout currency for a composite payout.
    barrier : float
        Barrier level, in the same currency as the strike.
    units : float
        Number of commodity units the option is written on. Must not be zero.
    is_call : bool
        ``True`` for a call, ``False`` for a put.
    is_up : bool
        ``True`` when the barrier is above the price, ``False`` when below.
    is_knock_in : bool
        ``True`` for a knock in, ``False`` for a knock out.
    forward_curve_name : str
        Key of the commodity forward price curve in ``market_state``. Its tenors are Excel
        serial dates of the delivery dates.
    fixing_curve : array-like, shape (n, 2)
        Mapping from a fixing date (column 0) to the delivery date it reads (column 1),
        both as Excel serials. Linear between points and flat outside.
    discount_curve_names : str or sequence of str
        Key of the discount curve in ``market_state``. Give several names to add spread
        curves on top of the first.
    vol_surface : object
        Commodity volatility surface with ``moneyness_of(underlying, strike)`` and
        ``get_vol(moneyness, expiry)``.
    is_buy : bool
        ``True`` when the option was bought, ``False`` when it was sold.
    cash_rebate : float
        Total cash rebate for the whole trade, not per unit.
    monitoring_interval_years : float
        Time between barrier checks in years. Zero means watched all the time.
    payoff_type : {"standard", "quanto", "composite"}
        How a payout in another currency is treated. See the module notes.
    cross_currency : CrossCurrencyPayoff, optional
        FX inputs. Needed for ``quanto`` and ``composite``.
    payoff_fx_name, report_fx_name : str, optional
        Keys of the FX spot factors of the payout currency and the reporting currency in
        ``market_state``. Leave both ``None`` to report in the payout currency.
    curve_interpolators : dict, optional
        ``{curve name: interpolator factory}`` for the rate curves. Linear when not given.
    forward_extrapolation : {"flat", "linear"}
        Treatment of delivery dates outside the forward curve's pillars.
    days_in_year : float
        Divisor that turns calendar days into years.
    min_volatility : float
        Floor applied to the volatility.
    barrier_touched_before : bool
        ``True`` when the barrier is known to have been touched before the valuation date.
    volatility_moneyness_basis : {"spot", "forward"}
        Price used with the strike to read the volatility surface: the price today or the
        forward price to expiry.
    """

    def __init__(
        self,
        name: str,
        expiry_date: date,
        strike: float,
        barrier: float,
        units: float,
        is_call: bool,
        is_up: bool,
        is_knock_in: bool,
        forward_curve_name: str,
        fixing_curve,
        discount_curve_names: str | Sequence[str],
        vol_surface,
        is_buy: bool = True,
        cash_rebate: float = 0.0,
        monitoring_interval_years: float = 0.0,
        payoff_type: str = "standard",
        cross_currency: CrossCurrencyPayoff | None = None,
        payoff_fx_name: str | None = None,
        report_fx_name: str | None = None,
        curve_interpolators: dict[str, Callable] | None = None,
        forward_extrapolation: str = "flat",
        days_in_year: float = 365.0,
        min_volatility: float = MIN_BARRIER_VOLATILITY,
        barrier_touched_before: bool = False,
        volatility_moneyness_basis: str = "spot",
    ) -> None:
        super().__init__(name)
        if payoff_type not in PAYOFF_TYPES:
            raise ValueError(f"payoff_type must be one of {PAYOFF_TYPES}, got {payoff_type!r}")
        if payoff_type != "standard" and cross_currency is None:
            raise ValueError(f"payoff_type {payoff_type!r} needs the cross_currency inputs")
        if volatility_moneyness_basis not in VOLATILITY_MONEYNESS_BASES:
            raise ValueError(
                f"volatility_moneyness_basis must be one of {VOLATILITY_MONEYNESS_BASES}")
        if units == 0.0:
            raise ValueError("units must not be zero")
        if strike <= 0.0 or barrier <= 0.0:
            raise ValueError("strike and barrier must be positive")

        self.expiry_date = expiry_date
        self.strike = float(strike)
        self.barrier = float(barrier)
        self.units = float(units)
        self.is_call = bool(is_call)
        self.is_up = bool(is_up)
        self.is_knock_in = bool(is_knock_in)
        self.is_buy = bool(is_buy)
        self.cash_rebate = float(cash_rebate)
        self.forward_curve_name = forward_curve_name
        self.fixing_curve = np.asarray(fixing_curve, dtype=float)
        self.discount_curve_names = (
            (discount_curve_names,) if isinstance(discount_curve_names, str)
            else tuple(discount_curve_names))
        self.vol_surface = vol_surface
        self.monitoring_interval_years = float(monitoring_interval_years)
        self.payoff_type = payoff_type
        self.cross_currency = cross_currency
        self.payoff_fx_name = payoff_fx_name
        self.report_fx_name = report_fx_name
        self.curve_interpolators = dict(curve_interpolators or {})
        self.forward_extrapolation = forward_extrapolation
        self.days_in_year = float(days_in_year)
        self.min_volatility = float(min_volatility)
        self.barrier_touched_before = bool(barrier_touched_before)
        self.volatility_moneyness_basis = volatility_moneyness_basis

    # ---------------------------------------------------------------- helpers
    def delivery_serial(self, fixing_date: date) -> float:
        """Excel serial of the delivery date that ``fixing_date`` fixes against."""
        serial = float((fixing_date - EXCEL_EPOCH).days)
        return float(np.interp(serial, self.fixing_curve[:, 0], self.fixing_curve[:, 1]))

    def check_no_contract_roll(self, val_date: date) -> None:
        """Refuse a reference price that changes futures contract before expiry.

        Day by day from the valuation date to expiry, the delivery date must either stay
        the same (one contract) or move forward one day at a time (a spot like reference).
        Anything else means the observed price jumps when the contract rolls, which a
        closed form on one continuous price cannot value.
        """
        start = (val_date - EXCEL_EPOCH).days
        end = (self.expiry_date - EXCEL_EPOCH).days
        if end <= start:
            return
        days = np.arange(start, end + 1, dtype=float)
        steps = np.diff(np.interp(days, self.fixing_curve[:, 0], self.fixing_curve[:, 1]))
        if not (np.allclose(steps, 0.0) or np.allclose(steps, 1.0)):
            raise ValueError(
                f"{self.name}: the reference price rolls from one delivery date to another "
                f"before the expiry date {self.expiry_date}. The barrier closed form cannot "
                f"value a price that jumps at the roll.")

    # ------------------------------------------------------------- valuation
    def valuation_details(
        self, val_date: date, market_state: dict[str, RiskFactorSlice],
    ) -> dict[str, np.ndarray | float | str]:
        """Value the option and return every intermediate number.

        Each array has one entry per market scenario in ``market_state``. The entry
        ``"present_value"`` is what :meth:`scenario_npvs` returns.
        """
        self.check_no_contract_roll(val_date)
        expiry = (self.expiry_date - val_date).days / self.days_in_year
        sign = 1.0 if self.is_buy else -1.0
        report_fx = np.asarray(scalar_value(market_state, self.payoff_fx_name), dtype=float) / np.asarray(
            scalar_value(market_state, self.report_fx_name), dtype=float)
        curve = market_state[self.forward_curve_name]

        spot_local = forward_price_for_delivery(
            curve, self.delivery_serial(val_date), self.forward_extrapolation)
        if expiry < 0.0:
            return {"time_to_expiry": expiry, "method": "expired",
                    "present_value": 0.0 * spot_local}
        forward_local = forward_price_for_delivery(
            curve, self.delivery_serial(self.expiry_date), self.forward_extrapolation)
        time_for_rates = expiry if expiry > 0.0 else 1.0
        carry_rate = np.log(forward_local / spot_local) / time_for_rates
        discount_rate = (summed_zero_rate(market_state, self.discount_curve_names,
                                          self.curve_interpolators, expiry)
                         if expiry > 0.0 else np.zeros_like(spot_local))

        details: dict[str, np.ndarray | float | str] = {
            "time_to_expiry": expiry, "spot_price_curve_read": spot_local,
            "forward_price_curve_read": forward_local, "fx_to_reporting_currency": report_fx,
        }

        # FX terms for a payout in another currency.
        fx_spot, fx_forward, fx_carry, carry_adjustment = 1.0, 1.0, 0.0, 0.0
        fx_vol, rho = None, None
        if self.payoff_type != "standard" and expiry > 0.0:
            cross = self.cross_currency
            fx_vol, rho = cross.fx_at_the_money_vol(expiry), cross.correlation
            details.update(fx_volatility=fx_vol, correlation=rho)
            if self.payoff_type == "composite":
                fx_spot = cross.fx_spot(market_state)
                fx_carry = cross.fx_carry_rate(market_state, self.curve_interpolators, expiry)
                fx_forward = fx_spot * np.exp(fx_carry * expiry)
                details.update(fx_spot=fx_spot, fx_forward=fx_forward)

        # Volatility at the strike. A composite strike is converted back to commodity
        # currency at the FX forward before the commodity surface is read.
        if expiry > 0.0:
            underlying = spot_local if self.volatility_moneyness_basis == "spot" else forward_local
            moneyness = self.vol_surface.moneyness_of(underlying, self.strike / fx_forward)
            surface_vol = np.asarray(self.vol_surface.get_vol(moneyness, expiry), dtype=float)
            volatility = surface_vol
            if self.payoff_type == "composite":
                volatility = composite_volatility(surface_vol, fx_vol, rho)
            elif self.payoff_type == "quanto":
                atm_vol = float(self.vol_surface.get_vol(
                    at_the_money_moneyness(self.vol_surface), expiry))
                carry_adjustment = -rho * atm_vol * fx_vol
                details.update(commodity_at_the_money_volatility=atm_vol,
                               quanto_carry_adjustment=carry_adjustment)
            details["surface_volatility"] = surface_vol
        else:
            volatility = np.full_like(spot_local, self.min_volatility)

        spot = spot_local * fx_spot
        carry = carry_rate + carry_adjustment + fx_carry
        volatility_used = np.maximum(volatility, self.min_volatility)
        barrier_used = monitoring_adjusted_barrier(
            self.barrier, volatility_used, self.monitoring_interval_years, self.is_up)
        touched = np.logical_or(self.barrier_touched_before,
                                barrier_is_breached(spot, barrier_used, self.is_up))

        value_per_unit = single_barrier_option_value(
            spot, carry, discount_rate, volatility, expiry, self.strike, self.barrier,
            self.cash_rebate / self.units, self.is_call, self.is_up, self.is_knock_in,
            monitoring_interval_years=self.monitoring_interval_years,
            min_volatility=self.min_volatility,
            barrier_touched_before=self.barrier_touched_before)
        present_value = sign * self.units * value_per_unit * report_fx

        details.update(
            spot_price=spot, forward_price=spot * np.exp(carry * expiry), carry_rate=carry,
            discount_zero_rate=discount_rate, volatility=volatility_used,
            strike=self.strike, barrier=self.barrier, barrier_used_in_formula=barrier_used,
            barrier_touched=touched,
            formula=barrier_formula_label(self.is_call, self.is_up, self.is_knock_in,
                                          self.strike > self.barrier),
            value_per_unit=value_per_unit, present_value=present_value)
        return details

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Present value in the reporting currency, one entry per market scenario."""
        value = self.valuation_details(val_date, market_state)["present_value"]
        return np.atleast_1d(np.asarray(value, dtype=float))
