"""Credit default swap.

One side pays a regular premium. The other side pays the loss when the reference name
defaults. The value is the protection leg less the premium leg for a protection buyer.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Callable

import numpy as np

from instruments.components.schedule_config import ScheduleConfig
from instruments.instrument import Instrument
from utils.ql_helpers import to_ql_date
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, RiskFactorSlice
from models.cashflow_pv import filter_future_periods, compute_period_year_fractions
from models.credit_pv import (
    compute_credit_quantities,
    pv_defaultable_leg,
    pv_credit_risky_cashflow_leg,
)


# ---------------------------------------------------------------------------
# CDS
# ---------------------------------------------------------------------------

class CDS(Instrument):
    """Credit Default Swap priced with midpoint default assumptions.

    The default grid coincides with the coupon (premium) schedule.
    Within each period, default is assumed to occur at the midpoint.
    The midpoint discount factor is the average of the discount factors
    at the period boundaries: DF_mid = (DF(t_start) + DF(t_end)) / 2.

    Priced from the **protection buyer's** perspective:
        NPV = Protection Leg PV - Premium Leg PV

    Protection Leg PV:
        Σ (1 - R) * DF_mid_i * (S(t_start_i) - S(t_end_i))

    Premium Leg PV:
        Σ coupon * accrual_i * DF(t_end_i) * S(t_end_i)          [scheduled]
      + Σ coupon * (accrual_i / 2) * DF_mid_i * (S_start - S_end) [accrued on default]
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        notional: float,
        coupon: float,
        recovery_rate: float,
        discount_curve_name: str,
        credit_curve_name: str,
        interpolator: Callable,
        is_protection_buyer: bool = True,
        credit_interpolator: Callable | None = None,
        floating_curve_name: str | None = None,
        frequency: int = 3,
        schedule_config: ScheduleConfig | None = None,
        # legacy flat params, used only when schedule_config is not supplied
        calendar: str = "USD",
        business_convention: str = "ModifiedFollowing",
        termination_business_convention: str = "ModifiedFollowing",
        date_generation: str = "Backward",
        day_count: str = "ACT/360",
        curve_day_count: str = "ACT/365",
        end_of_month: bool = False,
        premium_extra_day: bool = False,
        include_on_val_date: bool = False,
    ):
        super().__init__(name)
        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.notional = notional
        self.coupon = coupon
        self.recovery_rate = recovery_rate
        self.discount_curve_name = discount_curve_name
        self.credit_curve_name = credit_curve_name
        self.interpolator = interpolator
        self.is_protection_buyer = is_protection_buyer
        self.credit_interpolator = credit_interpolator or interpolator
        self.floating_curve_name = floating_curve_name
        self.frequency = frequency
        self.premium_extra_day = premium_extra_day
        self.include_on_val_date = include_on_val_date

        self.schedule_config = schedule_config or ScheduleConfig(
            calendar=calendar,
            business_convention=business_convention,
            termination_business_convention=termination_business_convention,
            date_generation=date_generation,
            day_count=day_count,
            curve_day_count=curve_day_count,
            end_of_month=end_of_month,
        )

        self._generate_schedule()

    # ------------------------------------------------------------------
    # schedule generation
    # ------------------------------------------------------------------

    def _generate_schedule(self):
        """Build the coupon schedule (also the default grid)."""
        self.schedule = self.schedule_config.build(
            self.effective_date, self.maturity_date, self.frequency,
        )

    # ------------------------------------------------------------------
    # reset / fixing interface (floating coupon)
    # ------------------------------------------------------------------

    def get_reset_dates(self) -> list[tuple[date, str, date, date]]:
        """Return (reset_date, curve_name, period_start, period_end) for floating resets."""
        if self.floating_curve_name is None:
            return []
        return [
            (start, self.floating_curve_name, start, end)
            for start, end, _pay_date, _accrual in self.schedule
        ]

    def compute_fixings(
        self,
        resets: list[tuple[date, str, date, date]],
        time_slice: dict[str, RiskFactorSlice],
        scenario_date: date,
    ) -> dict[tuple[str, date], np.ndarray]:
        """Compute forward rates for the given resets from an earlier scenario's curve."""
        fixings: dict[tuple[str, date], np.ndarray] = {}
        ql_scenario = to_ql_date(scenario_date)

        for _reset_date, curve_name, p_start, p_end in resets:
            fwd_slice: CurveSlice = time_slice[curve_name]
            fwd_curve = YieldCurve(
                year_fracs=fwd_slice.tenors,
                rates=fwd_slice.values,
                interpolator=self.interpolator,
            )
            t_start = self.schedule_config.curve_day_counter.yearFraction(
                ql_scenario, to_ql_date(p_start),
            )
            t_end = self.schedule_config.curve_day_counter.yearFraction(
                ql_scenario, to_ql_date(p_end),
            )
            rate = fwd_curve.forward_rate(t_start, t_end)
            fixings[(curve_name, p_start)] = rate

        return fixings

    # ------------------------------------------------------------------
    # pricing
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        disc_slice: CurveSlice = market_state[self.discount_curve_name]
        credit_slice: CurveSlice = market_state[self.credit_curve_name]
        n_paths = disc_slice.values.shape[0]

        if val_date > self.maturity_date:
            return np.zeros(n_paths)

        discount_curve = YieldCurve(
            year_fracs=disc_slice.tenors,
            rates=disc_slice.values,
            interpolator=self.interpolator,
        )
        credit_curve = YieldCurve(
            year_fracs=credit_slice.tenors,
            rates=credit_slice.values,
            interpolator=self.credit_interpolator,
        )

        future = filter_future_periods(
            self.schedule, val_date, self.include_on_val_date,
        )
        if not future:
            return np.zeros(n_paths)

        t_starts, t_ends, _t_pays, accruals = compute_period_year_fractions(
            future, val_date, self.schedule_config.curve_day_counter,
        )

        (df_starts, df_ends, df_mids,
         surv_starts, surv_ends, default_probs) = compute_credit_quantities(
            t_starts, t_ends, discount_curve, credit_curve,
        )

        # --- protection leg ---
        protection_pv = pv_defaultable_leg(
            df_mids, default_probs, self.recovery_rate,
        )

        # --- premium leg ---
        premium_pv = pv_credit_risky_cashflow_leg(
            future=future,
            t_starts=t_starts,
            t_ends=t_ends,
            accruals=accruals,
            df_ends=df_ends,
            df_mids=df_mids,
            surv_ends=surv_ends,
            default_probs=default_probs,
            n_paths=n_paths,
            coupon=self.coupon,
            floating_curve_name=self.floating_curve_name,
            market_state=market_state,
            interpolator=self.interpolator,
            fixings=fixings,
            premium_extra_day=self.premium_extra_day,
            day_counter=self.schedule_config.day_counter,
        )

        direction = 1.0 if self.is_protection_buyer else -1.0
        return direction * self.notional * (protection_pv - premium_pv)
