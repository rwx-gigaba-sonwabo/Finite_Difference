"""Definition of one inflation linked leg: real rate, index curve, base index level and lag."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional


@dataclass
class InflationLeg:
    """Definition of an inflation-indexed cashflow leg.

    Models the CPI-linked side of an index-linked swap.  Each coupon period
    pays a real fixed rate on a notional that is scaled by the CPI index ratio
    relative to the base CPI level at trade inception:

        scaled_notional(t) = base_notional * CPI(ref(t)) / base_cpi

    where ``ref(t)`` is the BESA-lagged reference date for payment date ``t``
    (default lag: 4 months back to the first of month).

    At maturity the inflation-adjusted notional is repaid (standard BESA ILS
    convention).  This can be disabled by setting
    ``include_notional_exchange=False``.

    CPI index values during Monte Carlo simulation are sourced from a stochastic
    ``CurveSlice`` stored in the market state under ``cpi_curve_name``.  For
    payment dates whose BESA reference date has already passed (≤ valuation
    date), pre-computed historical CPI values are used instead.

    Parameters
    ----------
    frequency : int
        Payment frequency in months (e.g. 6 for semi-annual, 12 for annual).
        Use ``0`` for a zero-coupon leg: a single payment at maturity covering
        the full effective-to-maturity accrual period.
    fixed_rate : float
        Real annualised fixed coupon rate.
    spread : float
        Additive spread applied to the coupon rate.
    cpi_curve_name : str
        Market data name of the spot CPI level.  The
        ``CurveSlice`` stored under this key must contain the last
        published CPI index level per path.

        *Legacy mode* (``inflation_rate_curve_name`` is empty): the
        ``CurveSlice`` must additionally carry a forward term structure
        of CPI index levels at multiple tenors so that future bracket
        dates can be interpolated directly.

        *two curve mode* (``inflation_rate_curve_name`` is set): only
        the spot value at ``values[:, 0]`` is read; forward CPI levels
        are derived from ``inflation_rate_curve_name`` instead.
    inflation_rate_curve_name : str
        Optional market data name of the real inflation rate
        term structure.  When
        provided, forward CPI at reference date T is computed as:

            CPI(T) = spot_CPI / DF_infl(T)
                   = spot_CPI × exp(∫[0→T] r_infl(s) ds)

        where ``DF_infl`` is the discount factor implied by the
        inflation rate curve.  Leave empty to use the legacy direct
        CPI level interpolation approach.
    base_cpi : float
        CPI index level at trade inception (used to compute index ratios).
    lag_months : int
        Number of months for the CPI publication lag (default 4, BESA).
    include_notional_exchange : bool
        If True the final period includes repayment of the inflation-adjusted
        notional at maturity (standard BESA ILS convention).
    compounding_period_months : int
        Sub-period compounding interval in months (0 = simple accrual, the default).
        When non-zero, the coupon interest for each payment period is computed as:

            interest = (1 + rate * cp_tau) ** (tau / cp_tau) - 1

        where ``cp_tau = compounding_period_months / 12`` and ``tau`` is the
        payment-period year fraction.  This replaces the simple ``rate * tau``
        formula
        when the ``Compound`` field is set (e.g. 6m compounding on a zero-coupon
        inflation leg gives ``(1 + rate/2) ** (2*T) - 1`` for a ``T``-year tenor).
    next_publication_date : date or None
        The date on which the CPI for the period immediately after the last
        entry in ``historical_cpi_map`` (i.e. ``Last_Period_Start + 1 period``)
        will be officially released.  When provided, ``get_cpi_last_pub_date``
        uses the exact publication schedule rather than the simple
        ``first_of_month(sim_date) - 1 month`` approximation.

        Example (ZAR CPI, monthly): if ``historical_cpi_map`` covers up to
        Jun-01-2025 and the Jul-01-2025 CPI will be published Aug-15-2025,
        set ``next_publication_date = date(2025, 8, 15)``.

        Leave ``None`` (default) to keep the legacy formula, which is exact
        for month-end simulation grids and approximates within ~±15 days for
        daily grids.
    publication_frequency_months : int
        How often CPI is published: 1 for monthly (default, ZAR), 3 for
        quarterly.  Only used when ``next_publication_date`` is set.
    """

    frequency: int
    fixed_rate: float
    spread: float = 0.0
    cpi_curve_name: str = ""
    inflation_rate_curve_name: str = ""
    base_cpi: float = 100.0
    lag_months: int = 4
    include_notional_exchange: bool = True
    compounding_period_months: int = 0
    next_publication_date: Optional[date] = None
    publication_frequency_months: int = 1

    def __post_init__(self):
        if self.fixed_rate is None:
            raise ValueError("fixed_rate is required for an InflationLeg")
        if not self.cpi_curve_name:
            raise ValueError("cpi_curve_name is required for an InflationLeg")
        if self.base_cpi <= 0:
            raise ValueError("base_cpi must be positive")
        if self.compounding_period_months < 0:
            raise ValueError("compounding_period_months must be non-negative")
