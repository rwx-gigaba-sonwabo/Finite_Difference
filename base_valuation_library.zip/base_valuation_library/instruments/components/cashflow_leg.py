"""Definition of one interest leg: fixed or floating, its frequency, rate, spread and curve."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class LegType(Enum):
    FIXED = "fixed"
    FLOATING = "floating"


_VALID_COMPOUNDING_METHODS = frozenset(
    {"None", "Flat", "Include_Margin", "Exclude_Margin", "Exponential"}
)
_VALID_AVERAGING_METHODS = frozenset({"None", "Average_Rate", "Average_Interest"})


@dataclass
class CashflowLeg:
    """Definition of a single cashflow leg.

    A generic leg definition that can be used across multiple instrument
    types (IR swaps, cross-currency swaps, etc.).

    Parameters
    ----------
    leg_type : LegType
        Whether the leg pays a fixed rate or a floating rate.
    frequency : int
        Payment frequency in months (e.g. 3 for quarterly, 6 for semi-annual,
        12 for annual). Use ``0`` for a zero-coupon leg: a single payment
        at maturity covering the full effective-to-maturity accrual period.
    spread : float
        Additive spread applied to the rate.
    fixed_rate : float or None
        The fixed coupon rate (annualised). Required when leg_type is FIXED.
    curve_name : str or None
        Market data name of the floating reference curve.
        Required when leg_type is FLOATING.
    fixing_tenor_months : int or None
        Tenor (in months) used to look up the LIBOR fixing rate from the
        projection curve.  When set, BOTH valuation and the in-progress
        fixing use this tenor instead of the schedule period length.
        Required whenever the schedule period length can differ from the
        index tenor, e.g. a JIBAR-3m leg on a trade whose maturity is
        less than 3 months, or any leg with front/back stub periods.
        Has no effect on overnight-compounding legs.
    forward_business_convention : str or None
        If the forward index uses a different business convention from
        the leg schedule, specify it here.
    overnight_compounding : bool
        When True, the floating rate for each period is computed by
        compounding daily overnight forward factors (e.g. SOFR, ESTR).
        Each business day's one-day forward factor DF(t_i)/DF(t_{i+1}) is
        multiplied together, then converted to a simply-compounded rate over
        the full accrual period tau.  Has no effect on FIXED legs.
    include_notional_exchange : bool
        If True, the fixed notional is repaid at maturity alongside the
        final coupon cashflow.  On the nominal leg of an index-linked swap
        this matches the inflation-adjusted notional returned on the
        inflation leg.  Defaults to False (no principal exchange).
    reset_frequency_months : int
        Sub-period reset frequency in months.  When non-zero AND less than
        ``frequency``, each payment period is split into multiple sub-periods
        of this length (the last may be shorter if the division is uneven).
        A separate floating rate is fixed at the start of each sub-period,
        and the sub-period rates are combined via ``compounding_method`` or
        ``averaging_method``
        (e.g. JIBAR-3m resets inside a 6-month payment period).
        Set to ``0`` (default) for the standard single-reset-per-period
        behaviour.
    compounding_period_months : int
        Sub-period compounding interval in months for **FIXED** legs (default 0 =
        simple accrual).  When non-zero, the coupon interest for each payment
        period is computed as:

            interest = ∏_j (1 + rate × τ_j) − 1

        where the sub-periods advance ``compounding_period_months`` at a time from
        the period start (with a possible short stub at the end).  This is the
        usual treatment of a leg that compounds within each coupon period.
        Has no effect on ``FLOATING`` legs; use
        ``reset_frequency_months`` with ``compounding_method`` for those.
    compounding_method : str
        How sub-period rates are combined when ``reset_frequency_months > 0``.
        The choices are:

        - ``"None"``         , no compounding; only the first sub-period
                                rate is used (effectively falls back to
                                single-reset behaviour).
        - ``"Include_Margin"``, compound ``(r_i + spread) * tau_i`` for
                                each sub-period (ISDA "Straight" compounding):
                                ``prod(1 + (r_i+m)*tau_i) - 1``.
        - ``"Flat"``         , compound ``r_i * tau_i`` without the spread;
                                spread is added linearly on the original notional:
                                ``prod(1 + r_i*tau_i) - 1 + m*tau_total``
                                (ISDA "Flat" compounding).
        - ``"Exclude_Margin"``, same as ``"Flat"``: compound rates, spread
                                applied linearly.
        - ``"Exponential"``  , ``exp(sum(r_i*tau_i)) - 1 + m*tau_total``.

        Mutually exclusive with ``averaging_method``.
    averaging_method : str
        How sub-period rates are combined when ``reset_frequency_months > 0``.
        The choices are:

        - ``"None"``             , no averaging (use ``compounding_method``).
        - ``"Average_Rate"``     , arithmetic mean of sub-period rates applied
                                    to the full payment period:
                                    ``(mean(r_i) + m) * tau_total``.
        - ``"Average_Interest"`` , sum individual sub-period interest amounts:
                                    ``sum(r_i * tau_i) + m * tau_total``.

        Mutually exclusive with ``compounding_method``.
    """

    leg_type: LegType
    frequency: int
    spread: float = 0.0
    fixed_rate: float | None = None
    curve_name: str | None = None
    fixing_tenor_months: int | None = None
    forward_business_convention: str | None = None
    overnight_compounding: bool = False
    include_notional_exchange: bool = False
    compounding_period_months: int = 0
    reset_frequency_months: int = 0
    compounding_method: str = "None"
    averaging_method: str = "None"

    def __post_init__(self):
        if self.leg_type == LegType.FIXED and self.fixed_rate is None:
            raise ValueError("fixed_rate is required for a FIXED leg")
        if self.leg_type == LegType.FLOATING and self.curve_name is None:
            raise ValueError("curve_name is required for a FLOATING leg")
        if self.overnight_compounding and self.leg_type != LegType.FLOATING:
            raise ValueError("overnight_compounding requires leg_type=FLOATING")
        if self.compounding_period_months < 0:
            raise ValueError("compounding_period_months must be non-negative")
        if self.compounding_method not in _VALID_COMPOUNDING_METHODS:
            raise ValueError(
                f"compounding_method must be one of {sorted(_VALID_COMPOUNDING_METHODS)}, "
                f"got {self.compounding_method!r}"
            )
        if self.averaging_method not in _VALID_AVERAGING_METHODS:
            raise ValueError(
                f"averaging_method must be one of {sorted(_VALID_AVERAGING_METHODS)}, "
                f"got {self.averaging_method!r}"
            )
        # Both may be set simultaneously, this is valid in the trade JSON file.
        # When compounding_method != "None", it takes precedence and averaging_method
        # is ignored.  A leg cannot compound and average at the same time, so the
        # averaging method is not read when a compounding method is active.


# Backwards-compatible alias
SwapLeg = CashflowLeg
