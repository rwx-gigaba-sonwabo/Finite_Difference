"""Definition of one commodity price leg: fixed or floating, its quantity and its price curve."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Callable

from utils.interpolation import forward_price_interpolator, linear_interpolator


class CommodityLegType(Enum):
    FIXED = "fixed"
    FLOATING = "floating"


class PriceConstruction(Enum):
    """How a FLOATING leg's reference forward price is constructed.

    CURVE : read (with linear interpolation) from a market-observed
        commodity forward price curve, e.g. a listed futures curve.
    CARRY : synthesised from a spot price rolled forward at the cost of
        financing the position (spot / carry-curve discount factor),
        replicating a cash-and-carry forward.  As for a
        commodity forward, spot is read live, at every valuation
        step, off the front of the same forward price curve (not a
        separate risk factor), and grown to settlement by a genuinely
        separate carry-rate curve.
    """
    CURVE = "curve"
    CARRY = "carry"


@dataclass
class CommodityPriceLeg:
    """Definition of a single leg of a :class:`CommodityPriceSwap`.

    Each period's cashflow is ``price_i * quantity * D_discount(t, T_i)``.
    It is a *price* referenced against a quantity, not a rate accrued over a
    notional.  This follows the Commodity Price Swap / Emission Credit
    Price Swap model theory: float-for-float, fixed-for-float, and
    zero-coupon (single bullet period) structures all fall out of the
    same per-period formula.

    Parameters
    ----------
    leg_type : CommodityLegType
        FIXED (a constant reference price, e.g. the swap strike) or
        FLOATING (a stochastic reference price built from market data).
    frequency : int
        Payment frequency in months (e.g. 3 = quarterly, 12 = annual).
        Use ``0`` for a zero-coupon leg: a single period spanning
        effective_date to maturity_date with one bullet cashflow at
        maturity, the Emission Credit Price Swap convention, used when
        the underlying is only listed with a handful of maturities.
    quantity : float
        Quantity of the underlying per period (e.g. tonnes of CO2,
        barrels).  Applied uniformly to every period.
    fixed_price : float or None
        Reference price for a FIXED leg (e.g. the swap strike).
        Required when ``leg_type`` is FIXED.
    construction : PriceConstruction or None
        How the reference price is built for a FLOATING leg.
        Required when ``leg_type`` is FLOATING.
    forward_curve_name : str or None
        Risk-factor name for the commodity forward price CurveSlice.
        Tenors are Excel serial dates; values are prices per path, 
        the same convention used by CommodityForward /
        CommodityAverageForward.  Required when ``construction`` is CURVE.
    carry_spot_curve_name : str or None
        Risk-factor name for the commodity forward price CurveSlice the
        CARRY construction reads its spot from, same Excel-serial-date
        convention as ``forward_curve_name``, and typically the *same*
        curve name as the sibling CURVE leg (there is usually only one
        market-observed forward curve for a given underlying).  Spot is
        read live at each valuation date via a query at that date (which
        always precedes the first listed pillar, so it resolves to the
        curve's own flat-left-extrapolated front value).  The value is
        read again on
        every valuation date rather than frozen at inception.
        Required when ``construction`` is CARRY.
    carry_curve_name : str or None
        Risk-factor name for the financing / carry curve CurveSlice
        (e.g. ESTR) used to roll the spot price forward.
        Required when ``construction`` is CARRY.  When
        ``carry_basis_curve_name`` is also set, this is instead the
        *base* curve (e.g. ``"InterestRate.EUR-ESTR"``) that the basis
        spread is layered on top of, rather than the outright carry
        rate curve itself.
    carry_basis_curve_name : str or None
        Risk-factor name for an additive zero-rate basis-spread
        CurveSlice quoted on top of ``carry_curve_name`` (e.g.
        ``"InterestRate.EUR-ESTR.EUR-ESTR+65BP"`` for a carry rate of
        EUR-ESTR + 65bp), the same "basis spreads layered on a base
        curve" convention used by CommodityForward /
        CommodityAverageForward for their ZAR-USD-BASIS domestic curve:

            r_carry(T) = r_base(T) + basis_spread(T)

        The base curve is sampled (via ``carry_interpolator``) at the
        basis curve's own tenor pillars, the two are added, and the
        result is interpolated (via ``carry_basis_interpolator``) as
        the effective carry curve.  Leave unset (default) to use
        ``carry_curve_name`` directly as the outright carry curve, with
        no basis stacking.
    carry_spread : float
        Additive spread applied to the carry forward price, reflecting
        the incremental financing cost of holding the commodity as
        collateral over the base risk-free rate.  Has no effect on the
        CURVE construction.  Default 0.0.
    spot_lag : int
        Business days from the valuation date to the spot date t_spot
        used to roll the spot price forward under the CARRY
        construction.  Has no effect on the CURVE construction.
        Default 0, which gives the plain commodity forward
        formula exactly (growth measured directly over [val_date,
        T_settle] with no lag).  A value above zero is
        an optional generalisation for underlyings
        with a genuine spot-settlement lag (e.g. T+2 registry
        transfer).
    settlement_lag : int
        Business days from each period's accrual-end date to the
        settlement date T_settle at which the forward price (CURVE or
        CARRY) is evaluated.  Default 0 (T_settle == accrual end),
        matching the Emission Credit Price Swap convention where the
        listed futures settlement date coincides with the period
        maturity.
    lag_calendar : str
        Calendar (key in utils.ql_helpers.CALENDARS) used to advance
        dates by spot_lag / settlement_lag business days.
    forward_interpolator : callable
        Interpolator factory for the CURVE forward price curve.
        Defaults to forward_price_interpolator (linear with linear
        right-extrapolation), matching the other commodity instruments.
    carry_interpolator : callable
        Interpolator factory for the CARRY financing curve.  When
        ``carry_basis_curve_name`` is set, this is the interpolator
        used to sample the *base* curve rather than the outright carry
        curve (mirrors ``money_market_interpolator`` /
        ``foreign_interpolator`` on CommodityForward).
        Defaults to linear_interpolator.
    carry_basis_interpolator : callable
        Interpolator factory for the combined (base + basis) carry
        curve, used only when ``carry_basis_curve_name`` is set
        (mirrors ``domestic_interpolator`` on CommodityForward).
        Defaults to linear_interpolator.
    carry_spot_interpolator : callable
        Interpolator factory for the CARRY leg's spot-source forward
        curve (``carry_spot_curve_name``).  Defaults to
        forward_price_interpolator, matching ``forward_interpolator``'s
        default.
    """

    leg_type: CommodityLegType
    frequency: int
    quantity: float
    fixed_price: float | None = None
    construction: PriceConstruction | None = None
    forward_curve_name: str | None = None
    carry_spot_curve_name: str | None = None
    carry_curve_name: str | None = None
    carry_basis_curve_name: str | None = None
    carry_spread: float = 0.0
    spot_lag: int = 0
    settlement_lag: int = 0
    lag_calendar: str = "TARGET"
    forward_interpolator: Callable = forward_price_interpolator
    carry_interpolator: Callable = linear_interpolator
    carry_basis_interpolator: Callable = linear_interpolator
    carry_spot_interpolator: Callable = forward_price_interpolator

    def __post_init__(self):
        if self.leg_type == CommodityLegType.FIXED and self.fixed_price is None:
            raise ValueError("fixed_price is required for a FIXED leg")
        if self.leg_type == CommodityLegType.FLOATING:
            if self.construction is None:
                raise ValueError("construction is required for a FLOATING leg")
            if self.construction == PriceConstruction.CURVE and not self.forward_curve_name:
                raise ValueError(
                    "forward_curve_name is required when construction=CURVE"
                )
            if self.construction == PriceConstruction.CARRY and (
                not self.carry_spot_curve_name or not self.carry_curve_name
            ):
                raise ValueError(
                    "carry_spot_curve_name and carry_curve_name are required "
                    "when construction=CARRY"
                )
        if self.spot_lag < 0 or self.settlement_lag < 0:
            raise ValueError("spot_lag and settlement_lag must be non-negative")

    @property
    def fixing_key_name(self) -> str:
        """Stable identifier for this leg's fixings, used as the first
        element of the ``(key_name, period_end_date)`` fixings-dict key.

        Empty string for a FIXED leg (no fixing is ever required).
        """
        if self.leg_type == CommodityLegType.FIXED:
            return ""
        if self.construction == PriceConstruction.CURVE:
            return self.forward_curve_name
        return self.carry_curve_name
