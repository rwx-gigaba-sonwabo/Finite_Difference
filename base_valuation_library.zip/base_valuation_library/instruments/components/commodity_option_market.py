"""Market inputs shared by the commodity digital option and the commodity barrier option.

Both options need the same things from the market on the valuation date:

* a forward price read off a commodity forward price curve for a delivery date,
* a zero rate read off a discount curve that may carry spread layers,
* for a payout in another currency, the FX forward, the FX volatility and a correlation.

The helpers here read those inputs out of a ``market_state`` dictionary. They hold no
pricing formulas.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence

import numpy as np

from market_data.risk_factor import CurveSlice, RiskFactorSlice, ScalarSlice
from market_data.yield_curve import YieldCurve
from utils.interpolation import linear_interpolator

PAYOFF_TYPES = ("standard", "quanto", "composite")
FORWARD_EXTRAPOLATIONS = ("flat", "linear")


def forward_price_for_delivery(
    forward_curve: CurveSlice, delivery_serial: float, extrapolation: str = "flat",
) -> np.ndarray:
    """Read the forward price for one delivery date off a forward price curve.

    Prices are linear between the curve's pillars. Pillars are Excel serial dates, so the
    interpolation is linear in calendar days.

    Parameters
    ----------
    forward_curve : CurveSlice
        ``tenors`` are the delivery dates of the pillars as Excel serials. ``values`` has
        shape ``(n_paths, n_pillars)``.
    delivery_serial : float
        Excel serial of the delivery date to read.
    extrapolation : {"flat", "linear"}
        What to do outside the pillar range. ``"flat"`` holds the first or last price.
        ``"linear"`` holds the first price before the curve and extends the last segment
        after it.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    if extrapolation not in FORWARD_EXTRAPOLATIONS:
        raise ValueError(f"extrapolation must be one of {FORWARD_EXTRAPOLATIONS}")
    pillars = np.asarray(forward_curve.tenors, dtype=float)
    prices = np.atleast_2d(forward_curve.values)
    if pillars.size == 1:
        return prices[:, 0].copy()

    upper = int(np.clip(np.searchsorted(pillars, delivery_serial, side="right"), 1, pillars.size - 1))
    lower = upper - 1
    weight = (delivery_serial - pillars[lower]) / (pillars[upper] - pillars[lower])
    if delivery_serial <= pillars[0]:
        weight = 0.0
    elif delivery_serial >= pillars[-1] and extrapolation == "flat":
        weight = 1.0
    return prices[:, lower] + weight * (prices[:, upper] - prices[:, lower])


def summed_zero_rate(
    market_state: dict[str, RiskFactorSlice], curve_names: Sequence[str],
    interpolators: dict[str, Callable], t: float,
) -> np.ndarray:
    """Zero rate for a time ``t`` in years, as the sum of a base curve and its spread layers.

    Parameters
    ----------
    market_state : dict
        Must hold a ``CurveSlice`` for every name in ``curve_names``. Tenors are in years.
    curve_names : sequence of str
        The base curve first, then any spread curves to add on top.
    interpolators : dict
        ``{curve name: interpolator factory}``. Curves not listed are read linearly.
    t : float
        Time in years.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    total = 0.0
    for name in curve_names:
        curve_slice = market_state[name]
        curve = YieldCurve(curve_slice.tenors, curve_slice.values,
                           interpolators.get(name, linear_interpolator))
        total = total + curve.get_rate(float(t))
    return np.asarray(total, dtype=float)


def scalar_value(market_state: dict[str, RiskFactorSlice], name: str | None) -> np.ndarray | float:
    """Value of a single number factor such as an FX spot. ``None`` gives 1."""
    if name is None:
        return 1.0
    factor = market_state[name]
    if not isinstance(factor, ScalarSlice):
        raise TypeError(f"{name} must be a ScalarSlice")
    return factor.values


def at_the_money_moneyness(vol_surface) -> float:
    """Moneyness coordinate of an at the money option on a volatility surface.

    It is 1 on a surface quoted in underlying over strike and 0 on a surface quoted in
    log moneyness or in distance from the forward.
    """
    stated = getattr(vol_surface, "at_the_money_moneyness", None)
    if stated is not None:
        return float(stated)
    return 0.0 if getattr(vol_surface, "log_moneyness", False) else 1.0


@dataclass(frozen=True)
class CrossCurrencyPayoff:
    """Inputs for an option that pays in a different currency from its underlying.

    The underlying commodity is quoted in the *local* currency. The option pays in the
    *payoff* currency. ``X`` below is the FX rate in payoff currency per one unit of local
    currency.

    Attributes
    ----------
    local_fx_name, payoff_fx_name : str
        Names of the two FX spot factors in ``market_state``. Each is the value of one
        unit of that currency in the base currency of the market data.
    local_rate_curve_names, payoff_rate_curve_names : tuple of str
        Zero rate curves that carry each currency forward. Base curve first, spreads after.
    fx_vol_surface : object
        Volatility surface of ``X`` with ``get_vol(moneyness, expiry)``. Read at the money.
    correlation : float
        Correlation between the returns of the commodity price and the returns of ``X``.
    """

    local_fx_name: str
    payoff_fx_name: str
    local_rate_curve_names: tuple
    payoff_rate_curve_names: tuple
    fx_vol_surface: object
    correlation: float

    def fx_spot(self, market_state: dict[str, RiskFactorSlice]) -> np.ndarray:
        """Spot ``X``: payoff currency per one unit of local currency."""
        return np.asarray(scalar_value(market_state, self.local_fx_name), dtype=float) / np.asarray(
            scalar_value(market_state, self.payoff_fx_name), dtype=float)

    def fx_carry_rate(self, market_state: dict[str, RiskFactorSlice],
                      interpolators: dict[str, Callable], t: float) -> np.ndarray:
        """Carry rate of ``X`` to time ``t``: payoff currency rate minus local currency rate."""
        if t <= 0.0:
            return np.zeros_like(self.fx_spot(market_state))
        return (summed_zero_rate(market_state, self.payoff_rate_curve_names, interpolators, t)
                - summed_zero_rate(market_state, self.local_rate_curve_names, interpolators, t))

    def fx_forward(self, market_state: dict[str, RiskFactorSlice],
                   interpolators: dict[str, Callable], t: float) -> np.ndarray:
        """Forward ``X`` for time ``t`` in years, by covered interest parity."""
        return self.fx_spot(market_state) * np.exp(
            self.fx_carry_rate(market_state, interpolators, t) * t)

    def fx_at_the_money_vol(self, t: float) -> float:
        """At the money volatility of ``X`` for a time to expiry ``t`` in years."""
        return float(self.fx_vol_surface.get_vol(at_the_money_moneyness(self.fx_vol_surface), t))
