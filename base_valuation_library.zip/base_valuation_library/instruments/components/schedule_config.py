"""Settings for building a payment schedule: calendar, business day rules and day counts."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

import QuantLib as ql

from utils.ql_helpers import (
    build_bond_schedule,
    build_schedule,
    CALENDARS, BUSINESS_CONVENTIONS, DAY_COUNTERS, DATE_GENERATION,
)


@dataclass
class ScheduleConfig:
    """Reusable cashflow schedule configuration.

    Resolves QuantLib objects once at construction and exposes a
    :meth:`build` method that generates accrual schedules for any
    effective / maturity / frequency combination.

    Parameters
    ----------
    calendar : str
        Calendar name (e.g. "ZAR", "USD", "TARGET").
    business_convention : str
        Business day convention (e.g. "ModifiedFollowing").
    termination_business_convention : str
        Termination date convention.
    date_generation : str
        Date generation rule (e.g. "Backward", "Forward").
    day_count : str
        Accrual day count convention (e.g. "ACT/365", "ACT/360").
    curve_day_count : str
        Day count for curve year-fraction computations.
    end_of_month : bool
        End-of-month adjustment rule.
    """

    calendar: str = "ZAR"
    business_convention: str = "ModifiedFollowing"
    termination_business_convention: str = "ModifiedFollowing"
    date_generation: str = "Backward"
    day_count: str = "ACT/365"
    curve_day_count: str = "ACT/365"
    end_of_month: bool = False
    pay_date_convention: str = "Following"
    payment_offset_days: int = 0

    # resolved QuantLib objects (set in __post_init__)
    ql_calendar: ql.Calendar = field(init=False, repr=False)
    ql_convention: int = field(init=False, repr=False)
    ql_term_convention: int = field(init=False, repr=False)
    ql_date_generation: int = field(init=False, repr=False)
    ql_pay_convention: int = field(init=False, repr=False)
    day_counter: ql.DayCounter = field(init=False, repr=False)
    curve_day_counter: ql.DayCounter = field(init=False, repr=False)

    def __post_init__(self):
        self.ql_calendar = CALENDARS[self.calendar]
        self.ql_convention = BUSINESS_CONVENTIONS[self.business_convention]
        self.ql_term_convention = BUSINESS_CONVENTIONS[self.termination_business_convention]
        self.ql_date_generation = DATE_GENERATION[self.date_generation]
        self.ql_pay_convention = BUSINESS_CONVENTIONS[self.pay_date_convention]
        self.day_counter = DAY_COUNTERS[self.day_count]
        self.curve_day_counter = DAY_COUNTERS[self.curve_day_count]

    def build_bond_schedule(
        self,
        effective_date: date,
        maturity_date: date,
        freq_months: int,
        first_date: date | None = None,
        next_to_last_date: date | None = None,
    ) -> list[tuple[date, date, date, float]]:
        """Bond coupon schedule: Unadjusted accrual dates, Following payment dates.

        Accrual fractions are computed per-period via ``day_counter.yearFraction``
        so stub periods (short or long, front or back) carry the correct fraction.

        Parameters
        ----------
        first_date : date or None
            Front-stub anchor.  Pass the second regular coupon date for a long
            front stub; leave None for an automatic short front stub when
            *effective_date* does not align with the backward-generated dates.
        next_to_last_date : date or None
            Back-stub anchor producing a short or long final stub period.

        Returns
        -------
        list of (accrual_start, accrual_end, payment_date, accrual_fraction)
        """
        return build_bond_schedule(
            effective_date, maturity_date, freq_months,
            self.ql_calendar, self.ql_pay_convention,
            day_counter=self.day_counter,
            first_date=first_date,
            next_to_last_date=next_to_last_date,
            date_generation=self.ql_date_generation,
        )

    def build(
        self,
        effective_date: date,
        maturity_date: date,
        freq_months: int,
        first_date: date | None = None,
        next_to_last_date: date | None = None,
    ) -> list[tuple[date, date, date, float]]:
        """Generate a schedule as (start, accrual_end, payment_date, accrual_fraction).

        Parameters
        ----------
        first_date : date or None
            Front-stub anchor date (fixes the first coupon date).
        next_to_last_date : date or None
            Back-stub anchor date.  Backwards generation anchors from here,
            producing a short final period [next_to_last_date, maturity_date].
        """
        return build_schedule(
            effective_date, maturity_date, freq_months,
            self.ql_calendar, self.ql_convention, self.ql_term_convention,
            self.ql_date_generation, self.day_counter, self.end_of_month,
            first_date=first_date,
            next_to_last_date=next_to_last_date,
            payment_offset_days=self.payment_offset_days,
            payment_offset_convention=self.ql_pay_convention,
        )
