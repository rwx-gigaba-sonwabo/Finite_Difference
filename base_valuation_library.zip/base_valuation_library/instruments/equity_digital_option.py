"""European digital option on an equity price.

What the trade is
-----------------
On the expiry date the option looks at the closing price of a share or an index, the fixing.
A call is in the money when the fixing is above the strike. A put is in the money when the
fixing is below the strike. When in the money the option pays on the settlement date:

``cash`` payout style
    a fixed amount of currency, ``payoff_amount``.
``asset`` payout style
    ``payoff_amount`` units of the equity, worth ``payoff_amount * fixing``.

Out of the money it pays nothing.

How it is valued
----------------
1. **Forward price.** ``F = S * DF_div(T_F) / DF_carry(T_F)`` where ``S`` is the spot
   price, ``DF_div`` the discount factor of the continuous dividend yield curve and
   ``DF_carry`` the discount factor of the carry (funding) curve. ``T_F`` is the time to the
   forward date. By default that is the expiry date. It can be set later, for example two
   business days after expiry, the date the equity would settle.
2. **Volatility.** ``sigma`` is read off the equity volatility surface at the strike and the
   time to expiry ``T``. Two kinds of surface are accepted:

   * a parametric skew (:class:`market_data.vol_surface.BenchmarkVolSkew`), read by strike;
   * a moneyness grid (:class:`market_data.moneyness_vol_surface.MoneynessVolSurface`),
     read at ``underlying / strike`` where the underlying is the spot price (default) or
     the forward price.

3. **Digital value before discounting**, per unit of payout, with ``w = +1`` for a call
   and ``-1`` for a put:

   * closed form, used when ``relative_digital_spread`` is zero:
     cash ``N(w * d2)`` and asset ``F * N(w * d1)``;
   * strike spread, used when ``relative_digital_spread`` is ``eps > 0``:
     cash ``w * (V(K * (1 - eps)) - V(K * (1 + eps))) / (2 * eps * K)`` where ``V`` is the
     Black value of a vanilla option and each strike uses its own volatility,
     and asset ``w * V(K) + K * cash``.

   The formulas are the ones in :mod:`models.digital_option_pv`, shared with the commodity
   digital option.

4. **Present value.** ``sign * payoff_amount * digital * DF(settlement)`` where ``sign`` is
   +1 for a bought option and -1 for a sold option, and ``DF`` is the discount factor of
   the discount curve to the settlement date.

Quanto payout
-------------
When the payout is in another currency at a fixed FX rate of one, give
``quanto_fx_volatility`` and ``quanto_correlation``. The forward price is then multiplied by
``exp(-rho * sigma_S * sigma_X * T_F)`` where ``sigma_S`` is the equity volatility read with
the strike at the spot price and ``sigma_X`` the FX volatility. The volatility used in the
formula is not changed.

After expiry
------------
Between expiry and settlement the fixing is known. Pass it as ``expiry_fixing``. The value
is then the known payout, discounted to the settlement date. After settlement it is zero.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, RiskFactorSlice, ScalarSlice
from market_data.yield_curve import YieldCurve
from models.digital_option_pv import (
    asset_digital_by_strike_spread_undiscounted,
    black_asset_digital_undiscounted,
    black_cash_digital_undiscounted,
    cash_digital_by_strike_spread_undiscounted,
    strike_spread_strikes,
)
from models.equity_pv import equity_forward_price

PAYOFF_STYLES = ("cash", "asset")
MONEYNESS_BASES = ("spot", "forward")


class EquityDigitalOption(Instrument):
    """European cash or asset digital option on an equity price.

    Parameters
    ----------
    name : str
        Trade identifier, used in reports.
    expiry_date : date
        Date the equity price is observed and the option is decided.
    strike : float
        Strike price.
    payoff_amount : float
        Cash amount paid (``cash`` style) or number of shares paid (``asset`` style) when
        the option expires in the money. Must not be zero.
    is_call : bool
        ``True`` pays when the fixing is above the strike. ``False`` pays when below.
    spot_name : str
        Key of the equity spot price in ``market_state``.
    carry_curve_name : str
        Key of the carry (funding) zero rate curve the forward price grows on.
    dividend_curve_name : str
        Key of the continuous dividend yield curve.
    discount_curve_name : str
        Key of the zero rate curve used to discount the payout.
    vol_surface : object
        A :class:`BenchmarkVolSkew` (read by strike) or a surface with
        ``moneyness_of(underlying, strike)`` and ``get_vol(moneyness, expiry)``.
    carry_interpolator, dividend_interpolator, discount_interpolator : callable
        Interpolator factories of the three curves.
    is_buy : bool
        ``True`` when the option was bought, ``False`` when it was sold.
    payoff_style : {"cash", "asset"}
        What is paid when in the money.
    settlement_date : date, optional
        Date the payout is paid. The expiry date when not given.
    forward_date : date, optional
        Date the forward price is carried to. The expiry date when not given.
    relative_digital_spread : float
        Half width of the replicating strike spread, as a fraction of the strike. Zero
        selects the closed form.
    skew_stickiness : {"strike", "delta"}
        How a parametric skew is read. Ignored for a moneyness grid.
    moneyness_basis : {"spot", "forward"}
        Underlying level a moneyness grid is read with. Ignored for a parametric skew.
    quanto_fx_volatility, quanto_correlation : float, optional
        Give both for a quanto payout. See the module notes.
    days_in_year : float
        Divisor that turns calendar days into years.
    expiry_fixing : float, optional
        The observed fixing, for a valuation date after the expiry date.
    """

    def __init__(
        self,
        name: str,
        expiry_date: date,
        strike: float,
        payoff_amount: float,
        is_call: bool,
        spot_name: str,
        carry_curve_name: str,
        dividend_curve_name: str,
        discount_curve_name: str,
        vol_surface,
        carry_interpolator: Callable,
        dividend_interpolator: Callable,
        discount_interpolator: Callable,
        is_buy: bool = True,
        payoff_style: str = "cash",
        settlement_date: date | None = None,
        forward_date: date | None = None,
        relative_digital_spread: float = 0.0,
        skew_stickiness: str = "strike",
        moneyness_basis: str = "spot",
        quanto_fx_volatility: float | None = None,
        quanto_correlation: float | None = None,
        days_in_year: float = 365.0,
        expiry_fixing: float | None = None,
    ) -> None:
        super().__init__(name)
        if payoff_style not in PAYOFF_STYLES:
            raise ValueError(f"payoff_style must be one of {PAYOFF_STYLES}, got {payoff_style!r}")
        if moneyness_basis not in MONEYNESS_BASES:
            raise ValueError(
                f"moneyness_basis must be one of {MONEYNESS_BASES}, got {moneyness_basis!r}")
        if skew_stickiness not in ("strike", "delta"):
            raise ValueError(f"skew_stickiness must be 'strike' or 'delta', got {skew_stickiness!r}")
        if payoff_amount == 0.0:
            raise ValueError("payoff_amount must not be zero")
        if strike <= 0.0:
            raise ValueError("strike must be positive")
        if relative_digital_spread < 0.0 or relative_digital_spread >= 1.0:
            raise ValueError("relative_digital_spread must be at least 0 and below 1")
        if (quanto_fx_volatility is None) != (quanto_correlation is None):
            raise ValueError("a quanto payout needs both quanto_fx_volatility and quanto_correlation")

        self.expiry_date = expiry_date
        self.settlement_date = settlement_date or expiry_date
        if self.settlement_date < expiry_date:
            raise ValueError("settlement_date cannot be before expiry_date")
        self.forward_date = forward_date or expiry_date
        if self.forward_date < expiry_date:
            raise ValueError("forward_date cannot be before expiry_date")
        self.strike = float(strike)
        self.payoff_amount = float(payoff_amount)
        self.is_call = bool(is_call)
        self.is_buy = bool(is_buy)
        self.payoff_style = payoff_style
        self.spot_name = spot_name
        self.carry_curve_name = carry_curve_name
        self.dividend_curve_name = dividend_curve_name
        self.discount_curve_name = discount_curve_name
        self.vol_surface = vol_surface
        self.carry_interpolator = carry_interpolator
        self.dividend_interpolator = dividend_interpolator
        self.discount_interpolator = discount_interpolator
        self.relative_digital_spread = float(relative_digital_spread)
        self.skew_stickiness = skew_stickiness
        self.moneyness_basis = moneyness_basis
        self.quanto_fx_volatility = quanto_fx_volatility
        self.quanto_correlation = quanto_correlation
        self.days_in_year = float(days_in_year)
        self.expiry_fixing = expiry_fixing

    @property
    def is_quanto(self) -> bool:
        return self.quanto_fx_volatility is not None

    # --------------------------------------------------------------- helpers
    def _curve(self, market_state, name: str, interpolator: Callable) -> YieldCurve:
        curve_slice: CurveSlice = market_state[name]
        return YieldCurve(curve_slice.tenors, curve_slice.values, interpolator)

    def _volatility(self, strike, expiry: float, spot, forward) -> np.ndarray:
        """Volatility at one strike, from whichever kind of surface the option holds."""
        surface = self.vol_surface
        if hasattr(surface, "moneyness_of"):
            underlying = spot if self.moneyness_basis == "spot" else forward
            moneyness = surface.moneyness_of(underlying, strike)
            return np.asarray(surface.get_vol(moneyness, expiry), dtype=float)
        by_delta = self.skew_stickiness == "delta"
        return np.asarray(surface.get_vol(
            strike=strike, tenor=expiry,
            forward_skew=forward if by_delta else None,
            forward_expiry=forward if by_delta else None,
            sticky=self.skew_stickiness), dtype=float)

    # ------------------------------------------------------------- valuation
    def valuation_details(
        self, val_date: date, market_state: dict[str, RiskFactorSlice],
    ) -> dict[str, np.ndarray | float | str]:
        """Value the option and return every intermediate number.

        Each array has one entry per market scenario in ``market_state``. The entry
        ``"present_value"`` is what :meth:`scenario_npvs` returns.
        """
        expiry = (self.expiry_date - val_date).days / self.days_in_year
        settlement = (self.settlement_date - val_date).days / self.days_in_year
        forward_time = (self.forward_date - val_date).days / self.days_in_year
        sign = 1.0 if self.is_buy else -1.0

        spot_slice: ScalarSlice = market_state[self.spot_name]
        spot = np.asarray(spot_slice.values, dtype=float)
        details: dict[str, np.ndarray | float | str] = {
            "time_to_expiry": expiry, "time_to_forward_date": forward_time,
            "time_to_settlement": settlement, "spot_price": spot,
        }

        if settlement < 0.0:
            details.update(method="settled", present_value=0.0 * spot)
            return details

        if expiry < 0.0:
            # Decided but not yet paid. The payout is known from the observed fixing.
            if self.expiry_fixing is None:
                raise ValueError(
                    f"{self.name}: the valuation date is after the expiry date "
                    f"{self.expiry_date}. Give the observed fixing as expiry_fixing.")
            forward = np.full_like(spot, float(self.expiry_fixing))
            volatility = np.zeros_like(spot)
            expiry_used = 0.0
        else:
            carry = self._curve(market_state, self.carry_curve_name, self.carry_interpolator)
            dividends = self._curve(market_state, self.dividend_curve_name, self.dividend_interpolator)
            forward, _, _ = equity_forward_price(spot, carry, dividends, max(forward_time, 0.0))
            details["forward_price_before_adjustment"] = forward
            expiry_used = expiry
            volatility = None

        if expiry_used > 0.0 and self.is_quanto:
            atm_vol = self._volatility(spot, expiry_used, spot, forward)
            quanto_drift = -float(self.quanto_correlation) * atm_vol * float(self.quanto_fx_volatility)
            forward = forward * np.exp(quanto_drift * forward_time)
            details.update(equity_at_the_money_volatility=atm_vol, quanto_drift=quanto_drift)

        strike = self.strike
        if volatility is None:
            volatility = self._volatility(strike, expiry_used, spot, forward)

        eps = self.relative_digital_spread
        if eps > 0.0 and expiry_used > 0.0:
            strike_low, strike_high = strike_spread_strikes(strike, eps)
            vol_low = self._volatility(strike_low, expiry_used, spot, forward)
            vol_high = self._volatility(strike_high, expiry_used, spot, forward)
            if self.payoff_style == "cash":
                digital = cash_digital_by_strike_spread_undiscounted(
                    forward, strike, vol_low, vol_high, expiry_used, self.is_call, eps)
            else:
                digital = asset_digital_by_strike_spread_undiscounted(
                    forward, strike, volatility, vol_low, vol_high, expiry_used, self.is_call, eps)
            details.update(method="strike spread", lower_strike=strike_low, upper_strike=strike_high,
                           lower_strike_volatility=vol_low, upper_strike_volatility=vol_high)
        else:
            pricer = (black_cash_digital_undiscounted if self.payoff_style == "cash"
                      else black_asset_digital_undiscounted)
            digital = pricer(forward, strike, volatility, expiry_used, self.is_call)
            details["method"] = "closed form" if expiry_used > 0.0 else "payoff at expiry"

        if settlement > 0.0:
            discount = self._curve(market_state, self.discount_curve_name, self.discount_interpolator)
            discount_factor = np.asarray(discount.discount_factor(settlement), dtype=float).reshape(-1)
        else:
            discount_factor = np.ones_like(spot)
        present_value = sign * self.payoff_amount * digital * discount_factor

        details.update(
            forward_price=forward, strike=strike, volatility=volatility,
            undiscounted_digital_per_unit=digital, discount_factor=discount_factor,
            present_value=present_value)
        return details

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Present value in the payout currency, one entry per market scenario."""
        value = self.valuation_details(val_date, market_state)["present_value"]
        return np.atleast_1d(np.asarray(value, dtype=float))
