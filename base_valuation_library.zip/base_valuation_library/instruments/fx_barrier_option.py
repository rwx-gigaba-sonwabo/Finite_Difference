"""Single barrier option on an FX rate.

A European call or put that is knocked in or knocked out when the FX rate touches a barrier,
valued with the closed form for a barrier that is watched all the time.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from instruments.instrument import Instrument
from instruments.single_barrier_pricer import single_barrier_price
from market_data.risk_factor import CurveSlice, RiskFactorSlice, ScalarSlice
from market_data.vol_surface import FXVolSurface
from market_data.yield_curve import YieldCurve
from utils.ql_helpers import DAY_COUNTERS, to_ql_date

# Broadie-Glasserman-Kou discrete monitoring constant: -zeta(1/2) / sqrt(2*pi)
BGK_BETA = 0.5826
# Days in a year used for the bridge interval variance
DAYS_IN_YEAR = 365.25


class FXBarrierOption(Instrument):
    """Single barrier FX option with the barrier watched all the time.

    The option is on 1 unit of the underlying (foreign) currency, struck in the
    domestic currency; NPV is returned in domestic currency (times nominal).

    Spot
    ----
    Built from the two FX factors in the market data.
    With ``fx_quote='base_per_unit'``:

        spot = FX[underlying] / FX[currency]          (domestic per foreign)

    A factor name of ``None`` means that currency is the base currency (FX = 1).
    With ``fx_quote='unit_per_base'`` (e.g. Fx.ZAR ~ 17.9 ZAR per USD) each
    factor is inverted first.

    Volatility
    ----------
    Read per path and grid date from a static :class:`FXVolSurface` at
    moneyness F/K (log(F/K) for Malz; inverted when ``invert_moneyness``) and
    the remaining tenor, floored at ``min_vol``, .

    Path dependency
    ---------------
    From
    ``effective_date`` a per-path touch PROBABILITY is carried forward. A spot
    beyond the (BGK-shifted) barrier on a grid date is a certain touch; between
    grid dates the Brownian-bridge crossing probability exp(-2 d0 d1 / var) is
    added, with var = ``bridge_variance_rate`` * elapsed days / 365.25. Values
    are weighted by the probability rather than switched. The state resets when
    ``scenario_npvs`` is called with a date not after the previous one (a new run).

    Parameters
    ----------
    name : str
    effective_date : date
        Start of barrier monitoring.
    maturity_date : date
        Option expiry.
    strike, barrier : float
        Domestic per foreign.
    is_call, is_up, is_knock_in : bool
    nominal : float
        Underlying (foreign) amount.
    currency_fx_name : str or None
        Cube factor for the domestic (strike) currency, e.g. "Fx.ZAR".
    underlying_fx_name : str or None
        Cube factor for the underlying currency; None if it is the base currency.
    domestic_curve_name, foreign_curve_name : str
        Repo curves of the two currencies; b = r_dom(tau) - r_for(tau).
    vol_surface : FXVolSurface
    invert_moneyness : bool
        True when the vol surface is quoted <Currency>.<Underlying>.
    buy : bool
    domestic_basis_name, foreign_basis_name : str or None
        Optional basis spread curves added to the respective repo curve rates.
    discount_curve_name : str or None
        Discount curve. Defaults to the domestic repo curve (incl. basis).
    discount_basis_name : str or None
    cash_rebate : float
        Rebate amount (domestic, total, not per unit).
    rebate_at_hit : bool
        Knock-out rebate paid at hit (True) or at expiry (False).
    monitoring_days : int
        Barrier monitoring frequency in days (0 = continuous, no BGK shift).
    barrier_crossed : bool
        Barrier already crossed before the valuation date.
    report_fx_name : str or None
        Cube factor for the reporting currency. NPV is converted with
        FX[currency] / FX[report] (base_per_unit convention).
    fx_quote : {'base_per_unit', 'unit_per_base'}
    min_vol : float
        Vol floor. Barrier values are very sensitive to low volatility, so it is floored at 5%.
    bridge_variance_rate : float or None
        Annualised log-variance of the spot between two valuation dates
        for the barrier underlying.
        Drives the Brownian-bridge touch probability between grid dates;
        None observes grid-date endpoints only.
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        strike: float,
        barrier: float,
        is_call: bool,
        is_up: bool,
        is_knock_in: bool,
        nominal: float,
        currency_fx_name: str | None,
        underlying_fx_name: str | None,
        domestic_curve_name: str,
        foreign_curve_name: str,
        vol_surface: FXVolSurface,
        invert_moneyness: bool = False,
        buy: bool = True,
        domestic_interpolator: Callable = None,
        foreign_interpolator: Callable = None,
        domestic_basis_name: str | None = None,
        foreign_basis_name: str | None = None,
        basis_interpolator: Callable = None,
        discount_curve_name: str | None = None,
        discount_interpolator: Callable = None,
        discount_basis_name: str | None = None,
        cash_rebate: float = 0.0,
        rebate_at_hit: bool = True,
        monitoring_days: int = 1,
        barrier_crossed: bool = False,
        report_fx_name: str | None = None,
        fx_quote: str = "base_per_unit",
        min_vol: float = 0.05,
        day_count: str = "ACT/365",
        bridge_variance_rate: float | None = None,
    ):
        super().__init__(name)
        if fx_quote not in ("base_per_unit", "unit_per_base"):
            raise ValueError("fx_quote must be 'base_per_unit' or 'unit_per_base'")
        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.strike = strike
        self.barrier = barrier
        self.is_call = is_call
        self.is_up = is_up
        self.is_knock_in = is_knock_in
        self.nominal = nominal
        self.currency_fx_name = currency_fx_name
        self.underlying_fx_name = underlying_fx_name
        self.domestic_curve_name = domestic_curve_name
        self.foreign_curve_name = foreign_curve_name
        self.vol_surface = vol_surface
        self.invert_moneyness = invert_moneyness
        self.sign = 1.0 if buy else -1.0
        self.domestic_interpolator = domestic_interpolator
        self.foreign_interpolator = foreign_interpolator
        self.domestic_basis_name = domestic_basis_name
        self.foreign_basis_name = foreign_basis_name
        self.basis_interpolator = basis_interpolator
        self.discount_curve_name = discount_curve_name
        self.discount_interpolator = discount_interpolator
        self.discount_basis_name = discount_basis_name
        self.cash_rebate = cash_rebate
        self.rebate_at_hit = rebate_at_hit
        self.monitoring_shift = BGK_BETA * np.sqrt(monitoring_days / 365.0)
        self.barrier_crossed = barrier_crossed
        self.report_fx_name = report_fx_name
        self.fx_quote = fx_quote
        self.min_vol = min_vol
        self._dc = DAY_COUNTERS[day_count]
        self.bridge_variance_rate = bridge_variance_rate

        self._touched: np.ndarray | None = None
        self._prev_spot: np.ndarray | None = None
        self._last_date: date | None = None

    @property
    def effective_maturity(self) -> date:
        return self.maturity_date

    def _fx(self, market_state, factor_name: str | None) -> np.ndarray | float:
        """Value of 1 unit of the factor's currency in base currency."""
        if factor_name is None:
            return 1.0
        s: ScalarSlice = market_state[factor_name]
        return s.values if self.fx_quote == "base_per_unit" else 1.0 / s.values

    def spot(self, market_state: dict[str, RiskFactorSlice]) -> np.ndarray:
        """Spot (domestic per foreign) per path, crossed from the cube's FX factors."""
        fx_und = self._fx(market_state, self.underlying_fx_name)
        return np.atleast_1d(fx_und / self._fx(market_state, self.currency_fx_name))

    def _rate(self, market_state, curve_name, interpolator, basis_name, tau) -> np.ndarray:
        s: CurveSlice = market_state[curve_name]
        r = YieldCurve(s.tenors, s.values, interpolator).get_rate(tau)
        if basis_name is not None:
            b: CurveSlice = market_state[basis_name]
            r = r + YieldCurve(b.tenors, b.values, self.basis_interpolator).get_rate(tau)
        return r

    def _update_touched(self, val_date: date, spot: np.ndarray, barrier_t: np.ndarray) -> tuple:
        """Running probability that the barrier has been touched.

        Returns (touched, prev_touched). The first monitored date (and any date without a
        bridge variance) observes endpoints only; after that a path whose endpoints are both
        inside ``barrier_t`` touches with the Brownian-bridge probability exp(-2 d0 d1 / var).
        """
        if self._last_date is None or val_date <= self._last_date or self._touched is None:
            self._touched = np.full(spot.shape, 1.0 if self.barrier_crossed else 0.0)
            self._prev_spot = None
        prev_touched = self._touched
        elapsed = 0 if self._last_date is None or self._prev_spot is None else (val_date - self._last_date).days
        self._last_date = val_date

        if val_date >= self.effective_date:
            beyond = (spot > barrier_t if self.is_up else spot < barrier_t).astype(float)
            variance = (self.bridge_variance_rate or 0.0) / DAYS_IN_YEAR * elapsed
            if not variance:
                touched = np.minimum(prev_touched + beyond, 1.0)
            else:
                if self.is_up:
                    d0, d1 = np.log(barrier_t / self._prev_spot), np.log(barrier_t / spot)
                else:
                    d0, d1 = np.log(self._prev_spot / barrier_t), np.log(spot / barrier_t)
                crossed = np.where((d0 > 0) & (d1 > 0),
                                   np.exp(np.minimum(-2.0 * d0 * d1 / variance, 0.0)), 1.0)
                touched = prev_touched + (1.0 - prev_touched) * np.maximum(beyond, crossed)
            self._touched = touched
            self._prev_spot = spot
        return self._touched, prev_touched

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        spot = self.spot(market_state)
        n_paths = spot.shape[0]

        if val_date > self.maturity_date:
            return np.zeros(n_paths)

        tau = self._dc.yearFraction(to_ql_date(val_date), to_ql_date(self.maturity_date))
        tau = max(tau, 0.0)
        phi = 1.0 if self.is_call else -1.0

        if tau > 0.0:
            r_dom = self._rate(market_state, self.domestic_curve_name, self.domestic_interpolator,
                               self.domestic_basis_name, tau)
            r_for = self._rate(market_state, self.foreign_curve_name, self.foreign_interpolator,
                               self.foreign_basis_name, tau)
            if self.discount_curve_name is None:
                r_disc = r_dom
            else:
                r_disc = self._rate(market_state, self.discount_curve_name, self.discount_interpolator,
                                    self.discount_basis_name, tau)
        else:
            r_dom = r_for = r_disc = np.zeros(n_paths)
        carry = r_dom - r_for

        # vol at the strike moneyness on the forward, per path (also needed at expiry for the shift)
        forward = spot * np.exp(carry * tau)
        moneyness = self.vol_surface.moneyness_of(forward, self.strike, self.invert_moneyness)
        vol = np.maximum(self.vol_surface.get_vol(moneyness, tau), self.min_vol)

        # discrete monitoring (BGK): shift the barrier away from the live region, by barrier type
        barrier_t = self.barrier * np.exp((1.0 if self.is_up else -1.0) * vol * self.monitoring_shift)

        # touch probability tested against the SAME (shifted) barrier the closed form uses
        touched, prev_touched = self._update_touched(val_date, spot, barrier_t)

        # knock-out rebate paid on the touch increment)
        if self.is_knock_in:
            rebate_part = 0.0
        elif self.rebate_at_hit:
            rebate_part = self.cash_rebate * (touched - prev_touched)
        else:
            rebate_part = self.cash_rebate * touched * np.exp(-r_disc * tau)

        if tau <= 0.0:
            # expiry: intrinsic on the live payoff, rebate otherwise
            intrinsic = self.nominal * np.maximum(phi * (spot - self.strike), 0.0)
            if self.is_knock_in:
                value = touched * intrinsic + (1.0 - touched) * self.cash_rebate
            else:
                value = (1.0 - touched) * intrinsic + rebate_part
        else:
            strike_above = self.strike > self.barrier

            # keep the closed form finite on paths beyond the barrier (their weight is 1 - touched = 0)
            spot_safe = np.minimum(spot, barrier_t) if self.is_up else np.maximum(spot, barrier_t)

            per_unit = single_barrier_price(
                S=spot_safe, carry=carry, r=r_disc, T=tau, X=self.strike, sigma=vol,
                H=barrier_t, is_call=self.is_call, is_up=self.is_up, is_knock_in=self.is_knock_in,
                K=self.cash_rebate / self.nominal, rebate_at_hit=self.rebate_at_hit,
                crossed=False, strike_above=strike_above,
            )
            alive = (1.0 - touched) * self.nominal * per_unit
            if self.is_knock_in:
                vanilla = single_barrier_price(
                    S=spot, carry=carry, r=r_disc, T=tau, X=self.strike, sigma=vol,
                    H=self.barrier, is_call=self.is_call, is_up=self.is_up, is_knock_in=True,
                    crossed=True,
                )
                value = touched * self.nominal * vanilla + alive
            else:
                value = alive + rebate_part

        npv = self.sign * value
        if self.report_fx_name is not None:
            fx_ccy = self._fx(market_state, self.currency_fx_name)
            npv = npv * fx_ccy / self._fx(market_state, self.report_fx_name)
        return npv
