"""Asian option on an FX rate.

A call or put on the average of an FX rate over a set of sampling dates, valued with a
lognormal approximation to the distribution of the average.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, TYPE_CHECKING, cast

import numpy as np

from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, ScalarSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.equity_pv import black76_euro_option
from models.fx_pv import fx_forward_price
from utils.ql_helpers import (
    DAY_COUNTERS,
    generate_business_days,
    to_ql_date,
)

if TYPE_CHECKING:
    from market_data.vol_surface import MalzVol


class FXAsian(Instrument):
    """Arithmetically averaged Asian FX option priced via moment matching.

    Daily fixing dates are generated as business days in [period_start, period_end].
    The risk-neutral FX forward for each averaging date is computed via
    :func:`fx_forward_price` using covered-interest parity.  The arithmetic
    average of future forwards is matched to a log-normal distribution using
    Turnbull-Wakeman moment matching, producing a single adjusted volatility
    for a Black-76 European option.

    When some fixings have already been observed the strike is adjusted to
    account for the realised average so far.

    FX spot resolution
    ------------------
    Either pass ``fx_spot_name`` (a direct CCYPAIR scalar risk factor) or pass
    both ``domestic_fx_name`` and ``foreign_fx_name`` (each a CCY/USD scalar).
    When the latter pair is given, spot is triangulated as:
        spot = domestic_fx / foreign_fx  (e.g. ZAR/USD / EUR/USD = ZAR/EUR)

    Parameters
    ----------
    name : str
        Trade identifier.
    period_start : date
        First date of the averaging window.
    period_end : date
        Last date of the averaging window (option expiry for moment-matching).
    settlement_date : date
        Date on which the settled payoff is paid; used only for discounting.
    strike : float
        Option strike (domestic per 1 foreign).
    notional : float
        Contract notional in foreign currency.
    is_call : bool
        True for a call (right to buy foreign at strike).
    vol_surface : MalzVol
        Malz FX implied-vol surface.
    domestic_basis : str
        Risk factor name for the domestic basis / forecast curve
        (e.g. ``"ZAR-USD-BASIS"``).
    domestic_curve : str
        Risk factor name for the domestic discount curve.
    foreign_curve : str
        Risk factor name for the foreign discount curve.
    discount_curve : str
        Risk factor name for the discount curve used to present-value the
        payoff (typically the domestic discount curve).
    averaging_calendar : str
        Calendar key used to enumerate business days in the averaging window.
    domestic_basis_interpolator : callable
        Interpolator factory for the domestic basis curve.
    domestic_curve_interpolator : callable
        Interpolator factory for the domestic discount curve.
    foreign_curve_interpolator : callable
        Interpolator factory for the foreign discount curve.
    discount_interpolator : callable
        Interpolator factory for the discount curve.
    foreign_basis : str, optional
        Risk factor name for the foreign basis / forecast curve
        (e.g. ``"EUR-USD-BASIS"``).  When omitted its discount factor
        defaults to 1.
    foreign_basis_interpolator : callable, optional
        Interpolator factory for the foreign basis curve.
    fx_spot_name : str, optional
        Risk factor name for the direct FX spot (domestic per 1 foreign).
    domestic_fx_name : str, optional
        Risk factor name for the domestic CCY/USD spot rate (e.g. ``"Fx.ZAR"``).
    foreign_fx_name : str, optional
        Risk factor name for the foreign CCY/USD spot rate (e.g. ``"Fx.EUR"``).
    day_count : str
        Day-count convention key (default ``"ACT/365"``).
    direction : int
        ``+1`` for long, ``-1`` for short.  Default ``+1``.
    """

    def __init__(
        self,
        name: str,
        period_start: date,
        period_end: date,
        settlement_date: date,
        strike: float,
        notional: float,
        is_call: bool,
        vol_surface: MalzVol,
        domestic_basis: str,
        domestic_curve: str,
        foreign_curve: str,
        discount_curve: str,
        averaging_calendar: str,
        domestic_basis_interpolator: Callable,
        domestic_curve_interpolator: Callable,
        foreign_curve_interpolator: Callable,
        discount_interpolator: Callable,
        foreign_basis: str | None = None,
        foreign_basis_interpolator: Callable | None = None,
        fx_spot_name: str | None = None,
        domestic_fx_name: str | None = None,
        foreign_fx_name: str | None = None,
        day_count: str = "ACT/365",
        direction: int = 1,
    ) -> None:
        super().__init__(name)
        self.period_start = period_start
        self.period_end = period_end
        self.settlement_date = settlement_date
        self.strike = strike
        self.notional = notional
        self.is_call = is_call
        self.vol_surface = vol_surface
        self.domestic_basis = domestic_basis
        self.domestic_curve = domestic_curve
        self.foreign_curve = foreign_curve
        self.discount_curve = discount_curve
        self.domestic_basis_interpolator = domestic_basis_interpolator
        self.domestic_curve_interpolator = domestic_curve_interpolator
        self.foreign_curve_interpolator = foreign_curve_interpolator
        self.discount_interpolator = discount_interpolator
        self.foreign_basis = foreign_basis
        self.foreign_basis_interpolator = foreign_basis_interpolator
        self.fx_spot_name = fx_spot_name
        self.domestic_fx_name = domestic_fx_name
        self.foreign_fx_name = foreign_fx_name
        self.direction = direction
        self._dc = DAY_COUNTERS[day_count]

        self._averaging_dates: list[date] = generate_business_days(
            period_start, period_end, averaging_calendar,
        )

        # Canonical key used for fixing storage
        self._spot_key: str = fx_spot_name or domestic_fx_name or ""

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_fx_spot(self, market_state: dict[str, RiskFactorSlice]) -> np.ndarray:
        """Return FX spot (domestic per 1 foreign) from market state."""
        if self.domestic_fx_name and self.foreign_fx_name:
            dom = cast(ScalarSlice, market_state[self.domestic_fx_name])
            fgn = cast(ScalarSlice, market_state[self.foreign_fx_name])
            return dom.values / fgn.values
        spot_slice = cast(ScalarSlice, market_state[self.fx_spot_name])
        return spot_slice.values

    def _build_curves(
        self, market_state: dict[str, RiskFactorSlice]
    ) -> tuple[YieldCurve, YieldCurve, YieldCurve, YieldCurve | None]:
        """Build YieldCurves for forward pricing from market state."""
        dom_basis_slice = cast(CurveSlice, market_state[self.domestic_basis])
        dom_basis_curve = YieldCurve(
            dom_basis_slice.tenors, dom_basis_slice.values,
            self.domestic_basis_interpolator,
        )

        dom_slice = cast(CurveSlice, market_state[self.domestic_curve])
        dom_curve = YieldCurve(
            dom_slice.tenors, dom_slice.values, self.domestic_curve_interpolator,
        )

        for_slice = cast(CurveSlice, market_state[self.foreign_curve])
        for_curve = YieldCurve(
            for_slice.tenors, for_slice.values, self.foreign_curve_interpolator,
        )

        for_basis_curve: YieldCurve | None = None
        if self.foreign_basis:
            for_basis_slice = cast(CurveSlice, market_state[self.foreign_basis])
            for_basis_curve = YieldCurve(
                for_basis_slice.tenors, for_basis_slice.values,
                self.foreign_basis_interpolator,
            )

        return dom_basis_curve, dom_curve, for_curve, for_basis_curve

    # ------------------------------------------------------------------
    # Pricing
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        """Compute per-path NPV of the Asian FX option.

        Parameters
        ----------
        val_date : date
            Current valuation date.
        market_state : dict
            Mapping from risk-factor name to RiskFactorSlice.
        fixings : dict or None
            Realised FX spot prices for past averaging dates.
            Key: ``(spot_key, averaging_date)`` → ``np.ndarray (n_paths,)``.
        rng : ignored.

        Returns
        -------
        np.ndarray, shape (n_paths,)
        """
        spot = self._get_fx_spot(market_state)  # (n_paths,)
        n_paths = spot.shape[0]

        if val_date > self.settlement_date:
            return np.zeros(n_paths)

        dom_basis_curve, dom_curve, for_curve, for_basis_curve = self._build_curves(
            market_state,
        )

        disc_slice = cast(CurveSlice, market_state[self.discount_curve])
        disc_curve = YieldCurve(
            disc_slice.tenors, disc_slice.values, self.discount_interpolator,
        )

        T_settle = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.settlement_date),
        ))
        df = disc_curve.discount_factor(T_settle)

        T_expiry = float(self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.period_end),
        ))

        _fix: dict = fixings if fixings is not None else {}
        n_total = len(self._averaging_dates)

        # EURZAR spot (ZAR per 1 EUR) = 1 / (EUR/ZAR), used as fallback when a
        # fixing is missing and as the correct unit for the K_eff formula.
        eurzar_spot = 1.0 / np.maximum(spot, 1e-12)

        def _get_fixing(avg_date: date) -> np.ndarray:
            key = (self._spot_key, avg_date)
            if key in _fix:
                f = np.asarray(_fix[key], dtype=np.float64)
                return np.full(n_paths, float(f)) if f.ndim == 0 else f
            return eurzar_spot.copy()

        # ------------------------------------------------------------------
        # At or past period end: all fixings realised, intrinsic payoff
        # ------------------------------------------------------------------
        if val_date >= self.period_end:
            price_sum = np.zeros(n_paths)
            for avg_date in self._averaging_dates:
                price_sum += _get_fixing(avg_date)
            S_avg = price_sum / n_total
            if self.is_call:
                payoff = np.maximum(S_avg - self.strike, 0.0)
            else:
                payoff = np.maximum(self.strike - S_avg, 0.0)
            return self.direction * payoff * self.notional * df

        # ------------------------------------------------------------------
        # Accumulate realised fixings for past averaging dates
        # ------------------------------------------------------------------
        past_sum = np.zeros(n_paths)
        n_past = 0

        for avg_date in self._averaging_dates:
            if avg_date >= val_date:
                break
            n_past += 1
            past_sum += _get_fixing(avg_date)

        n_future = n_total - n_past

        # ------------------------------------------------------------------
        # Effective strike adjusted for any past fixings
        # ------------------------------------------------------------------
        if n_past > 0:
            K_eff: float | np.ndarray = (
                (n_total / n_future) * self.strike
                - (n_past / n_future) * (past_sum / n_past)
            )
            strike_for_vol: float | np.ndarray = K_eff
        else:
            K_eff = float(self.strike)
            strike_for_vol = float(self.strike)

        strike_for_vol = np.maximum(strike_for_vol, 1e-12)

        # ------------------------------------------------------------------
        # Moment matching over future fixing dates
        # ------------------------------------------------------------------
        M1_sum = np.zeros(n_paths)
        M2_diag = np.zeros(n_paths)
        M2_cross = np.zeros(n_paths)
        running_weighted = np.zeros(n_paths)

        for avg_date in self._averaging_dates:
            if avg_date < val_date:
                continue

            t_i = float(self._dc.yearFraction(
                to_ql_date(val_date), to_ql_date(avg_date),
            ))

            F_i, _ = fx_forward_price(
                spot, dom_basis_curve, dom_curve, for_curve, t_i,
                foreign_forecast_curve=for_basis_curve,
            )

            vol_i = np.asarray(
                self.vol_surface.get_vol(
                    strike=strike_for_vol,
                    forward=F_i,
                    tenor=t_i,
                ),
                dtype=np.float64,
            )
            if vol_i.ndim == 0:
                vol_i = np.full(n_paths, float(vol_i))

            exp_var_i = np.exp(vol_i ** 2 * t_i)

            M2_cross += F_i * running_weighted
            running_weighted += F_i * exp_var_i

            M2_diag += F_i ** 2 * exp_var_i
            M1_sum += F_i

        M1 = M1_sum / n_future
        M2 = (M2_diag + 2.0 * M2_cross) / (n_future ** 2)

        safe_M1 = np.maximum(M1, 1e-12)
        log_ratio = np.log(np.maximum(M2, safe_M1 ** 2)) - 2.0 * np.log(safe_M1)
        log_ratio = np.maximum(log_ratio, 0.0)
        adjusted_vol = (
            np.sqrt(log_ratio / T_expiry) if T_expiry > 0.0 else np.zeros(n_paths)
        )

        option_pv = black76_euro_option(
            forward=M1,
            strike=K_eff,
            vol=adjusted_vol,
            df=df,
            T=T_expiry,
            is_call=self.is_call,
        )

        pv = self.direction * option_pv * self.notional
        if n_past > 0:
            pv = pv * (n_future / n_total)

        return pv

    # ------------------------------------------------------------------
    # Simulation grid requirements
    # ------------------------------------------------------------------

    def required_sim_dates(self) -> list[date]:
        """Return averaging dates that must appear in the simulation grid."""
        return list(self._averaging_dates)

    # ------------------------------------------------------------------
    # Fixing interface (called by the code that runs the valuation)
    # ------------------------------------------------------------------

    def compute_commodity_fixings(
        self,
        market_state: dict[str, RiskFactorSlice],
        sim_date: date,
        existing_fixings: dict | None = None,
    ) -> dict:
        """Stamp realised FX spot prices for newly past averaging dates."""
        _existing = existing_fixings or {}
        new_fixings: dict = {}

        if not self._averaging_dates or self._averaging_dates[0] > sim_date:
            return {}

        spot = self._get_fx_spot(market_state)
        # Store fixings as EURZAR (ZAR per 1 EUR), the same units used by the
        # Asian payoff formula and K_eff adjustment (strike is also in EURZAR).
        # _get_fx_spot returns dom/fgn = EUR/ZAR, so we invert here.
        eurzar = 1.0 / np.maximum(spot, 1e-12)

        for avg_date in self._averaging_dates:
            if avg_date > sim_date:
                break

            key = (self._spot_key, avg_date)
            if key in _existing:
                continue

            new_fixings[key] = eurzar.copy()

        return new_fixings
