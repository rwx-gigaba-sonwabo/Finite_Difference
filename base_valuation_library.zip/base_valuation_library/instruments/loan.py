"""Fixed rate loan repaid in one amount.

The nominal plus simple interest is paid on the end date and discounted to the valuation
date.
"""

from __future__ import annotations

from datetime import date
from typing import Callable

import numpy as np

from instruments.instrument import Instrument
from utils.ql_helpers import DAY_COUNTERS, to_ql_date
from market_data.yield_curve import YieldCurve
from market_data.risk_factor import CurveSlice, RiskFactorSlice


class Loan(Instrument):
    """Fixed-rate loan valued in a simulation context.

    The future value at maturity is determined by the original loan tenor and
    simple interest rate.  At any valuation date the NPV is that future value
    discounted back continuously using the discount curve::

        FV(t) = N * DF(t, T) * (1 + r * (T - t_start))

    where ``DF(t, T)`` is the continuously-compounded discount factor from the
    valuation date to maturity, and ``T - t_start`` is the full loan tenor
    (fixed at inception).

    Parameters
    ----------
    name : str
        Trade identifier.
    start_date : date
        Date the loan was originated (``t_start``).
    end_date : date
        Loan maturity date (``T``).
    nominal : float
        Principal / notional amount.
    simple_rate : float
        Simple (flat) interest rate of the loan (e.g. 0.08 for 8 %).
    discount_curve_name : str
        Risk factor name for the discount curve.
    discount_interpolator : callable, optional
        Interpolator factory for the discount curve.
    day_count : str
        Day count convention for year fractions (default ``"ACT/365"``).
    """

    def __init__(
        self,
        name: str,
        start_date: date,
        end_date: date,
        nominal: float,
        simple_rate: float,
        discount_curve_name: str,
        discount_interpolator: Callable = None,
        day_count: str = "ACT/365",
    ):
        super().__init__(name)
        self.start_date = start_date
        self.end_date = end_date
        self.nominal = nominal
        self.simple_rate = simple_rate
        self.discount_curve_name = discount_curve_name
        self.discount_interpolator = discount_interpolator
        self._dc = DAY_COUNTERS[day_count]

        # Full loan tenor is fixed at construction, does not change with val_date
        self._loan_tenor = self._dc.yearFraction(
            to_ql_date(start_date), to_ql_date(end_date)
        )

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
    ) -> np.ndarray:
        disc_slice: CurveSlice = market_state[self.discount_curve_name]
        n_paths = disc_slice.values.shape[0]

        if val_date > self.end_date:
            return np.zeros(n_paths)

        disc_curve = YieldCurve(
            disc_slice.tenors, disc_slice.values, self.discount_interpolator,
        )

        T_remaining = self._dc.yearFraction(
            to_ql_date(val_date), to_ql_date(self.end_date)
        )

        df = disc_curve.discount_factor(T_remaining)
        future_value = self.nominal * (1.0 + self.simple_rate * self._loan_tenor)

        return future_value * df
