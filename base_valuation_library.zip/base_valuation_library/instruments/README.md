# Instruments

Each file holds one type of trade. An instrument stores the trade terms and knows how to
value itself from a `market_state` dictionary.

Every instrument offers the same call:

```python
values = instrument.scenario_npvs(valuation_date, market_state, fixings)
```

`market_state` holds the curves and spot values on the valuation date. `fixings` holds past
observations, for example averages that have already set. The call returns an array. For a
base valuation it has one entry, the value today.

The two commodity options added for this validation also offer
`valuation_details(valuation_date, market_state)`. It returns every intermediate number of
the calculation, so a reviewer can follow the value step by step.

The formulas themselves live in `models/`. The instruments prepare the inputs and call them.

## Files

| File | What it holds |
|---|---|
| `bond_forward.py` | Forward on a fixed rate bond. |
| `cds.py` | Credit default swap. |
| `commodity_asian.py` | Asian option on a commodity price. |
| `commodity_average_forward.py` | Forward on the average of a commodity price. |
| `commodity_barrier_option.py` | Single barrier option on a commodity reference price, with the barrier watched all the time. |
| `commodity_digital_option.py` | European digital option on a commodity reference price. |
| `commodity_forward.py` | Forward on a commodity price for one delivery date. |
| `commodity_price_swap.py` | Swap of two commodity price legs. |
| `cross_currency_swap.py` | Cross currency swap with a notional that resets to the market FX rate. |
| `dividend_option.py` | Strip of expected dividend payments on a share. |
| `equity_asian.py` | Asian option on an equity price. |
| `equity_forward.py` | Forward on an equity price. |
| `equity_option.py` | European option on an equity price. |
| `equity_trs.py` | Equity total return swap. |
| `fx_asian.py` | Asian option on an FX rate. |
| `fx_barrier_option.py` | Single barrier option on an FX rate. |
| `fx_cash_swap.py` | FX swap as two fixed cash amounts in two currencies. |
| `fx_forward.py` | FX forward. |
| `fx_option.py` | European option on an FX rate. |
| `index_linked_swap.py` | Index linked swap. |
| `inflation_linked_bond_forward.py` | Forward on an inflation linked bond. |
| `instrument.py` | Base class that every instrument follows. |
| `ir_swap.py` | Single currency interest rate swap. |
| `loan.py` | Fixed rate loan repaid in one amount. |
| `single_barrier_pricer.py` | Closed form value of a single barrier option, used by the FX barrier option. |
| `swaption.py` | European swaption. |

## Components

The `components/` folder holds the building blocks that several instruments share: cashflow legs, commodity price legs, inflation legs, schedule settings and the market readers of the commodity options.

| File | What it holds |
|---|---|
| `cashflow_leg.py` | Definition of one interest leg: fixed or floating, its frequency, rate, spread and curve. |
| `commodity_option_market.py` | Market inputs shared by the commodity digital option and the commodity barrier option. |
| `commodity_price_leg.py` | Definition of one commodity price leg: fixed or floating, its quantity and its price curve. |
| `inflation_leg.py` | Definition of one inflation linked leg: real rate, index curve, base index level and lag. |
| `schedule_config.py` | Settings for building a payment schedule: calendar, business day rules and day counts. |
