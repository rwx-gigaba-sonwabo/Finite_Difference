"""Forward on an inflation linked bond.

Like a bond forward, with coupons and principal scaled by the growth in a consumer price
index.
"""

from __future__ import annotations

from datetime import date
from typing import Callable, Optional

import numpy as np

from instruments.components.inflation_leg import InflationLeg
from instruments.components.schedule_config import ScheduleConfig
from instruments.instrument import Instrument
from market_data.risk_factor import CurveSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.inflation_bond_pv import inflation_bond_forward_pv
from models.inflation_pv import _first_of_month, _shift_months, _shift_months_any, besa_bracket
from utils.ql_helpers import advance_business_days, to_ql_date


class InflationLinkedBondForward(Instrument):
    """Forward contract on an inflation-linked bond.

    Structurally the inflation-indexed counterpart of
    :class:`~instruments.bond_forward.BondForward`: same three-curve
    cash-and-carry mechanics and the same T+3 (BESA) settlement-lag
    handling, but the underlying is an inflation-linked bond rather than a
    plain fixed-coupon bond, so every coupon (and the final notional
    repayment) is scaled by the CPI index ratio applicable to *its own*
    accrual period, exactly as :class:`~instruments.index_linked_swap.IndexLinkedSwap`'s
    inflation leg already does. In fact the underlying bond *is* an
    :class:`~instruments.components.inflation_leg.InflationLeg` with
    ``include_notional_exchange=True``, this instrument prices it with
    :func:`models.inflation_bond_pv.inflation_bond_forward_pv`, which reuses
    :func:`models.inflation_pv.inflation_leg_pv` internally.

    Three-curve pricing framework (mirrors BondForward exactly)
    -------------------------------------------------------------
    bond_curve_name:
        Nominal discount curve for the underlying inflation-linked bond.
        Discounts the (index-ratio-scaled) coupon and notional cashflows to
        compute the spot dirty price and the PV of post-delivery cashflows.
    repo_curve_name:
        Carries the bond's dirty price forward from val_date to
        delivery_date (financing / repo rate). Defaults to bond_curve_name.
    forward_curve_name:
        Discounts the forward payoff from delivery_date back to val_date
        (OIS / swap curve). Defaults to bond_curve_name.

    T+3 settlement convention
    --------------------------
    Identical to BondForward: *delivery_date* is the booking/fixing date;
    the cash-and-securities exchange happens at
    ``delivery_settle = delivery_date + settlement_lag business days``.
    All PV/carry/discounting calculations are anchored at delivery_settle,
    and the forward remains live in simulation until
    ``val_date >= delivery_settle``.

    Forward strike, real vs nominal
    -----------------------------------
    Two mutually exclusive ways to specify the agreed forward price, in the
    same priority order as BondForward:

    - *settlement_amount*: a pre-agreed **absolute** dirty settlement
      amount in currency units. Fixed, not index-scaled.
    - *forward_real_clean_price*: the agreed clean price in **real** terms
      (a fraction of par, e.g. 0.985), the market convention for
      inflation-linked bond forwards. The actual nominal cash settled at
      delivery is this real price (plus real accrued interest) scaled by
      the realised BESA index ratio at delivery, which is exactly the
      stochastic quantity that makes the forward depend on inflation.

    CPI sourcing and fixings
    ------------------------
    Identical machinery to ``IndexLinkedSwap``: CPI is read from a
    stochastic ``CurveSlice`` in the market state under
    ``inflation_leg.cpi_curve_name`` (legacy mode: full forward CPI level
    term structure; two curve mode: spot level only, combined with
    ``inflation_leg.inflation_rate_curve_name``). This instrument
    implements the same duck-typed hooks (``get_cpi_reference_dates``,
    ``_compute_cpi_fixing_for_date``, ``_compute_t_last_pub_fixing``,
    ``get_cpi_last_pub_date``, ``compute_cpi_fixings``) so
    a caller that already handles ``IndexLinkedSwap`` needs no
    changes, CPI bracket dates crossed between valuation dates are
    stamped once and reused, exactly as for ``IndexLinkedSwap``.

    Scope note: unlike ``BondForward``, there is no zero-coupon
    (``compounding=True``, single terminal cashflow) mode here, only the
    standard periodic-coupon inflation-linked bond (the structure
    explicitly requested: "notional at each coupon date gets scaled by the
    index ratio"). ``InflationLeg.compounding_period_months`` (sub-period
    compounding *within* each coupon) is
    still supported and passed through.

    Parameters
    ----------
    name : str
        Trade identifier.
    effective_date : date
        Bond issue / start date.
    maturity_date : date
        Bond maturity date.
    delivery_date : date
        Forward delivery / booking date. Must be strictly before
        *maturity_date*.
    notional : float
        Face value (real terms).
    inflation_leg : InflationLeg
        Real coupon rate, CPI curve name, base CPI, lag, etc. Pass with
        ``include_notional_exchange=True`` (the standard ILB convention;
        the class does not override this for you).
    bond_curve_name : str
        Nominal discount curve risk-factor name.
    forward_real_clean_price : float or None
        Agreed forward clean price in real terms (fraction of par). Used
        only when *settlement_amount* is None.
    interpolator : callable
        Interpolator factory for the bond curve. Default for repo/forward
        curves and the CPI curve when their own interpolators aren't given.
    cpi_interpolator : callable or None
        Interpolator factory for the CPI level curve (legacy mode).
        Defaults to *interpolator* when None.
    inflation_rate_interpolator : callable or None
        Interpolator factory for ``inflation_leg.inflation_rate_curve_name``. Leave ``None`` for legacy mode.
    inflation_index : InflationIndex or None
        Historical CPI data object; seeds ``_historical_cpi_map`` exactly
        as for ``IndexLinkedSwap``.
    direction : int
        +1 for buyer (long forward); -1 for seller (short).
    ex_coupon_days : int
        BESA book-close window in business days (default 0 = no CUMEX).
    settlement_amount : float or None
        Pre-agreed absolute dirty settlement amount; see class docstring.
    repo_curve_name, forward_curve_name : str or None
        Default to *bond_curve_name* when None.
    repo_interpolator, forward_interpolator : callable or None
        Default to *interpolator* when None.
    schedule_config : ScheduleConfig or None
        Full schedule configuration. When None, built from the flat
        keyword parameters below.
    calendar, business_convention, termination_business_convention,
    date_generation, day_count, curve_day_count, end_of_month :
        Ignored when *schedule_config* is provided.
    settlement_lag : int
        Business-day settlement lag (default 3, BESA T+3).
    first_date, next_to_last_date : date or None
        Front/back stub anchors, as in BondForward.

    Raises
    ------
    ValueError
        If *delivery_date* is not strictly before *maturity_date*, or the
        computed delivery-settlement date is not strictly before
        *maturity_date*.
    """

    def __init__(
        self,
        name: str,
        effective_date: date,
        maturity_date: date,
        delivery_date: date,
        notional: float,
        inflation_leg: InflationLeg,
        bond_curve_name: str,
        interpolator: Callable,
        forward_real_clean_price: Optional[float] = None,
        cpi_interpolator: Optional[Callable] = None,
        inflation_rate_interpolator: Optional[Callable] = None,
        inflation_index=None,
        direction: int = 1,
        ex_coupon_days: int = 0,
        settlement_amount: Optional[float] = None,
        repo_curve_name: Optional[str] = None,
        forward_curve_name: Optional[str] = None,
        repo_interpolator: Optional[Callable] = None,
        forward_interpolator: Optional[Callable] = None,
        schedule_config: Optional[ScheduleConfig] = None,
        calendar: str = "ZAR",
        business_convention: str = "ModifiedFollowing",
        termination_business_convention: str = "ModifiedFollowing",
        date_generation: str = "Backward",
        day_count: str = "ACT/365",
        curve_day_count: str = "ACT/365",
        end_of_month: bool = False,
        settlement_lag: int = 3,
        first_date: Optional[date] = None,
        next_to_last_date: Optional[date] = None,
        include_sim_date_cashflows: bool = False,
    ) -> None:
        super().__init__(name)

        if delivery_date >= maturity_date:
            raise ValueError(
                f"delivery_date ({delivery_date}) must be strictly before "
                f"maturity_date ({maturity_date})"
            )

        if settlement_amount is None and forward_real_clean_price is None:
            raise ValueError(
                "either settlement_amount or forward_real_clean_price must be given"
            )

        self.settlement_lag = settlement_lag
        _cal = (schedule_config.calendar if schedule_config is not None else calendar)
        self._delivery_settle: date = advance_business_days(delivery_date, settlement_lag, _cal)
        if self._delivery_settle >= maturity_date:
            raise ValueError(
                f"delivery settlement date ({self._delivery_settle}, "
                f"delivery_date + {settlement_lag} BD) must be strictly before "
                f"maturity_date ({maturity_date})"
            )

        self.effective_date = effective_date
        self.maturity_date = maturity_date
        self.delivery_date = delivery_date
        self.notional = notional
        self.inflation_leg = inflation_leg
        self.bond_curve_name = bond_curve_name
        self.interpolator = interpolator
        self.forward_real_clean_price = forward_real_clean_price
        self.cpi_interpolator = cpi_interpolator if cpi_interpolator is not None else interpolator
        self.inflation_rate_interpolator = inflation_rate_interpolator
        self.inflation_index = inflation_index
        self.direction = direction
        self.ex_coupon_days = ex_coupon_days
        self.settlement_amount = settlement_amount
        self.repo_curve_name = repo_curve_name
        self.forward_curve_name = forward_curve_name
        self.bond_interpolator = interpolator
        self.repo_interpolator = repo_interpolator if repo_interpolator is not None else interpolator
        self.forward_interpolator = forward_interpolator if forward_interpolator is not None else interpolator
        self.include_sim_date_cashflows = include_sim_date_cashflows            

        self.schedule_config = schedule_config or ScheduleConfig(
            calendar=calendar,
            business_convention=business_convention,
            termination_business_convention=termination_business_convention,
            date_generation=date_generation,
            day_count=day_count,
            curve_day_count=curve_day_count,
            end_of_month=end_of_month,
        )

        self._schedule = self.schedule_config.build_bond_schedule(
            self.effective_date, self.maturity_date, self.inflation_leg.frequency,
            first_date=first_date,
            next_to_last_date=next_to_last_date,
        )
        self._effective_maturity = self._delivery_settle 
        self._build_historical_cpi_map()

    def _build_historical_cpi_map(self) -> None:
        """
        Seed ``self._historical_cpi_map`` from the ``InflationIndex`` object.

        The map is ``dict[date, float]`` keyed by first-of-month CPI reference
        dates.  During pricing, entries whose date ≤ the simulation date are
        used as known historical fixings; future entries are overridden by the
        stochastic CPI curve.
        """
        self._historical_cpi_map: dict[date, float] = {}
        if self.inflation_index is None:
            return {}
        # Use the full monthly fixing map (historical + any pre-extended projection)
        if hasattr(self.inflation_index, "_monthly_cpi"):
            self._historical_cpi_map = dict(self.inflation_index._monthly_cpi)

    @property
    def discount_curve_name(self) -> str:
        """Name of the curve the payoff is discounted on.

        Returns *forward_curve_name* when set, otherwise *bond_curve_name*.
        """
        return self.forward_curve_name or self.bond_curve_name

    # ------------------------------------------------------------------
    # CPI fixing interface
    # ------------------------------------------------------------------

    def get_cpi_last_pub_date(self, val_date: date) -> date:
        """
        Return the exact T_last_pub for ``val_date``.

        When ``inflation_leg.next_publication_date`` is set, this counts how many publication
        events have been crossed up to ``val_date`` and advances from the last
        historical CPI reference date by that many periods.  This is correct to
        the day for any simulation grid, including daily grids where the simple
        approximation diverges during the 1, 14 day window before each
        mid-month publication.

        When ``next_publication_date`` is ``None`` (default), or when
        ``_historical_cpi_map`` is empty, falls back to the legacy approximation:
        ``first_of_month(val_date) − 1 month``.  This is exact for month-end
        simulation grids and approximates within ~±15 days on daily grids.

        Pass the return value as ``cpi_last_pub_date`` to ``scenario_npvs()``
        to eliminate the T_last_pub growth bias.
        """
        npd = self.inflation_leg.next_publication_date
        freq = self.inflation_leg.publication_frequency_months

        if npd is None or not self._historical_cpi_map:
            return _shift_months(_first_of_month(val_date), -1)

        last_period_start = max(self._historical_cpi_map)
        # Count how many publication events have been crossed up to val_date.
        n = 0
        while _shift_months_any(npd, n * freq) <= val_date:
            n += 1
        return _shift_months(last_period_start, n * freq)
    

    def get_cpi_reference_dates(self) -> list[tuple[date, str]]:
        """
        Return ``(bracket_date, cpi_curve_name)`` for every unique BESA bracket
        date in the full inflation schedule, sorted chronologically.

        Analogous to ``get_reset_dates()`` for the nominal floating leg.  The
        caller reads this once at trade setup to know which CPI publication
        dates to track; as each valuation date completes,
        ``compute_cpi_fixings()`` captures the per-path CPI level for bracket
        dates that have become past, and these are forwarded to subsequent
        ``scenario_npvs()`` calls via the ``cpi_fixings`` argument.

        This keeps the ``PriceIndex`` (spot)
        factor, which is read back for past reference dates, apart from the
        forward ``InflationRate`` curve used for future CPI levels.
        """
        seen: set[date] = set()
        refs: list[tuple[date, str]] = []
        for _, end_date, _, _ in self._schedule:
            j, j1 = besa_bracket(end_date, self.inflation_leg.lag_months)
            for ref_date in sorted({j, j1}):
                if ref_date not in seen:
                    refs.append((ref_date, self.inflation_leg.cpi_curve_name))
                    seen.add(ref_date)
        return sorted(refs, key=lambda x: x[0])
    

    def _compute_cpi_fixing_for_date(
        self, ref_date: date, fix_state: dict[str, RiskFactorSlice],
    ) -> dict[date, np.ndarray]:
        """Return {ref_date: spot_cpi} from fix_state, or {} for historical dates.

        Call this with the historical market
        state nearest to ref_date (bisect pattern).  Called by
        compute_cpi_fixings with the current step's state for standalone use.
        """
        if ref_date in self._historical_cpi_map:
            return {}
        cpi_slice: CurveSlice = fix_state[self.inflation_leg.cpi_curve_name]
        return {ref_date: cpi_slice.values[:, 0].copy()}

    def _compute_t_last_pub_fixing(
        self,
        time_slice: dict[str, RiskFactorSlice],
        sim_date: date,
        existing_fixings: dict[date, np.ndarray],
    ) -> dict[date, np.ndarray]:
        """Return {T_last_pub: spot_cpi} for the current step, or {} if already stamped.

        T_last_pub is inherently defined relative to sim_date (publication lag),
        so it always uses the current step's market state, never a historical state.
        """
        t_pub = self.get_cpi_last_pub_date(sim_date)
        if t_pub in existing_fixings:
            return {}
        cpi_slice: CurveSlice = time_slice[self.inflation_leg.cpi_curve_name]
        return {t_pub: cpi_slice.values[:, 0].copy()}

    def compute_cpi_fixings(
        self,
        time_slice: dict[str, RiskFactorSlice],
        scenario_date: date,
        existing_fixings: dict[date, np.ndarray] | None = None,
    ) -> dict[date, np.ndarray]:
        """
        Return per-path CPI levels for BESA bracket dates **newly** crossed at
        ``scenario_date``, using the spot CPI from ``time_slice``.

        Standalone convenience method: uses ``scenario_date``'s ``time_slice``
        for all bracket dates.  A caller
        gets better accuracy by calling ``_compute_cpi_fixing_for_date``
        with the market state at the nearest scenario date ≤ each bracket date
        (bisect pattern), avoiding the growing re-evaluation bias on coarser
        simulation grids.

        Parameters
        ----------
        time_slice : dict[str, RiskFactorSlice]
            Market state at ``scenario_date`` from the market state.
        scenario_date : date
            Simulation date at which the CPI path is being recorded.
        existing_fixings : dict[date, np.ndarray] or None
            Already-accumulated per-path fixings from earlier simulation steps.
            Bracket dates present here are skipped so the first-crossing value
            is preserved.  Pass ``None`` to return all past bracket dates
            (legacy standalone behaviour).

        Returns
        -------
        dict[date, np.ndarray]
            Newly-crossed bracket dates mapped to per-path CPI levels,
            shape ``(n_paths,)`` each.
        """
        fixings: dict[date, np.ndarray] = {}

        if existing_fixings is not None:
            fixings.update(
                self._compute_t_last_pub_fixing(time_slice, scenario_date, existing_fixings)
            )

        for _, end_date, _, _ in self.inflation_schedule:
            j, j1 = besa_bracket(end_date, self.inflation_leg.lag_months)
            for ref_date in sorted({j, j1}):
                if ref_date > scenario_date:
                    continue
                if ref_date in fixings:
                    continue
                if existing_fixings is not None and ref_date in existing_fixings:
                    continue
                fixings.update(self._compute_cpi_fixing_for_date(ref_date, time_slice))
        return fixings

    # ------------------------------------------------------------------
    # Instrument interface
    # ------------------------------------------------------------------

    def scenario_npvs(
        self,
        val_date: date,
        market_state: dict[str, RiskFactorSlice],
        fixings: dict[tuple[str, date], np.ndarray] | None = None,
        rng: np.random.Generator | None = None,
        cpi_fixings: dict[date, np.ndarray] | None = None,
        cpi_last_pub_date: date | None = None,
    ) -> np.ndarray:
        """Per-path NPV of the inflation-linked bond forward at *val_date*.

        Parameters
        ----------
        val_date : date
        market_state : dict[str, RiskFactorSlice]
            Must contain *bond_curve_name* and ``inflation_leg.cpi_curve_name``
            (and ``inflation_leg.inflation_rate_curve_name`` in two curve mode).
            *repo_curve_name* / *forward_curve_name* looked up if set.
        fixings : ignored
        rng : ignored
        cpi_fixings, cpi_last_pub_date :
            Supplied by a caller that tracks CPI fixings
            (this instrument's CPI fixing hooks are
            written for that); pass explicitly for standalone use.

        Returns
        -------
        np.ndarray, shape (n_paths,)
            Zero for all paths once *val_date* reaches delivery settlement.
        """
        bond_slice: CurveSlice = market_state[self.bond_curve_name]
        n_paths = bond_slice.values.shape[0]

        if val_date > self._effective_maturity:
            return np.zeros(n_paths)

        bond_curve = YieldCurve(
            year_fracs=bond_slice.tenors,
            rates=bond_slice.values,
            interpolator=self.bond_interpolator,
        )

        repo_curve = None
        if self.repo_curve_name and self.repo_curve_name in market_state:
            repo_slice: CurveSlice = market_state[self.repo_curve_name]
            repo_curve = YieldCurve(
                year_fracs=repo_slice.tenors,
                rates=repo_slice.values,
                interpolator=self.repo_interpolator,
            )

        fwd_curve = None
        if self.forward_curve_name and self.forward_curve_name in market_state:
            fwd_slice: CurveSlice = market_state[self.forward_curve_name]
            fwd_curve = YieldCurve(
                year_fracs=fwd_slice.tenors,
                rates=fwd_slice.values,
                interpolator=self.forward_interpolator,
            )

        sc = self.schedule_config

        return inflation_bond_forward_pv(
            schedule=self._schedule,
            leg=self.inflation_leg,
            base_notional=self.notional,
            val_date=val_date,
            delivery_date=self.delivery_date,   # T+settlement_lag BD
            market_state=market_state,
            n_paths=n_paths,
            cpi_interpolator=self.cpi_interpolator,
            curve_day_counter=sc.curve_day_counter,
            day_counter=sc.day_counter,
            bond_curve=bond_curve,
            forward_real_clean_price=self.forward_real_clean_price,
            settlement_amount=self.settlement_amount,
            direction=self.direction,
            ex_coupon_days=self.ex_coupon_days,
            ql_calendar=sc.ql_calendar,
            repo_curve=repo_curve,
            forward_curve=fwd_curve,
            historical_cpi_map=self._historical_cpi_map,
            cpi_fixings=cpi_fixings,
            inflation_rate_interpolator=self.inflation_rate_interpolator,
            cpi_last_pub_date=cpi_last_pub_date,
            calendar=sc.ql_calendar,
            convention=sc.ql_convention,
            include_on_val_date=self.include_sim_date_cashflows,
        )
