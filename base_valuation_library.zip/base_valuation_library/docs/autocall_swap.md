# Autocallable swap and its put leg

Code: `autocall_pricer/`. Run script: `validation_runs/autocall_swap/`.

## The trade

An autocallable swap has three parts.

| Part | What it pays |
|---|---|
| Coupon leg | On each observation date, if the equity is at or above the trigger level, the coupon of that date is paid and the swap ends |
| Floating leg | A floating amount each period, for as long as the swap has not ended |
| Put | A loss when the equity ends below a barrier, but only if the swap was never called |

The trigger level of an observation date is its threshold times the strike.

## Two ways the put is held

| Mode | How the put sits in the trade file | Lines in the report |
|---|---|---|
| `booking` | The swap deal has no put. Four option deals are booked next to it | Five: the swap and the four options |
| `autocall` | The swap deal carries its own put | One |

In booking mode the four deals are:

| Deal type | What it is | Bought or sold |
|---|---|---|
| `EquityOptionDeal` | European put | Sold |
| `EquityBarrierOption` | Up and in put, barrier at the trigger level, checked on the coupon dates | Bought |
| `EquityBinaryOption` | European cash digital put | Sold |
| `EquityBarrierBinaryOption` | Up and in cash digital put, same barrier and dates | Bought |

A European option plus its up and in partner is an up and out option. It only pays on paths
that never closed above the trigger level, which are the paths on which the swap was never
called.

## How the swap is valued

By Monte Carlo simulation.

1. The equity price is simulated on every observation date. Each step is an exact lognormal
   draw, so there is no discretisation error.
2. The drift of each step comes from the funding curve and the dividend yield curve. The
   average simulated price on each date equals the forward price.
3. The variance of each step comes from the volatility surface. In the default mode the
   total variance to each date equals the surface's own variance to that date.
4. On each path the payoff is worked out date by date: called or not, floating payment or
   not, put barrier breached or not.
5. Each payment is discounted on the discount curve. The value is the average over all paths.

The standard error of the average is reported next to the value.

When the swap carries its own put, the coupon paths and the put paths use the same random
numbers but read the volatility at their own levels: the trigger level for the coupon, the
put barrier for the put.

## How the four booked options are valued

| Deal | Method |
|---|---|
| European put | Black model on the forward price, volatility at the strike |
| European digital put | Black model. With a digital strike spread above zero, a spread of two puts struck just below and just above the strike, each with its own volatility |
| Up and in put | Simulation. The path knocks in when it closes above the barrier on a barrier date |
| Up and in digital put | Simulation. With a digital strike spread above zero, a spread of two up and in puts |

The simulated paths of the options use the volatility read at the option's own strike.

### Forward date of the European options

The setting `EUROPEAN_FORWARD_LAG_BUSINESS_DAYS` moves the date the forward price of the two
European options is carried to. With 0 the forward is carried to the expiry date. With 2 it
is carried to two business days after the expiry, the date the equity would settle. The
volatility time and the discounting are not changed. See
[validation_status.md](validation_status.md) for why the sample run uses 2.

## Quanto payout

When the deal pays in another currency at a fixed FX rate, the equity drifts at an extra rate
per year of minus the correlation times the equity volatility times the FX volatility. The
run script needs the FX volatility and the correlation to be set. A quanto deal without them
stops with an error.

## How the lines are compared

| Line | Compared on |
|---|---|
| Swap, up and in put, up and in digital put | z score: the difference divided by the standard error of the simulation |
| European put, European digital put | Absolute or relative difference |

See [comparison_method.md](comparison_method.md).

## Points to note

* A swap whose past fixing already triggered a call has no cashflows left. It is reported
  with a value of zero and a note.
* Floating amounts are read from the deal's table as the cash amount of each period per unit
  of notional. They are not projected from a curve by this library.
* The target system's own simulated values also carry sampling noise. The z score only uses
  this library's standard error. Ask the target system for enough paths that its own noise
  is small next to this library's.
