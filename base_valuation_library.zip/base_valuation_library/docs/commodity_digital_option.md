# European commodity digital option

Code: `instruments/commodity_digital_option.py` and `models/digital_option_pv.py`.
Run script: `validation_runs/commodity_digital_option/`.

## The trade

On the expiry date the option looks at one commodity reference price, the fixing.

* A call is in the money when the fixing is above the strike.
* A put is in the money when the fixing is below the strike.

In the money, it pays on the settlement date. Out of the money, it pays nothing.

| Payout style | What is paid in the money |
|---|---|
| Cash | A fixed amount of currency, the `Payoff` |
| Asset | `Payoff` units of the commodity, worth `Payoff` times the fixing |

## Inputs

| Input | Where it comes from |
|---|---|
| Forward price `F` | Commodity forward price curve, read at the delivery date the expiry fixes against |
| Volatility `sigma` | Commodity volatility surface, read at the option's moneyness and time to expiry |
| Discount factor `DF` | Zero rate curve of the payout currency, to the settlement date |
| FX rate | Spot rate from the payout currency into the reporting currency |
| Time to expiry `T` | Days from the valuation date to the expiry date, divided by the curve's day count basis |

### Reading the forward price

A reference price fixes against a delivery date. The trade file holds a mapping from fixing
date to delivery date for each reference price. The forward price is read off the forward
price curve at the delivery date of the expiry. Between two pillars of the curve the price is
a straight line in calendar days. Outside the pillars the first or the last price is held.

## Valuation

With `w = +1` for a call and `w = -1` for a put, and `N` the standard normal distribution
function:

```
d1 = ln(F / K) / (sigma * sqrt(T)) + sigma * sqrt(T) / 2
d2 = d1 - sigma * sqrt(T)
```

### Method 1. Closed form

Used when the digital strike spread is zero.

```
cash digital  = N(w * d2)
asset digital = F * N(w * d1)
```

One volatility is used, read at the strike. The slope of the volatility smile is ignored.

### Method 2. Strike spread

Used when the digital strike spread `eps` is above zero. The digital is replicated with two
vanilla options, one struck just below and one just above the strike. `V(k)` is the Black
value of a vanilla option struck at `k`, with the volatility read at `k`.

```
cash digital  = w * (V(K * (1 - eps)) - V(K * (1 + eps))) / (2 * eps * K)
asset digital = w * V(K) + K * cash digital
```

Because each strike uses its own volatility, the slope of the smile is included. This is the
usual market treatment of digital risk.

The spread `eps` is read from the trade file, under
`Valuation Configuration > CommodityDigitalOption > Relative_Digital_Spread`. A run script
can replace it.

### Present value

```
value = sign * Payoff * digital * DF(settlement) * FX
```

`sign` is +1 for a bought option and -1 for a sold option.

## Payout in another currency

The commodity is quoted in one currency. The option can pay in another. `X` is the FX rate
in payout currency per unit of commodity currency. `rho` is the correlation between the
commodity price and `X`.

| Payout type | Strike is a level in | Forward used | Volatility used |
|---|---|---|---|
| Standard | commodity currency | `F` | `sigma_S` at the strike |
| Quanto | commodity currency | `F * exp(-rho * sigma_S * sigma_X * T)` | `sigma_S` at the strike |
| Composite | payout currency | `F * X_forward(T)` | `sqrt(sigma_S^2 + 2 * rho * sigma_S * sigma_X + sigma_X^2)` |

For a composite payout the commodity volatility is read at the strike converted back into
commodity currency, `K / X_forward(T)`. For a quanto payout the adjustment uses the at the
money volatilities of the commodity and of `X`.

## After expiry

Between the expiry date and the settlement date the fixing is known. The option is then
worth its known payout, discounted. The fixing must be given in the deal's `Price_Fixing`
table.

## Points to note

* The time to expiry and the discounting time use the day count basis of the discount curve.
* With a steeply sloped smile and a wide spread, the strike spread value can fall outside the
  range of zero to one. That is a property of the surface, not of the method.
* `valuation_details` on the instrument returns every number above, and the run script
  prints them under "Calculation steps".
