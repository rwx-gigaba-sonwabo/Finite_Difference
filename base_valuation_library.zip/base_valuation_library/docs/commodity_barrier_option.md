# Commodity barrier option, barrier watched all the time

Code: `instruments/commodity_barrier_option.py` and `models/barrier_option_pv.py`.
Run script: `validation_runs/commodity_barrier_option/`.

## The trade

A European call or put on a commodity reference price, on a number of units, with one
barrier level.

| Type | What the barrier does |
|---|---|
| Knock out | The option dies the first time the price touches the barrier. A cash rebate, if agreed, is paid at that moment |
| Knock in | The option only comes to life once the price touches the barrier. A cash rebate, if agreed, is paid at expiry when the barrier was never touched |

An up barrier sits above the price. A down barrier sits below it. That gives eight option
types: up or down, in or out, call or put.

## Inputs

| Symbol | Meaning | Where it comes from |
|---|---|---|
| `S` | Price today | Forward price curve, read at the delivery date that today fixes against |
| `F` | Forward price to expiry | Forward price curve, read at the delivery date the expiry fixes against |
| `T` | Time to expiry in years | Valuation date to expiry date, on the discount curve's day count basis |
| `b` | Cost of carry | `ln(F / S) / T`, so that `S * exp(b * T)` equals `F` |
| `r` | Discount rate | Zero rate to expiry off the discount curve |
| `sigma` | Volatility | Commodity volatility surface at the strike, floored at 5% |
| `K`, `H`, `R` | Strike, barrier, rebate | The deal |

The volatility is read with the moneyness measured on the price today, `S / K`. A run script
setting can measure it on the forward price instead.

## The model

The price follows a lognormal process with constant `sigma`, `b` and `r`. The value then has
a closed form built from six terms, A to F (Merton 1973, Reiner and Rubinstein 1991, as set
out in Haug, "The Complete Guide to Option Pricing Formulas").

```
v      = sigma * sqrt(T)
mu     = (b - sigma^2 / 2) / sigma^2
lambda = sqrt(mu^2 + 2 * r / sigma^2)
x1 = ln(S / K) / v + (1 + mu) * v            x2 = ln(S / H) / v + (1 + mu) * v
y1 = ln(H^2 / (S * K)) / v + (1 + mu) * v    y2 = ln(H / S) / v + (1 + mu) * v
z  = ln(H / S) / v + lambda * v

phi = +1 for a call, -1 for a put
eta = +1 for a down barrier, -1 for an up barrier

A = phi * S * exp((b - r) * T) * N(phi * x1) - phi * K * exp(-r * T) * N(phi * (x1 - v))
B = phi * S * exp((b - r) * T) * N(phi * x2) - phi * K * exp(-r * T) * N(phi * (x2 - v))
C = phi * S * exp((b - r) * T) * (H / S)^(2 * (mu + 1)) * N(eta * y1)
    - phi * K * exp(-r * T) * (H / S)^(2 * mu) * N(eta * (y1 - v))
D = phi * S * exp((b - r) * T) * (H / S)^(2 * (mu + 1)) * N(eta * y2)
    - phi * K * exp(-r * T) * (H / S)^(2 * mu) * N(eta * (y2 - v))
E = R * exp(-r * T) * (N(eta * (x2 - v)) - (H / S)^(2 * mu) * N(eta * (y2 - v)))
F = R * ((H / S)^(mu + lambda) * N(eta * z) + (H / S)^(mu - lambda) * N(eta * (z - 2 * lambda * v)))
```

`A` is the plain European option. `E` is a rebate paid at expiry when the barrier is never
touched. `F` is a rebate paid at the moment the barrier is touched.

| Option type | Strike above barrier | Strike at or below barrier |
|---|---|---|
| Down and in call | C + E | A - B + D + E |
| Up and in call | A + E | B - C + D + E |
| Down and in put | B - C + D + E | A + E |
| Up and in put | A - B + D + E | C + E |
| Down and out call | A - C + F | B - D + F |
| Up and out call | F | A - B + C - D + F |
| Down and out put | A - B + C - D + F | F |
| Up and out put | B - D + F | A - C + F |

The value per unit is multiplied by the units, by +1 for a bought and -1 for a sold option,
and by the FX rate into the reporting currency. The rebate in the deal is a cash amount for
the whole trade. It is divided by the units before it enters the formula.

## States the closed form does not cover

| State on the valuation date | Value per unit |
|---|---|
| Knock out, barrier already touched | The rebate |
| Knock in, barrier already touched | The plain European option |
| Knock out, on the expiry date, still alive | The payoff |
| Knock in, on the expiry date, never touched | The rebate |

The barrier counts as touched when the price today is strictly beyond it, or when the run
script says it was touched before the valuation date. A price exactly on the barrier does
not count.

## Barrier checked at intervals

The run script reads `Barrier_Monitoring_Frequency` from the deal. When it is set, the
barrier is only checked once per interval. The closed form is still used, with the barrier
moved away from the price (Broadie, Glasserman and Kou 1997):

```
H used = H * exp(+0.5826 * sigma * sqrt(interval))   for an up barrier
H used = H * exp(-0.5826 * sigma * sqrt(interval))   for a down barrier
```

The row of the table above is still chosen on the barrier in the deal.

## Payout in another currency

| Payout type | Strike and barrier are levels in | What changes |
|---|---|---|
| Standard | commodity currency | Nothing |
| Quanto | commodity currency | The carry is reduced by `rho * sigma_S * sigma_X` |
| Composite | payout currency | `S` is multiplied by the FX spot, `F` by the FX forward, and the volatility becomes `sqrt(sigma_S^2 + 2 * rho * sigma_S * sigma_X + sigma_X^2)` |

## Limits of the model

* One volatility and one carry are used for the whole life of the option. The barrier does
  not see the term structure of volatility or the shape of the forward curve before expiry.
* The reference price must not roll from one futures contract to the next before expiry. The
  price would jump at the roll and the model has no jumps. The instrument checks this and
  stops with an error.
* The volatility floor of 5% is a deliberate choice. Barrier values are very sensitive to a
  volatility near zero.

## The deal layout

The deal type is `CommodityBarrierOption`. Its fields are listed in
[trade_file_format.md](trade_file_format.md).
