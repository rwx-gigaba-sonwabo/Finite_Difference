# Validation status

This page records what this library has been compared against so far, and what was found.
The words target system and comparison value are explained in the main [README](../README.md).

Last updated: 11 November 2026.

## Summary

| Trade type | Compared with the target system | Result |
|---|---|---|
| European commodity digital option | Yes, 48 cases | Agree to 13 significant figures |
| Commodity barrier option | Indirectly, 192 cases. See below | Agree to 10 significant figures |
| Autocallable swap and booked put leg | Yes, 1 sample with 5 lines | All lines inside tolerance |
| Equity forward | Yes, 1 sample | Agree to 13 significant figures |
| All other trade types | No | Run on sample files only |

## European commodity digital option

The library value was compared with the target system's value of the same deal in the same
trade file.

| What was varied | Values |
|---|---|
| Option type | Call, put |
| Side | Bought, sold |
| Payout style | Cash, asset |
| Payout type | Standard, quanto, composite |
| Settlement | On expiry, five days after expiry |
| Discount curve | Plain curve, curve with a spread layer |
| Digital strike spread | 0 (closed form), 0.01, 0.02 |
| Reporting currency | Commodity currency, another currency |

48 cases. Largest relative difference: 3.1e-14.

The sample file `validation_runs/commodity_digital_option/sample_trade.json` holds three of
these deals with their comparison values.

## Commodity barrier option

The target system had no commodity barrier deal type at the time of this work. A direct
comparison was therefore not possible.

The barrier formula was checked indirectly. For each case a second trade was built in the
target system: a barrier option on a share, with the barrier watched all the time. The share
was given the same price today, the same forward price to expiry, the same volatility surface
and the same correlation as the commodity. The two trades are then the same option in the
model, and the target system values the share option with the same closed form that a
commodity barrier option is expected to use.

| What was varied | Values |
|---|---|
| Option type | Call, put |
| Barrier side | Up, down |
| Barrier kind | Knock in, knock out |
| Strike | Below the barrier, above the barrier |
| Payout type | Standard, quanto, composite |
| Barrier checks | All the time, once a week |
| Cash rebate | None, with rebate |

192 cases. Largest relative difference: 1.8e-11.

**What this does and does not show.** It shows that the closed form, the interval shift, the
volatility floor and the quanto and composite treatment in this library match the target
system's barrier pricing. It does not show how the target system will read a commodity
barrier deal once that deal type exists. Three points must be confirmed against the real
deal type when it is available:

1. **Price today.** This library reads it off the forward price curve at the delivery date
   that the valuation date fixes against.
2. **Moneyness for the volatility.** This library measures it on the price today, as the
   share barrier option does. The run script setting `VOLATILITY_MONEYNESS_BASIS` switches it
   to the forward price.
3. **A barrier touched before the valuation date.** The trade file does not record it. The
   run script setting `BARRIER_TOUCHED_BEFORE` supplies it.

The sample file `validation_runs/commodity_barrier_option/sample_trade.json` holds three
deals. Their comparison values come from the matching share barrier options.

## Autocallable swap and booked put leg

Sample file: `validation_runs/autocall_swap/sample_trade.json`. Library run with 400 000
paths and seed 7.

| Line | Method | Library value | Standard error | Comparison value | z score | Outcome |
|---|---|---|---|---|---|---|
| Swap | Simulation | 4 203 398.02 | 5 042.56 | 4 202 841.06 | 0.11 | PASS |
| European put | Closed form | -1 350 224.74 | | -1 350 224.74 | | PASS |
| Up and in put | Simulation | 228 987.20 | 1 987.41 | 227 902.42 | 0.55 | PASS |
| European digital put | Closed form | -1 393 451.77 | | -1 393 451.77 | | PASS |
| Up and in digital put | Simulation | 394 067.26 | 7 158.82 | 377 299.36 | 2.34 | PASS |

**Point to note.** The up and in digital put passes, but its z score of 2.34 is the highest
of the lines and the difference is 4.4% of the value. The comparison value is itself a
simulated number and its own standard error is not known here. Before signing this line off,
rerun both sides with more paths and with a second seed, and check that the difference
shrinks with the noise.

## Equity forward

Sample file: `validation_runs/equity_forward/sample_trade.json`. One deal. Library value
206 211.284032, comparison value 206 211.284032.

## Trade types that have not been compared

The run scripts of the other trade types run on their sample files and report
`NOT COMPARED`. Their pricing code comes from the original code base and was not changed in
substance. Its earlier use was for values on future dates, not for this base valuation
comparison.

The sample deals of these trade types are short. They hold the fields the run script reads,
not every field the target system needs to value the deal. A first trial was made on three of
them by adding the missing fields. It gave these differences:

| Trade type | Library value | Target system value | Relative difference | Status |
|---|---|---|---|---|
| European equity option | 7 929 654.16 | 7 901 919.45 | 0.35% | Cause not established |
| European FX option | 2 568 080.82 | 2 600 912.60 | 1.26% | Cause not established |
| FX forward | 1 211 750.33 | 4 197 734.40 | large | Cause not established |

These trials are not findings against either system. The two sides were not set up the same
way. For example the library's FX scripts add a basis spread curve to the domestic curve,
and the trial deals did not name one. They are listed so that the gap is visible.

**What to do for each of these trade types.** Point the run script at a real trade file that
the target system values. Set the market data names in the `SETTINGS` block to the curves
that the deal names. Give the comparison value. Then treat any difference as open until it
is explained.

## Known limits of the library

| Item | Detail |
|---|---|
| Barrier model | One volatility and one carry rate for the whole life of the option |
| Reference price roll | A barrier option on a reference price that rolls to a new futures contract before expiry is refused with an error |
| Barrier volatility floor | 5% |
| Averaging coupons | An autocallable swap whose coupon is decided on the average of several fixings is refused with an error |
| Two expected test failures | Explained in [tests/README.md](../tests/README.md) |
