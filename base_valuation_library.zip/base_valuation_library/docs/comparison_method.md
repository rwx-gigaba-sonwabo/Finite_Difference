# How two values are compared

Code: `valuation/base_valuation.py` and `valuation/component_report.py`.

## A value from a formula

```
difference          = library value - comparison value
relative difference = difference / absolute comparison value
```

The two values agree when **either** test passes:

* the absolute difference is at most `ABSOLUTE_TOLERANCE`, or
* the absolute relative difference is at most `RELATIVE_TOLERANCE`.

Two tests are used because one is not enough. A relative test alone fails a very small trade
on rounding. An absolute test alone passes a difference on a very large trade that is small
in rand but large for that trade.

## A value from a simulation

A simulated value is an average over random paths. It carries sampling noise, measured by its
standard error. A difference only means something when it is larger than that noise.

```
z score = absolute difference / standard error
```

The two values agree when the z score is at most `Z_SCORE_TOLERANCE`. The default is 3. A
difference of three standard errors is rarely produced by chance alone.

A simulated line also passes on the absolute or the relative test, so a line with almost no
noise is not failed on a negligible difference.

## Outcomes

| Outcome | Meaning |
|---|---|
| `PASS` | The values agree inside the tolerance |
| `FAIL` | They do not |
| `NOT COMPARED` | No comparison value was given. The library value is still reported |

A report with several lines is `FAIL` when any line fails.

## Report files

Each run writes three files to the `output` folder next to its script.

| File | Content |
|---|---|
| `<reference>_base_valuation.txt` | The report as printed on the screen |
| `<reference>_base_valuation.csv` | One row per line, for pasting into a workbook |
| `<reference>_base_valuation.json` | The same content for other programs to read |

The report lists the interpolation scheme used for each curve and where that scheme came
from, so a reader can see how every curve was read.
