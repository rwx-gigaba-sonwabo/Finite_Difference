# Layout of the trade JSON file

Code: `trade_data/trade_file.py` reads the file. `trade_data/base_market.py` builds the
market from it.

One trade JSON file holds everything a valuation needs: the valuation date, the trades and
the market data. A run script reads the same file that is given to the system being
validated, so both value the same trade off the same market.

## The sections of the file

```
Calc
  Calculation
    Base_Date                 the valuation date
    Currency                  the reporting currency
  Deals
    Deals
      Children[]              one entry per trade
        Instrument
          .Deal               the fields of one trade
  MergeMarketData
    ExplicitMarketData
      Price Factors                 the market data, one entry per name
      Valuation Configuration       optional settings per deal type
      Price Factor Interpolation    optional interpolation rule per curve type
```

A file that holds only market data, with `MarketData` at the top, is also read.

## Tagged values

The file marks typed values with a dictionary that has one key. The reader turns them into
plain Python values.

| Tag | Example in the file | Value after reading |
|---|---|---|
| `.Timestamp` | `{".Timestamp": "2026-10-30"}` | a date |
| `.Curve` | `{".Curve": {"meta": [], "data": [[0.5, 0.07], [1.0, 0.072]]}}` | an array of points |
| `.Percent` | `{".Percent": 5.0}` | `0.05` |
| `.Basis` | `{".Basis": 25.0}` | `0.0025` |
| `.DateOffset` | `{".DateOffset": "3M"}` | `"3M"` |
| `.DateList` | `{".DateList": [["2026-01-15", 1.0]]}` | a list of date and value rows |
| `.Deal` | `{".Deal": {...}}` | a dictionary of the deal fields |

## Price factors

A price factor is one piece of market data. Its name is `<Type>.<Name>`, for example
`InterestRate.USD-SOFR`.

| Type | What it holds | Fields that are read |
|---|---|---|
| `FxRate` | Spot value of one unit of a currency, in the base currency of the file | `Spot`, `Interest_Rate` |
| `InterestRate` | Zero rate curve. Rates are continuously compounded. Pillars are in years | `Curve`, `Day_Count`, `Currency` |
| `ForwardPrice` | Commodity forward price curve. Pillars are delivery dates as Excel serial numbers | `Curve`, `Currency` |
| `ReferencePrice` | Link between a commodity reference price and its forward price curve | `ForwardPrice`, `Fixing_Curve` |
| `CommodityPriceVol` | Commodity volatility surface. Rows of moneyness, expiry in years, volatility | `Surface`, `Surface_Type` |
| `FXVol` | FX volatility surface | `Surface` or `Delta_Surface`, `Surface_Type` |
| `EquityPrice` | Share price | `Spot`, `Currency`, `Interest_Rate` |
| `DividendRate` | Continuous dividend yield curve | `Curve` |
| `EquityPriceVol` | Equity volatility surface | `Surface` or the skew parameter curves |
| `InterestYieldVol` | Swaption volatility. Rows of moneyness, expiry, tenor, volatility | `Surface` |
| `SurvivalProb` | Credit curve, stored as minus the log of the survival probability | `Curve`, `Recovery_Rate` |
| `PriceIndex` | Consumer price index levels | `Curve` |
| `Correlation` | Correlation between two price factors. The name is `Correlation.<A>/<B>` | `Value` |

### A curve with spread layers

A curve name with more than two parts is a spread on top of a base curve. For
`InterestRate.ZAR-SWAP.ZAR-USD-BASIS` the rate used is the rate of `InterestRate.ZAR-SWAP`
plus the rate of `InterestRate.ZAR-SWAP.ZAR-USD-BASIS`.

### The fixing curve of a reference price

`Fixing_Curve` maps a fixing date to the delivery date whose forward price is observed on
that day. Both are Excel serial numbers. Between two points the mapping is a straight line.
Outside the points the first or the last delivery date is held.

### Surface types

| `Surface_Type` | Moneyness on the surface |
|---|---|
| `Explicit` | Underlying price divided by strike |
| `Relative_Forward` | Strike minus forward, divided by forward |
| `Malz` | Quoted in delta, in the field `Delta_Surface` |

### Curve interpolation

`Price Factor Interpolation` names the interpolation scheme per curve type. A run script
reports the scheme used for each curve under "Notes on inputs". The setting
`CURVE_INTERPOLATION_OVERRIDES` in a run script replaces the scheme for one curve.

## The commodity digital option deal

`Object` is `CommodityDigitalOption`.

| Field | Meaning | If left out |
|---|---|---|
| `Reference` | Name of the trade. Picks the deal and labels the report | |
| `Currency` | Payout currency | required |
| `Discount_Rate` | Name of the discount curve, without the `InterestRate.` prefix | the curve named after the payout currency |
| `Buy_Sell` | `Buy` or `Sell` | `Buy` |
| `Option_Type` | `Call` or `Put` | `Call` |
| `Expiry_Date` | Date the fixing is observed | required |
| `Settlement_Date` | Date the payout is paid | the expiry date |
| `Strike_Price` | Strike | required |
| `Payoff` | Cash amount, or number of commodity units for an asset payout | required |
| `Payoff_Style` | `Cash` or `Asset` | `Cash` |
| `Payoff_Type` | `Standard`, `Quanto` or `Compo` (composite) | `Standard` |
| `Reference_Type` | Name of the reference price, without the `ReferencePrice.` prefix | required |
| `Reference_Volatility` | Name of the volatility surface, without the `CommodityPriceVol.` prefix | required |
| `Price_Fixing` | Rows of date and observed price. Needed once the expiry date has passed | |

The digital strike spread is read from
`Valuation Configuration > CommodityDigitalOption > Relative_Digital_Spread`. Zero or missing
means the closed form is used.

## The commodity barrier option deal

`Object` is `CommodityBarrierOption`. The setting `DEAL_TYPE` in the run script changes the
name that is looked for.

| Field | Meaning | If left out |
|---|---|---|
| `Reference` | Name of the trade | |
| `Currency` | Payout currency | required |
| `Discount_Rate` | Name of the discount curve | the curve named after the payout currency |
| `Buy_Sell` | `Buy` or `Sell` | `Buy` |
| `Option_Type` | `Call` or `Put` | `Call` |
| `Expiry_Date` | Expiry date of the option | required |
| `Strike_Price` | Strike | required |
| `Units` | Number of commodity units | required |
| `Barrier_Type` | `Up_And_Out`, `Up_And_In`, `Down_And_Out` or `Down_And_In` | required |
| `Barrier_Price` | Barrier level | required |
| `Cash_Rebate` | Cash rebate for the whole trade | `0` |
| `Barrier_Monitoring_Frequency` | Time between barrier checks, for example `1W`. Zero means watched all the time | watched all the time |
| `Payoff_Type` | `Standard`, `Quanto` or `Compo` (composite) | `Standard` |
| `Reference_Type` | Name of the reference price | required |
| `Reference_Volatility` | Name of the volatility surface | required |

For a quanto or composite payout both option deals also read the FX volatility surface of
the currency pair and the factor
`Correlation.FxRate.<commodity currency>.<payout currency>/ReferencePrice.<name>.<commodity currency>`.

## Other deal types

Each of the other run scripts lists the deal fields it reads in its `SETTINGS` block, as
`from_trade_file("Field")`. The autocallable swap deal is described in
[autocall_swap.md](autocall_swap.md).
