# European equity digital option

Code: `instruments/equity_digital_option.py`, with the formulas in `models/digital_option_pv.py`
and the forward price in `models/equity_pv.py`.
Run script: `validation_runs/equity_digital_option/`.
Deal type in the trade file: `EquityBinaryOption`.

## The trade

On the expiry date the option looks at the closing price of a share or an index, the fixing.

* A call is in the money when the fixing is above the strike.
* A put is in the money when the fixing is below the strike.

In the money, it pays on the settlement date. Out of the money, it pays nothing.

| Payout style | What is paid in the money |
|---|---|
| Cash | A fixed amount of currency, the `Payoff` |
| Asset | `Payoff` shares, worth `Payoff` times the fixing |

## Inputs

| Input | Where it comes from |
|---|---|
| Spot price `S` | The equity price factor, field `Spot` |
| Forward price `F` | `S * DF_div(T_F) / DF_carry(T_F)` from the dividend yield curve and the carry curve |
| Forward time `T_F` | Days to the forward date over 365. The forward date is the expiry date plus `FORWARD_LAG_BUSINESS_DAYS` (2 by default) |
| Volatility `sigma` | The equity volatility factor, read at the strike and the time to expiry |
| Time to expiry `T` | Days from the valuation date to the expiry date, over 365 |
| Discount factor `DF` | The discount curve, to the settlement date (the expiry date when there is none) |

### Reading the volatility

Two kinds of equity volatility factor are accepted. The run script picks the reader from the
factor's `Surface_Type`.

| `Surface_Type` | Reader | How a strike `K` is read |
|---|---|---|
| `Skew` | `BenchmarkVolSkew` | By strike. `SKEW_STICKINESS` chooses sticky strike or sticky delta |
| `Explicit` | `MoneynessVolSurface` | At moneyness `S / K` (or `F / K` when `VOLATILITY_MONEYNESS_BASIS = "forward"`) |

### Why the forward runs two business days past expiry

The target system carries the forward of an equity option to the date the equity would
settle, two business days after expiry. The volatility time still runs to the expiry date and
the discounting to the settlement date. This is the convention under which the autocall's
European digital put matched the target system exactly. Set `FORWARD_LAG_BUSINESS_DAYS = 0`
to carry the forward to expiry instead.

## Valuation

With `w = +1` for a call and `w = -1` for a put, and `N` the standard normal distribution
function:

```
d1 = ln(F / K) / (sigma * sqrt(T)) + sigma * sqrt(T) / 2
d2 = d1 - sigma * sqrt(T)
```

### Method 1. Closed form

Used when the digital strike spread is zero.

```
cash digital  = N(w * d2)
asset digital = F * N(w * d1)
```

### Method 2. Strike spread

Used when the digital strike spread `eps` is above zero. The run script reads it from the
trade file (`Valuation Configuration > EquityBinaryOption > Relative_Digital_Spread`) unless
`RELATIVE_DIGITAL_SPREAD` is set.

```
cash digital  = w * (V(K * (1 - eps)) - V(K * (1 + eps))) / (2 * eps * K)
asset digital = w * V(K) + K * cash digital
```

`V` is the undiscounted Black value of a vanilla option. Each of the two spread strikes uses
the volatility at its own strike, so the slope of the smile is priced in.

### Present value

```
value = sign * Payoff * digital * DF(settlement)
```

`sign` is +1 for a bought option and -1 for a sold option.

## Quanto payout

For `Payoff_Type = Quanto`, set `QUANTO_FX_VOLATILITY` and `QUANTO_CORRELATION` in the run
script. The forward becomes `F * exp(-rho * sigma_S * sigma_X * T_F)`, where `sigma_S` is the
equity volatility read with the strike at the spot price. The volatility in the formula is not
changed. `Payoff_Type = Compo` is refused with an error.

## After expiry

Between the expiry date and the settlement date the fixing is known. Type it into
`EXPIRY_FIXING`. The value is then the known payout discounted to the settlement date. After
the settlement date the value is zero.

## Checks

| Check | Where |
|---|---|
| The sample deal `AUTOCALL_DIGITAL_EUROPEAN` against the target system's value | `validation_runs/equity_digital_option/`, relative difference 2.2e-14 |
| Cash call plus cash put equals the discount factor | `tests/test_equity_digital_option.py` |
| Asset call less `K` cash calls equals the vanilla call | `tests/test_equity_digital_option.py` |
| Strike spread on a flat surface approaches the closed form | `tests/test_equity_digital_option.py` |
| A parametric skew is read at each strike | `tests/test_equity_digital_option.py` |
| Settlement lag, sold side, quanto, after expiry, bad terms | `tests/test_equity_digital_option.py` |
