# Models

The pricing formulas. Each function takes numbers and arrays and returns values. No function
here reads a file or knows about a trade file.

The two files written for this validation are `digital_option_pv.py` and
`barrier_option_pv.py`. Their module notes set out every formula and its source.

## Files

| File | What it holds |
|---|---|
| `barrier_option_pv.py` | Closed form valuation of single barrier options that are monitored all the time. |
| `bond_pv.py` | Value of fixed rate bond cashflows and of a forward on a bond. |
| `cashflow_pv.py` | Value of fixed and floating interest cashflows, including compounded and averaged rates. |
| `commodity_pv.py` | Forward prices read off commodity curves and the value of commodity forwards and price legs. |
| `credit_pv.py` | Value of the protection leg and the premium leg of a credit default swap. |
| `digital_option_pv.py` | Valuation of European digital options with the Black model on a forward price. Shared by the commodity and the equity digital option. |
| `equity_pv.py` | Equity forward prices, the Black formula on a forward, and equity swap cashflows. |
| `fx_pv.py` | Forward FX rate from two interest rate curves. |
| `inflation_bond_pv.py` | Value of inflation linked bond cashflows and of a forward on an inflation linked bond. |
| `inflation_pv.py` | Consumer price index levels on reference dates and the value of inflation linked legs. |
