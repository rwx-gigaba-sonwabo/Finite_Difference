"""Closed form valuation of single barrier options that are monitored all the time.

A barrier option is a European call or put with one extra condition on the path of the
underlying price before expiry.

Knock out
    The option dies the first time the price touches the barrier. A cash rebate, if any,
    is paid at that moment.
Knock in
    The option only comes to life once the price touches the barrier. A cash rebate, if
    any, is paid at expiry when the barrier was never touched.

The barrier is either above the price (an up barrier) or below it (a down barrier). That
gives eight option types: up or down, in or out, call or put.

The model
---------
The underlying follows a lognormal process with a constant volatility ``sigma``, a constant
cost of carry ``b`` and a constant discount rate ``r``. Under these assumptions the value
has a closed form, built from six terms named A to F (Merton 1973, Reiner and Rubinstein
1991, as set out in Haug, "The Complete Guide to Option Pricing Formulas").

With ``S`` the price now, ``K`` the strike, ``H`` the barrier, ``T`` the time to expiry,
``R`` the rebate, ``N`` the standard normal distribution function and::

    v      = sigma * sqrt(T)
    mu     = (b - sigma**2 / 2) / sigma**2
    lambda = sqrt(mu**2 + 2 * r / sigma**2)
    x1 = ln(S / K) / v + (1 + mu) * v          x2 = ln(S / H) / v + (1 + mu) * v
    y1 = ln(H**2 / (S * K)) / v + (1 + mu) * v  y2 = ln(H / S) / v + (1 + mu) * v
    z  = ln(H / S) / v + lambda * v

    phi = +1 for a call, -1 for a put
    eta = +1 for a down barrier, -1 for an up barrier

the six terms are::

    A = phi * S * exp((b - r) * T) * N(phi * x1) - phi * K * exp(-r * T) * N(phi * (x1 - v))
    B = phi * S * exp((b - r) * T) * N(phi * x2) - phi * K * exp(-r * T) * N(phi * (x2 - v))
    C = phi * S * exp((b - r) * T) * (H / S)**(2 * (mu + 1)) * N(eta * y1)
        - phi * K * exp(-r * T) * (H / S)**(2 * mu) * N(eta * (y1 - v))
    D = phi * S * exp((b - r) * T) * (H / S)**(2 * (mu + 1)) * N(eta * y2)
        - phi * K * exp(-r * T) * (H / S)**(2 * mu) * N(eta * (y2 - v))
    E = R * exp(-r * T) * (N(eta * (x2 - v)) - (H / S)**(2 * mu) * N(eta * (y2 - v)))
    F = R * ((H / S)**(mu + lambda) * N(eta * z) + (H / S)**(mu - lambda) * N(eta * (z - 2 * lambda * v)))

``A`` is the plain European option. ``E`` is a rebate paid at expiry when the barrier is
never touched. ``F`` is a rebate paid at the moment the barrier is touched.

Which terms make up each option
-------------------------------
=================  ==================  ==================
Option type        Strike above H      Strike at or below H
=================  ==================  ==================
Down and in call   C + E               A - B + D + E
Up and in call     A + E               B - C + D + E
Down and in put    B - C + D + E       A + E
Up and in put      A - B + D + E       C + E
Down and out call  A - C + F           B - D + F
Up and out call    F                   A - B + C - D + F
Down and out put   A - B + C - D + F   F
Up and out put     B - D + F           A - C + F
=================  ==================  ==================

A barrier that is only checked at intervals
-------------------------------------------
When the barrier is checked at fixed intervals rather than all the time, the closed form
is still used, with the barrier moved away from the price by a factor
``exp(0.5826 * sigma * sqrt(interval))`` (Broadie, Glasserman and Kou 1997). An up barrier
moves up and a down barrier moves down.

All functions accept numbers or arrays for the market inputs.
"""

from __future__ import annotations

import numpy as np

from utils.maths import norm_cdf

#: Volatility floor. Barrier values are very sensitive to volatility near zero.
MIN_BARRIER_VOLATILITY = 0.05
#: Constant of the correction for a barrier that is checked at intervals: -zeta(1/2) / sqrt(2 * pi).
MONITORING_SHIFT_CONSTANT = 0.5826


def barrier_is_breached(spot, barrier, is_up: bool) -> np.ndarray:
    """True where the price is strictly beyond the barrier.

    A price exactly on the barrier does not count as a breach.
    """
    spot = np.asarray(spot, dtype=float)
    return spot > barrier if is_up else spot < barrier


def monitoring_adjusted_barrier(barrier: float, volatility, monitoring_interval_years: float,
                                is_up: bool) -> np.ndarray:
    """Barrier level to use in the closed form when the barrier is checked at intervals.

    Parameters
    ----------
    barrier : float
        The contractual barrier level.
    volatility : float or np.ndarray
        Volatility used to price the option.
    monitoring_interval_years : float
        Time between two barrier checks, in years. Zero means the barrier is watched all
        the time and the barrier is returned unchanged.
    is_up : bool
        ``True`` for an up barrier, ``False`` for a down barrier.
    """
    if monitoring_interval_years <= 0.0:
        return np.asarray(barrier, dtype=float) + 0.0 * np.asarray(volatility, dtype=float)
    direction = 1.0 if is_up else -1.0
    shift = MONITORING_SHIFT_CONSTANT * np.asarray(volatility, dtype=float) * np.sqrt(
        monitoring_interval_years)
    return barrier * np.exp(direction * shift)


def barrier_terms(spot, carry_rate, discount_rate, volatility, expiry: float, strike: float,
                  barrier, rebate: float, is_call: bool, is_up: bool) -> dict[str, np.ndarray]:
    """Compute the six building blocks A to F and the intermediate quantities.

    Parameters
    ----------
    spot : float or np.ndarray
        Price of the underlying now.
    carry_rate : float or np.ndarray
        Cost of carry ``b``. The forward price to expiry is ``spot * exp(b * expiry)``.
    discount_rate : float or np.ndarray
        Continuously compounded zero rate ``r`` to expiry.
    volatility : float or np.ndarray
        Volatility ``sigma``. Must be positive.
    expiry : float
        Time to expiry in years. Must be positive.
    strike : float
        Option strike ``K``.
    barrier : float or np.ndarray
        Barrier level ``H`` used in the formula.
    rebate : float
        Cash rebate ``R`` per unit of the underlying.
    is_call, is_up : bool
        Option type and barrier side.

    Returns
    -------
    dict
        Keys ``A`` to ``F`` plus ``x1, x2, y1, y2, z, mu, lam``, each an array.
    """
    if expiry <= 0.0:
        raise ValueError("expiry must be positive")
    spot = np.asarray(spot, dtype=float)
    sigma = np.asarray(volatility, dtype=float)
    if np.any(sigma <= 0.0):
        raise ValueError("volatility must be positive")
    b = np.asarray(carry_rate, dtype=float)
    r = np.asarray(discount_rate, dtype=float)
    barrier = np.asarray(barrier, dtype=float)

    phi = 1.0 if is_call else -1.0
    eta = -1.0 if is_up else 1.0

    v = sigma * np.sqrt(expiry)
    mu = (b - 0.5 * sigma ** 2) / sigma ** 2
    lam = np.sqrt(mu ** 2 + 2.0 * r / sigma ** 2)
    log_h_over_s = np.log(barrier / spot)

    x1 = np.log(spot / strike) / v + (1.0 + mu) * v
    x2 = np.log(spot / barrier) / v + (1.0 + mu) * v
    y1 = np.log(barrier ** 2 / (spot * strike)) / v + (1.0 + mu) * v
    y2 = log_h_over_s / v + (1.0 + mu) * v
    z = log_h_over_s / v + lam * v

    carry_discount = np.exp((b - r) * expiry)
    discount = np.exp(-r * expiry)
    power_asset = np.exp(2.0 * (mu + 1.0) * log_h_over_s)
    power_cash = np.exp(2.0 * mu * log_h_over_s)

    term_a = phi * spot * carry_discount * norm_cdf(phi * x1) - phi * strike * discount * norm_cdf(
        phi * (x1 - v))
    term_b = phi * spot * carry_discount * norm_cdf(phi * x2) - phi * strike * discount * norm_cdf(
        phi * (x2 - v))
    term_c = (phi * spot * carry_discount * power_asset * norm_cdf(eta * y1)
              - phi * strike * discount * power_cash * norm_cdf(eta * (y1 - v)))
    term_d = (phi * spot * carry_discount * power_asset * norm_cdf(eta * y2)
              - phi * strike * discount * power_cash * norm_cdf(eta * (y2 - v)))
    term_e = rebate * discount * (norm_cdf(eta * (x2 - v)) - power_cash * norm_cdf(eta * (y2 - v)))
    term_f = rebate * (np.exp((mu + lam) * log_h_over_s) * norm_cdf(eta * z)
                       + np.exp((mu - lam) * log_h_over_s) * norm_cdf(eta * (z - 2.0 * lam * v)))

    return {"A": term_a, "B": term_b, "C": term_c, "D": term_d, "E": term_e, "F": term_f,
            "x1": x1, "x2": x2, "y1": y1, "y2": y2, "z": z, "mu": mu, "lam": lam}


def barrier_formula_label(is_call: bool, is_up: bool, is_knock_in: bool, strike_above_barrier: bool) -> str:
    """Name the combination of terms that values one option type, for example ``"A - C + F"``."""
    if is_knock_in:
        if is_call and not is_up:
            return "C + E" if strike_above_barrier else "A - B + D + E"
        if is_call and is_up:
            return "A + E" if strike_above_barrier else "B - C + D + E"
        if not is_up:
            return "B - C + D + E" if strike_above_barrier else "A + E"
        return "A - B + D + E" if strike_above_barrier else "C + E"
    if is_call and not is_up:
        return "A - C + F" if strike_above_barrier else "B - D + F"
    if is_call and is_up:
        return "F" if strike_above_barrier else "A - B + C - D + F"
    if not is_up:
        return "A - B + C - D + F" if strike_above_barrier else "F"
    return "B - D + F" if strike_above_barrier else "A - C + F"


def single_barrier_untouched_value(
    spot, carry_rate, discount_rate, volatility, expiry: float, strike: float, barrier,
    rebate: float, is_call: bool, is_up: bool, is_knock_in: bool,
    strike_above_barrier: bool | None = None,
) -> np.ndarray:
    """Value per unit of a barrier option whose barrier has not been touched yet.

    The inputs are those of :func:`barrier_terms`. ``strike_above_barrier`` picks the row of
    the formula table. It defaults to ``strike > barrier``. Pass it when ``barrier`` has
    been moved for interval monitoring, so the row is chosen on the contractual barrier.

    Returns
    -------
    np.ndarray
        Present value per unit of the underlying, rebate included.
    """
    terms = barrier_terms(spot, carry_rate, discount_rate, volatility, expiry, strike, barrier,
                          rebate, is_call, is_up)
    if strike_above_barrier is None:
        strike_above_barrier = bool(strike > np.max(barrier))
    label = barrier_formula_label(is_call, is_up, is_knock_in, strike_above_barrier)
    value = 0.0 * terms["A"]
    sign = 1.0
    for token in label.split():
        if token in "+-":
            sign = 1.0 if token == "+" else -1.0
        else:
            value = value + sign * terms[token]
    return value


def european_option_value(spot, carry_rate, discount_rate, volatility, expiry: float,
                          strike: float, is_call: bool) -> np.ndarray:
    """Present value per unit of a plain European option, on the same inputs as the barrier.

    ``exp(-r * T) * w * (F * N(w * d1) - K * N(w * d2))`` with ``F = S * exp(b * T)``.
    A knock in option is worth this once its barrier has been touched.
    """
    from models.digital_option_pv import black_vanilla_undiscounted

    forward = np.asarray(spot, dtype=float) * np.exp(np.asarray(carry_rate, dtype=float) * expiry)
    return black_vanilla_undiscounted(forward, strike, volatility, expiry, is_call) * np.exp(
        -np.asarray(discount_rate, dtype=float) * expiry)


def single_barrier_option_value(
    spot, carry_rate, discount_rate, volatility, expiry: float, strike: float, barrier: float,
    rebate: float, is_call: bool, is_up: bool, is_knock_in: bool,
    monitoring_interval_years: float = 0.0, min_volatility: float = MIN_BARRIER_VOLATILITY,
    barrier_touched_before=False,
) -> np.ndarray:
    """Present value per unit of a single barrier option, in every state of its life.

    This wraps the closed form with the states it does not cover:

    =============================  ==========================================
    State on the valuation date    Value per unit
    =============================  ==========================================
    Knock out, barrier touched     the rebate, paid now
    Knock in, barrier touched      the plain European option
    Knock out, at expiry, alive    the payoff ``max(w * (F - K), 0)``
    Knock in, at expiry, not in    the rebate
    Otherwise                      the closed form of the formula table
    =============================  ==========================================

    The barrier counts as touched when ``barrier_touched_before`` says so, or when the
    price on the valuation date is strictly beyond the barrier used in the formula.

    Parameters
    ----------
    spot, carry_rate, discount_rate, volatility, expiry, strike, rebate, is_call, is_up
        As in :func:`barrier_terms`. ``rebate`` is per unit of the underlying.
    barrier : float
        The contractual barrier level.
    is_knock_in : bool
        ``True`` for a knock in option, ``False`` for a knock out option.
    monitoring_interval_years : float
        Time between barrier checks in years. Zero means watched all the time.
    min_volatility : float
        Floor applied to ``volatility`` before pricing.
    barrier_touched_before : bool or np.ndarray
        ``True`` when the barrier is known to have been touched before the valuation date.
    """
    spot = np.asarray(spot, dtype=float)
    sigma = np.maximum(np.asarray(volatility, dtype=float), min_volatility)
    barrier_used = monitoring_adjusted_barrier(barrier, sigma, monitoring_interval_years, is_up)
    touched = np.logical_or(barrier_touched_before, barrier_is_breached(spot, barrier_used, is_up))
    phi = 1.0 if is_call else -1.0

    if expiry <= 0.0:
        payoff = np.maximum(phi * (spot - strike), 0.0)
        if is_knock_in:
            return np.where(touched, payoff, rebate)
        return np.where(touched, rebate, payoff)

    if is_knock_in:
        touched_value = european_option_value(
            spot, carry_rate, discount_rate, sigma, expiry, strike, is_call)
    else:
        touched_value = rebate + 0.0 * spot

    # The closed form needs the price on the live side of the barrier. Where the barrier
    # is already breached the result is replaced below, so a safe stand in price is used.
    safe_spot = np.where(touched, barrier_used * (0.5 if is_up else 2.0), spot)
    untouched_value = single_barrier_untouched_value(
        safe_spot, carry_rate, discount_rate, sigma, expiry, strike, barrier_used, rebate,
        is_call, is_up, is_knock_in, strike_above_barrier=bool(strike > barrier))
    return np.where(touched, touched_value, untouched_value)
