"""Consumer price index levels on reference dates and the value of inflation linked legs."""

from __future__ import annotations

import calendar as _cal
from datetime import date, timedelta
from typing import Callable, Dict, Optional

import numpy as np
import QuantLib as ql

from instruments.components.inflation_leg import InflationLeg
from market_data.risk_factor import CurveSlice, RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.cashflow_pv import filter_future_periods, compute_period_year_fractions
from utils.ql_helpers import to_ql_date, from_ql_date, generate_sub_periods


# ---------------------------------------------------------------------------
# BESA bracket helpers (module-level, reused by IndexLinkedSwap at construction)
# ---------------------------------------------------------------------------

def _first_of_month(d: date) -> date:
    return date(d.year, d.month, 1)


def _shift_months(d: date, months: int) -> date:
    """Shift a first-of-month date by an integer number of months."""
    y, m = divmod(d.month - 1 + months, 12)
    return date(d.year + y, m + 1, 1)

def _shift_months_any(d: date, months: int) -> date:
    """Shift any date (not just first-of-month) by an integer number of months.

    The day is clamped to the last day of the target month so that e.g.
    Jan-31 + 1M = Feb-28 rather than raising an error.  For first-of-month
    inputs this is identical to _shift_months.
    """
    m = d.month - 1 + months
    y, m = divmod(m, 12)
    y += d.year
    m += 1
    return date(y, m, min(d.day, _cal.monthrange(y, m)[1]))

def besa_bracket(end_date: date, lag_months: int = 4) -> tuple[date, date]:
    """
    Return the BESA (j, j1) bracket dates for a payment end date.

    Parameters
    ----------
    end_date : date
        Payment period end date.
    lag_months : int
        CPI publication lag (default 4, BESA convention).

    Returns
    -------
    (j, j1) : tuple[date, date]
        j  = first of month, lag_months before end_date's month.
        j1 = j + 1 month.
        When end_date.day == 1, j == j1 (no interpolation needed).
    """
    first = _first_of_month(end_date)
    j = _shift_months(first, -lag_months)
    j1 = _shift_months(j, 1)
    if end_date.day == 1:
        return j, j
    return j, j1


def _besa_fraction(end_date: date) -> float:
    """Intra-month linear interpolation weight for the BESA rule."""
    D = _cal.monthrange(end_date.year, end_date.month)[1]
    return (end_date.day - 1) / D


# ---------------------------------------------------------------------------
# Fixed-rate sub-period compounding helper
# ---------------------------------------------------------------------------

def _compound_fixed_rate(
    future: list[tuple[date, date, float]],
    rate: float,
    cp_months: int,
    calendar: ql.Calendar,
    convention: int,
    day_counter: ql.DayCounter,
) -> np.ndarray:
    """Interest factor per payment period using actual sub-period compounding.

    For each (start, end) pair in *future*, generates compounding sub-periods
    of *cp_months* length (with a possible short stub at the end) advancing
    forward from *start*.  Each sub-period's year fraction is computed with
    *day_counter*.  Returns:

        factor_i = ∏_j (1 + rate × τ_j) − 1

    for each period i, shape (n_periods,).

    This is the exact formula for the ``Compound`` field on a
    zero-coupon fixed leg: sub-periods run
    from the period start (= effective date for ZC legs) to the period end
    (= maturity), the same sub-periods a leg has
    when it compounds every 6 months.
    """
    factors = np.empty(len(future))
    for i, (start, end, _, _) in enumerate(future):
        subs = generate_sub_periods(start, end, cp_months, calendar, convention, day_counter, direction="Backward")
        cf = 1.0
        for _, _, tau_i in subs:
            cf *= (1.0 + rate * tau_i)
        factors[i] = cf - 1.0
    return factors


# ---------------------------------------------------------------------------
# Internal CPI resolver
# ---------------------------------------------------------------------------

def _get_cpi_level(
    ref_date: date,
    val_date: date,
    cpi_interp: Optional[Callable],
    hist_map: Dict[date, float],
    curve_day_counter: ql.DayCounter,
    ql_val: ql.Date,
    n_paths: int,
    cpi_fixings: Optional[Dict[date, np.ndarray]] = None,
    spot_cpi: Optional[np.ndarray] = None,
    inflation_rate_curve: Optional[YieldCurve] = None,
    last_pub_date: Optional[date] = None,
) -> np.ndarray:

    """Return the CPI level at ``ref_date`` as an ``(n_paths,)`` array.

    Resolution order depends on the mode and ``pub_cutoff``:

    In **two curve mode** (``inflation_rate_curve`` provided), bracket dates are
    split by ``pub_cutoff = last_pub_date`` (T_last_pub):

    *Confirmed published* (``ref_date <= pub_cutoff``):
      1. ``cpi_fixings``, per-path arrays accumulated from earlier simulation
         dates, read AT ``ref_date`` itself (the index level's own
         spot value at that past bracket date).
      2. ``hist_map``, scalar levels from pre-simulation historical data.
      3. Fallback: last entry in ``hist_map`` before ``pub_cutoff``, or zero.

    *Calendar-past but not yet published* (``pub_cutoff < ref_date <= val_date``):
      Falls straight through to forward projection below, ``cpi_fixings`` is
      NOT consulted here (a fixing keyed by ``ref_date`` cannot exist for an
      unpublished date, and an
      older bracket date's fixing is never used for a different date's projection;
      see below). For ZAR CPI (1-month publication lag), this zone covers the
      current month, the CPI for reference month M is only published
      mid-month M+1, so dates in (first-of-prev-month, val_date] are
      calendar-past but the release has not been made public yet.

    In **legacy mode** (no ``inflation_rate_curve``), ``pub_cutoff = val_date``
    and there is no "not yet published" zone, all past dates resolve via
    ``cpi_fixings`` / ``hist_map``.

    For **future** bracket dates (``ref_date > val_date``), and the unpublished
    zone in two curve mode, two forward-projection modes are supported:

    *two curve mode*, when both ``spot_cpi`` and ``inflation_rate_curve``
    are provided (Interpretation B, GBMPriceIndex):

      The market state stores ``CPI(val_date)`` (the continuously evolving
      stochastic level at the simulation date), not the last published step.
      The current spot level
      is ALWAYS the projection anchor, never
      a fixing stamped at some earlier bracket date, and only the discount
      factor's tenor is measured from ``T_last_pub``:

          CPI(T_ref) = spot_cpi(val_date) / DF_infl(T_ref - T_last_pub)

      When ``last_pub_date`` is ``None``, ``val_date`` is used as the origin
      instead (degenerate fallback, e.g. legacy-mode callers that never
      resolved a ``T_last_pub``):

          CPI(T_ref) = spot_cpi / DF_infl(T_ref - val_date)

    *Legacy mode*, when ``cpi_interp`` is provided: the CPI level is
    read directly from the ``CurveSlice`` containing a forward term
    structure of CPI index levels (tenor measured from ``val_date``).

    Parameters
    ----------
    ref_date : date
        First-of-month CPI bracket date.
    val_date : date
        Current simulation / valuation date.
    cpi_interp : callable or None
        Vectorised interpolator over CPI index levels.  Required for legacy
        mode; ``None`` when using two curve mode.
    hist_map : dict[date, float]
        Scalar historical CPI levels for bracket dates before the simulation.
    curve_day_counter : ql.DayCounter
        Day-count convention for year fractions.
    ql_val : ql.Date
        QuantLib representation of ``val_date``.
    n_paths : int
        Number of Monte Carlo paths.
    cpi_fixings : dict[date, np.ndarray] or None
        Per-path CPI levels for bracket dates that became past during the
        valuation run (accumulated by the caller via
        ``IndexLinkedSwap.compute_cpi_fixings()``).
    spot_cpi : np.ndarray or None
        Per-path spot CPI level (= ``CPI(val_date)`` under GBMPriceIndex /
        Interpretation B).  Provide together with ``inflation_rate_curve``
        to activate two curve mode.
    inflation_rate_curve : YieldCurve or None
        Pre-built real inflation rate curve used to grow the spot CPI to
        future reference dates.  Provide together with ``spot_cpi``.
    last_pub_date : date or None
        Last CPI publication date (``T_last_pub``) for two curve mode.
        Used as ``pub_cutoff`` to split confirmed-published bracket dates
        (resolved via ``hist_map``) from unpublished-past / future dates
        (resolved via forward projection).  When None, ``val_date`` is used
        as the cutoff (legacy behaviour, no unpublished-past zone).

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    # pub_cutoff: boundary between "confirmed published" (→ hist_map) and
    # "needs forward projection". In two curve mode this is T_last_pub (the
    # last CPI publication reference date). In legacy mode it is val_date,
    # which preserves the original behaviour for all past dates.
    pub_cutoff = (
        last_pub_date
        if (last_pub_date is not None and inflation_rate_curve is not None)
        else val_date
    )

    if ref_date <= val_date:
        # Priority 1: per-path fixings for confirmed published bracket dates only.
        # Gate on pub_cutoff: dates in the "unpublished past" zone (pub_cutoff <
        # ref_date <= val_date) must be projected from pub_cutoff via the inflation
        # curve, not served from cpi_fixings.  A stamped reset is only used
        # when ref_date <= last_published_date.
        if cpi_fixings is not None and ref_date in cpi_fixings and ref_date <= pub_cutoff:
            return np.asarray(cpi_fixings[ref_date], dtype=np.float64)

        # Priority 2: exact match in hist_map, checked BEFORE the pub_cutoff split.
        # Historical data loaded at trade setup is authoritative for any past bracket
        # date. This includes dates in the "unpublished past" zone (pub_cutoff <
        # ref_date <= val_date) where the CPI for that month may be present in
        # hist_map even though T_last_pub has not yet caught up to it (e.g. the most
        # recent month's data was pre-loaded from a data provider).
        if ref_date in hist_map:
            return np.full(n_paths, hist_map[ref_date], dtype=np.float64)

        if ref_date <= pub_cutoff:
            # Confirmed published, no exact hist_map match; use nearest before cutoff.
            known = [k for k in hist_map if k <= pub_cutoff]
            if known:
                return np.full(n_paths, hist_map[max(known)], dtype=np.float64)
            return np.zeros(n_paths, dtype=np.float64)
        
        # Unpublished past: pub_cutoff < ref_date <= val_date.
        # The bracket date has been crossed by the simulation but the CPI for that
        # reference month has not yet been officially released (publication lag).
        #
        # Two curve mode: fall through to forward projection below, grows spot_cpi
        # from T_last_pub to ref_date using the inflation rate curve.
        #
        # Legacy mode: no rate curve is available to project backwards from val_date.
        # Querying the CPI level curve at t_ref = yearFrac(val_date, ref_date) <= 0
        # is outside the curve's defined tenor range and returns wrong/zero values.
        # Use the most recent hist_map entry on or before val_date as the best proxy.
        if inflation_rate_curve is None:
            known = [k for k in hist_map if k <= val_date]
            if known:
                return np.full(n_paths, hist_map[max(known)], dtype=np.float64)
            return np.zeros(n_paths, dtype=np.float64)
        # Two curve mode: fall through to forward projection below.

    # Forward projection, reached for:
    #   (a) future dates (ref_date > val_date), and
    #   (b) two curve mode: calendar-past but unpublished (pub_cutoff < ref_date <= val_date)
    if inflation_rate_curve is not None:
        # The
        # market state's PriceIndex factor is read at val_date,
        #   last_published_index = PriceIndex level on the valuation date
        # and is *always* used as the numerator, regardless of whether any
        # bracket date has previously been crossed/stamped in cpi_fixings.  The
        # growth period is T_ref - T_last_pub
        # i.e. T_last_pub is only used to size the
        # discount factor's tenor, never to select a different numerator:
        #   CPI(T_ref) = spot_cpi(val_date) / DF_infl(T_ref - T_last_pub)
        #
        # A previous version of this function substituted cpi_fixings[j_last] (the
        # CPI level stamped at whichever bracket date was most recently crossed) as
        # the numerator instead of spot_cpi.  That is wrong: under
        # a continuously evolving index, CPI moves every day, so
        # cpi_fixings[j_last] and spot_cpi(val_date) are different points on the
        # same stochastic path once val_date has moved on from j_last, exactly
        # the case for an inflation-linked bond forward, whose schedule accumulates
        # many crossed bracket dates by the time a mid-life delivery date is
        # reached, unlike a single zero-coupon swap cashflow priced standalone
        # (cpi_fixings absent) where the two formulas happen to coincide.
        origin = to_ql_date(last_pub_date) if last_pub_date is not None else ql_val
        t_ref = float(curve_day_counter.yearFraction(origin, to_ql_date(ref_date)))
        df_infl = np.ravel(np.asarray(inflation_rate_curve.discount_factor(t_ref)))  # (n_paths,)
        anchor = np.asarray(spot_cpi).reshape(-1)
        df_infl = np.asarray(df_infl).reshape(-1)
        assert anchor.shape == df_infl.shape == (n_paths,), (anchor.shape, df_infl.shape)
        cpi_level = anchor / df_infl
        return cpi_level

    # Legacy mode: interpolate CPI levels directly from the CurveSlice
    t_ref = float(curve_day_counter.yearFraction(ql_val, to_ql_date(ref_date)))
    return cpi_interp(t_ref)  # (n_paths,)


# ---------------------------------------------------------------------------
# CPI setup / per-period index ratio (shared by inflation_leg_pv and the
# inflation-linked bond accrued-interest helpers in models/inflation_bond_pv.py)
# ---------------------------------------------------------------------------

def _resolve_cpi_setup(
    leg: InflationLeg,
    val_date: date,
    market_state: dict[str, RiskFactorSlice],
    cpi_interpolator: Callable,
    inflation_rate_interpolator: Optional[Callable],
    cpi_last_pub_date: Optional[date],
) -> tuple[Optional[np.ndarray], Optional[Callable], Optional[YieldCurve], Optional[date]]:
    """Resolve the CPI-mode setup shared across all bracket-date lookups for
    one pricing call: (spot_cpi, cpi_interp, infl_curve, last_pub_date).

    Extracted from ``inflation_leg_pv`` so the inflation-linked bond's
    accrued-interest calculation (``models.inflation_bond_pv``) can compute a
    single period's index ratio without duplicating the two curve /
    legacy-mode branch. Pure extraction, no behaviour change.
    """
    cpi_slice: CurveSlice = market_state[leg.cpi_curve_name]
    use_two_curve_mode = bool(
        leg.inflation_rate_curve_name and inflation_rate_interpolator is not None
    )
    if use_two_curve_mode:
        spot_cpi: Optional[np.ndarray] = cpi_slice.values[:].copy()
        infl_slice: CurveSlice = market_state[leg.inflation_rate_curve_name]
        infl_curve: Optional[YieldCurve] = YieldCurve(
            year_fracs=infl_slice.tenors,
            rates=infl_slice.values,
            interpolator=inflation_rate_interpolator,
        )
        cpi_interp: Optional[Callable] = None
        if cpi_last_pub_date is not None:
            last_pub_date: Optional[date] = cpi_last_pub_date
        else:
            last_pub_date = _shift_months(_first_of_month(val_date), -1)
    else:
        spot_cpi = None
        infl_curve = None
        cpi_interp = cpi_interpolator(cpi_slice.tenors, cpi_slice.values)
        last_pub_date = None
    return spot_cpi, cpi_interp, infl_curve, last_pub_date


def _index_ratio_at(
    end_date: date,
    leg: InflationLeg,
    val_date: date,
    hist_map: Dict[date, float],
    cpi_interp: Optional[Callable],
    spot_cpi: Optional[np.ndarray],
    infl_curve: Optional[YieldCurve],
    last_pub_date: Optional[date],
    curve_day_counter: ql.DayCounter,
    ql_val: ql.Date,
    n_paths: int,
    cpi_fixings: Optional[Dict[date, np.ndarray]],
) -> np.ndarray:
    """BESA index ratio (``CPI(end_date's lagged bracket) / base_cpi``) for a
    single accrual-end date, given an already-resolved CPI setup (see
    :func:`_resolve_cpi_setup`). Extracted from ``inflation_leg_pv``'s
    per-period loop, no behaviour change.
    """
    j, j1 = besa_bracket(end_date, leg.lag_months)

    if j == j1:
        cpi_j = _get_cpi_level(
            j, val_date, cpi_interp, hist_map,
            curve_day_counter, ql_val, n_paths,
            cpi_fixings=cpi_fixings,
            spot_cpi=spot_cpi,
            inflation_rate_curve=infl_curve,
            last_pub_date=last_pub_date,
        )
        cpi_j = np.ravel(np.asarray(cpi_j))
        return cpi_j / leg.base_cpi

    frac = _besa_fraction(end_date)
    cpi_j = _get_cpi_level(
        j, val_date, cpi_interp, hist_map,
        curve_day_counter, ql_val, n_paths,
        cpi_fixings=cpi_fixings,
        spot_cpi=spot_cpi,
        inflation_rate_curve=infl_curve,
        last_pub_date=last_pub_date,
    )
    cpi_j = np.ravel(np.asarray(cpi_j))

    cpi_j1 = _get_cpi_level(
        j1, val_date, cpi_interp, hist_map,
        curve_day_counter, ql_val, n_paths,
        cpi_fixings=cpi_fixings,
        spot_cpi=spot_cpi,
        inflation_rate_curve=infl_curve,
        last_pub_date=last_pub_date,
    )
    cpi_j = np.ravel(np.asarray(cpi_j))
    return (cpi_j + frac * (cpi_j1 - cpi_j)) / leg.base_cpi


# ---------------------------------------------------------------------------
# Inflation leg PV
# ---------------------------------------------------------------------------

def inflation_leg_pv(
    schedule: list[tuple[date, date, float]],
    leg: InflationLeg,
    base_notional: float,
    val_date: date,
    market_state: dict[str, RiskFactorSlice],
    discount_curve: YieldCurve,
    n_paths: int,
    cpi_interpolator: Callable,
    curve_day_counter: ql.DayCounter,
    historical_cpi_map: Optional[Dict[date, float]] = None,
    include_on_val_date: bool = True,
    cpi_fixings: Optional[Dict[date, np.ndarray]] = None,
    inflation_rate_interpolator: Optional[Callable] = None,
    cpi_last_pub_date: Optional[date] = None,
    calendar: Optional[ql.Calendar] = None,
    day_counter: Optional[ql.DayCounter] = None,
    convention: Optional[int] = None,
    cutoff_date: Optional[date] = None,
) -> np.ndarray:
    """
    Present value of an inflation-indexed leg, vectorised over Monte Carlo paths.

    Mechanics
    ---------
    For each future coupon period ``(start, end, accrual)``:

    1.  Compute the BESA bracket dates ``(j, j1)`` for ``end``:
            j  = first of month, ``leg.lag_months`` before ``end``.
            j1 = j + 1 month.

    2.  Obtain CPI levels at j (and j1 if needed) either from
        ``historical_cpi_map`` (when the bracket date ≤ val_date) or from
        the stochastic ``CurveSlice`` in the market state.

    3.  Apply the BESA linear interpolation formula:
            CPI(end) = cpi_j  (when end.day == 1)
            CPI(end) = cpi_j + frac * (cpi_j1 - cpi_j)  otherwise

    4.  Index ratio = ``CPI(end) / leg.base_cpi``.

    5.  Scaled notional = ``base_notional * index_ratio``.

    6.  Coupon cashflow = ``scaled_notional * accrual * (leg.fixed_rate + leg.spread)``.

    7.  At the last period, if ``leg.include_notional_exchange``, add
        ``base_notional * index_ratio`` as the final notional repayment.

    8.  Discount all cashflows to ``val_date`` and sum.

    CPI Curve Formats
    -----------------
    *Legacy mode* (``leg.inflation_rate_curve_name`` is empty):
      The ``CurveSlice`` at ``market_state[leg.cpi_curve_name]`` must carry
      a full forward term structure of CPI index levels across multiple tenors.
      ``cpi_interpolator`` is applied to this slice to query future levels.

    *two curve mode* (``leg.inflation_rate_curve_name`` is set and
    ``inflation_rate_interpolator`` is provided):
      ``market_state[leg.cpi_curve_name]`` need only contain the spot CPI
      level per path (``values[:, 0]``).
      ``market_state[leg.inflation_rate_curve_name]`` must contain a term
      structure of annualised real inflation rates (zero-rate convention).
      Forward CPI is then derived as:
        CPI(T) = spot_CPI / DF_infl(T) = spot_CPI × exp(∫[0→T] r_infl ds)

    Parameters
    ----------
    schedule : list of (accrual_start, accrual_end, accrual_fraction)
        The inflation leg payment schedule.
    leg : InflationLeg
        Leg parameters (real fixed rate, base CPI, lag, etc.).
    base_notional : float
        Notional amount in the reporting currency.
    val_date : date
        Current valuation / simulation date.
    market_state : dict[str, RiskFactorSlice]
        Factor values at this time step from the market state.
    discount_curve : YieldCurve
        Pre-built nominal discount curve (built by the caller using
        ``discount_interpolator``).
    n_paths : int
        Number of Monte Carlo paths.
    cpi_interpolator : callable
        Interpolator factory ``(tenors, values) -> callable`` applied to the
        CPI index level curve.  Linear interpolation is typical since the
        stored values are raw index levels, not rates.
    curve_day_counter : ql.DayCounter
        Day-count convention for year fractions.
    historical_cpi_map : dict[date, float] or None
        Scalar CPI levels for bracket dates that predate the simulation.
        Seeded from ``InflationIndex`` at trade construction.  For bracket
        dates that have become past *during* the simulation, ``cpi_fixings``
        (below) takes priority.
    include_on_val_date : bool
        Whether to include cashflows settling on ``val_date`` itself.
    cpi_fixings : dict[date, np.ndarray] or None
        Per-path CPI levels for bracket dates that became past during the
        valuation run (accumulated by the caller via
        ``IndexLinkedSwap.compute_cpi_fixings()``).  Takes priority over
        ``historical_cpi_map``.
    inflation_rate_interpolator : callable or None
        Interpolator factory for the real inflation rate curve
        (``leg.inflation_rate_curve_name``).  When provided alongside a
        non-empty ``leg.inflation_rate_curve_name``, activates the
        two-curve mode: forward CPI is derived from the spot level and the
        inflation rate curve rather than interpolated from a CPI level surface.
    cpi_last_pub_date : date or None
        Explicit last CPI publication date (``T_last_pub``) for two curve mode.
        When provided, forward CPI growth is measured from this date rather than
        ``val_date``, eliminating the systematic bias caused by the publication
        lag (typically 3, 4 months for ZAR).  When None the function derives
        ``T_last_pub`` automatically as the most recent key in
        ``historical_cpi_map ∪ cpi_fixings`` that is ≤ ``val_date``.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Present value of the inflation leg per path.
    """
    _cutoff = cutoff_date if cutoff_date is not None else val_date
    future = filter_future_periods(schedule, _cutoff, include_on_val_date)
    if not future:
        return np.zeros(n_paths)

    # Last end date across the *full* schedule (for notional exchange)
    last_end = max(e for _, e, _, _ in schedule)
    
    cpi_slice: CurveSlice = market_state[leg.cpi_curve_name]
    cpi_slice_tenors = cpi_slice.tenors if hasattr(cpi_slice, "tenors") and cpi_slice.tenors is not None else np.array([0.0])
    ql_val = to_ql_date(val_date)
    hist_map: Dict[date, float] = historical_cpi_map or {}

    # Two curve mode: spot CPI + separate inflation rate curve.
    # Legacy mode: forward CPI levels interpolated directly from cpi_slice.
    use_two_curve_mode = bool(
        leg.inflation_rate_curve_name and inflation_rate_interpolator is not None
    )
    if use_two_curve_mode:
        spot_cpi: Optional[np.ndarray] = cpi_slice.values[:].copy()
        infl_slice: CurveSlice = market_state[leg.inflation_rate_curve_name]
        infl_curve: Optional[YieldCurve] = YieldCurve(
            year_fracs=infl_slice.tenors,
            rates=infl_slice.values,
            interpolator=inflation_rate_interpolator,
        )
        cpi_interp: Optional[Callable] = None
        # Determine T_last_pub: the market state stores CPI(T_last_pub), so
        # forward growth must start from T_last_pub, not val_date.
        # Use the explicit override when provided; otherwise approximate from
        # val_date so that T_last_pub ADVANCES with the simulation (rather than
        # freezing at the last historical hist_map entry, which becomes years
        # stale at long simulation horizons and causes monotonically growing error).
        # Approximation:
        #   T_last_pub ≈ first_of_month(val_date) − (lag_months − 1) months.
        # For BESA (lag_months=4): 3 months before val_date's month start.
        if cpi_last_pub_date is not None:
            last_pub_date: Optional[date] = cpi_last_pub_date
        else:
            last_pub_date = _shift_months(_first_of_month(val_date), -1)
    else:
        spot_cpi = None
        infl_curve = None
        cpi_interp = cpi_interpolator(cpi_slice.tenors, cpi_slice.values)
        last_pub_date = None

    # Year fractions from val_date to each period end (for discounting)
    _, t_ends, t_pays, accruals = compute_period_year_fractions(
        future, val_date, curve_day_counter,
    )
    # (n_paths, n_periods)
    dfs = discount_curve.discount_factor(t_pays)

    n_periods = len(future)
    coupon_rate = leg.fixed_rate + leg.spread

    # Build index ratio matrix: (n_paths, n_periods)
    index_ratios = np.empty((n_paths, n_periods), dtype=np.float64)

    for i, (_, end_date, _, _) in enumerate(future):
        j, j1 = besa_bracket(end_date, leg.lag_months)

        if j == j1:
            cpi_j = _get_cpi_level(
                j, val_date, cpi_interp, hist_map,
                curve_day_counter, ql_val, n_paths,
                cpi_fixings=cpi_fixings,
                spot_cpi=spot_cpi,
                inflation_rate_curve=infl_curve,
                last_pub_date=last_pub_date,
            )

            cpi_j = np.ravel(np.asarray(cpi_j))
            est_cpi = cpi_j
            index_ratio_i = est_cpi / leg.base_cpi
            index_ratios[:, i] = index_ratio_i
        else:
            frac = _besa_fraction(end_date)
            cpi_j = _get_cpi_level(
                j, val_date, cpi_interp, hist_map,
                curve_day_counter, ql_val, n_paths,
                cpi_fixings=cpi_fixings,
                spot_cpi=spot_cpi,
                inflation_rate_curve=infl_curve,
                last_pub_date=last_pub_date,
            )
            cpi_j = np.ravel(np.asarray(cpi_j))

            cpi_j1 = _get_cpi_level(
                j1, val_date, cpi_interp, hist_map,
                curve_day_counter, ql_val, n_paths,
                cpi_fixings=cpi_fixings,
                spot_cpi=spot_cpi,
                inflation_rate_curve=infl_curve,
                last_pub_date=last_pub_date,
            )

            cpi_j1 = np.ravel(np.asarray(cpi_j1))

            est_cpi = (cpi_j + frac * (cpi_j1 - cpi_j))

        index_ratio_i = est_cpi / leg.base_cpi
        index_ratios[:,i] = index_ratio_i

    # Coupon interest factors: shape (n_periods,).
    # When compounding_period_months > 0, the period is split into actual sub-periods of that length
    # (advancing with the calendar from the period start, with a possible short stub
    # at the end), and the fixed rate is compounded period-by-period:
    #   factor = ∏_j (1 + rate × τ_j) − 1
    # This is the exact formula, e.g. a 1Y ZC at 10% with 6m compounding
    # gives (1 + 0.10×181/365) × (1 + 0.10×184/365) − 1 ≈ 10.244%, not 10% (simple).
    # For compounding_period_months == 0 the standard rate × tau formula is used.
    if leg.compounding_period_months > 0:
        if calendar is None or day_counter is None:
            raise ValueError(
                "calendar and day_counter must be provided when "
                "InflationLeg.compounding_period_months > 0"
            )
        interest_factors = _compound_fixed_rate(
            future, coupon_rate, leg.compounding_period_months,
            calendar, 
            convention if convention is not None else ql.ModifiedFollowing, 
            day_counter,
        )
    else:
        interest_factors = accruals * coupon_rate

    # Coupon cashflows: base_notional * index_ratio * interest_factor
    # index_ratios:     (n_paths, n_periods)
    # interest_factors: (n_periods,)  → broadcast
    cashflows = base_notional * index_ratios * interest_factors

    # Final notional exchange at maturity
    if leg.include_notional_exchange:
        for i, (_, end_date, _, _) in enumerate(future):
            if end_date == last_end:
                cashflows[:, i] += base_notional * index_ratios[:, i]
                break

    # PV = sum_i CF_i * DF_i   (n_paths,)
    return np.sum(cashflows * dfs, axis=1)
