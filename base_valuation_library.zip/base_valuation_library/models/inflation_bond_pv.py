"""Value of inflation linked bond cashflows and of a forward on an inflation linked bond."""

from __future__ import annotations

from datetime import date
from typing import Callable, Dict, Optional

import numpy as np
import QuantLib as ql

from instruments.components.inflation_leg import InflationLeg
from market_data.risk_factor import RiskFactorSlice
from market_data.yield_curve import YieldCurve
from models.inflation_pv import (
    _index_ratio_at,
    _resolve_cpi_setup,
    inflation_leg_pv,
)
from utils.ql_helpers import to_ql_date, advance_business_days

__all__ = [
    "inflation_bond_period_index_ratio",
    "inflation_bond_accrued_interest",
    "inflation_bond_forward_pv",
]


# ---------------------------------------------------------------------------
# Per-period index ratio / accrued interest for a standalone inflation-linked
# bond (as opposed to a swap leg netted against a nominal leg).
#
# The bond itself is priced exactly as InflationLeg/inflation_leg_pv already
# does for IndexLinkedSwap's inflation leg, each coupon's notional is
# scaled by the BESA index ratio at ITS OWN accrual end date, and the final
# period repays the index-ratio-scaled notional (leg.include_notional_exchange
# =True). A standalone inflation-linked bond is simply this leg's PV.
#
# What's new here is only what a bond forward additionally needs beyond
# inflation_leg_pv: (a) the PV of cashflows strictly after a given delivery
# date (inflation_leg_pv(cutoff_date=...) already covers this), and
# (b) accrued interest at an arbitrary query date, index-scaled by the
# containing period's own ratio, needed for the forward strike/K_dirty
# calculation, mirroring models.bond_pv.accrued_interest but per-path (CPI
# is stochastic) and index-scaled.
# ---------------------------------------------------------------------------


def inflation_bond_period_index_ratio(
    query_date: date,
    schedule: list[tuple[date, date, date, float]],
    leg: InflationLeg,
    val_date: date,
    market_state: dict[str, RiskFactorSlice],
    n_paths: int,
    cpi_interpolator: Callable,
    curve_day_counter: ql.DayCounter,
    historical_cpi_map: Optional[Dict[date, float]] = None,
    cpi_fixings: Optional[Dict[date, np.ndarray]] = None,
    inflation_rate_interpolator: Optional[Callable] = None,
    cpi_last_pub_date: Optional[date] = None,
) -> np.ndarray:
    """BESA index ratio for the schedule period containing *query_date*.

    Per ``InflationLeg``'s convention, the ratio used for an entire coupon
    period is computed **once, at that period's accrual end date** (not
    daily-interpolated across the period), so this looks up which period
    contains *query_date* and returns that period's own end-date ratio.

    Parameters
    ----------
    query_date : date
        Date to find the containing period for (e.g. a forward delivery
        date, for computing accrued interest or a forward strike).
    schedule : list of (accrual_start, accrual_end, payment_date, accrual_fraction)
        The bond's coupon schedule.
    leg, val_date, market_state, n_paths, cpi_interpolator, curve_day_counter,
    historical_cpi_map, cpi_fixings, inflation_rate_interpolator, cpi_last_pub_date :
        As in :func:`models.inflation_pv.inflation_leg_pv`.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    period_end = None
    for start, end, _pay, _a in schedule:
        if start <= query_date < end:
            period_end = end
            break
    if period_end is None:
        # query_date on/after the last period's start (including exactly on
        # a boundary), use the last period's own end date.
        period_end = schedule[-1][1]

    hist_map = historical_cpi_map or {}
    ql_val = to_ql_date(val_date)
    spot_cpi, cpi_interp, infl_curve, last_pub_date = _resolve_cpi_setup(
        leg, val_date, market_state, cpi_interpolator,
        inflation_rate_interpolator, cpi_last_pub_date,
    )
    return _index_ratio_at(
        period_end, leg, val_date, hist_map, cpi_interp, spot_cpi,
        infl_curve, last_pub_date, curve_day_counter, ql_val, n_paths,
        cpi_fixings,
    )


def inflation_bond_accrued_interest(
    schedule: list[tuple[date, date, date, float]],
    leg: InflationLeg,
    base_notional: float,
    query_date: date,
    val_date: date,
    market_state: dict[str, RiskFactorSlice],
    n_paths: int,
    cpi_interpolator: Callable,
    curve_day_counter: ql.DayCounter,
    day_counter: ql.DayCounter,
    historical_cpi_map: Optional[Dict[date, float]] = None,
    cpi_fixings: Optional[Dict[date, np.ndarray]] = None,
    inflation_rate_interpolator: Optional[Callable] = None,
    cpi_last_pub_date: Optional[date] = None,
    ex_coupon_days: int = 0,
    calendar: Optional[ql.Calendar] = None,
) -> np.ndarray:
    """Per-path accrued interest (absolute currency) at *query_date* for an
    inflation-linked bond.

    Index-ratio-scaled, per-path analogue of
    :func:`models.bond_pv.accrued_interest`: the containing period's real
    coupon accrual (``coupon_rate * yearFraction(period_start, query_date)``)
    is scaled by that SAME period's BESA index ratio (computed at its own
    accrual end date, see :func:`inflation_bond_period_index_ratio`), since
    CPI is stochastic there is one accrued-interest value per path rather
    than a single fraction of notional.

    BESA CUMEX (``ex_coupon_days`` > 0): mirrors ``accrued_interest``,
    inside the book-close window before the period's payment date, accrued
    interest is negative (the buyer forgoes the next coupon).

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Zero for every path if *query_date* falls outside every period
        (before the first period starts, or on/after an accrual-end
        boundary where accrual has just reset).
    """
    ql_query = to_ql_date(query_date)
    coupon_rate = leg.fixed_rate + leg.spread

    for start, accrual_end, pay_date, _ in schedule:
        if start <= query_date < accrual_end:
            # Compute the ratio for THIS period directly at its own end date
            # and do not search again via inflation_bond_period_index_ratio(
            # accrual_end, ...): that function's containment test is
            # ``start <= q < end`` (exclusive upper bound), so passing this
            # same accrual_end back in as the query would match the NEXT
            # period instead of this one. Caught by a sloped-CPI-curve
            # regression test (a flat CPI term structure masks the bug,
            # since every bracket date then resolves to the same ratio).
            hist_map = historical_cpi_map or {}
            ql_val = to_ql_date(val_date)
            spot_cpi, cpi_interp, infl_curve, last_pub_date = _resolve_cpi_setup(
                leg, val_date, market_state, cpi_interpolator,
                inflation_rate_interpolator, cpi_last_pub_date,
            )
            index_ratio = _index_ratio_at(
                accrual_end, leg, val_date, hist_map, cpi_interp, spot_cpi,
                infl_curve, last_pub_date, curve_day_counter, ql_val, n_paths,
                cpi_fixings,
            )
            indexed_notional = base_notional * index_ratio  # (n_paths,)

            if ex_coupon_days > 0 and calendar is not None:
                ql_pay = to_ql_date(pay_date)
                bcd = calendar.advance(
                    ql_pay, ql.Period(-ex_coupon_days, ql.Days), ql.Preceding,
                )
                if ql_query >= bcd:
                    tau = float(day_counter.yearFraction(ql_query, ql_pay))
                    return -indexed_notional * coupon_rate * tau

            tau = float(day_counter.yearFraction(to_ql_date(start), ql_query))
            return indexed_notional * coupon_rate * tau

    return np.zeros(n_paths, dtype=np.float64)


# ---------------------------------------------------------------------------
# Inflation-linked bond forward, 3-curve cash-and-carry, per-path
# ---------------------------------------------------------------------------


def inflation_bond_forward_pv(
    schedule: list[tuple[date, date, date, float]],
    leg: InflationLeg,
    base_notional: float,
    val_date: date,
    delivery_date: date,
    market_state: dict[str, RiskFactorSlice],
    n_paths: int,
    cpi_interpolator: Callable,
    curve_day_counter: ql.DayCounter,
    day_counter: ql.DayCounter,
    bond_curve: YieldCurve,
    forward_real_clean_price: Optional[float] = None,
    settlement_amount: Optional[float] = None,
    direction: int = 1,
    ex_coupon_days: int = 0,
    ql_calendar: Optional[ql.Calendar] = None,
    repo_curve: Optional[YieldCurve] = None,
    forward_curve: Optional[YieldCurve] = None,
    historical_cpi_map: Optional[Dict[date, float]] = None,
    cpi_fixings: Optional[Dict[date, np.ndarray]] = None,
    inflation_rate_interpolator: Optional[Callable] = None,
    cpi_last_pub_date: Optional[date] = None,
    calendar: Optional[ql.Calendar] = None,
    convention: Optional[int] = None,
    include_on_val_date: bool = False,
) -> np.ndarray:
    """MTM value of a forward contract on an inflation-linked bond.

    Structurally identical to :func:`models.bond_pv.bond_forward_pv`'s
    three-curve cash-and-carry formula, the underlying is simply an
    inflation-linked bond (an ``InflationLeg`` with
    ``include_notional_exchange=True``) instead of a plain fixed-coupon
    bond, so every cashflow (coupon and final notional) is scaled by the
    BESA index ratio applicable to *its own* accrual end date, exactly as
    ``IndexLinkedSwap``'s inflation leg already does. CPI is stochastic, so
    unlike the nominal bond forward, both the underlying PV and the forward
    strike/accrued interest are genuinely **per-path**.

    Three-curve roles (identical to ``bond_forward_pv``)::

        bond_curve (nominal, e.g. "ZAR-ILB")
            Discounts the underlying's cashflows, computes PV_after
            (dirty PV of cashflows strictly after delivery_date).
        repo_curve
            Carries PV_after forward from val_date to delivery_date
            (financing rate). Defaults to bond_curve when None.
        forward_curve
            Discounts the forward payoff back to val_date. Defaults to
            bond_curve when None.

    NPV formula::

        NPV(t) = direction * [PV_after(t) * DF_fwd(t,T) / DF_repo(t,T)
                              - K_dirty(t) * DF_fwd(t,T)]

    where ``T = delivery_date`` and ``K_dirty`` is per-path:

    - ``settlement_amount`` given: ``K_dirty = settlement_amount`` for every
      path (a pre-agreed absolute cash amount, not index-scaled, the same
      treatment as
      ``BondForward``/``bond_forward_pv`` already do).
    - Otherwise: ``K_dirty(path) = (forward_real_clean_price * notional
      + accrued_indexed(path)) * index_ratio_at_delivery(path)``, the
      **real** (inflation-unadjusted) clean price and accrued interest are
      converted to a nominal cash amount using the BESA index ratio of the
      period containing ``delivery_date``. This is the genuinely stochastic
      piece: two parties can agree on a fixed real clean price today, but
      the actual nominal cash settled at delivery depends on realised
      inflation between now and then, exactly the inflation risk the
      forward is written to capture.

      Note the real accrued fraction itself is NOT separately re-scaled by
      the index ratio in this branch (unlike the nominal-cashflow K_dirty
      formula for coupons), ``accrued_indexed`` from
      :func:`inflation_bond_accrued_interest` already returns an
      index-scaled absolute amount, so it is added directly, not multiplied
      again by ``index_ratio_at_delivery``. See the accrued-interest
      docstring: it uses the SAME period-end ratio internally, so the two
      terms are consistent by construction (both scaled by
      ``index_ratio(period containing delivery_date)``).

    Parameters
    ----------
    schedule : list of (accrual_start, accrual_end, payment_date, accrual_fraction)
    leg : InflationLeg
        Real coupon rate, CPI curve name, base CPI, lag, etc.
    base_notional : float
        Face value.
    val_date : date
    delivery_date : date
        Forward delivery / settlement date. Must be strictly before the
        bond's maturity (last schedule accrual end).
    market_state : dict[str, RiskFactorSlice]
        Must contain ``leg.cpi_curve_name`` (and
        ``leg.inflation_rate_curve_name`` in two curve mode).
    n_paths : int
    cpi_interpolator : callable
    curve_day_counter : ql.DayCounter
        Day count for curve year fractions (discounting, index-ratio
        bracket-date year fractions).
    day_counter : ql.DayCounter
        Accrual day count (for accrued interest).
    bond_curve : YieldCurve
        Nominal discount curve for the underlying inflation-linked bond.
    forward_real_clean_price : float or None
        Agreed forward clean price, in REAL terms, as a fraction of par
        (e.g. 0.985). Used only when *settlement_amount* is None.
    settlement_amount : float or None
        Pre-agreed dirty settlement amount in absolute currency units.
        Takes priority over *forward_real_clean_price* when provided.
    direction : int
        +1 for buyer (long forward); -1 for seller (short).
    ex_coupon_days, ql_calendar : as in ``bond_forward_pv`` (BESA CUMEX).
    repo_curve, forward_curve : YieldCurve or None
        Default to *bond_curve* when None (single-curve fallback).
    historical_cpi_map, cpi_fixings, inflation_rate_interpolator,
    cpi_last_pub_date : as in ``inflation_leg_pv``.
    calendar, convention : ql.Calendar / int, optional
        Only required when ``leg.compounding_period_months > 0``,
        forwarded to ``inflation_leg_pv``.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    T_spot = advance_business_days(val_date,3,"ZAR")
    T_settle = advance_business_days(delivery_date,3,"ZAR")

    if val_date > T_settle:
        return np.zeros(n_paths)

    _repo = repo_curve if repo_curve is not None else bond_curve
    _fwd = forward_curve if forward_curve is not None else bond_curve

    # PV of bond cashflows paid strictly after delivery (using bond curve).
    pv_after = inflation_leg_pv(
        schedule=schedule,
        leg=leg,
        base_notional=base_notional,
        val_date=val_date,
        market_state=market_state,
        discount_curve=bond_curve,
        n_paths=n_paths,
        cpi_interpolator=cpi_interpolator,
        curve_day_counter=curve_day_counter,
        historical_cpi_map=historical_cpi_map,
        cpi_fixings=cpi_fixings,
        inflation_rate_interpolator=inflation_rate_interpolator,
        cpi_last_pub_date=cpi_last_pub_date,
        calendar=calendar,
        day_counter=day_counter,
        convention=convention,
        cutoff_date=delivery_date,
        include_on_val_date=include_on_val_date,
    )

    pv_spot = pv_after #/ _repo.discount_factor(T_spot_yrfrc)

    if settlement_amount is not None:
        k_dirty = np.full(n_paths, float(settlement_amount), dtype=np.float64)
    else:
        if forward_real_clean_price is None:
            raise ValueError(
                "either settlement_amount or forward_real_clean_price must be given"
            )
        index_ratio_delivery = inflation_bond_period_index_ratio(
            delivery_date, schedule, leg, val_date, market_state, n_paths,
            cpi_interpolator, curve_day_counter, historical_cpi_map,
            cpi_fixings, inflation_rate_interpolator, cpi_last_pub_date,
        )
        accrued_indexed = inflation_bond_accrued_interest(
            schedule, leg, base_notional, delivery_date, val_date, market_state,
            n_paths, cpi_interpolator, curve_day_counter, day_counter,
            historical_cpi_map=historical_cpi_map, cpi_fixings=cpi_fixings,
            inflation_rate_interpolator=inflation_rate_interpolator,
            cpi_last_pub_date=cpi_last_pub_date,
            ex_coupon_days=ex_coupon_days, calendar=ql_calendar,
        )
        k_dirty = (
            forward_real_clean_price * base_notional * index_ratio_delivery
            + accrued_indexed
        )

    # Discount factors to delivery from each curve: shape (n_paths,)
    T_del = float(curve_day_counter.yearFraction(
        to_ql_date(val_date), to_ql_date(T_settle),
    ))
    df_repo = _repo.discount_factor(T_del)   # financing curve, carries dirty price forward
    df_fwd  = _fwd.discount_factor(T_del)    # payoff discount curve, discounts the payoff

    # Three-curve NPV:
    #   NPV = direction * [PV_after * (df_fwd / df_repo) - K_dirty * df_fwd]
    # When repo = fwd = bond_curve: df_fwd/df_repo = 1 -> reduces to single-curve formula.
    strike_npv = k_dirty * df_fwd
    fwrd_npv = direction * (pv_spot * (df_fwd / df_repo) - strike_npv)
    return fwrd_npv
