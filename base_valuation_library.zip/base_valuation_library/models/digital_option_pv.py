"""Valuation of European digital options with the Black model on a forward price.

A European digital option pays a fixed amount when it expires in the money, and nothing
otherwise. Two payout styles are covered:

``cash``
    Pays one unit of currency when in the money.
``asset``
    Pays one unit of the underlying, worth the fixing price, when in the money.

Two ways of valuing the digital are provided.

Closed form
    One volatility, read at the strike. A cash digital call is worth ``N(d2)``.
    This ignores the slope of the volatility smile.

Strike spread
    The digital is replicated with two vanilla options struck just below and just above
    the strike. Each vanilla option uses the volatility at its own strike, so the slope of
    the smile is priced in. This is the usual market treatment of digital risk.

All functions return undiscounted values per unit of payout. The caller applies the payout
size, the buy or sell sign, and the discount factor. Inputs can be numbers or arrays.

Notation
--------
``F`` forward price, ``K`` strike, ``sigma`` volatility, ``T`` time to expiry in years,
``w`` is +1 for a call and -1 for a put, ``N`` the standard normal distribution function.

``d1 = ln(F / K) / (sigma * sqrt(T)) + sigma * sqrt(T) / 2`` and ``d2 = d1 - sigma * sqrt(T)``.
"""

from __future__ import annotations

import numpy as np

from utils.maths import norm_cdf

#: Smallest standard deviation used in the Black formula. Keeps ``d1`` and ``d2`` finite.
MIN_STANDARD_DEVIATION = 1e-5
#: Smallest forward price used in the Black formula. Keeps the logarithm finite.
MIN_FORWARD = 1e-5


def _black_terms(forward, strike, volatility, expiry: float):
    """Return ``(forward, d1, d2)`` for the Black formula, with the safety floors applied."""
    forward = np.maximum(np.asarray(forward, dtype=float), MIN_FORWARD)
    std_dev = np.maximum(np.asarray(volatility, dtype=float) * np.sqrt(expiry), MIN_STANDARD_DEVIATION)
    d1 = np.log(forward / strike) / std_dev + 0.5 * std_dev
    return forward, d1, d1 - std_dev


def black_vanilla_undiscounted(forward, strike, volatility, expiry: float, is_call: bool) -> np.ndarray:
    """Undiscounted Black value of a European call or put on a forward price.

    ``w * (F * N(w * d1) - K * N(w * d2))``. With no time left the value is the payoff
    ``max(w * (F - K), 0)``.
    """
    w = 1.0 if is_call else -1.0
    if expiry <= 0.0:
        return np.maximum(w * (np.asarray(forward, dtype=float) - strike), 0.0)
    forward, d1, d2 = _black_terms(forward, strike, volatility, expiry)
    return w * (forward * norm_cdf(w * d1) - strike * norm_cdf(w * d2))


def black_cash_digital_undiscounted(forward, strike, volatility, expiry: float,
                                    is_call: bool) -> np.ndarray:
    """Undiscounted closed form value of a digital paying one unit of cash.

    ``N(w * d2)``, the probability of expiring in the money under the pricing measure.
    With no time left the value is 1 when ``w * (F - K) > 0`` and 0 otherwise.
    """
    w = 1.0 if is_call else -1.0
    if expiry <= 0.0:
        return (w * (np.asarray(forward, dtype=float) - strike) > 0.0).astype(float)
    _, _, d2 = _black_terms(forward, strike, volatility, expiry)
    return norm_cdf(w * d2)


def black_asset_digital_undiscounted(forward, strike, volatility, expiry: float,
                                     is_call: bool) -> np.ndarray:
    """Undiscounted closed form value of a digital paying one unit of the underlying.

    ``F * N(w * d1)``. With no time left the value is ``F`` when in the money, else 0.
    """
    w = 1.0 if is_call else -1.0
    if expiry <= 0.0:
        forward = np.asarray(forward, dtype=float)
        return forward * (w * (forward - strike) > 0.0)
    forward, d1, _ = _black_terms(forward, strike, volatility, expiry)
    return forward * norm_cdf(w * d1)


def strike_spread_strikes(strike: float, relative_spread: float) -> tuple[float, float]:
    """Return the lower and upper strikes of the replicating spread.

    The strikes sit ``strike * relative_spread`` below and above the digital's strike.
    """
    return strike * (1.0 - relative_spread), strike * (1.0 + relative_spread)


def cash_digital_by_strike_spread_undiscounted(
    forward, strike: float, volatility_low, volatility_high, expiry: float,
    is_call: bool, relative_spread: float,
) -> np.ndarray:
    """Undiscounted value of a one unit cash digital, replicated with two vanilla options.

    A call digital is a long call struck at ``K * (1 - eps)`` and a short call struck at
    ``K * (1 + eps)``, scaled by ``1 / (2 * eps * K)``. A put digital is the mirror image.
    As ``eps`` goes to zero this becomes minus the strike derivative of the vanilla price,
    which includes the effect of the smile slope.

    Parameters
    ----------
    forward : float or np.ndarray
        Forward price of the underlying for the option's fixing.
    strike : float
        Strike of the digital.
    volatility_low, volatility_high : float or np.ndarray
        Volatility read at the lower strike and at the upper strike.
    expiry : float
        Time to expiry in years.
    is_call : bool
        ``True`` for a call digital, ``False`` for a put digital.
    relative_spread : float
        Half width of the spread as a fraction of the strike, ``eps``. Must be positive.
    """
    if relative_spread <= 0.0:
        raise ValueError("relative_spread must be positive for the strike spread method")
    w = 1.0 if is_call else -1.0
    strike_low, strike_high = strike_spread_strikes(strike, relative_spread)
    value_low = black_vanilla_undiscounted(forward, strike_low, volatility_low, expiry, is_call)
    value_high = black_vanilla_undiscounted(forward, strike_high, volatility_high, expiry, is_call)
    return w * (value_low - value_high) / (2.0 * relative_spread * strike)


def asset_digital_by_strike_spread_undiscounted(
    forward, strike: float, volatility, volatility_low, volatility_high, expiry: float,
    is_call: bool, relative_spread: float,
) -> np.ndarray:
    """Undiscounted value of a one unit asset digital, using the strike spread method.

    An asset digital pays the underlying when in the money. It equals a vanilla option
    plus ``K`` cash digitals: ``w * vanilla(K) + K * cash_digital(K)``. The vanilla option
    uses the volatility at the strike. The cash digital uses the strike spread.
    """
    w = 1.0 if is_call else -1.0
    vanilla = black_vanilla_undiscounted(forward, strike, volatility, expiry, is_call)
    cash_digital = cash_digital_by_strike_spread_undiscounted(
        forward, strike, volatility_low, volatility_high, expiry, is_call, relative_spread)
    return w * vanilla + strike * cash_digital


def composite_volatility(volatility, fx_volatility, correlation: float) -> np.ndarray:
    """Volatility of the product of two lognormal prices.

    ``sqrt(sigma_S**2 + 2 * rho * sigma_S * sigma_X + sigma_X**2)``. Used when the option is
    written on a foreign currency price converted into the payout currency.
    """
    volatility = np.asarray(volatility, dtype=float)
    return np.sqrt(volatility ** 2 + 2.0 * correlation * volatility * fx_volatility + fx_volatility ** 2)
