"""Forward prices read off commodity curves and the value of commodity forwards and price legs."""

from __future__ import annotations

from datetime import date

import numpy as np
import QuantLib as ql

from instruments.components.commodity_price_leg import (
    CommodityLegType,
    CommodityPriceLeg,
    PriceConstruction,
)
from market_data.risk_factor import RiskFactorSlice
from market_data.yield_curve import YieldCurve
from utils.interpolation import (
    excel_serials_to_year_fracs,
    get_forward_price_from_slice,
    linear_interpolator,
)
from utils.ql_helpers import advance_business_days, to_ql_date


def fx_forward_rate(
    fx_spot: np.ndarray,
    dom_curve: YieldCurve,
    for_curve: YieldCurve,
    T_pay: float,
    fx_settlement_T: float = 0.0,
) -> np.ndarray:
    """FX forward rate from the FX settlement date to the payment date.

    Uses covered interest-rate parity with continuously-compounded zero
    rates from ``dom_curve`` (domestic, e.g. ZAR-USD-BASIS) and
    ``for_curve`` (foreign, e.g. USD-SOFR).

    For FX quoted as *domestic / foreign* (e.g. ZAR/USD):

        FX_fwd(T) = FX_spot * DF_for(T) / DF_dom(T)

    When the observed FX spot settles at ``fx_settlement_T`` (rather than
    T+0) the formula is adjusted:

        FX_fwd(T_pay) = FX_spot
                        * DF_for(T_pay) * DF_dom(T_s)
                        / (DF_for(T_s)  * DF_dom(T_pay))

    which equals the forward from the settlement date T_s to T_pay,
    consistent with standard cross-currency arbitrage conditions.

    Parameters
    ----------
    fx_spot : np.ndarray, shape (n_paths,)
        FX spot rate (domestic / foreign, e.g. ZAR/USD).
    dom_curve : YieldCurve
        Domestic yield curve (e.g. ZAR-USD-BASIS).
    for_curve : YieldCurve
        Foreign yield curve (e.g. USD-SOFR).
    T_pay : float
        Year fraction from val_date to the payment date.
    fx_settlement_T : float
        Year fraction from val_date to the FX spot settlement date
        (e.g. T+2 business days for most FX markets).  Set to 0 to
        treat the market observable as a T+0 rate.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        FX forward rate at T_pay.
    """
    df_dom_pay = dom_curve.discount_factor(T_pay)   # (n_paths,)
    df_for_pay = for_curve.discount_factor(T_pay)   # (n_paths,)

    if fx_settlement_T > 0.0:
        df_dom_s = dom_curve.discount_factor(fx_settlement_T)  # (n_paths,)
        df_for_s = for_curve.discount_factor(fx_settlement_T)  # (n_paths,)
        return fx_spot * (df_for_pay * df_dom_s) / (df_for_s * df_dom_pay)
    else:
        return fx_spot * df_for_pay / df_dom_pay


def commodity_average_forward_pv(
    avg_price: np.ndarray,
    strike: float,
    notional: float,
    is_composite: bool,
    fx_spot: np.ndarray,
    dom_curve: YieldCurve,
    for_curve: YieldCurve,
    mm_curve: YieldCurve,
    T_pay: float,
    fx_settlement_T: float = 0.0,
    direction: int = 1,
) -> np.ndarray:
    """PV of a commodity average forward under the ZAR-CSA discounting framework.

    All payoffs are discounted using the money-market (ZAR-SWAP) curve
    regardless of contract denomination.  The ZAR-CSA adjustment converts
    the USD payoff to ZAR via the FX forward, discounts at the ZAR money
    market rate, then converts back to USD, which under no-arbitrage
    equates to discounting the USD payoff at the USD rate.

    **Standard contract** (USD underlying, USD-denominated payoff):

        payoff_USD  = direction * (avg_price - strike) * notional
        PV_ZAR      = payoff_USD * FX_fwd(T_pay) * DF_MM(T_pay)
        PV_USD      = PV_ZAR / FX_spot

    **Composite contract** (USD underlying, ZAR-denominated payoff/strike):

        payoff_ZAR  = direction * (avg_price * FX_fwd(T_pay) - strike_ZAR) * notional
        PV_ZAR      = payoff_ZAR * DF_MM(T_pay)

    Parameters
    ----------
    avg_price : np.ndarray, shape (n_paths,)
        Arithmetic average of commodity forward prices in USD per unit.
    strike : float
        Strike price.  In USD for a standard contract; in ZAR for a
        composite contract.
    notional : float
        Quantity (e.g. number of barrels).
    is_composite : bool
        If ``True``, the payoff currency is domestic (ZAR) and the
        strike is quoted in ZAR.  If ``False``, the payoff currency is
        foreign (USD) with ZAR-CSA discounting applied.
    fx_spot : np.ndarray, shape (n_paths,)
        FX spot rate (ZAR/USD, i.e. domestic / foreign).
    dom_curve : YieldCurve
        Domestic curve used in the FX forward calculation
        (ZAR-USD-BASIS).
    for_curve : YieldCurve
        Foreign curve used in the FX forward calculation (USD-SOFR).
    mm_curve : YieldCurve
        Money-market curve used for discounting all payoffs (ZAR-SWAP).
    T_pay : float
        Year fraction from val_date to the payment date.
    fx_settlement_T : float
        Year fraction from val_date to the FX spot settlement date
        (default 0 = T+0 spot convention).
    direction : int
        ``+1`` for a long position (receive avg, pay strike) or ``-1``
        for a short position (pay avg, receive strike).  Default ``+1``.

    Returns
    -------
    np.ndarray, shape (n_paths,)
        Present value per path.
        In USD for a standard contract; in ZAR for a composite contract.
    """
    fx_fwd = fx_forward_rate(
        fx_spot, dom_curve, for_curve, T_pay, fx_settlement_T,
    )                                       # (n_paths,)
    df_mm = mm_curve.discount_factor(T_pay) # (n_paths,)

    if is_composite:
        # Payoff denominated in ZAR
        payoff = direction * (avg_price * fx_fwd - strike) * notional  # (n_paths,)
        return payoff * df_mm
    else:
        # Payoff denominated in USD; apply ZAR-CSA adjustment
        payoff_usd = direction * (avg_price - strike) * notional        # (n_paths,)
        pv_zar = payoff_usd * fx_fwd * df_mm                           # (n_paths,)
        return pv_zar / fx_spot


# ---------------------------------------------------------------------------
# Commodity Price Swap (float-for-float / fixed-for-float, single-currency)
# ---------------------------------------------------------------------------

def commodity_carry_forward_price(
    spot: np.ndarray,
    carry_curve: YieldCurve,
    t_spot: float,
    t_settle: float,
) -> np.ndarray:
    """Cost-of-carry forward price: spot rolled forward at the financing rate.

        F(t; t_spot, T_settle) = S(t_spot) * DF_carry(t_spot) / DF_carry(T_settle)

    Both discount factors are read off *carry_curve* rooted at the
    valuation date, so the ratio is the forward growth factor over
    [t_spot, T_settle] (> 1 for positive rates when T_settle > t_spot), 
    the same cash-and-carry construction used by EquityForward, applied
    here with no dividend/convenience-yield leg.

    Parameters
    ----------
    spot : np.ndarray, shape (n_paths,)
        Underlying spot price at t_spot.
    carry_curve : YieldCurve
        Financing curve (e.g. ESTR) used to roll the spot forward.
    t_spot : float
        Year fraction from val_date to the spot date.
    t_settle : float
        Year fraction from val_date to the settlement date.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    df_spot = carry_curve.discount_factor(t_spot)
    df_settle = carry_curve.discount_factor(t_settle)
    return spot * df_spot / df_settle


def _resolve_carry_curve(
    leg: CommodityPriceLeg,
    market_state: dict[str, RiskFactorSlice],
) -> YieldCurve:
    """Build the CARRY leg's financing curve, stacking a basis spread on
    a base curve when ``leg.carry_basis_curve_name`` is set.

    Same ZAR-USD-BASIS-on-ZAR-SWAP construction as used by
    CommodityForward / CommodityAverageForward: the base curve
    (``leg.carry_curve_name``) is sampled at the basis curve's own
    tenor pillars and the two are added, so::

        r_carry(T) = r_base(T) + basis_spread(T)

    When ``carry_basis_curve_name`` is unset, ``carry_curve_name`` is
    used directly as the outright carry curve (no basis stacking).
    """
    base_slice = market_state[leg.carry_curve_name]
    if not leg.carry_basis_curve_name:
        return YieldCurve(
            base_slice.tenors, base_slice.values, leg.carry_interpolator,
        )

    base_curve = YieldCurve(
        base_slice.tenors, base_slice.values, leg.carry_interpolator,
    )
    basis_slice = market_state[leg.carry_basis_curve_name]
    base_rates_at_basis = base_curve.get_rate(basis_slice.tenors)
    combined_rates = (
        base_rates_at_basis + np.asarray(basis_slice.values, dtype=np.float64)
    )
    return YieldCurve(
        basis_slice.tenors, combined_rates, leg.carry_basis_interpolator,
    )


def _read_forward_curve_price(
    market_state: dict[str, RiskFactorSlice],
    curve_name: str,
    interpolator,
    as_of_date: date,
    target_date: date,
    day_counter: ql.DayCounter,
) -> np.ndarray:
    """Interpolate a commodity forward price CurveSlice (Excel-serial
    tenors) at *target_date*, as observed from *as_of_date*.

    Shared by the CURVE construction (target_date = settlement date) and
    the CARRY construction's live spot read (target_date = as_of_date
    itself, always before the first listed pillar, so this resolves to
    the curve's own flat-left-extrapolated front value, that is the price
    for
    "today").
    """
    fwd_slice = market_state[curve_name]
    tenors_yf = excel_serials_to_year_fracs(fwd_slice.tenors, as_of_date, day_counter)
    right_extrap = "flat" if interpolator is linear_interpolator else "linear"
    return get_forward_price_from_slice(
        curve_serial_tenors=fwd_slice.tenors,
        curve_values=fwd_slice.values,
        value_date=as_of_date,
        target_date=target_date,
        day_counter=day_counter,
        right_extrapolation=right_extrap,
        left_extrapolation="flat",
        _precomputed_tenors_yf=tenors_yf,
    )


def commodity_leg_forward_price(
    leg: CommodityPriceLeg,
    market_state: dict[str, RiskFactorSlice],
    as_of_date: date,
    settle_date: date,
    day_counter: ql.DayCounter,
) -> np.ndarray:
    """Per-path floating reference price for one CommodityPriceSwap period.

    Dispatches on ``leg.construction``:

    CURVE : linear interpolation of the market-observed forward price
        curve at *settle_date* (same convention as CommodityForward).
    CARRY : spot price, read live off the front of
        ``leg.carry_spot_curve_name`` at *as_of_date* (spot is not frozen at
        inception; the forward curve's
        current value at every valuation step), rolled forward at the
        financing curve rate, plus ``leg.carry_spread``.

    ``as_of_date`` is the date *market_state* is observed at, either
    the live valuation date, or (when computing a realised/frozen
    fixing) the scenario date the price was locked at.  ``settle_date``
    is the settlement-lag-adjusted tenor the price is evaluated for.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    if leg.construction == PriceConstruction.CURVE:
        return _read_forward_curve_price(
            market_state, leg.forward_curve_name, leg.forward_interpolator,
            as_of_date, settle_date, day_counter,
        )

    # CARRY
    spot = _read_forward_curve_price(
        market_state, leg.carry_spot_curve_name, leg.carry_spot_interpolator,
        as_of_date, as_of_date, day_counter,
    )
    carry_curve = _resolve_carry_curve(leg, market_state)
    spot_date = (
        advance_business_days(as_of_date, leg.spot_lag, leg.lag_calendar)
        if leg.spot_lag > 0
        else as_of_date
    )
    ql_as_of = to_ql_date(as_of_date)
    t_spot = float(day_counter.yearFraction(ql_as_of, to_ql_date(spot_date)))
    t_settle = float(day_counter.yearFraction(ql_as_of, to_ql_date(settle_date)))
    return (
        commodity_carry_forward_price(spot, carry_curve, t_spot, t_settle)
        + leg.carry_spread
    )


def commodity_price_leg_pv(
    schedule: list[tuple[date, date, date, float]],
    settle_dates: list[date],
    leg: CommodityPriceLeg,
    val_date: date,
    market_state: dict[str, RiskFactorSlice],
    discount_curve: YieldCurve,
    n_paths: int,
    day_counter: ql.DayCounter,
    fixings: dict[tuple[str, date], np.ndarray] | None = None,
    include_on_val_date: bool = False,
) -> np.ndarray:
    """PV of a single CommodityPriceSwap leg: sum_i price_i * Q * DF(t, T_i).

    Parameters
    ----------
    schedule : list of (accrual_start, accrual_end, payment_date, accrual_fraction)
        The leg's period schedule, as produced by ScheduleConfig.build.
        Use ``frequency=0`` on the leg to obtain a single zero-coupon
        period (Emission Credit Price Swap convention).
    settle_dates : list of date
        Settlement-lag-adjusted date T_settle for each schedule period,
        aligned by index, used only for FLOATING legs.
    leg : CommodityPriceLeg
        Leg definition (FIXED / FLOATING, quantity, construction).
    val_date : date
        Valuation date.
    market_state : dict[str, RiskFactorSlice]
        Current market state.
    discount_curve : YieldCurve
        Discount curve for the swap's currency.
    n_paths : int
        Number of simulation paths.
    day_counter : ql.DayCounter
        Day-count convention for year fractions (curve lookups and
        discounting share the same convention here, matching the
        Commodity Price Swap model theory's D_discount / F definitions).
    fixings : dict or None
        Realised/frozen per-period prices keyed by
        ``(leg.fixing_key_name, accrual_end_date)`` → ``np.ndarray
        (n_paths,)`` or scalar.  When present for a period, the frozen
        price is used instead of recomputing it from *market_state*, 
        required once a period's settlement date is in the past so the
        realised price stops fluctuating with the live (later) market
        state.
    include_on_val_date : bool
        When True, periods whose payment date equals val_date are
        included.

    Returns
    -------
    np.ndarray, shape (n_paths,)
    """
    idx_filtered = [
        i for i, (_, _, pay, _) in enumerate(schedule)
        if pay > val_date or (include_on_val_date and pay == val_date)
    ]
    if not idx_filtered:
        return np.zeros(n_paths)

    ql_val = to_ql_date(val_date)
    t_pays = np.array([
        day_counter.yearFraction(ql_val, to_ql_date(schedule[i][2]))
        for i in idx_filtered
    ])
    dfs = discount_curve.discount_factor(t_pays)  # (n_paths, n_periods)

    if leg.leg_type == CommodityLegType.FIXED:
        cashflows = np.full(len(idx_filtered), leg.quantity * leg.fixed_price)
        return dfs @ cashflows  # (n_paths,)

    prices = np.empty((n_paths, len(idx_filtered)))
    for col, i in enumerate(idx_filtered):
        _, end, _, _ = schedule[i]
        settle_date = settle_dates[i]
        key = (leg.fixing_key_name, end)
        if fixings and key in fixings:
            price = np.asarray(fixings[key], dtype=np.float64)
            if price.ndim == 0:
                price = np.full(n_paths, float(price))
        else:
            price = commodity_leg_forward_price(
                leg, market_state, val_date, settle_date, day_counter,
            )
            if np.ndim(price) == 0:
                price = np.full(n_paths, float(price))
        prices[:, col] = price

    cashflows = leg.quantity * prices  # (n_paths, n_periods)
    return np.sum(cashflows * dfs, axis=1)
