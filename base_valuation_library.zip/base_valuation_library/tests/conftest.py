"""Make the library importable when the tests are run from any folder."""

import sys
from pathlib import Path

LIBRARY_ROOT = Path(__file__).resolve().parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))
