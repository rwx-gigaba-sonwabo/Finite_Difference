# Tests

Unit tests of the library. Run them from the root folder of the library:

```bash
pytest
```

Expected result: 328 passed, 2 expected failures.

This runs two sets of tests.

| Folder | What it covers | Count |
|---|---|---|
| `tests/` | The pricing formulas, the instruments, the trade file reader and the run scripts | 265 passed, 2 expected failures |
| `autocall_pricer/tests/` | The autocall package | 63 passed |

To run one set only, name its folder, for example `pytest tests`.

## Files

| File | What it checks |
|---|---|
| `test_digital_option_pv.py` | The digital option formulas: closed form, strike spread, put and call parity, limits |
| `test_equity_digital_option.py` | The equity digital option: parity, strike spread limit, skew reading, settlement lag, quanto, after expiry |
| `test_barrier_option_pv.py` | The barrier formulas: knock in plus knock out equals the plain option, limits, the interval shift |
| `test_commodity_options_against_stored_values.py` | Every deal in the two commodity option samples against its stored comparison value |
| `test_validation_runs.py` | Every run script runs on its sample file and does not report `FAIL` |
| `test_trade_file.py` | Reading a trade JSON file and its tagged values |
| `test_single_barrier_pricer.py` | The barrier closed form used by the FX barrier option |
| `test_fx_barrier_option.py` | The FX barrier option and its volatility surface |
| `test_commodity_asian.py` | The commodity Asian option |
| `test_commodity_average_forward.py` | The commodity average price forward |
| `test_vol_surface.py` | The volatility surfaces |
| `test_interpolation.py` | Curve interpolation |
| `test_conversion.py` | Small conversion helpers |

## The two expected failures

Both are known gaps in code that came with the original code base. They are marked so that
they stay visible. Neither touches the commodity digital option, the commodity barrier
option or the autocallable swap.

| Test | What the gap is |
|---|---|
| `test_single_barrier_pricer.py`, breached barrier test | `instruments/single_barrier_pricer.py` returns a negative value when it is given a price that is already beyond the barrier but told the barrier was not crossed. The inputs contradict each other, but an error would be safer than a negative value. `models/barrier_option_pv.py`, which the commodity barrier option uses, does not have this gap. It checks the price against the barrier itself |
| `test_vol_surface.py`, term structure test | One interpolation check on the parametric skew surface fails. It failed in the original code base as well and was not changed |
