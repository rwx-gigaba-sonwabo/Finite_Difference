"""Commodity digital and barrier options against values stored with the sample trade files.

Each sample trade file in ``validation_runs/`` comes with a file of comparison values that
were produced outside this library. These tests value every deal in the two commodity
option samples and check the result against its stored value.
"""

import csv
from pathlib import Path

import pytest

from trade_data.base_market import BaseMarket
from trade_data.commodity_option_builders import (
    build_commodity_barrier_option,
    build_commodity_digital_option,
)
from trade_data.trade_file import TradeFile

RUNS = Path(__file__).resolve().parents[1] / "validation_runs"
CASES = [
    ("commodity_digital_option", "CommodityDigitalOption", build_commodity_digital_option),
    ("commodity_barrier_option", "CommodityBarrierOption", build_commodity_barrier_option),
]


def stored_values(folder: str) -> dict:
    with open(RUNS / folder / "sample_comparison_values.csv", newline="") as handle:
        return {row["Reference"]: float(row["Value"]) for row in csv.DictReader(handle)}


@pytest.mark.parametrize("folder, deal_type, builder", CASES)
def test_every_sample_deal_matches_its_stored_value(folder, deal_type, builder):
    trade_file = TradeFile(RUNS / folder / "sample_trade.json")
    market = BaseMarket(trade_file)
    expected = stored_values(folder)
    deals = [deal for deal in trade_file.deals if deal.get("Object") == deal_type]
    assert len(deals) == len(expected) == 3
    for deal in deals:
        instrument, market_state = builder(deal, market)
        value = instrument.npv(trade_file.valuation_date, market_state)
        assert float(value) == pytest.approx(expected[deal["Reference"]], rel=1e-9)
