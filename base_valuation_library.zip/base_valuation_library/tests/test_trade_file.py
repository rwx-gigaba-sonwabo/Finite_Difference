"""Tests of the trade JSON file reader and the comparison helpers."""

import json
from datetime import date
from pathlib import Path

import numpy as np
import pytest

from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term
from trade_data.trade_file import TradeFile, TradeFileError, decode_value
from valuation.base_valuation import compare_values
from valuation.component_report import ComponentLine, compare_line

SAMPLE = Path(__file__).resolve().parents[1] / "validation_runs" / "commodity_digital_option" / "sample_trade.json"


def test_tagged_values_are_decoded():
    assert decode_value({".Timestamp": "2026-10-30"}) == date(2026, 10, 30)
    assert decode_value({".Percent": 5.0}) == pytest.approx(0.05)
    assert decode_value({".Basis": 25.0}) == pytest.approx(0.0025)
    curve = decode_value({".Curve": {"meta": [], "data": [[0.5, 0.07], [1.0, 0.08]]}})
    assert isinstance(curve, np.ndarray) and curve.shape == (2, 2)


def test_sample_file_is_read():
    trade_file = TradeFile(SAMPLE)
    assert trade_file.valuation_date == date(2026, 10, 30)
    assert trade_file.reporting_currency == "ZAR"
    assert len(trade_file.deals) == 3
    assert trade_file.has_price_factor("ForwardPrice.BRENT")
    assert trade_file.valuation_setting("CommodityDigitalOption", "Relative_Digital_Spread") == 0.005


def test_find_deal_needs_one_match():
    trade_file = TradeFile(SAMPLE)
    assert trade_file.find_deal(reference="BRENT_DIGITAL_PUT_ASSET")["Option_Type"] == "Put"
    with pytest.raises(TradeFileError):
        trade_file.find_deal(deal_type="CommodityDigitalOption")
    with pytest.raises(TradeFileError):
        trade_file.find_deal(reference="NOT_IN_FILE")


def test_missing_price_factor_is_reported():
    with pytest.raises(TradeFileError):
        TradeFile(SAMPLE).price_factor("ForwardPrice.NOT_IN_FILE")


def test_trade_terms_come_from_the_deal_or_are_typed():
    deal = {"Reference": "X", "Buy_Sell": "Sell", "Units": 10.0}
    assert resolve_term(5.0, deal) == 5.0
    assert resolve_term(from_trade_file("Units"), deal) == 10.0
    assert resolve_term(from_trade_file("Buy_Sell", is_buy), deal) is False
    assert resolve_term(from_trade_file("Missing", default=1.5), deal) == 1.5
    with pytest.raises(KeyError):
        resolve_term(from_trade_file("Missing"), deal)
    assert is_call("Call") and not is_call("Put")


def test_values_agree_on_either_tolerance():
    assert compare_values(100.0, 100.005, 0.01, 0.0)[2] is True
    assert compare_values(1_000_000.0, 1_000_000.5, 0.01, 1e-6)[2] is True
    assert compare_values(1_000_000.0, 1_000_100.0, 0.01, 1e-6)[2] is False


def test_simulated_line_passes_on_its_z_score():
    line = ComponentLine("A", "simulated", "simulation", 1050.0, 25.0, comparison_value=1000.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "PASS" and line.z_score == pytest.approx(2.0)
    line = ComponentLine("B", "simulated", "simulation", 1100.0, 25.0, comparison_value=1000.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "FAIL"
    line = ComponentLine("C", "formula", "closed form", 1050.0, comparison_value=1000.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "FAIL"
    line = ComponentLine("D", "formula", "closed form", 1050.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "NOT COMPARED"


# --- Netting set wrappers ------------------------------------------------------
# Booked exports put each trade inside a NettingCollateralSet that carries the trade's
# label. The wrapper has no trade terms, so it must not be read as a second trade.
LABEL = "EQ/ZAR/WBO/C/Digi_CoN/TEST"


def _wrapped_file(tmp_path, inner_deals, label=LABEL):
    def child(reference, obj, **terms):
        return {"Instrument": {".Deal": {"Object": obj, "Reference": reference, **terms}}}
    wrapper = child(label, "NettingCollateralSet")
    wrapper["Children"] = [child(ref, obj, Strike_Price=100.0) for ref, obj in inner_deals]
    content = {"Calc": {
        "Calculation": {"Base_Date": {".Timestamp": "2026-10-30"}, "Currency": "ZAR"},
        "Deals": {"Deals": {"Children": [wrapper]}},
        "MergeMarketData": {"ExplicitMarketData": {"Price Factors": {}}}}}
    path = tmp_path / "wrapped_trade.json"
    path.write_text(json.dumps(content), encoding="utf-8")
    return TradeFile(path)


def test_netting_set_wrapper_is_not_a_trade(tmp_path):
    trade_file = _wrapped_file(tmp_path, [("233302604", "EquityBinaryOption")])
    assert [d["Reference"] for d in trade_file.deals] == ["233302604"]
    # The settings left as None find the one real trade.
    assert trade_file.find_deal()["Reference"] == "233302604"
    # Both filters set, as recommended.
    assert trade_file.find_deal("233302604", "EquityBinaryOption")["Strike_Price"] == 100.0
    # The wrapper's label still picks the trade inside it.
    assert trade_file.find_deal(LABEL, "EquityBinaryOption")["Reference"] == "233302604"
    assert trade_file.find_deal(LABEL)["Reference"] == "233302604"


def test_wrapper_holding_two_trades_is_refused(tmp_path):
    trade_file = _wrapped_file(
        tmp_path, [("233302604", "EquityBinaryOption"), ("233302605", "EquityOptionDeal")])
    with pytest.raises(TradeFileError, match="2 trades match"):
        trade_file.find_deal(LABEL)
    with pytest.raises(TradeFileError):
        trade_file.find_deal()
    # Narrowing by deal type, or naming the trade itself, removes the doubt.
    assert trade_file.find_deal(LABEL, "EquityOptionDeal")["Reference"] == "233302605"
    assert trade_file.find_deal("233302604")["Object"] == "EquityBinaryOption"
