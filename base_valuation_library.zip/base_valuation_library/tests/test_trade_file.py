"""Tests of the trade JSON file reader and the comparison helpers."""

from datetime import date
from pathlib import Path

import numpy as np
import pytest

from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term
from trade_data.trade_file import TradeFile, TradeFileError, decode_value
from valuation.base_valuation import compare_values
from valuation.component_report import ComponentLine, compare_line

SAMPLE = Path(__file__).resolve().parents[1] / "validation_runs" / "commodity_digital_option" / "sample_trade.json"


def test_tagged_values_are_decoded():
    assert decode_value({".Timestamp": "2026-10-30"}) == date(2026, 10, 30)
    assert decode_value({".Percent": 5.0}) == pytest.approx(0.05)
    assert decode_value({".Basis": 25.0}) == pytest.approx(0.0025)
    curve = decode_value({".Curve": {"meta": [], "data": [[0.5, 0.07], [1.0, 0.08]]}})
    assert isinstance(curve, np.ndarray) and curve.shape == (2, 2)


def test_sample_file_is_read():
    trade_file = TradeFile(SAMPLE)
    assert trade_file.valuation_date == date(2026, 10, 30)
    assert trade_file.reporting_currency == "ZAR"
    assert len(trade_file.deals) == 3
    assert trade_file.has_price_factor("ForwardPrice.BRENT")
    assert trade_file.valuation_setting("CommodityDigitalOption", "Relative_Digital_Spread") == 0.005


def test_find_deal_needs_one_match():
    trade_file = TradeFile(SAMPLE)
    assert trade_file.find_deal(reference="BRENT_DIGITAL_PUT_ASSET")["Option_Type"] == "Put"
    with pytest.raises(TradeFileError):
        trade_file.find_deal(deal_type="CommodityDigitalOption")
    with pytest.raises(TradeFileError):
        trade_file.find_deal(reference="NOT_IN_FILE")


def test_missing_price_factor_is_reported():
    with pytest.raises(TradeFileError):
        TradeFile(SAMPLE).price_factor("ForwardPrice.NOT_IN_FILE")


def test_trade_terms_come_from_the_deal_or_are_typed():
    deal = {"Reference": "X", "Buy_Sell": "Sell", "Units": 10.0}
    assert resolve_term(5.0, deal) == 5.0
    assert resolve_term(from_trade_file("Units"), deal) == 10.0
    assert resolve_term(from_trade_file("Buy_Sell", is_buy), deal) is False
    assert resolve_term(from_trade_file("Missing", default=1.5), deal) == 1.5
    with pytest.raises(KeyError):
        resolve_term(from_trade_file("Missing"), deal)
    assert is_call("Call") and not is_call("Put")


def test_values_agree_on_either_tolerance():
    assert compare_values(100.0, 100.005, 0.01, 0.0)[2] is True
    assert compare_values(1_000_000.0, 1_000_000.5, 0.01, 1e-6)[2] is True
    assert compare_values(1_000_000.0, 1_000_100.0, 0.01, 1e-6)[2] is False


def test_simulated_line_passes_on_its_z_score():
    line = ComponentLine("A", "simulated", "simulation", 1050.0, 25.0, comparison_value=1000.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "PASS" and line.z_score == pytest.approx(2.0)
    line = ComponentLine("B", "simulated", "simulation", 1100.0, 25.0, comparison_value=1000.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "FAIL"
    line = ComponentLine("C", "formula", "closed form", 1050.0, comparison_value=1000.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "FAIL"
    line = ComponentLine("D", "formula", "closed form", 1050.0)
    assert compare_line(line, 0.01, 1e-6, 3.0).outcome == "NOT COMPARED"
