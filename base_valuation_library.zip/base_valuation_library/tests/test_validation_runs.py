"""Every validation run script runs on its sample trade file without a failed comparison."""

import importlib.util
from pathlib import Path

import pytest

RUNS = Path(__file__).resolve().parents[1] / "validation_runs"
SCRIPTS = sorted(RUNS.glob("*/run_*_validation.py"))


@pytest.mark.parametrize("script", SCRIPTS, ids=lambda path: path.parent.name)
def test_run_script_runs_on_its_sample(script, capsys):
    spec = importlib.util.spec_from_file_location(script.stem, script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.OUTPUT_FOLDER = None            # do not write report files during tests
    if hasattr(module, "NUMBER_OF_PATHS"):
        module.NUMBER_OF_PATHS = 100_000   # keep the simulated run quick
    result = module.main()
    capsys.readouterr()
    assert result.outcome in ("PASS", "NOT COMPARED")
