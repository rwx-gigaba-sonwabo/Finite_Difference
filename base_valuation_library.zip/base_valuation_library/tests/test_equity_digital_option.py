"""Tests of the European equity digital option in ``instruments/equity_digital_option.py``."""

from datetime import date
from pathlib import Path

import numpy as np
import pytest

from instruments.equity_digital_option import EquityDigitalOption
from market_data.moneyness_vol_surface import FlatVolSurface
from market_data.risk_factor import CurveSlice, ScalarSlice
from models.digital_option_pv import black_vanilla_undiscounted
from trade_data.base_market import BaseMarket
from trade_data.trade_file import TradeFile
from utils.maths import norm_cdf

VALUATION = date(2026, 10, 30)
EXPIRY = date(2027, 10, 29)
SPOT, STRIKE, VOL, RATE, DIV = 100.0, 105.0, 0.22, 0.07, 0.025
TENORS = np.array([0.5, 1.0, 5.0])
SAMPLES = Path(__file__).resolve().parents[1] / "validation_runs"


def flat_interpolator(tenors, rates):
    return lambda t: rates[:, 0]


def market_state():
    return {
        "spot": ScalarSlice(SPOT),
        "carry": CurveSlice(np.full(3, RATE), TENORS),
        "div": CurveSlice(np.full(3, DIV), TENORS),
        "disc": CurveSlice(np.full(3, RATE), TENORS),
    }


def option(**overrides):
    terms = dict(
        name="test", expiry_date=EXPIRY, strike=STRIKE, payoff_amount=1.0, is_call=True,
        spot_name="spot", carry_curve_name="carry", dividend_curve_name="div",
        discount_curve_name="disc", vol_surface=FlatVolSurface(VOL),
        carry_interpolator=flat_interpolator, dividend_interpolator=flat_interpolator,
        discount_interpolator=flat_interpolator)
    terms.update(overrides)
    return EquityDigitalOption(**terms)


def value(instrument, on=VALUATION):
    return float(instrument.scenario_npvs(on, market_state())[0])


T = (EXPIRY - VALUATION).days / 365.0
FORWARD = SPOT * np.exp((RATE - DIV) * T)
DF = np.exp(-RATE * T)


def test_cash_call_matches_hand_formula():
    d2 = (np.log(FORWARD / STRIKE) - 0.5 * VOL ** 2 * T) / (VOL * np.sqrt(T))
    assert value(option(payoff_amount=1e6)) == pytest.approx(1e6 * DF * norm_cdf(d2), rel=1e-12)


def test_cash_call_and_put_add_up_to_the_discount_factor():
    total = value(option(is_call=True)) + value(option(is_call=False))
    assert total == pytest.approx(DF, abs=1e-12)


def test_asset_call_less_strike_cash_calls_is_the_vanilla_call():
    asset = value(option(payoff_style="asset"))
    cash = value(option(payoff_style="cash"))
    vanilla = DF * float(black_vanilla_undiscounted(FORWARD, STRIKE, VOL, T, True))
    assert asset - STRIKE * cash == pytest.approx(vanilla, rel=1e-10)


@pytest.mark.parametrize("style", ["cash", "asset"])
@pytest.mark.parametrize("is_call", [True, False])
def test_strike_spread_on_a_flat_surface_approaches_the_closed_form(style, is_call):
    closed = value(option(payoff_style=style, is_call=is_call))
    spread = value(option(payoff_style=style, is_call=is_call, relative_digital_spread=1e-4))
    assert spread == pytest.approx(closed, rel=1e-6)


def test_sold_option_is_minus_the_bought_option():
    assert value(option(is_buy=False)) == pytest.approx(-value(option()), rel=1e-14)


def test_settlement_lag_discounts_to_the_settlement_date():
    settle = date(2027, 11, 3)
    lagged = value(option(settlement_date=settle))
    extra = (settle - EXPIRY).days / 365.0
    assert lagged == pytest.approx(value(option()) * np.exp(-RATE * extra), rel=1e-12)


def test_negative_quanto_correlation_raises_the_call_value():
    plain = value(option())
    quanto = value(option(quanto_fx_volatility=0.15, quanto_correlation=-0.3))
    assert quanto > plain


def test_after_expiry_the_known_payout_is_discounted():
    after = date(2027, 11, 1)
    paid = value(option(settlement_date=date(2027, 11, 3), expiry_fixing=110.0), on=after)
    assert paid == pytest.approx(np.exp(-RATE * 2 / 365.0), rel=1e-12)
    missed = value(option(settlement_date=date(2027, 11, 3), expiry_fixing=100.0), on=after)
    assert missed == 0.0


def test_after_expiry_without_a_fixing_is_an_error():
    with pytest.raises(ValueError, match="expiry_fixing"):
        value(option(settlement_date=date(2027, 11, 3)), on=date(2027, 11, 1))


def test_after_settlement_the_value_is_zero():
    assert value(option(), on=date(2027, 11, 5)) == 0.0


def test_parametric_skew_is_read_by_strike():
    """The equity option sample holds a Skew surface. The digital reads it at its strikes."""
    trade_file = TradeFile(SAMPLES / "equity_option" / "sample_trade.json")
    market = BaseMarket(trade_file)
    skew = market.equity_volatility("EquityPriceVol.ZAR_SHARE")
    curve = "InterestRate.ZAR-SWAP"
    instrument = EquityDigitalOption(
        name="skew", expiry_date=date(2027, 4, 30), strike=175.0, payoff_amount=1.0,
        is_call=False, spot_name="EquityPrice.ZAR_SHARE", carry_curve_name=curve,
        dividend_curve_name="DividendRate.ZAR_SHARE", discount_curve_name=curve,
        vol_surface=skew, carry_interpolator=market.curve_interpolator(curve),
        dividend_interpolator=market.curve_interpolator("DividendRate.ZAR_SHARE"),
        discount_interpolator=market.curve_interpolator(curve), relative_digital_spread=0.01)
    state = market.market_state(curves=[curve, "DividendRate.ZAR_SHARE"],
                                scalars=["EquityPrice.ZAR_SHARE"])
    details = instrument.valuation_details(trade_file.valuation_date, state)
    t = details["time_to_expiry"]
    expected_vol = float(np.atleast_1d(skew.get_vol(strike=175.0, tenor=t))[0])
    assert float(np.atleast_1d(details["volatility"])[0]) == pytest.approx(expected_vol, rel=1e-14)
    # A put skew: lower strikes carry more volatility.
    assert float(np.atleast_1d(details["lower_strike_volatility"])[0]) > float(
        np.atleast_1d(details["upper_strike_volatility"])[0])
    assert 0.0 < float(np.atleast_1d(details["present_value"])[0]) < 1.0


@pytest.mark.parametrize("bad", [
    dict(payoff_style="digital"), dict(payoff_amount=0.0), dict(strike=0.0),
    dict(relative_digital_spread=1.0), dict(settlement_date=date(2027, 10, 1)),
    dict(quanto_fx_volatility=0.15), dict(moneyness_basis="atm"),
])
def test_bad_terms_are_refused(bad):
    with pytest.raises(ValueError):
        option(**bad)
