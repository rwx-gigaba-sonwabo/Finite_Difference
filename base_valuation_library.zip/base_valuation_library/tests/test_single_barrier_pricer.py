"""
Tests for instruments/single_barrier_pricer.py, Reiner-Rubinstein / Haug
continuously-monitored single barrier options.

These are self-validating: rather than pinning externally-sourced reference
numbers, they assert analytical identities the closed form must satisfy.

- In-out parity: with no rebate, knock-in + knock-out = the vanilla option.
  This holds for all four barrier types and is the standard correctness check
  for a barrier pricer.
- Barrier limits: a barrier placed far out of reach makes a knock-out approach
  the vanilla and a knock-in approach zero.
- Already-crossed handling: a crossed knock-in is the vanilla; a crossed
  knock-out pays only the rebate.
- Vectorisation over paths, and input validation.
"""
from __future__ import annotations

import numpy as np
import numpy.testing as npt
import pytest

from instruments.single_barrier_pricer import barrier_factors, single_barrier_price
from utils.maths import norm_cdf


# ---------------------------------------------------------------------------
# Constants / helpers
# ---------------------------------------------------------------------------

SPOT = 100.0
STRIKE = 100.0
CARRY = 0.02          # cost of carry b
RATE = 0.05           # discount rate r
VOL = 0.20
T = 1.0

# All four combinations of (is_call, is_up)
BARRIER_TYPES = [
    pytest.param(True, False, id="down-call"),
    pytest.param(True, True, id="up-call"),
    pytest.param(False, False, id="down-put"),
    pytest.param(False, True, id="up-put"),
]


def generalised_bs(S, X, T_, r, b, sigma, is_call):
    """Generalised Black-Scholes, the vanilla the barriers must sum to.

    This is factor A of the Reiner-Rubinstein decomposition evaluated at the
    strike, i.e. the same convention the pricer discounts with.
    """
    sqrtT = np.sqrt(T_)
    d1 = (np.log(S / X) + (b + 0.5 * sigma ** 2) * T_) / (sigma * sqrtT)
    d2 = d1 - sigma * sqrtT
    phi = 1.0 if is_call else -1.0
    return (
        phi * S * np.exp((b - r) * T_) * norm_cdf(phi * d1)
        - phi * X * np.exp(-r * T_) * norm_cdf(phi * d2)
    )


def price(H, is_call, is_up, is_knock_in, **kw):
    kw.setdefault("K", 0.0)
    return single_barrier_price(
        SPOT, CARRY, RATE, T, STRIKE, VOL, H, is_call, is_up, is_knock_in, **kw
    )


# ---------------------------------------------------------------------------
# In-out parity
# ---------------------------------------------------------------------------

class TestInOutParity:
    @pytest.mark.parametrize("is_call, is_up", BARRIER_TYPES)
    @pytest.mark.parametrize("H", [85.0, 95.0, 105.0, 115.0])
    def test_knock_in_plus_knock_out_equals_vanilla(self, is_call, is_up, H):
        """With zero rebate, in + out = vanilla for every barrier type and level."""
        ki = price(H, is_call, is_up, is_knock_in=True)
        ko = price(H, is_call, is_up, is_knock_in=False)
        vanilla = generalised_bs(SPOT, STRIKE, T, RATE, CARRY, VOL, is_call)
        npt.assert_allclose(ki + ko, vanilla, rtol=1e-10)

    @pytest.mark.parametrize("is_call, is_up", BARRIER_TYPES)
    def test_parity_holds_across_vols(self, is_call, is_up):
        """Parity must not depend on the volatility level."""
        vanilla_for = lambda s: generalised_bs(SPOT, STRIKE, T, RATE, CARRY, s, is_call)
        for sigma in (0.05, 0.15, 0.35, 0.80):
            ki = single_barrier_price(
                SPOT, CARRY, RATE, T, STRIKE, sigma, 95.0,
                is_call, is_up, True, K=0.0,
            )
            ko = single_barrier_price(
                SPOT, CARRY, RATE, T, STRIKE, sigma, 95.0,
                is_call, is_up, False, K=0.0,
            )
            npt.assert_allclose(ki + ko, vanilla_for(sigma), rtol=1e-10)


# ---------------------------------------------------------------------------
# Barrier limits
# ---------------------------------------------------------------------------

class TestBarrierLimits:
    def test_unreachable_down_barrier_knock_out_approaches_vanilla(self):
        """A down barrier far below spot almost never knocks out."""
        ko = price(1.0, is_call=True, is_up=False, is_knock_in=False)
        vanilla = generalised_bs(SPOT, STRIKE, T, RATE, CARRY, VOL, True)
        npt.assert_allclose(ko, vanilla, rtol=1e-8)

    def test_unreachable_down_barrier_knock_in_approaches_zero(self):
        ki = price(1.0, is_call=True, is_up=False, is_knock_in=True)
        assert abs(float(ki)) < 1e-8

    def test_unreachable_up_barrier_knock_out_approaches_vanilla(self):
        """An up barrier far above spot almost never knocks out."""
        ko = price(10_000.0, is_call=False, is_up=True, is_knock_in=False)
        vanilla = generalised_bs(SPOT, STRIKE, T, RATE, CARRY, VOL, False)
        npt.assert_allclose(ko, vanilla, rtol=1e-8)

    def test_unreachable_up_barrier_knock_in_approaches_zero(self):
        ki = price(10_000.0, is_call=False, is_up=True, is_knock_in=True)
        assert abs(float(ki)) < 1e-8

    @pytest.mark.parametrize("is_call, is_up", BARRIER_TYPES)
    def test_prices_are_non_negative(self, is_call, is_up):
        """Prices must be non-negative for barriers placed on their valid side.

        A "down" barrier belongs below spot and an "up" barrier above it; the
        other way round the option is already breached at inception and must be
        priced with ``crossed=True`` instead.
        """
        levels = (80.0, 90.0, 99.0) if not is_up else (101.0, 110.0, 120.0)
        for H in levels:
            for ki in (True, False):
                assert float(price(H, is_call, is_up, ki)) >= -1e-10

    @pytest.mark.xfail(
        reason="Known gap: a barrier already breached at inception but passed "
               "with crossed=False returns a negative option price instead of "
               "raising. Reiner-Rubinstein assumes an un-breached barrier, so "
               "this is inconsistent input - but a negative price is a silent "
               "wrong answer rather than a loud one.",
        strict=True,
    )
    def test_breached_barrier_with_crossed_false_should_not_be_negative(self):
        """Down-and-out call with the barrier above spot: already knocked out."""
        assert float(price(110.0, is_call=True, is_up=False, is_knock_in=False)) >= -1e-10


# ---------------------------------------------------------------------------
# Already-crossed barrier
# ---------------------------------------------------------------------------

class TestCrossedBarrier:
    def test_crossed_knock_in_is_vanilla(self):
        """Once the barrier is hit a knock-in has become the vanilla option."""
        got = price(95.0, is_call=True, is_up=False, is_knock_in=True, crossed=True)
        vanilla = generalised_bs(SPOT, STRIKE, T, RATE, CARRY, VOL, True)
        npt.assert_allclose(got, vanilla, rtol=1e-12)

    def test_crossed_knock_out_pays_rebate_only(self):
        got = price(95.0, is_call=True, is_up=False, is_knock_in=False,
                    crossed=True, K=7.0, rebate_at_hit=True)
        npt.assert_allclose(got, 7.0, rtol=1e-12)

    def test_crossed_knock_out_zero_rebate_is_worthless(self):
        got = price(95.0, is_call=True, is_up=False, is_knock_in=False, crossed=True)
        npt.assert_allclose(got, 0.0, atol=1e-12)

    def test_crossed_applies_per_path(self):
        """``crossed`` is per-path and must select pathwise."""
        crossed = np.array([True, False, True, False])
        got = price(95.0, is_call=True, is_up=False, is_knock_in=True, crossed=crossed)
        alive = price(95.0, is_call=True, is_up=False, is_knock_in=True, crossed=False)
        vanilla = generalised_bs(SPOT, STRIKE, T, RATE, CARRY, VOL, True)
        npt.assert_allclose(got[[0, 2]], vanilla, rtol=1e-12)
        npt.assert_allclose(got[[1, 3]], float(alive), rtol=1e-12)


# ---------------------------------------------------------------------------
# Vectorisation and validation
# ---------------------------------------------------------------------------

class TestVectorisation:
    def test_per_path_spot_matches_scalar_calls(self):
        spots = np.array([90.0, 100.0, 110.0])
        vec = single_barrier_price(
            spots, CARRY, RATE, T, STRIKE, VOL, 85.0, True, False, False, K=0.0,
        )
        scalars = [
            float(single_barrier_price(
                float(s), CARRY, RATE, T, STRIKE, VOL, 85.0, True, False, False, K=0.0,
            ))
            for s in spots
        ]
        npt.assert_allclose(vec, scalars, rtol=1e-12)

    def test_per_path_vol_is_respected(self):
        vols = np.array([0.10, 0.20, 0.40])
        vec = single_barrier_price(
            SPOT, CARRY, RATE, T, STRIKE, vols, 85.0, True, False, False, K=0.0,
        )
        assert vec.shape == (3,)
        assert len(set(np.round(vec, 10))) == 3, "per-path vols should give distinct prices"


class TestValidation:
    def test_non_positive_maturity_raises(self):
        with pytest.raises(ValueError, match="sigma and T must be positive"):
            single_barrier_price(
                SPOT, CARRY, RATE, 0.0, STRIKE, VOL, 95.0, True, False, True,
            )

    def test_non_positive_vol_raises(self):
        with pytest.raises(ValueError, match="sigma and T must be positive"):
            single_barrier_price(
                SPOT, CARRY, RATE, T, STRIKE, 0.0, 95.0, True, False, True,
            )


class TestBarrierFactors:
    def test_factors_are_finite_and_complete(self):
        f = barrier_factors(SPOT, CARRY, RATE, T, STRIKE, VOL, 95.0, 0.0, True, False)
        for key in ("A", "B", "C", "D", "E", "F", "erT"):
            assert key in f, f"missing factor {key}"
            assert np.all(np.isfinite(f[key])), f"factor {key} is not finite"

    def test_factor_A_is_the_vanilla(self):
        """Factor A of the decomposition is the generalised Black-Scholes price."""
        f = barrier_factors(SPOT, CARRY, RATE, T, STRIKE, VOL, 95.0, 0.0, True, False)
        vanilla = generalised_bs(SPOT, STRIKE, T, RATE, CARRY, VOL, True)
        npt.assert_allclose(f["A"], vanilla, rtol=1e-12)
