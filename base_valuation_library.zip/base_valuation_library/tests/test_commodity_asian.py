"""
Tests for instruments/commodity_asian.py, CommodityAsian.

This module had no coverage at all, despite sharing the Excel-serial
forward-curve tenor convention that had already silently broken the
commodity average-forward fixtures (a curve fed year fractions maps every
short tenor onto the Excel epoch, 1899-12-30, which is below QuantLib's
minimum date).  ``test_forward_curve_tenors_are_excel_serials`` locks that
convention down so the same drift cannot recur unnoticed.

The pricer is a moment-matched (Turnbull-Wakeman / Levy) arithmetic Asian: it
computes the first and second moments of the average, derives an adjusted
lognormal vol, then prices with Black-76 on the forward M1.  Because the call
and put are priced off the *same* M1, call-put parity is exact, which gives a
strong assertion that needs no externally-sourced reference numbers.
"""
from __future__ import annotations

from datetime import date, timedelta

import numpy as np
import numpy.testing as npt
import pytest

from instruments.commodity_asian import CommodityAsian
from market_data.risk_factor import CurveSlice
from market_data.vol_surface import NonPreciousCommodityVol
from utils.interpolation import linear_interpolator
from utils.ql_helpers import DAY_COUNTERS, to_ql_date


# ---------------------------------------------------------------------------
# Constants / helpers
# ---------------------------------------------------------------------------

N_PATHS = 4
VAL_DATE = date(2025, 1, 2)
EXCEL_EPOCH = date(1899, 12, 30)

PERIOD_START = date(2025, 6, 2)
PERIOD_END = date(2025, 6, 30)
SETTLEMENT = date(2025, 7, 3)

FWD_PRICE = 80.0
STRIKE = 80.0
DISC_RATE = 0.05
VOL = 0.25
NOTIONAL = 1_000.0

DISC_TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0], dtype=np.float64)

# The forward price curve carries Excel serial pillar DATES, not year
# fractions.  Derived from VAL_DATE so the relationship stays visible.
_FWD_PILLAR_DAYS = [30, 90, 180, 365, 730]
FWD_TENORS = np.array(
    [(VAL_DATE + timedelta(days=d) - EXCEL_EPOCH).days for d in _FWD_PILLAR_DAYS],
    dtype=np.float64,
)

_DC = DAY_COUNTERS["ACT/365"]


def flat_vol_surface(vol=VOL):
    return NonPreciousCommodityVol(
        [[m, t, vol] for t in (0.25, 0.5, 1.0, 2.0) for m in (-0.2, 0.0, 0.2)]
    )


def market_state(fwd=FWD_PRICE, rate=DISC_RATE):
    return {
        "FWD": CurveSlice(
            values=np.full((N_PATHS, len(FWD_TENORS)), fwd), tenors=FWD_TENORS
        ),
        "DISC": CurveSlice(
            values=np.full((N_PATHS, len(DISC_TENORS)), rate), tenors=DISC_TENORS
        ),
    }


def make_asian(is_call=True, direction=1, notional=NOTIONAL, strike=STRIKE,
               period_start=PERIOD_START, period_end=PERIOD_END,
               settlement=SETTLEMENT, vol=VOL, **kw):
    return CommodityAsian(
        name="ASIAN",
        period_start=period_start,
        period_end=period_end,
        settlement_date=settlement,
        strike=strike,
        notional=notional,
        is_call=is_call,
        vol_surface=flat_vol_surface(vol),
        forward_curve_name="FWD",
        discount_curve_name="DISC",
        averaging_calendar="USD",
        lag_calendar="USD",
        direction=direction,
        **kw,
    )


def settlement_df(rate=DISC_RATE, settlement=SETTLEMENT):
    t = float(_DC.yearFraction(to_ql_date(VAL_DATE), to_ql_date(settlement)))
    return np.exp(-rate * t)


# ---------------------------------------------------------------------------
# Tenor convention, the thing that drifted before
# ---------------------------------------------------------------------------

class TestForwardCurveTenorConvention:
    def test_forward_curve_tenors_are_excel_serials(self):
        """Feeding year fractions must fail loudly, not price silently.

        ``excel_serials_to_year_fracs`` maps a small number such as 0.25 onto
        the Excel epoch (1899-12-30), which QuantLib rejects.  This asserts the
        contract explicitly so a fixture written in year fractions cannot
        quietly produce wrong prices.
        """
        ms = market_state()
        ms["FWD"] = CurveSlice(
            values=np.full((N_PATHS, len(DISC_TENORS)), FWD_PRICE),
            tenors=DISC_TENORS,          # year fractions, the wrong convention
        )
        with pytest.raises(RuntimeError, match="out of bound"):
            make_asian().scenario_npvs(VAL_DATE, ms)

    def test_excel_serial_curve_prices_successfully(self):
        pv = make_asian().scenario_npvs(VAL_DATE, market_state())
        assert pv.shape == (N_PATHS,)
        assert np.all(np.isfinite(pv))


# ---------------------------------------------------------------------------
# Call-put parity
# ---------------------------------------------------------------------------

class TestCallPutParity:
    def test_at_the_money_call_equals_put(self):
        """Flat forward at the strike: C - P = df * (M1 - K) = 0."""
        ms = market_state()
        call = make_asian(is_call=True).scenario_npvs(VAL_DATE, ms)
        put = make_asian(is_call=False).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(call, put, rtol=1e-10)

    @pytest.mark.parametrize("strike", [60.0, 70.0, 80.0, 90.0, 110.0])
    def test_parity_holds_across_strikes(self, strike):
        """C - P = notional * df * (M1 - K); with a flat curve M1 = forward."""
        ms = market_state()
        call = make_asian(is_call=True, strike=strike).scenario_npvs(VAL_DATE, ms)
        put = make_asian(is_call=False, strike=strike).scenario_npvs(VAL_DATE, ms)
        expected = NOTIONAL * settlement_df() * (FWD_PRICE - strike)
        npt.assert_allclose(call - put, expected, rtol=1e-8)

    @pytest.mark.parametrize("vol", [0.05, 0.25, 0.60])
    def test_parity_is_independent_of_vol(self, vol):
        ms = market_state()
        call = make_asian(is_call=True, strike=70.0, vol=vol).scenario_npvs(VAL_DATE, ms)
        put = make_asian(is_call=False, strike=70.0, vol=vol).scenario_npvs(VAL_DATE, ms)
        expected = NOTIONAL * settlement_df() * (FWD_PRICE - 70.0)
        npt.assert_allclose(call - put, expected, rtol=1e-8)


# ---------------------------------------------------------------------------
# Structural properties
# ---------------------------------------------------------------------------

class TestStructuralProperties:
    def test_value_is_linear_in_notional(self):
        ms = market_state()
        one = make_asian(notional=NOTIONAL).scenario_npvs(VAL_DATE, ms)
        five = make_asian(notional=5.0 * NOTIONAL).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(five, 5.0 * one, rtol=1e-10)

    def test_direction_flips_the_sign(self):
        ms = market_state()
        long_pv = make_asian(direction=1).scenario_npvs(VAL_DATE, ms)
        short_pv = make_asian(direction=-1).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(long_pv + short_pv, 0.0, atol=1e-10)

    def test_deep_in_the_money_call_approaches_discounted_intrinsic(self):
        """A far-ITM call is worth about df * (F - K) per unit."""
        ms = market_state()
        pv = make_asian(is_call=True, strike=1.0, vol=0.01).scenario_npvs(VAL_DATE, ms)
        expected = NOTIONAL * settlement_df() * (FWD_PRICE - 1.0)
        npt.assert_allclose(pv, expected, rtol=1e-3)

    def test_deep_out_of_the_money_call_is_almost_worthless(self):
        ms = market_state()
        pv = make_asian(is_call=True, strike=10_000.0, vol=0.01).scenario_npvs(
            VAL_DATE, ms
        )
        assert float(pv[0]) < 1e-6

    def test_higher_vol_raises_an_at_the_money_option(self):
        ms = market_state()
        low = make_asian(vol=0.10).scenario_npvs(VAL_DATE, ms)
        high = make_asian(vol=0.50).scenario_npvs(VAL_DATE, ms)
        assert float(high[0]) > float(low[0])

    def test_prices_are_non_negative(self):
        ms = market_state()
        for strike in (40.0, 80.0, 160.0):
            for is_call in (True, False):
                pv = make_asian(is_call=is_call, strike=strike).scenario_npvs(
                    VAL_DATE, ms
                )
                assert float(pv[0]) >= -1e-10


# ---------------------------------------------------------------------------
# Averaging schedule
# ---------------------------------------------------------------------------

class TestAveragingSchedule:
    def test_averaging_dates_are_business_days_in_the_period(self):
        inst = make_asian()
        assert inst._averaging_dates, "expected a non-empty averaging schedule"
        assert all(PERIOD_START <= d <= PERIOD_END for d in inst._averaging_dates)
        assert inst._averaging_dates == sorted(inst._averaging_dates)

    def test_pricing_dates_are_lagged_from_averaging_dates(self):
        inst = make_asian(pricing_lag=2)
        assert len(inst._pricing_dates) == len(inst._averaging_dates)
        for avg, prc in zip(inst._averaging_dates, inst._pricing_dates):
            assert prc > avg, "a positive pricing lag must move the date later"

    def test_required_sim_dates_are_the_averaging_dates(self):
        inst = make_asian()
        assert inst.required_sim_dates() == inst._averaging_dates

    def test_single_day_period_has_one_averaging_date(self):
        inst = make_asian(period_start=date(2025, 6, 2), period_end=date(2025, 6, 2))
        assert len(inst._averaging_dates) == 1
