"""Tests of the European digital option formulas in ``models/digital_option_pv.py``."""

import numpy as np
import pytest

from models.digital_option_pv import (
    asset_digital_by_strike_spread_undiscounted,
    black_asset_digital_undiscounted,
    black_cash_digital_undiscounted,
    black_vanilla_undiscounted,
    cash_digital_by_strike_spread_undiscounted,
    composite_volatility,
)

FORWARD, STRIKE, VOLATILITY, EXPIRY = 79.45, 82.0, 0.32, 0.5


def test_cash_digital_call_and_put_add_up_to_one():
    """Exactly one of the call and the put pays, so their values add up to one."""
    call = black_cash_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, True)
    put = black_cash_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, False)
    assert call + put == pytest.approx(1.0, abs=1e-12)


def test_asset_digital_call_and_put_add_up_to_the_forward():
    """The call and the put together always deliver the underlying."""
    call = black_asset_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, True)
    put = black_asset_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, False)
    assert call + put == pytest.approx(FORWARD, abs=1e-10)


def test_vanilla_equals_asset_digital_less_strike_cash_digitals():
    """A call is an asset digital call less ``K`` cash digital calls."""
    vanilla = black_vanilla_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, True)
    asset = black_asset_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, True)
    cash = black_cash_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, True)
    assert vanilla == pytest.approx(asset - STRIKE * cash, abs=1e-10)


@pytest.mark.parametrize("is_call", [True, False])
def test_strike_spread_tends_to_the_closed_form_on_a_flat_smile(is_call):
    """With the same volatility at both strikes a narrow spread gives the closed form."""
    closed_form = black_cash_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, is_call)
    spread = cash_digital_by_strike_spread_undiscounted(
        FORWARD, STRIKE, VOLATILITY, VOLATILITY, EXPIRY, is_call, 1e-5)
    assert spread == pytest.approx(closed_form, abs=1e-7)


def test_strike_spread_picks_up_the_smile_slope():
    """Volatility that falls as the strike rises makes a digital call worth more."""
    flat = cash_digital_by_strike_spread_undiscounted(FORWARD, STRIKE, 0.32, 0.32, EXPIRY, True, 0.01)
    sloped = cash_digital_by_strike_spread_undiscounted(FORWARD, STRIKE, 0.33, 0.31, EXPIRY, True, 0.01)
    assert sloped > flat


def test_asset_digital_by_strike_spread_matches_the_closed_form_on_a_flat_smile():
    closed_form = black_asset_digital_undiscounted(FORWARD, STRIKE, VOLATILITY, EXPIRY, False)
    spread = asset_digital_by_strike_spread_undiscounted(
        FORWARD, STRIKE, VOLATILITY, VOLATILITY, VOLATILITY, EXPIRY, False, 1e-5)
    assert spread == pytest.approx(closed_form, abs=1e-5)


def test_values_at_expiry_are_the_payoff():
    assert black_cash_digital_undiscounted(90.0, STRIKE, VOLATILITY, 0.0, True) == 1.0
    assert black_cash_digital_undiscounted(70.0, STRIKE, VOLATILITY, 0.0, True) == 0.0
    assert black_asset_digital_undiscounted(70.0, STRIKE, VOLATILITY, 0.0, False) == 70.0
    assert black_vanilla_undiscounted(90.0, STRIKE, VOLATILITY, 0.0, True) == pytest.approx(8.0)


def test_strike_spread_needs_a_positive_width():
    with pytest.raises(ValueError):
        cash_digital_by_strike_spread_undiscounted(FORWARD, STRIKE, 0.3, 0.3, EXPIRY, True, 0.0)


def test_composite_volatility():
    assert composite_volatility(0.3, 0.15, 0.0) == pytest.approx(np.hypot(0.3, 0.15))
    assert composite_volatility(0.3, 0.15, 1.0) == pytest.approx(0.45)
    assert composite_volatility(0.3, 0.15, -1.0) == pytest.approx(0.15)
