"""Tests of the single barrier closed form in ``models/barrier_option_pv.py``."""

import numpy as np
import pytest

from models.barrier_option_pv import (
    european_option_value,
    monitoring_adjusted_barrier,
    single_barrier_option_value,
    single_barrier_untouched_value,
)

# The worked example in Haug, "The Complete Guide to Option Pricing Formulas", for standard
# barrier options: price 100, six months, rate 8%, carry 4%, volatility 25%, rebate 3.
MARKET = dict(spot=100.0, carry_rate=0.04, discount_rate=0.08, volatility=0.25, expiry=0.5)

#: (strike, barrier, is_call, is_up, is_knock_in, published value)
PUBLISHED_VALUES = [
    (90.0, 95.0, True, False, False, 9.0246),
    (100.0, 95.0, True, False, False, 6.7924),
    (110.0, 95.0, True, False, False, 4.8759),
    (90.0, 105.0, True, True, False, 2.6789),
    (100.0, 105.0, True, True, False, 2.3580),
    (90.0, 95.0, False, False, False, 2.2798),
    (90.0, 105.0, False, True, False, 3.7760),
    (90.0, 95.0, True, False, True, 7.7627),
    (90.0, 105.0, True, True, True, 14.1112),
    (90.0, 95.0, False, False, True, 2.9586),
    (90.0, 105.0, False, True, True, 1.4653),
]


@pytest.mark.parametrize("strike, barrier, is_call, is_up, is_knock_in, published", PUBLISHED_VALUES)
def test_closed_form_reproduces_published_values(strike, barrier, is_call, is_up, is_knock_in, published):
    value = single_barrier_untouched_value(
        strike=strike, barrier=barrier, rebate=3.0, is_call=is_call, is_up=is_up,
        is_knock_in=is_knock_in, **MARKET)
    assert float(value) == pytest.approx(published, abs=5e-5)


@pytest.mark.parametrize("is_call", [True, False])
@pytest.mark.parametrize("is_up, barrier", [(True, 112.0), (False, 88.0)])
@pytest.mark.parametrize("strike", [85.0, 100.0, 115.0])
def test_knock_in_plus_knock_out_is_the_european_option(is_call, is_up, barrier, strike):
    """With no rebate, exactly one of the knock in and the knock out pays at expiry."""
    common = dict(strike=strike, barrier=barrier, rebate=0.0, is_call=is_call, is_up=is_up, **MARKET)
    knock_in = single_barrier_untouched_value(is_knock_in=True, **common)
    knock_out = single_barrier_untouched_value(is_knock_in=False, **common)
    european = european_option_value(
        MARKET["spot"], MARKET["carry_rate"], MARKET["discount_rate"], MARKET["volatility"],
        MARKET["expiry"], strike, is_call)
    assert float(knock_in + knock_out) == pytest.approx(float(european), abs=1e-10)


def test_barrier_far_away_gives_the_european_option():
    value = single_barrier_option_value(
        strike=100.0, barrier=1e6, rebate=0.0, is_call=True, is_up=True, is_knock_in=False, **MARKET)
    european = european_option_value(100.0, 0.04, 0.08, 0.25, 0.5, 100.0, True)
    assert float(value) == pytest.approx(float(european), abs=1e-8)


def test_touched_knock_out_is_worth_its_rebate():
    value = single_barrier_option_value(
        strike=100.0, barrier=95.0, rebate=3.0, is_call=True, is_up=True, is_knock_in=False, **MARKET)
    assert float(value) == pytest.approx(3.0)


def test_touched_knock_in_is_worth_the_european_option():
    value = single_barrier_option_value(
        strike=100.0, barrier=95.0, rebate=3.0, is_call=True, is_up=True, is_knock_in=True, **MARKET)
    european = european_option_value(100.0, 0.04, 0.08, 0.25, 0.5, 100.0, True)
    assert float(value) == pytest.approx(float(european))


def test_volatility_is_floored():
    low = single_barrier_option_value(
        spot=100.0, carry_rate=0.04, discount_rate=0.08, volatility=0.01, expiry=0.5,
        strike=100.0, barrier=120.0, rebate=0.0, is_call=True, is_up=True, is_knock_in=False)
    floor = single_barrier_option_value(
        spot=100.0, carry_rate=0.04, discount_rate=0.08, volatility=0.05, expiry=0.5,
        strike=100.0, barrier=120.0, rebate=0.0, is_call=True, is_up=True, is_knock_in=False)
    assert float(low) == pytest.approx(float(floor))


def test_interval_monitoring_moves_the_barrier_away_from_the_price():
    weekly = 7.0 / 365.0
    assert float(monitoring_adjusted_barrier(110.0, 0.25, weekly, True)) > 110.0
    assert float(monitoring_adjusted_barrier(90.0, 0.25, weekly, False)) < 90.0
    assert float(monitoring_adjusted_barrier(110.0, 0.25, 0.0, True)) == 110.0
    shift = 0.5826 * 0.25 * np.sqrt(weekly)
    assert float(monitoring_adjusted_barrier(110.0, 0.25, weekly, True)) == pytest.approx(110.0 * np.exp(shift))


def test_accepts_arrays():
    values = single_barrier_option_value(
        spot=np.array([98.0, 100.0, 102.0]), carry_rate=0.04, discount_rate=0.08, volatility=0.25,
        expiry=0.5, strike=100.0, barrier=120.0, rebate=0.0, is_call=True, is_up=True,
        is_knock_in=False)
    assert values.shape == (3,) and np.all(np.diff(values) != 0.0)
