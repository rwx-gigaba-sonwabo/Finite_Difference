"""
Tests for instruments/fx_barrier_option.py and market_data FXVolSurface.

As with the underlying pricer, the assertions are analytical identities rather
than pinned reference numbers: in-out parity at the instrument level, buy/sell
antisymmetry, nominal linearity and the expiry payoff.

Note that ``FXBarrierOption`` keeps running touch state across calls
(``_touched``, ``_prev_spot``, ``_last_date``), so every price here is taken
from a freshly constructed instrument unless the test is specifically about
that state.
"""
from __future__ import annotations

from datetime import date

import numpy as np
import numpy.testing as npt
import pytest

from instruments.fx_barrier_option import FXBarrierOption
from market_data.risk_factor import CurveSlice, ScalarSlice
from market_data.vol_surface import FXVolSurface
from utils.interpolation import linear_interpolator
from utils.maths import norm_cdf


# ---------------------------------------------------------------------------
# Constants / helpers
# ---------------------------------------------------------------------------

N_PATHS = 4
TENORS = np.array([0.25, 0.5, 1.0, 2.0, 5.0], dtype=np.float64)

VAL_DATE = date(2025, 1, 2)
EXPIRY = date(2026, 1, 2)          # ACT/365 -> tau = 1.0 exactly

FX_SPOT = 18.0
STRIKE = 18.0
R_DOM = 0.08
R_FOR = 0.04
FLAT_VOL = 0.20
NOMINAL = 1_000_000.0


def flat_surface(vol=FLAT_VOL):
    """Explicit (moneyness, expiry, vol) triples, flat in both dimensions."""
    return np.array(
        [[m, e, vol] for e in (0.5, 1.0, 2.0) for m in (0.8, 1.0, 1.2)],
        dtype=np.float64,
    )


def market_state(spot=FX_SPOT, r_dom=R_DOM, r_for=R_FOR):
    return {
        "FX": ScalarSlice(values=np.full(N_PATHS, spot)),
        "ZAR": CurveSlice(values=np.full((N_PATHS, len(TENORS)), r_dom), tenors=TENORS),
        "USD": CurveSlice(values=np.full((N_PATHS, len(TENORS)), r_for), tenors=TENORS),
    }


def make_option(is_call=True, is_up=False, is_knock_in=False, barrier=16.0,
                buy=True, nominal=NOMINAL, maturity=EXPIRY, **kw):
    return FXBarrierOption(
        name="FXB",
        effective_date=VAL_DATE,
        maturity_date=maturity,
        strike=kw.pop("strike", STRIKE),
        barrier=barrier,
        is_call=is_call,
        is_up=is_up,
        is_knock_in=is_knock_in,
        nominal=nominal,
        currency_fx_name=None,
        underlying_fx_name="FX",
        domestic_curve_name="ZAR",
        foreign_curve_name="USD",
        vol_surface=FXVolSurface(flat_surface(), "Explicit"),
        domestic_interpolator=linear_interpolator,
        foreign_interpolator=linear_interpolator,
        buy=buy,
        **kw,
    )


def vanilla_fx_option(is_call=True, spot=FX_SPOT, strike=STRIKE, tau=1.0,
                      r_dom=R_DOM, r_for=R_FOR, vol=FLAT_VOL, nominal=NOMINAL):
    """Garman-Kohlhagen, i.e. generalised BS with carry = r_dom - r_for."""
    b = r_dom - r_for
    sqrtT = np.sqrt(tau)
    d1 = (np.log(spot / strike) + (b + 0.5 * vol ** 2) * tau) / (vol * sqrtT)
    d2 = d1 - vol * sqrtT
    phi = 1.0 if is_call else -1.0
    px = (
        phi * spot * np.exp((b - r_dom) * tau) * norm_cdf(phi * d1)
        - phi * strike * np.exp(-r_dom * tau) * norm_cdf(phi * d2)
    )
    return nominal * px


# ---------------------------------------------------------------------------
# FXVolSurface
# ---------------------------------------------------------------------------

class TestFXVolSurface:
    def test_flat_surface_returns_flat_vol(self):
        vs = FXVolSurface(flat_surface(0.23), "Explicit")
        for moneyness in (0.85, 1.0, 1.15):
            for expiry in (0.6, 1.0, 1.9):
                got = vs.get_vol(np.array([moneyness]), expiry)
                npt.assert_allclose(got, 0.23, rtol=1e-12)

    def test_flat_extrapolation_beyond_nodes(self):
        """Flat-extrapolated in both moneyness and expiry."""
        vs = FXVolSurface(flat_surface(0.23), "Explicit")
        npt.assert_allclose(vs.get_vol(np.array([0.1]), 1.0), 0.23, rtol=1e-12)
        npt.assert_allclose(vs.get_vol(np.array([9.0]), 1.0), 0.23, rtol=1e-12)
        npt.assert_allclose(vs.get_vol(np.array([1.0]), 0.01), 0.23, rtol=1e-12)
        npt.assert_allclose(vs.get_vol(np.array([1.0]), 50.0), 0.23, rtol=1e-12)

    def test_moneyness_is_forward_over_strike(self):
        vs = FXVolSurface(flat_surface(), "Explicit")
        fwd = np.array([20.0, 18.0])
        npt.assert_allclose(vs.moneyness_of(fwd, 18.0, False), fwd / 18.0, rtol=1e-12)

    def test_moneyness_inverts_when_asked(self):
        vs = FXVolSurface(flat_surface(), "Explicit")
        fwd = np.array([20.0, 18.0])
        plain = vs.moneyness_of(fwd, 18.0, False)
        inverted = vs.moneyness_of(fwd, 18.0, True)
        npt.assert_allclose(inverted, 1.0 / plain, rtol=1e-12)

    def test_unknown_surface_type_rejected(self):
        with pytest.raises(NotImplementedError, match="not supported"):
            FXVolSurface(flat_surface(), "SomethingElse")

    def test_sloped_surface_interpolates_monotonically(self):
        surface = np.array(
            [[0.8, 1.0, 0.18], [1.0, 1.0, 0.20], [1.2, 1.0, 0.26]], dtype=np.float64
        )
        vs = FXVolSurface(surface, "Explicit")
        vols = [float(vs.get_vol(np.array([m]), 1.0)[0]) for m in (0.8, 0.9, 1.0, 1.1, 1.2)]
        assert vols == sorted(vols), f"expected monotone increasing, got {vols}"


# ---------------------------------------------------------------------------
# In-out parity at the instrument level
# ---------------------------------------------------------------------------

class TestInOutParity:
    @pytest.mark.parametrize(
        "is_call, is_up, barrier",
        [
            (True, False, 16.0),
            (False, False, 16.0),
            (True, True, 20.0),
            (False, True, 20.0),
        ],
        ids=["down-call", "down-put", "up-call", "up-put"],
    )
    def test_knock_in_plus_knock_out_equals_vanilla(self, is_call, is_up, barrier):
        """With no rebate, in + out = the vanilla FX option.

        Both legs use the same monitoring-shifted barrier, so the shift cancels
        and parity is exact rather than approximate.
        """
        ms = market_state()
        ki = make_option(is_call, is_up, True, barrier).scenario_npvs(VAL_DATE, ms)
        ko = make_option(is_call, is_up, False, barrier).scenario_npvs(VAL_DATE, ms)
        expected = vanilla_fx_option(is_call=is_call)
        npt.assert_allclose(ki + ko, expected, rtol=1e-8)


# ---------------------------------------------------------------------------
# Structural properties
# ---------------------------------------------------------------------------

class TestStructuralProperties:
    def test_buy_and_sell_cancel(self):
        ms = market_state()
        bought = make_option(buy=True).scenario_npvs(VAL_DATE, ms)
        sold = make_option(buy=False).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(bought + sold, 0.0, atol=1e-9)

    def test_value_is_linear_in_nominal(self):
        ms = market_state()
        one = make_option(nominal=NOMINAL).scenario_npvs(VAL_DATE, ms)
        three = make_option(nominal=3.0 * NOMINAL).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(three, 3.0 * one, rtol=1e-10)

    def test_past_maturity_is_worthless(self):
        ms = market_state()
        pv = make_option().scenario_npvs(date(2026, 6, 1), ms)
        npt.assert_allclose(pv, 0.0, atol=1e-12)

    def test_returns_one_value_per_path(self):
        ms = market_state()
        pv = make_option().scenario_npvs(VAL_DATE, ms)
        assert pv.shape == (N_PATHS,)
        assert np.all(np.isfinite(pv))

    def test_effective_maturity_is_the_expiry(self):
        assert make_option().effective_maturity == EXPIRY

    def test_bad_fx_quote_rejected(self):
        with pytest.raises(ValueError, match="fx_quote"):
            make_option(fx_quote="upside_down")

    def test_min_vol_floors_the_lookup(self):
        """A surface below min_vol must be floored, not used as-is."""
        ms = market_state()
        opt = FXBarrierOption(
            name="FLOORED", effective_date=VAL_DATE, maturity_date=EXPIRY,
            strike=STRIKE, barrier=16.0, is_call=True, is_up=False,
            is_knock_in=False, nominal=NOMINAL,
            currency_fx_name=None, underlying_fx_name="FX",
            domestic_curve_name="ZAR", foreign_curve_name="USD",
            vol_surface=FXVolSurface(flat_surface(0.001), "Explicit"),
            domestic_interpolator=linear_interpolator,
            foreign_interpolator=linear_interpolator,
            min_vol=0.10,
        )
        floored = opt.scenario_npvs(VAL_DATE, ms)
        # Same option priced with a surface already at the floor must agree.
        at_floor = FXBarrierOption(
            name="ATFLOOR", effective_date=VAL_DATE, maturity_date=EXPIRY,
            strike=STRIKE, barrier=16.0, is_call=True, is_up=False,
            is_knock_in=False, nominal=NOMINAL,
            currency_fx_name=None, underlying_fx_name="FX",
            domestic_curve_name="ZAR", foreign_curve_name="USD",
            vol_surface=FXVolSurface(flat_surface(0.10), "Explicit"),
            domestic_interpolator=linear_interpolator,
            foreign_interpolator=linear_interpolator,
            min_vol=0.10,
        ).scenario_npvs(VAL_DATE, ms)
        npt.assert_allclose(floored, at_floor, rtol=1e-10)


# ---------------------------------------------------------------------------
# Already-crossed barrier
# ---------------------------------------------------------------------------

class TestBarrierCrossed:
    def test_crossed_knock_out_is_worthless_without_rebate(self):
        ms = market_state()
        pv = make_option(is_knock_in=False, barrier_crossed=True).scenario_npvs(
            VAL_DATE, ms
        )
        npt.assert_allclose(pv, 0.0, atol=1e-6)

    def test_crossed_knock_in_is_the_vanilla(self):
        ms = market_state()
        pv = make_option(is_knock_in=True, barrier_crossed=True).scenario_npvs(
            VAL_DATE, ms
        )
        npt.assert_allclose(pv, vanilla_fx_option(), rtol=1e-6)
