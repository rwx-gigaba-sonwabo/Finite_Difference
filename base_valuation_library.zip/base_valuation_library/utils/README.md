# Utilities

Helpers used across the library: interpolation schemes, date and schedule helpers, day
counts and small maths functions.

## Files

| File | What it holds |
|---|---|
| `conversion.py` | Conversions between date types and between calendar dates and Excel serial dates. |
| `curve_interpolation.py` | Choosing the interpolation scheme for a curve from the settings in a trade JSON file. |
| `inflation_index.py` | Consumer price index helper: reference months, publication lag and interpolation of levels. |
| `interpolation.py` | Interpolation schemes for curves: linear, linear in rate times time, Hermite and others. |
| `maths.py` | Standard normal distribution function. |
| `ql_helpers.py` | Helpers around the QuantLib package: calendars, day counts and payment schedules. |
