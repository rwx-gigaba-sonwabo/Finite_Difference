"""Choosing the interpolation scheme for a curve from the settings in a trade JSON file.

A curve is a set of pillars. The value between two pillars depends on the interpolation
scheme. Two systems can only agree on a value when they read the same curve with the same
scheme, so the scheme is resolved from the trade file itself and never assumed.

How the scheme is resolved
--------------------------
* ``InterestRate``, ``InflationRate`` and ``ForwardRate`` curves take their scheme from the
  ``Price Factor Interpolation`` section of the market data. That section holds filter rules
  per curve type, ``[[attribute, value], scheme]``. A rule matches when the curve has that
  attribute with that value. The attribute ``id`` stands for the curve name. The first
  matching rule wins. When no rule matches, the default for the curve type is used. When
  there is no default, the scheme is ``Linear``. The curve's own ``Interpolation`` field is
  not used for these types.
* ``DividendRate`` curves are always linear in ``1 / t``.
* Any other curve type uses its own ``Interpolation`` field, and ``Linear`` when that field
  is not one of the four schemes.
* A curve that sets ``Near_Interpolation`` and ``Near_Date`` uses two schemes split at a
  date. That is not supported here and is refused with a clear message.

Every scheme is flat outside the pillar range.

The schemes
-----------
``Linear``       linear in the zero rate
``LinearRT``     linear in zero rate times time
``Hermite``      cubic Hermite spline in the zero rate
``HermiteRT``    cubic Hermite spline in zero rate times time
``ReciprocalTime``  linear in ``1 / t``, used for dividend yield curves
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import numpy as np

from utils.interpolation import (
    hermite_interp,
    hermite_rt_interp,
    linear_interpolator,
    linear_rt_interp,
)

#: Long form scheme names that can appear in a trade file, mapped onto the scheme they mean.
FACTOR_INTERP_MAP = {
    "CubicSplineCurveInterpolation": "Hermite",
    "HermiteInterpolationCurveGetValue": "Hermite",
    "LinearInterFlatExtrapCurveGetValue": "Linear",
    "LogLinearCurveInterpolation": "LinearRT",
    "CubicSplineOnXTimesYCurveInterpolation": "HermiteRT",
    "HermiteRTInterpolationCurveGetValue": "HermiteRT",
    "NaturalCubicSplineCurveInterLinearExtrap": "Hermite",
    "LogNaturalCubicSplineCurveInterFlatExtrap": "HermiteRT",
    "HermiteRT": "HermiteRT",
    "Hermite": "Hermite",
    "LinearRT": "LinearRT",
    "Linear": "Linear",
    "LinearExtrapolate": "LinearExtrapolate",
}
INTERPOLATION_DEFAULT = "Linear"
ROUTED_TYPES = ("InterestRate", "InflationRate", "ForwardRate")
SCHEMES = ("HermiteRT", "Hermite", "LinearRT", "Linear")

def reciprocal_time_clipped_interp(year_fracs: np.ndarray, rates: np.ndarray) -> Callable:
    """Interpolator that is linear in ``1 / t`` between pillars, for dividend yield curves.

    ``1 / t`` is clipped at a tenor of ``1e-5`` years, so a pillar at tenor zero can be used
    without dividing by zero. Beyond the last pillar the rate is flat.

    Parameters
    ----------
    year_fracs : np.ndarray, shape (n_tenors,)
        Pillar tenors in years, sorted ascending.
    rates : np.ndarray, shape (n_paths, n_tenors) or (n_tenors,)
        Rate at each pillar.

    Returns
    -------
    callable
        ``t -> rates`` with shape ``(n_paths,)`` for a scalar ``t`` and
        ``(n_paths, n_queries)`` for an array ``t``.
    """
    x = np.asarray(year_fracs, dtype=np.float64)
    r = np.atleast_2d(np.asarray(rates, dtype=np.float64))
    last = max(x.size - 1, 0)
    inv = 1.0 / np.clip(x, 1e-5, np.inf)
    tenor_delta = np.append(inv[:-1] - inv[1:], 1.0)
    lo, hi = max(1e-5, x.min()), max(1e-5, x.max())

    def interp(t):
        scalar = np.isscalar(t)
        ten = np.atleast_1d(np.asarray(t, dtype=np.float64))
        idx = np.clip(np.searchsorted(x, ten, side="right") - 1, 0, last)
        nxt = np.clip(idx + 1, 0, last)
        alpha = (inv[idx] - 1.0 / np.clip(ten, lo, hi)) / tenor_delta[idx]
        out = r[:, idx] * (1.0 - alpha) + alpha * r[:, nxt]
        return out[:, 0] if scalar else out

    return interp


#: Scheme name mapped onto the interpolator factory that builds it.
INTERPOLATORS: dict[str, Callable] = {
    "HermiteRT": hermite_rt_interp,
    "Hermite": hermite_interp,
    "LinearRT": linear_rt_interp,
    "Linear": linear_interpolator,
    "ReciprocalTime": reciprocal_time_clipped_interp,
}


def _market(blob: dict) -> dict:
    """Return the market data block of a loaded trade file."""
    try:
        return blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]
    except KeyError:
        return blob.get("MarketData", {})


def _model_params(section) -> tuple[dict, dict]:
    """(modeldefaults, modelfilters) of a ``.ModelParams`` block; empty when absent."""
    if not section:
        return {}, {}
    params = section.get(".ModelParams", section)
    return params.get("modeldefaults", {}) or {}, params.get("modelfilters", {}) or {}


def resolve_curve_interpolation(job: str | Path | dict, factor_key: str) -> tuple[str, str]:
    """Return the interpolation scheme of one curve and a short note on how it was found.

    Parameters
    ----------
    job : str, Path or dict
        The trade JSON file, as a path or as the loaded dictionary.
    factor_key : str
        Full curve name with its type, for example ``"InterestRate.ZAR-SWAP"``.

    Returns
    -------
    scheme : str
        One of the keys of ``INTERPOLATORS``.
    how : str
        Plain language note on which rule gave the scheme. Printed by the run scripts so
        the choice can be checked.
    """
    blob = job if isinstance(job, dict) else json.loads(Path(job).read_text())
    market = _market(blob)
    factors = market.get("Price Factors", {})
    if factor_key not in factors:
        raise KeyError(f"{factor_key!r} not in Price Factors; available: {sorted(factors)}")
    pf = factors[factor_key]
    ftype, _, name = factor_key.partition(".")

    if pf.get("Near_Interpolation") and pf.get("Near_Date"):
        raise NotImplementedError(
            f"{factor_key}: Near_Interpolation {pf['Near_Interpolation']!r} up to "
            f"{pf['Near_Date']} uses two schemes on one curve. Only one scheme per curve is "
            f"supported. Set this curve's interpolation by hand if one scheme is acceptable.")
    if ftype == "DividendRate":
        return "ReciprocalTime", "DividendRate: always linear in 1/t"

    if ftype in ROUTED_TYPES:
        defaults, filters = _model_params(market.get("Price Factor Interpolation"))
        attribs = {str(k).lower(): v for k, v in pf.items()}
        attribs["id"] = name
        raw: str | None = None
        how = ""
        for (attrib, value), scheme in filters.get(ftype, []):
            if attribs.get(str(attrib).strip().lower()) == str(value).strip():
                raw, how = scheme, f"Price Factor Interpolation filter {attrib}={value}"
                break
        if raw is None and ftype in defaults:
            raw, how = defaults[ftype], f"Price Factor Interpolation default for {ftype}"
        if raw is None:
            return INTERPOLATION_DEFAULT, (f"no Price Factor Interpolation entry for {ftype}: "
                                           f"default scheme used (the curve's own field is not read)")
        scheme = FACTOR_INTERP_MAP.get(raw, INTERPOLATION_DEFAULT)
        if scheme == "LinearExtrapolate":
            raise NotImplementedError(f"{factor_key}: LinearExtrapolate is not a YieldCurve scheme")
        if raw not in FACTOR_INTERP_MAP:
            how += f" ({raw!r} is not a known scheme, read as {INTERPOLATION_DEFAULT})"
        return scheme, how

    own = pf.get("Interpolation")
    if own in SCHEMES:
        return own, f"{ftype}: its own Interpolation field"
    return INTERPOLATION_DEFAULT, f"{ftype}: own field {own!r} is not a scheme, default used"


def interpolator(scheme: str | Callable) -> Callable:
    """Return the interpolator factory for a scheme name.

    A factory that is passed in is returned unchanged, so callers can accept either form.
    """
    if callable(scheme):
        return scheme
    if scheme not in INTERPOLATORS:
        raise ValueError(f"unknown interpolation {scheme!r}; one of {sorted(INTERPOLATORS)} or a "
                         f"(year_fracs, rates) -> callable factory")
    return INTERPOLATORS[scheme]
