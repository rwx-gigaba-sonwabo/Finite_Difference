"""Standard normal distribution function."""

from __future__ import annotations

import math

import numpy as np

_SQRT2 = np.sqrt(2.0)

# Use scipy.special.erf if available, otherwise fall back to math.erf
try:
    from scipy.special import erf as _erf
except ImportError:
    _erf = np.vectorize(math.erf)


def norm_cdf(x: np.ndarray) -> np.ndarray:
    """Standard normal CDF."""
    return 0.5 * (1.0 + _erf(x / _SQRT2))
