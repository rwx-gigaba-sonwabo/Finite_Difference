# Market data

Containers for market data: curves, volatility surfaces and the small slice types that carry
one curve or one number into an instrument.

## Files

| File | What it holds |
|---|---|
| `forward_price_curve.py` | Commodity forward price curve read by delivery date. |
| `moneyness_vol_surface.py` | Implied volatility surface quoted on a grid of moneyness and time to expiry. |
| `risk_factor.py` | Small containers that carry one number, one curve or one surface into an instrument. |
| `vol_surface.py` | Benchmark volatility skew surface for equities. |
| `yield_curve.py` | Zero rate curve with a chosen interpolation scheme. Gives rates and discount factors. |
