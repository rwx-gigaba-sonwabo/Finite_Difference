"""Implied volatility surface quoted on a grid of moneyness and time to expiry.

The surface is a list of ``(moneyness, expiry, volatility)`` points. A volatility is read
off it in three steps:

1. Every expiry row is placed on one shared moneyness axis, the union of all quoted
   moneyness points. Values between a row's own points are linear in volatility.
2. The two rows either side of the wanted expiry are blended linearly in volatility.
3. The blended row is read linearly at the wanted moneyness.

Outside the quoted range the surface is flat, in both moneyness and expiry.

Moneyness conventions
---------------------
``"ratio"``
    ``underlying / strike``. At the money is 1.
``"relative_forward"``
    ``(strike - forward) / forward``. At the money is 0.
"""

from __future__ import annotations

import numpy as np

MONEYNESS_CONVENTIONS = ("ratio", "relative_forward")


class MoneynessVolSurface:
    """Volatility surface on a moneyness by expiry grid, linear inside and flat outside.

    Parameters
    ----------
    points : array-like, shape (n, 3)
        Rows of ``[moneyness, expiry_in_years, volatility]``.
    moneyness_convention : {"ratio", "relative_forward"}
        How a strike is turned into the moneyness coordinate of the grid.

    Attributes
    ----------
    expiries : np.ndarray
        Sorted expiry pillars in years.
    moneyness_axis : np.ndarray
        Sorted union of every quoted moneyness.
    grid : np.ndarray, shape (n_expiries, n_moneyness)
        Volatility of each expiry row on the shared moneyness axis.
    """

    def __init__(self, points, moneyness_convention: str = "ratio") -> None:
        if moneyness_convention not in MONEYNESS_CONVENTIONS:
            raise ValueError(
                f"moneyness_convention must be one of {MONEYNESS_CONVENTIONS}, "
                f"got {moneyness_convention!r}")
        points = np.asarray(points, dtype=float)
        if points.ndim != 2 or points.shape[1] != 3 or points.shape[0] == 0:
            raise ValueError("points must be rows of [moneyness, expiry, volatility]")

        self.moneyness_convention = moneyness_convention
        self.expiries = np.unique(points[:, 1])
        self.moneyness_axis = np.unique(points[:, 0])

        rows = []
        for expiry in self.expiries:
            row = points[points[:, 1] == expiry]
            row = row[np.argsort(row[:, 0])]
            rows.append(np.interp(self.moneyness_axis, row[:, 0], row[:, 2]))
        self.grid = np.array(rows)

    # ---------------------------------------------------------------- lookups
    @property
    def at_the_money_moneyness(self) -> float:
        """The moneyness coordinate of an at the money option."""
        return 1.0 if self.moneyness_convention == "ratio" else 0.0

    def moneyness_of(self, underlying, strike, invert: bool = False) -> np.ndarray:
        """Turn an underlying level and a strike into the grid's moneyness coordinate.

        Parameters
        ----------
        underlying : float or np.ndarray
            The forward price or the spot price, whichever the instrument reads the
            surface with.
        strike : float or np.ndarray
            The option strike.
        invert : bool
            For the ``"ratio"`` convention only. ``True`` gives ``strike / underlying``.
        """
        underlying = np.asarray(underlying, dtype=float)
        strike = np.asarray(strike, dtype=float)
        if self.moneyness_convention == "relative_forward":
            return (strike - underlying) / underlying
        return strike / underlying if invert else underlying / strike

    def get_vol(self, moneyness, expiry: float) -> np.ndarray:
        """Volatility at a moneyness coordinate and a time to expiry in years.

        ``moneyness=None`` reads the at the money volatility.
        """
        if moneyness is None:
            moneyness = self.at_the_money_moneyness
        pillars = self.expiries
        t = float(np.clip(expiry, pillars[0], pillars[-1]))
        lower = max(int(pillars.searchsorted(t, side="right")) - 1, 0)
        upper = min(lower + 1, pillars.size - 1)
        weight = 0.0 if upper == lower else (t - pillars[lower]) / (pillars[upper] - pillars[lower])
        row = self.grid[lower] * (1.0 - weight) + self.grid[upper] * weight
        return np.interp(np.asarray(moneyness, dtype=float), self.moneyness_axis, row)

    def at_the_money_vol(self, expiry: float) -> float:
        """Volatility of an at the money option for a time to expiry in years."""
        return float(self.get_vol(None, expiry))


class FlatVolSurface:
    """A single volatility for every strike and expiry. Useful for tests and what if runs."""

    moneyness_convention = "ratio"
    at_the_money_moneyness = 1.0

    def __init__(self, volatility: float) -> None:
        self.volatility = float(volatility)

    def moneyness_of(self, underlying, strike, invert: bool = False) -> np.ndarray:
        underlying = np.asarray(underlying, dtype=float)
        return strike / underlying if invert else underlying / strike

    def get_vol(self, moneyness, expiry: float) -> np.ndarray:
        shape = np.shape(moneyness) if moneyness is not None else ()
        return np.full(shape, self.volatility) if shape else np.float64(self.volatility)

    def at_the_money_vol(self, expiry: float) -> float:
        return self.volatility
