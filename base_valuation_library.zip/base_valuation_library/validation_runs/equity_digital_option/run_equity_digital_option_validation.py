"""Validation run: base valuation of a European equity digital option.

A European digital (binary) call or put on a share or an index. It pays a fixed amount of
cash, or a number of shares, when the equity closes beyond the strike on the expiry date.
It is valued with the Black model on the forward price of the equity, either in closed form
or as a tight call or put spread that prices in the slope of the volatility smile.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/equity_digital_option/run_equity_digital_option_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/equity_digital_option.py``  the instrument and its valuation steps
``models/digital_option_pv.py``           the digital option formulas
``models/equity_pv.py``                   the equity forward price
``docs/equity_digital_option.md``         the method in words and formulas
"""

from __future__ import annotations

import sys
from datetime import date, timedelta
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.equity_digital_option import EquityDigitalOption  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# Deal type of a European equity digital option in the trade file.
DEAL_TYPE = "EquityBinaryOption"

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only digital in the file.
TRADE_REFERENCE = "AUTOCALL_DIGITAL_EUROPEAN"

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Spot price of the equity.
SPOT_PRICE = "EquityPrice.ZAR_EQUITY_INDEX"

# Zero rate curve the equity price grows on (the funding or repo curve).
CARRY_CURVE = "InterestRate.ZAR-SWAP"

# Continuous dividend yield curve of the equity.
DIVIDEND_CURVE = "DividendRate.ZAR_EQUITY_INDEX"

# Zero rate curve used to discount the payout.
DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Volatility of the equity. Either a parametric skew (Surface_Type "Skew") or a moneyness
# grid (Surface_Type "Explicit"). The script picks the right reader from the file.
VOLATILITY_SURFACE = "EquityPriceVol.ZAR_EQUITY_INDEX"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Date the equity price is observed.
EXPIRY_DATE = from_trade_file("Expiry_Date")

# Date the payout is paid. None, or a deal without the field, pays on the expiry date.
SETTLEMENT_DATE = from_trade_file("Settlement_Date", default=None)

# Strike price.
STRIKE = from_trade_file("Strike_Price")

# True for a call, False for a put.
IS_CALL = from_trade_file("Option_Type", is_call)

# Cash amount paid ("Cash" style) or number of shares paid ("Asset" style) when in the money.
PAYOFF_AMOUNT = from_trade_file("Payoff")

# "Cash" or "Asset".
PAYOFF_STYLE = from_trade_file("Payoff_Style", default="Cash")

# True when the option was bought, False when sold.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# "Standard" or "Quanto". A quanto payout also needs the two quanto settings below.
PAYOFF_TYPE = from_trade_file("Payoff_Type", default="Standard")

# Observed closing price on the expiry date. Only needed when the valuation date is after
# the expiry date but on or before the settlement date.
EXPIRY_FIXING = None

# --- Valuation method --------------------------------------------------------
# Half width of the replicating strike spread, as a fraction of the strike.
#   None  : use the value in the trade file (Valuation Configuration >
#           EquityBinaryOption > Relative_Digital_Spread). Zero if the file has none.
#   0.0   : closed form with one volatility at the strike. Ignores the smile slope.
#   0.005 : call or put spread with strikes 0.5% either side of the strike.
RELATIVE_DIGITAL_SPREAD = None

# Business days after the expiry date that the forward price is carried to. 0 carries the
# forward to the expiry date. 2 carries it to the date the equity would settle, two
# business days later, which is how the target system matched for the autocall's
# European digital. Weekends are skipped. Public holidays are not. The volatility time
# always runs to the expiry date and the discounting to the settlement date.
FORWARD_LAG_BUSINESS_DAYS = 2

# How a parametric skew is read: "strike" or "delta". Not used by a moneyness grid.
SKEW_STICKINESS = "strike"

# Underlying level a moneyness grid is read with: "spot" (moneyness = spot / strike) or
# "forward" (moneyness = forward / strike). Not used by a parametric skew.
VOLATILITY_MONEYNESS_BASIS = "spot"

# --- Quanto payout -----------------------------------------------------------
# Only used when PAYOFF_TYPE is "Quanto". The forward then drifts at an extra rate of
# minus correlation times equity volatility times FX volatility.
QUANTO_FX_VOLATILITY = None            # example: 0.145
QUANTO_CORRELATION = None              # example: -0.25

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = SCRIPT_FOLDER / "sample_comparison_values.csv"
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-8      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def add_business_days(start: date, business_days: int) -> date:
    """Move a date forward by a number of business days, skipping Saturdays and Sundays."""
    day = start
    remaining = business_days
    while remaining > 0:
        day += timedelta(days=1)
        if day.weekday() < 5:
            remaining -= 1
    return day


def read_trade_terms(deal: dict, trade_file: TradeFile) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    spread = RELATIVE_DIGITAL_SPREAD
    if spread is None:
        spread = trade_file.valuation_setting(DEAL_TYPE, "Relative_Digital_Spread", 0.0) or 0.0
    return {
        "expiry_date": resolve_term(EXPIRY_DATE, deal, "EXPIRY_DATE"),
        "settlement_date": resolve_term(SETTLEMENT_DATE, deal, "SETTLEMENT_DATE"),
        "strike": float(resolve_term(STRIKE, deal, "STRIKE")),
        "is_call": bool(resolve_term(IS_CALL, deal, "IS_CALL")),
        "payoff_amount": float(resolve_term(PAYOFF_AMOUNT, deal, "PAYOFF_AMOUNT")),
        "payoff_style": str(resolve_term(PAYOFF_STYLE, deal, "PAYOFF_STYLE")).strip().lower(),
        "is_buy": bool(resolve_term(IS_BUY, deal, "IS_BUY")),
        "payoff_type": str(resolve_term(PAYOFF_TYPE, deal, "PAYOFF_TYPE")).strip().lower(),
        "relative_digital_spread": float(spread),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    if terms["payoff_type"] not in ("standard", "quanto"):
        raise NotImplementedError(
            f"Payoff_Type {terms['payoff_type']!r} is not supported. Use Standard or Quanto.")
    quanto = terms["payoff_type"] == "quanto"
    if quanto and (QUANTO_FX_VOLATILITY is None or QUANTO_CORRELATION is None):
        raise ValueError("The deal has a quanto payout. Set QUANTO_FX_VOLATILITY and "
                         "QUANTO_CORRELATION in the run script.")

    instrument = EquityDigitalOption(
        name="equity_digital_option",
        expiry_date=terms["expiry_date"],
        strike=terms["strike"],
        payoff_amount=terms["payoff_amount"],
        is_call=terms["is_call"],
        spot_name=SPOT_PRICE,
        carry_curve_name=CARRY_CURVE,
        dividend_curve_name=DIVIDEND_CURVE,
        discount_curve_name=DISCOUNT_CURVE,
        vol_surface=market.equity_volatility(VOLATILITY_SURFACE),
        carry_interpolator=market.curve_interpolator(CARRY_CURVE),
        dividend_interpolator=market.curve_interpolator(DIVIDEND_CURVE),
        discount_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        is_buy=terms["is_buy"],
        payoff_style=terms["payoff_style"],
        settlement_date=terms["settlement_date"],
        forward_date=add_business_days(terms["expiry_date"], FORWARD_LAG_BUSINESS_DAYS),
        relative_digital_spread=terms["relative_digital_spread"],
        skew_stickiness=SKEW_STICKINESS,
        moneyness_basis=VOLATILITY_MONEYNESS_BASIS,
        quanto_fx_volatility=QUANTO_FX_VOLATILITY if quanto else None,
        quanto_correlation=QUANTO_CORRELATION if quanto else None,
        expiry_fixing=EXPIRY_FIXING,
    )
    market_state = market.market_state(
        curves=[CARRY_CURVE, DIVIDEND_CURVE, DISCOUNT_CURVE], scalars=[SPOT_PRICE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE, deal_type=DEAL_TYPE)
    trade_reference = deal.get("Reference") or "equity_digital_option"

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal, trade_file)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type="European equity digital option",
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[
            f"Payout style: {terms['payoff_style']}. Payout type: {terms['payoff_type']}.",
            f"Digital strike spread: {terms['relative_digital_spread']:g}.",
            f"Forward price carried to {instrument.forward_date.isoformat()} "
            f"({FORWARD_LAG_BUSINESS_DAYS} business days after expiry).",
        ],
    )


if __name__ == "__main__":
    main()
