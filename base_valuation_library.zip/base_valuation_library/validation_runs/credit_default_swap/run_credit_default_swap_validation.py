"""Validation run: base valuation of a credit default swap.

Protection on a reference name against a regular premium. The value is the protection
leg less the premium leg for a protection buyer. Default probabilities come from a
hazard rate curve and a default is assumed to fall in the middle of a period.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/credit_default_swap/run_credit_default_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/cds.py``  the instrument
``models/credit_pv.py``  protection and premium legs

Points to note
--------------
The value is in the currency of the trade. It is not converted into the reporting
currency of the trade file.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.cds import CDS  # noqa: E402
from utils.interpolation import linear_rt_interp  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'USD_CDS_5Y_BUY_PROTECTION'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Zero rate curve used to discount both legs.
DISCOUNT_CURVE = "InterestRate.USD-SOFR"

# Survival probability curve of the reference name. The file stores minus the log of the
# survival probability at each tenor.
SURVIVAL_CURVE = "SurvivalProb.COUNTERPARTY"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Date protection starts.
EFFECTIVE_DATE = from_trade_file("Effective_Date")

# Date protection ends.
MATURITY_DATE = from_trade_file("Maturity_Date")

# Protected amount.
NOTIONAL = from_trade_file("Principal")

# Premium per year, as a decimal. 0.01 means 100 basis points.
PREMIUM_RATE = from_trade_file("Pay_Rate")

# True when protection is bought.
IS_PROTECTION_BUYER = from_trade_file("Buy_Sell", is_buy)

# Recovery rate as a decimal. None reads it from the survival curve factor, and uses 0.4
# when the factor has none.
RECOVERY_RATE = None

# Months between premium payments.
PREMIUM_FREQUENCY_MONTHS = 3

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "effective_date": resolve_term(EFFECTIVE_DATE, deal, "EFFECTIVE_DATE"),
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "notional": resolve_term(NOTIONAL, deal, "NOTIONAL"),
        "premium_rate": resolve_term(PREMIUM_RATE, deal, "PREMIUM_RATE"),
        "is_protection_buyer": resolve_term(IS_PROTECTION_BUYER, deal, "IS_PROTECTION_BUYER"),
        "recovery_rate": resolve_term(RECOVERY_RATE, deal, "RECOVERY_RATE"),
        "premium_frequency_months": resolve_term(PREMIUM_FREQUENCY_MONTHS, deal, "PREMIUM_FREQUENCY_MONTHS"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    recovery_rate = terms["recovery_rate"]
    if recovery_rate is None:
        recovery_rate = market.recovery_rate(SURVIVAL_CURVE)
    instrument = CDS(
        name="credit_default_swap",
        effective_date=terms["effective_date"],
        maturity_date=terms["maturity_date"],
        notional=float(terms["notional"]),
        coupon=float(terms["premium_rate"]),
        recovery_rate=float(recovery_rate),
        discount_curve_name=DISCOUNT_CURVE,
        credit_curve_name=SURVIVAL_CURVE,
        interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        credit_interpolator=linear_rt_interp,
        is_protection_buyer=bool(terms["is_protection_buyer"]),
        frequency=terms["premium_frequency_months"],
    )
    # The survival curve is turned into average hazard rates before it is priced.
    market_state = market.market_state(
        curves=[DISCOUNT_CURVE],
        extra={SURVIVAL_CURVE: market.hazard_rate_slice(SURVIVAL_CURVE)})
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'credit_default_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Credit default swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
