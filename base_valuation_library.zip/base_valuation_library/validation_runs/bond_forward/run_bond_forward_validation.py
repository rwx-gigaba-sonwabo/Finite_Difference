"""Validation run: base valuation of a forward on a fixed coupon bond.

An agreement to buy a fixed coupon bond at an agreed clean price on a delivery date. The
bond cashflows after delivery are valued on the bond curve, carried to delivery on the
repo curve and compared with the agreed dirty price, then discounted on the forward
curve.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/bond_forward/run_bond_forward_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/bond_forward.py``  the instrument
``models/bond_pv.py``  bond and forward valuation
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.bond_forward import BondForward  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_BOND_FORWARD_3M'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Zero rate curve the bond cashflows are discounted on.
BOND_CURVE = "InterestRate.ZAR-BOND"

# Zero rate curve the bond is carried on to the delivery date.
REPO_CURVE = "InterestRate.ZAR-REPO"

# Zero rate curve the forward payoff is discounted on.
FORWARD_DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# First accrual date of the bond.
BOND_ISSUE_DATE = date(2015, 3, 31)

# Redemption date of the bond.
BOND_MATURITY_DATE = date(2035, 3, 31)

# Date the bond is delivered against the agreed price.
DELIVERY_DATE = from_trade_file("Settlement_Date")

# Coupon per year, as a decimal.
COUPON_RATE = 0.0875

# Months between coupons.
COUPON_FREQUENCY_MONTHS = 6

# Face value of the bond.
NOTIONAL = from_trade_file("Notional")

# Agreed clean price as a fraction of face value. 0.925 means 92.50 per 100.
FORWARD_CLEAN_PRICE = from_trade_file("Forward_Clean_Price")

# True when the bond is bought forward.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "bond_issue_date": resolve_term(BOND_ISSUE_DATE, deal, "BOND_ISSUE_DATE"),
        "bond_maturity_date": resolve_term(BOND_MATURITY_DATE, deal, "BOND_MATURITY_DATE"),
        "delivery_date": resolve_term(DELIVERY_DATE, deal, "DELIVERY_DATE"),
        "coupon_rate": resolve_term(COUPON_RATE, deal, "COUPON_RATE"),
        "coupon_frequency_months": resolve_term(COUPON_FREQUENCY_MONTHS, deal, "COUPON_FREQUENCY_MONTHS"),
        "notional": resolve_term(NOTIONAL, deal, "NOTIONAL"),
        "forward_clean_price": resolve_term(FORWARD_CLEAN_PRICE, deal, "FORWARD_CLEAN_PRICE"),
        "is_buy": resolve_term(IS_BUY, deal, "IS_BUY"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    instrument = BondForward(
        name="bond_forward",
        effective_date=terms["bond_issue_date"],
        maturity_date=terms["bond_maturity_date"],
        delivery_date=terms["delivery_date"],
        coupon_rate=float(terms["coupon_rate"]),
        coupon_frequency=terms["coupon_frequency_months"],
        notional=float(terms["notional"]),
        forward_clean_price=float(terms["forward_clean_price"]),
        bond_curve_name=BOND_CURVE,
        interpolator=market.curve_interpolator(BOND_CURVE),
        direction=1 if terms["is_buy"] else -1,
        repo_curve_name=REPO_CURVE,
        forward_curve_name=FORWARD_DISCOUNT_CURVE,
        repo_interpolator=market.curve_interpolator(REPO_CURVE),
        forward_interpolator=market.curve_interpolator(FORWARD_DISCOUNT_CURVE),
    )
    market_state = market.market_state(curves=[BOND_CURVE, REPO_CURVE, FORWARD_DISCOUNT_CURVE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'bond_forward'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Bond forward',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
