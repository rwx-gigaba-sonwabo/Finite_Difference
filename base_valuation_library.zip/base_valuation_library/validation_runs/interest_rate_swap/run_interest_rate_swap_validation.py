"""Validation run: base valuation of an interest rate swap.

A single currency swap of a fixed leg against a floating leg. Each leg is the sum of its
remaining cashflows, discounted. Floating cashflows that have not fixed yet use forward
rates from the projection curve. The value is the receive leg less the pay leg.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/interest_rate_swap/run_interest_rate_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/ir_swap.py``  the instrument
``models/cashflow_pv.py``  leg cashflows and discounting
``instruments/components/cashflow_leg.py``  leg definition

Points to note
--------------
One interpolation scheme is used for both curves, the scheme of the discount curve.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

import numpy as np  # noqa: E402
from instruments.components.schedule_config import ScheduleConfig  # noqa: E402
from instruments.ir_swap import IRSwap, LegType, SwapLeg  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_IRS_5Y_PAY_FIXED'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Zero rate curve used to discount both legs.
DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Zero rate curve the floating rate is projected from.
PROJECTION_CURVE = "InterestRate.ZAR-JIBAR-3M"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# First accrual date of the swap.
EFFECTIVE_DATE = from_trade_file("Effective_Date")

# Last payment date of the swap.
MATURITY_DATE = from_trade_file("Maturity_Date")

# Notional amount both legs accrue on.
NOTIONAL = from_trade_file("Principal")

# Fixed rate per year, as a decimal.
FIXED_RATE = from_trade_file("Swap_Rate")

# Spread added to the floating rate, as a decimal.
FLOATING_SPREAD = from_trade_file("Floating_Margin", default=0.0)

# True when the fixed leg is received and the floating leg is paid. The deal field says
# which rate type is paid.
RECEIVE_FIXED = from_trade_file("Pay_Rate_Type", lambda v: v == "Floating")

# Months between fixed payments. 0 means one payment at maturity.
FIXED_FREQUENCY_MONTHS = 3

# Months between floating payments.
FLOATING_FREQUENCY_MONTHS = 3

# Holiday calendar for the payment schedule.
CALENDAR = "ZAR"

# Day count for the accrual fraction of each period.
ACCRUAL_DAY_COUNT = "ACT/365"

# Floating rates that fixed before the valuation date, as {period start date: rate}.
# Needed for a period that started before the valuation date. Example: {date(2026, 8,
# 3): 0.0721}.
KNOWN_FLOATING_RATES = {}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "effective_date": resolve_term(EFFECTIVE_DATE, deal, "EFFECTIVE_DATE"),
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "notional": resolve_term(NOTIONAL, deal, "NOTIONAL"),
        "fixed_rate": resolve_term(FIXED_RATE, deal, "FIXED_RATE"),
        "floating_spread": resolve_term(FLOATING_SPREAD, deal, "FLOATING_SPREAD"),
        "receive_fixed": resolve_term(RECEIVE_FIXED, deal, "RECEIVE_FIXED"),
        "fixed_frequency_months": resolve_term(FIXED_FREQUENCY_MONTHS, deal, "FIXED_FREQUENCY_MONTHS"),
        "floating_frequency_months": resolve_term(FLOATING_FREQUENCY_MONTHS, deal, "FLOATING_FREQUENCY_MONTHS"),
        "calendar": resolve_term(CALENDAR, deal, "CALENDAR"),
        "accrual_day_count": resolve_term(ACCRUAL_DAY_COUNT, deal, "ACCRUAL_DAY_COUNT"),
        "known_floating_rates": resolve_term(KNOWN_FLOATING_RATES, deal, "KNOWN_FLOATING_RATES"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    fixed_leg = SwapLeg(LegType.FIXED, frequency=terms["fixed_frequency_months"],
                        fixed_rate=float(terms["fixed_rate"]))
    floating_leg = SwapLeg(LegType.FLOATING, frequency=terms["floating_frequency_months"],
                           curve_name=PROJECTION_CURVE, spread=float(terms["floating_spread"]))
    receive_leg, pay_leg = ((fixed_leg, floating_leg) if terms["receive_fixed"]
                            else (floating_leg, fixed_leg))
    instrument = IRSwap(
        name="interest_rate_swap",
        effective_date=terms["effective_date"],
        maturity_date=terms["maturity_date"],
        notional=float(terms["notional"]),
        receive_leg=receive_leg,
        pay_leg=pay_leg,
        discount_curve_name=DISCOUNT_CURVE,
        interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        schedule_config=ScheduleConfig(calendar=terms["calendar"],
                                       day_count=terms["accrual_day_count"]),
        include_sim_date_cashflows=True,
    )
    market_state = market.market_state(curves=[DISCOUNT_CURVE, PROJECTION_CURVE])
    # Rates that have already fixed are passed as past observations.
    fixings = {(PROJECTION_CURVE, start): np.array([rate])
               for start, rate in terms["known_floating_rates"].items()}
    return instrument, market_state, fixings or None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'interest_rate_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Interest rate swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
