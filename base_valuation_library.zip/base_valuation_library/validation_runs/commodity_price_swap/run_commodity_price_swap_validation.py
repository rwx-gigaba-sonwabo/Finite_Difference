"""Validation run: base valuation of a commodity price swap.

A swap of a fixed commodity price against a floating commodity price on a fixed
quantity. Each period one leg pays the fixed price times the quantity. The other leg
pays the forward price for that period, read off the forward price curve, times the
quantity. Each payment is discounted. The value is the receive leg less the pay leg.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/commodity_price_swap/run_commodity_price_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/commodity_price_swap.py``  the instrument
``instruments/components/commodity_price_leg.py``  the leg definition
``models/commodity_pv.py``  forward prices and discounting

Points to note
--------------
The value is in the currency of the commodity and is not converted to the reporting
currency. The dates of the swap are typed in because the deal type holds its periods as
a list of sampling rows.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.commodity_price_swap import CommodityPriceSwap  # noqa: E402
from instruments.components.commodity_price_leg import CommodityLegType, CommodityPriceLeg, PriceConstruction  # noqa: E402
from instruments.components.schedule_config import ScheduleConfig  # noqa: E402
from utils.interpolation import forward_price_interpolator, linear_interpolator  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'BRENT_PRICE_SWAP_1Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Commodity forward price curve. Pillars are delivery dates, values are prices.
FORWARD_PRICE_CURVE = "ForwardPrice.BRENT"

# Zero rate curve used to discount both legs.
DISCOUNT_CURVE = "InterestRate.USD-SOFR"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# First day of the first period.
EFFECTIVE_DATE = date(2026, 10, 30)

# Last payment date of the swap.
MATURITY_DATE = date(2027, 10, 29)

# Commodity units per period.
QUANTITY = from_trade_file("Units")

# Fixed price per unit.
FIXED_PRICE = from_trade_file("Fixed_Price")

# True when the floating price is received and the fixed price is paid.
RECEIVE_FLOATING = from_trade_file("Buy_Sell", is_buy)

# Months between payments. 0 means one payment at maturity.
PAYMENT_FREQUENCY_MONTHS = 3

# Holiday calendar for the payment schedule.
CALENDAR = "TARGET"

# Forward price beyond the last pillar of the curve: "flat" holds the last price,
# "linear" extends the last segment.
FORWARD_PRICE_EXTRAPOLATION = "flat"

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "effective_date": resolve_term(EFFECTIVE_DATE, deal, "EFFECTIVE_DATE"),
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "quantity": resolve_term(QUANTITY, deal, "QUANTITY"),
        "fixed_price": resolve_term(FIXED_PRICE, deal, "FIXED_PRICE"),
        "receive_floating": resolve_term(RECEIVE_FLOATING, deal, "RECEIVE_FLOATING"),
        "payment_frequency_months": resolve_term(PAYMENT_FREQUENCY_MONTHS, deal, "PAYMENT_FREQUENCY_MONTHS"),
        "calendar": resolve_term(CALENDAR, deal, "CALENDAR"),
        "forward_price_extrapolation": resolve_term(FORWARD_PRICE_EXTRAPOLATION, deal, "FORWARD_PRICE_EXTRAPOLATION"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    frequency = terms["payment_frequency_months"]
    quantity = float(terms["quantity"])
    fixed_leg = CommodityPriceLeg(CommodityLegType.FIXED, frequency=frequency, quantity=quantity,
                                  fixed_price=float(terms["fixed_price"]))
    floating_leg = CommodityPriceLeg(
        CommodityLegType.FLOATING, frequency=frequency, quantity=quantity,
        construction=PriceConstruction.CURVE, forward_curve_name=FORWARD_PRICE_CURVE,
        forward_interpolator=(linear_interpolator if terms["forward_price_extrapolation"] == "flat"
                              else forward_price_interpolator))
    receive_leg, pay_leg = ((floating_leg, fixed_leg) if terms["receive_floating"]
                            else (fixed_leg, floating_leg))
    instrument = CommodityPriceSwap(
        name="commodity_price_swap",
        effective_date=terms["effective_date"],
        maturity_date=terms["maturity_date"],
        receive_leg=receive_leg,
        pay_leg=pay_leg,
        discount_curve_name=DISCOUNT_CURVE,
        discount_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        schedule_config=ScheduleConfig(calendar=terms["calendar"]),
        include_sim_date_cashflows=True,
    )
    market_state = market.market_state(curves=[FORWARD_PRICE_CURVE, DISCOUNT_CURVE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'commodity_price_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Commodity price swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
