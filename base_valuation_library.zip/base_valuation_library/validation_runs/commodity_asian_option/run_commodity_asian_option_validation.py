"""Validation run: base valuation of a commodity Asian option.

An option on the arithmetic average of daily commodity prices over a window. The average
is matched to a lognormal distribution by its first two moments and then valued with the
Black model. Prices already observed lower or raise the strike that is left to beat.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/commodity_asian_option/run_commodity_asian_option_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/commodity_asian.py``  the instrument
``market_data/vol_surface.py``  the volatility surface

Points to note
--------------
The value is in the currency of the commodity. The composite payout in domestic currency
that the instrument also supports is not wired into this script.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

import numpy as np  # noqa: E402
from instruments.commodity_asian import CommodityAsian  # noqa: E402
from utils.interpolation import forward_price_interpolator, linear_interpolator  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'BRENT_ASIAN_CALL_APR27'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Commodity forward price curve. Pillars are Excel serial dates.
FORWARD_PRICE_CURVE = "ForwardPrice.BRENT"

# Zero rate curve used to discount the payoff.
DISCOUNT_CURVE = "InterestRate.USD-SOFR"

# Commodity volatility surface quoted in moneyness (strike less forward, over forward).
VOLATILITY_SURFACE = "CommodityPriceVol.BRENT"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# First day of the averaging window.
AVERAGING_START = from_trade_file("Period_Start")

# Last day of the averaging window.
AVERAGING_END = from_trade_file("Period_End")

# Date the payoff is paid.
SETTLEMENT_DATE = from_trade_file("Settlement_Date")

# Strike price per unit.
STRIKE = from_trade_file("Strike")

# True for a call, False for a put.
IS_CALL = from_trade_file("Option_Type", is_call)

# Number of commodity units.
UNITS = from_trade_file("Volume")

# True when the option was bought, False when sold.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# Holiday calendar that decides which days are in the average.
AVERAGING_CALENDAR = "USD"

# Holiday calendar for the pricing lag.
PRICING_CALENDAR = "USD"

# Business days added to a fixing date to find the delivery date read on the forward
# curve.
PRICING_LAG_DAYS = 0

# Forward price beyond the last pillar of the curve: "flat" or "linear".
FORWARD_PRICE_EXTRAPOLATION = "flat"

# Commodity prices already observed in the averaging window, as {date: price}. Needed
# once the window has started. A past date with no entry uses the curve of the valuation
# date.
OBSERVED_PRICE_FIXINGS = {}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "averaging_start": resolve_term(AVERAGING_START, deal, "AVERAGING_START"),
        "averaging_end": resolve_term(AVERAGING_END, deal, "AVERAGING_END"),
        "settlement_date": resolve_term(SETTLEMENT_DATE, deal, "SETTLEMENT_DATE"),
        "strike": resolve_term(STRIKE, deal, "STRIKE"),
        "is_call": resolve_term(IS_CALL, deal, "IS_CALL"),
        "units": resolve_term(UNITS, deal, "UNITS"),
        "is_buy": resolve_term(IS_BUY, deal, "IS_BUY"),
        "averaging_calendar": resolve_term(AVERAGING_CALENDAR, deal, "AVERAGING_CALENDAR"),
        "pricing_calendar": resolve_term(PRICING_CALENDAR, deal, "PRICING_CALENDAR"),
        "pricing_lag_days": resolve_term(PRICING_LAG_DAYS, deal, "PRICING_LAG_DAYS"),
        "forward_price_extrapolation": resolve_term(FORWARD_PRICE_EXTRAPOLATION, deal, "FORWARD_PRICE_EXTRAPOLATION"),
        "observed_price_fixings": resolve_term(OBSERVED_PRICE_FIXINGS, deal, "OBSERVED_PRICE_FIXINGS"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    instrument = CommodityAsian(
        name="commodity_asian_option",
        period_start=terms["averaging_start"],
        period_end=terms["averaging_end"],
        settlement_date=terms["settlement_date"],
        strike=float(terms["strike"]),
        notional=float(terms["units"]),
        is_call=bool(terms["is_call"]),
        vol_surface=market.relative_moneyness_vol_surface(VOLATILITY_SURFACE),
        forward_curve_name=FORWARD_PRICE_CURVE,
        discount_curve_name=DISCOUNT_CURVE,
        averaging_calendar=terms["averaging_calendar"],
        lag_calendar=terms["pricing_calendar"],
        forward_interpolator=(linear_interpolator if terms["forward_price_extrapolation"] == "flat"
                              else forward_price_interpolator),
        discount_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        pricing_lag=terms["pricing_lag_days"],
        direction=1 if terms["is_buy"] else -1,
    )
    market_state = market.market_state(curves=[FORWARD_PRICE_CURVE, DISCOUNT_CURVE])
    fixings = {(FORWARD_PRICE_CURVE, day): np.array([price])
               for day, price in terms["observed_price_fixings"].items()}
    return instrument, market_state, fixings or None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'commodity_asian_option'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Commodity Asian option',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
