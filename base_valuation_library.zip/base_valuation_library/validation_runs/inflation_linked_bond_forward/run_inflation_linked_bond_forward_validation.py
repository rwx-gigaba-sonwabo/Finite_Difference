"""Validation run: base valuation of an inflation linked bond forward.

A forward on a bond whose coupons and redemption grow with the consumer price index. The
buyer agrees today to pay a fixed real clean price for the bond on the delivery date.
The cash paid at delivery is that real price scaled by the index ratio on the delivery
date. The value is the discounted value of the bond cashflows after delivery less the
discounted settlement amount.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/inflation_linked_bond_forward/run_inflation_linked_bond_forward_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/inflation_linked_bond_forward.py``  the instrument
``instruments/components/inflation_leg.py``  the inflation leg definition
``models/inflation_bond_pv.py``  the forward value
``models/inflation_pv.py``  index ratios

Points to note
--------------
The terms of the bond are typed in because the deal holds only the forward. The index
curve is interpolated in a straight line between its pillars.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.components.inflation_leg import InflationLeg  # noqa: E402
from instruments.inflation_linked_bond_forward import InflationLinkedBondForward  # noqa: E402
from utils.interpolation import linear_interpolator  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_INFLATION_BOND_FORWARD_6M'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Nominal zero rate curve that discounts the bond cashflows.
BOND_CURVE = "InterestRate.ZAR-BOND"

# Zero rate curve the bond is carried on up to delivery.
REPO_CURVE = "InterestRate.ZAR-REPO"

# Zero rate curve that discounts the forward payoff from the delivery date.
FORWARD_DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Projected consumer price index levels. Pillars are years from the valuation date,
# values are index levels.
PRICE_INDEX_CURVE = "PriceIndex.ZAR_CPI"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Issue date of the bond. The coupon schedule is built back from maturity.
BOND_ISSUE_DATE = date(2021, 3, 31)

# Maturity date of the bond.
BOND_MATURITY_DATE = date(2033, 3, 31)

# Date the bond is delivered and paid for.
DELIVERY_DATE = from_trade_file("Settlement_Date")

# Face value of the bond, before index scaling.
NOTIONAL = from_trade_file("Notional")

# Real coupon rate of the bond per year, as a decimal.
REAL_COUPON_RATE = 0.0250

# Months between coupons.
COUPON_FREQUENCY_MONTHS = 6

# Agreed clean price in real terms, as a fraction of the face value.
FORWARD_REAL_CLEAN_PRICE = from_trade_file("Forward_Real_Clean_Price")

# Index level on the issue date of the bond. Index ratios are measured from it.
BASE_INDEX_LEVEL = 89.6

# Months between an index reference month and the date it applies to.
INDEX_LAG_MONTHS = 4

# True when the bond is bought forward, False when sold.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# Business days between the delivery date and the cash settlement.
SETTLEMENT_LAG_DAYS = 3

# Index levels already published, as {first day of the reference month: level}.
PUBLISHED_INDEX_LEVELS = {date(2026, 5, 1): 111.2, date(2026, 6, 1): 111.5, date(2026, 7, 1): 111.8, date(2026, 8, 1): 112.0, date(2026, 9, 1): 112.2, date(2026, 10, 1): 112.4}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "bond_issue_date": resolve_term(BOND_ISSUE_DATE, deal, "BOND_ISSUE_DATE"),
        "bond_maturity_date": resolve_term(BOND_MATURITY_DATE, deal, "BOND_MATURITY_DATE"),
        "delivery_date": resolve_term(DELIVERY_DATE, deal, "DELIVERY_DATE"),
        "notional": resolve_term(NOTIONAL, deal, "NOTIONAL"),
        "real_coupon_rate": resolve_term(REAL_COUPON_RATE, deal, "REAL_COUPON_RATE"),
        "coupon_frequency_months": resolve_term(COUPON_FREQUENCY_MONTHS, deal, "COUPON_FREQUENCY_MONTHS"),
        "forward_real_clean_price": resolve_term(FORWARD_REAL_CLEAN_PRICE, deal, "FORWARD_REAL_CLEAN_PRICE"),
        "base_index_level": resolve_term(BASE_INDEX_LEVEL, deal, "BASE_INDEX_LEVEL"),
        "index_lag_months": resolve_term(INDEX_LAG_MONTHS, deal, "INDEX_LAG_MONTHS"),
        "is_buy": resolve_term(IS_BUY, deal, "IS_BUY"),
        "settlement_lag_days": resolve_term(SETTLEMENT_LAG_DAYS, deal, "SETTLEMENT_LAG_DAYS"),
        "published_index_levels": resolve_term(PUBLISHED_INDEX_LEVELS, deal, "PUBLISHED_INDEX_LEVELS"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    inflation_leg = InflationLeg(
        frequency=terms["coupon_frequency_months"],
        fixed_rate=float(terms["real_coupon_rate"]),
        cpi_curve_name=PRICE_INDEX_CURVE,
        base_cpi=float(terms["base_index_level"]),
        lag_months=terms["index_lag_months"],
        include_notional_exchange=True,
    )
    instrument = InflationLinkedBondForward(
        name="inflation_linked_bond_forward",
        effective_date=terms["bond_issue_date"],
        maturity_date=terms["bond_maturity_date"],
        delivery_date=terms["delivery_date"],
        notional=float(terms["notional"]),
        inflation_leg=inflation_leg,
        bond_curve_name=BOND_CURVE,
        interpolator=market.curve_interpolator(BOND_CURVE),
        forward_real_clean_price=float(terms["forward_real_clean_price"]),
        cpi_interpolator=linear_interpolator,
        direction=1 if terms["is_buy"] else -1,
        repo_curve_name=REPO_CURVE,
        forward_curve_name=FORWARD_DISCOUNT_CURVE,
        repo_interpolator=market.curve_interpolator(REPO_CURVE),
        forward_interpolator=market.curve_interpolator(FORWARD_DISCOUNT_CURVE),
        settlement_lag=terms["settlement_lag_days"],
    )
    # Index levels that are already published are given to the instrument directly.
    instrument._historical_cpi_map = dict(terms["published_index_levels"])
    market_state = market.market_state(
        curves=[BOND_CURVE, REPO_CURVE, FORWARD_DISCOUNT_CURVE, PRICE_INDEX_CURVE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'inflation_linked_bond_forward'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Inflation linked bond forward',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
