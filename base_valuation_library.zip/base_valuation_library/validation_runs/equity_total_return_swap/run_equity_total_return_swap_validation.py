"""Validation run: base valuation of an equity total return swap.

A swap of the total return on a share against interest. The return leg pays the change
in the share price plus the dividends, on a number of shares. The interest leg pays a
floating rate plus a spread on a notional. Future share prices are forward prices built
from the spot price, a carry curve and a dividend yield curve.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/equity_total_return_swap/run_equity_total_return_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/equity_trs.py``  the instrument
``models/equity_pv.py``  equity forward prices and the return leg
``models/cashflow_pv.py``  the interest leg

Points to note
--------------
The value is in the currency of the share. The dates and the reset frequency are typed
in because the deal type holds its cashflows as lists.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

import numpy as np  # noqa: E402
from instruments.components.cashflow_leg import CashflowLeg, LegType  # noqa: E402
from instruments.components.schedule_config import ScheduleConfig  # noqa: E402
from instruments.equity_trs import EquityTRS  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_SHARE_TOTAL_RETURN_SWAP_1Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Equity price factor. Its Spot is the share price on the valuation date.
SPOT_PRICE = "EquityPrice.ZAR_SHARE"

# Zero rate curve the share price is carried forward on.
CARRY_CURVE = "InterestRate.ZAR-SWAP"

# Continuous dividend yield curve of the share.
DIVIDEND_CURVE = "DividendRate.ZAR_SHARE"

# Zero rate curve used to discount both legs.
DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Zero rate curve the floating rate of the interest leg is projected from.
PROJECTION_CURVE = "InterestRate.ZAR-JIBAR-3M"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Start date of the swap and first reset date.
EFFECTIVE_DATE = date(2026, 10, 30)

# Last reset and payment date of the swap.
MATURITY_DATE = date(2027, 10, 29)

# Number of shares the return leg is on.
NUMBER_OF_SHARES = from_trade_file("Units")

# Share price at the most recent reset date. On the effective date it is the price the
# swap was struck at.
INITIAL_PRICE = from_trade_file("Initial_Price")

# Spread added to the floating rate of the interest leg, as a decimal.
INTEREST_SPREAD = from_trade_file("Floating_Margin", default=0.0)

# True when the total return is received and the interest is paid.
RECEIVE_TOTAL_RETURN = from_trade_file("Buy_Sell", is_buy)

# Months between resets. Both legs pay on the same dates.
RESET_FREQUENCY_MONTHS = 3

# Notional of the return leg: "Price" resets it to the share price each period, "Initial
# Price" keeps it fixed.
RETURN_NOTIONAL_RULE = "Price"

# Notional of the interest leg: "Price" resets it to the share price each period,
# "Initial Price" keeps it fixed.
INTEREST_NOTIONAL_RULE = "Initial Price"

# Holiday calendar for the payment schedule.
CALENDAR = "ZAR"

# Floating rates that fixed before the valuation date, as {period start date: rate}.
# Needed for a period that started before the valuation date.
KNOWN_FLOATING_RATES = {}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "effective_date": resolve_term(EFFECTIVE_DATE, deal, "EFFECTIVE_DATE"),
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "number_of_shares": resolve_term(NUMBER_OF_SHARES, deal, "NUMBER_OF_SHARES"),
        "initial_price": resolve_term(INITIAL_PRICE, deal, "INITIAL_PRICE"),
        "interest_spread": resolve_term(INTEREST_SPREAD, deal, "INTEREST_SPREAD"),
        "receive_total_return": resolve_term(RECEIVE_TOTAL_RETURN, deal, "RECEIVE_TOTAL_RETURN"),
        "reset_frequency_months": resolve_term(RESET_FREQUENCY_MONTHS, deal, "RESET_FREQUENCY_MONTHS"),
        "return_notional_rule": resolve_term(RETURN_NOTIONAL_RULE, deal, "RETURN_NOTIONAL_RULE"),
        "interest_notional_rule": resolve_term(INTEREST_NOTIONAL_RULE, deal, "INTEREST_NOTIONAL_RULE"),
        "calendar": resolve_term(CALENDAR, deal, "CALENDAR"),
        "known_floating_rates": resolve_term(KNOWN_FLOATING_RATES, deal, "KNOWN_FLOATING_RATES"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    shares = float(terms["number_of_shares"])
    initial_price = float(terms["initial_price"])
    interest_leg = CashflowLeg(LegType.FLOATING, frequency=terms["reset_frequency_months"],
                               curve_name=PROJECTION_CURVE, spread=float(terms["interest_spread"]))
    instrument = EquityTRS(
        name="equity_total_return_swap",
        effective_date=terms["effective_date"],
        maturity_date=terms["maturity_date"],
        quantity=shares,
        # The fixed notional of the interest leg is the value of the shares at the initial price.
        notional=shares * initial_price,
        interest_leg=interest_leg,
        spot_name=SPOT_PRICE,
        carry_curve_name=CARRY_CURVE,
        dividend_curve_name=DIVIDEND_CURVE,
        discount_curve_name=DISCOUNT_CURVE,
        carry_interpolator=market.curve_interpolator(CARRY_CURVE),
        dividend_interpolator=market.curve_interpolator(DIVIDEND_CURVE),
        discount_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        schedule_config=ScheduleConfig(calendar=terms["calendar"]),
        return_frequency=terms["reset_frequency_months"],
        initial_price=initial_price,
        return_nominal_scaling=terms["return_notional_rule"],
        interest_nominal_scaling=terms["interest_notional_rule"],
        is_receiver=bool(terms["receive_total_return"]),
    )
    curves = sorted({CARRY_CURVE, DIVIDEND_CURVE, DISCOUNT_CURVE, PROJECTION_CURVE})
    market_state = market.market_state(curves=curves, scalars=[SPOT_PRICE])
    # Rates that have already fixed are passed as past observations.
    fixings = {(PROJECTION_CURVE, start): np.array([rate])
               for start, rate in terms["known_floating_rates"].items()}
    return instrument, market_state, fixings or None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'equity_total_return_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Equity total return swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
