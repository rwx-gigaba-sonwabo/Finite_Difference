"""Validation run: base valuation of an FX swap.

Two exchanges of currency in opposite directions, a near leg and a far leg. Before the
near date both legs count. After it only the far leg remains: the foreign amount times
the far rate discounted on the domestic curve, less the foreign amount at spot
discounted on the foreign curve.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/fx_swap/run_fx_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/fx_cash_swap.py``  the instrument
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.fx_cash_swap import FXCashSwap  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'USDZAR_FX_SWAP_1Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Spot FX rate in domestic currency per one unit of foreign currency.
FX_SPOT = "FxRate.USD"

# Zero rate curve of the domestic currency.
DOMESTIC_CURVE = "InterestRate.ZAR-SWAP"

# Zero rate curve of the foreign currency.
FOREIGN_CURVE = "InterestRate.USD-SOFR"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Settlement date of the near leg.
NEAR_DATE = from_trade_file("Near_Settlement_Date")

# Settlement date of the far leg.
FAR_DATE = from_trade_file("Far_Settlement_Date")

# Amount of foreign currency exchanged.
FOREIGN_NOTIONAL = from_trade_file("Near_Buy_Amount")

# Agreed FX rate of the near leg, domestic per foreign.
NEAR_FX_RATE = 17.80

# Agreed FX rate of the far leg, domestic per foreign.
FAR_FX_RATE = 18.42

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "near_date": resolve_term(NEAR_DATE, deal, "NEAR_DATE"),
        "far_date": resolve_term(FAR_DATE, deal, "FAR_DATE"),
        "foreign_notional": resolve_term(FOREIGN_NOTIONAL, deal, "FOREIGN_NOTIONAL"),
        "near_fx_rate": resolve_term(NEAR_FX_RATE, deal, "NEAR_FX_RATE"),
        "far_fx_rate": resolve_term(FAR_FX_RATE, deal, "FAR_FX_RATE"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    instrument = FXCashSwap(
        name="fx_swap",
        effective_date=terms["near_date"],
        maturity_date=terms["far_date"],
        foreign_notional=float(terms["foreign_notional"]),
        near_fx_rate=float(terms["near_fx_rate"]),
        far_fx_rate=float(terms["far_fx_rate"]),
        domestic_discount_curve_name=DOMESTIC_CURVE,
        foreign_discount_curve_name=FOREIGN_CURVE,
        fx_spot_name=FX_SPOT,
        domestic_interpolator=market.curve_interpolator(DOMESTIC_CURVE),
        foreign_interpolator=market.curve_interpolator(FOREIGN_CURVE),
    )
    market_state = market.market_state(curves=[DOMESTIC_CURVE, FOREIGN_CURVE], scalars=[FX_SPOT])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'fx_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='FX swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
