"""Validation run: base valuation of an FX barrier option.

A European FX call or put with one knock in or knock out barrier. It is valued with the
closed form for single barrier options. A barrier checked at intervals is handled by
moving the barrier level.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/fx_barrier_option/run_fx_barrier_option_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/fx_barrier_option.py``  the instrument
``instruments/single_barrier_pricer.py``  the closed form
``market_data/vol_surface.py``  the volatility surface

Points to note
--------------
The value is in the domestic currency. The instrument keeps the barrier state between
calls, so build a new instrument for every run, as this script does.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.fx_barrier_option import FXBarrierOption  # noqa: E402
from market_data.vol_surface import FXVolSurface  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'USDZAR_UP_AND_OUT_CALL'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# FX factor of the domestic currency. None when the domestic currency is the base
# currency of the trade file.
DOMESTIC_FX = None

# FX factor of the foreign currency. None when it is the base currency of the trade
# file.
FOREIGN_FX = "FxRate.USD"

# Zero rate curve of the domestic currency.
DOMESTIC_CURVE = "InterestRate.ZAR-SWAP"

# Zero rate curve of the foreign currency.
FOREIGN_CURVE = "InterestRate.USD-SOFR"

# FX volatility surface. Its Surface_Type field says whether it is quoted in moneyness
# (Explicit) or in delta (Malz).
VOLATILITY_SURFACE = "FXVol.USD.ZAR_EXPLICIT"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Date the option expires.
EXPIRY_DATE = from_trade_file("Expiry_Date")

# Strike in domestic currency per one unit of foreign currency.
STRIKE = from_trade_file("Strike_Price")

# Barrier level in domestic currency per one unit of foreign currency.
BARRIER = from_trade_file("Barrier_Price")

# One of "Up_And_In", "Up_And_Out", "Down_And_In", "Down_And_Out".
BARRIER_TYPE = from_trade_file("Barrier_Type")

# True for a call, False for a put.
IS_CALL = from_trade_file("Option_Type", is_call)

# Amount of foreign currency the option is on.
FOREIGN_AMOUNT = from_trade_file("Underlying_Amount")

# True when the option was bought, False when sold.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# Total cash rebate in domestic currency.
CASH_REBATE = from_trade_file("Cash_Rebate", default=0.0)

# Days between barrier checks. 1 means checked daily. 0 means watched all the time.
MONITORING_DAYS = 1

# True when the barrier was touched before the valuation date.
BARRIER_TOUCHED_BEFORE = False

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "expiry_date": resolve_term(EXPIRY_DATE, deal, "EXPIRY_DATE"),
        "strike": resolve_term(STRIKE, deal, "STRIKE"),
        "barrier": resolve_term(BARRIER, deal, "BARRIER"),
        "barrier_type": resolve_term(BARRIER_TYPE, deal, "BARRIER_TYPE"),
        "is_call": resolve_term(IS_CALL, deal, "IS_CALL"),
        "foreign_amount": resolve_term(FOREIGN_AMOUNT, deal, "FOREIGN_AMOUNT"),
        "is_buy": resolve_term(IS_BUY, deal, "IS_BUY"),
        "cash_rebate": resolve_term(CASH_REBATE, deal, "CASH_REBATE"),
        "monitoring_days": resolve_term(MONITORING_DAYS, deal, "MONITORING_DAYS"),
        "barrier_touched_before": resolve_term(BARRIER_TOUCHED_BEFORE, deal, "BARRIER_TOUCHED_BEFORE"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    factor = market.trade_file.price_factor(VOLATILITY_SURFACE)
    surface_type = factor.get("Surface_Type") or "Explicit"
    surface_points = factor["Delta_Surface"] if surface_type == "Malz" else factor["Surface"]
    barrier_type = terms["barrier_type"]
    instrument = FXBarrierOption(
        name="fx_barrier_option",
        effective_date=valuation_date,
        maturity_date=terms["expiry_date"],
        strike=float(terms["strike"]),
        barrier=float(terms["barrier"]),
        is_call=bool(terms["is_call"]),
        is_up=barrier_type.startswith("Up"),
        is_knock_in=barrier_type.endswith("In"),
        nominal=float(terms["foreign_amount"]),
        currency_fx_name=DOMESTIC_FX,
        underlying_fx_name=FOREIGN_FX,
        domestic_curve_name=DOMESTIC_CURVE,
        foreign_curve_name=FOREIGN_CURVE,
        vol_surface=FXVolSurface(surface_points, surface_type),
        buy=bool(terms["is_buy"]),
        domestic_interpolator=market.curve_interpolator(DOMESTIC_CURVE),
        foreign_interpolator=market.curve_interpolator(FOREIGN_CURVE),
        cash_rebate=float(terms["cash_rebate"]),
        monitoring_days=terms["monitoring_days"],
        barrier_crossed=bool(terms["barrier_touched_before"]),
    )
    market_state = market.market_state(
        curves=[DOMESTIC_CURVE, FOREIGN_CURVE], scalars=[DOMESTIC_FX, FOREIGN_FX])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'fx_barrier_option'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='FX barrier option',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
