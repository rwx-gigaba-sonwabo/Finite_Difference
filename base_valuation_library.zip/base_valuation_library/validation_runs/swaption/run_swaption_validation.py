"""Validation run: base valuation of a European swaption.

The right to enter an interest rate swap on the expiry date. It is valued with the Black
model on the forward par swap rate: Black value times the annuity of the swap times the
notional. The volatility is read at the distance between the strike and the forward
rate.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/swaption/run_swaption_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/swaption.py``  the instrument
``instruments/ir_swap.py``  the underlying swap
``models/equity_pv.py``  the Black formula on a forward
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.components.schedule_config import ScheduleConfig  # noqa: E402
from instruments.ir_swap import IRSwap, LegType, SwapLeg  # noqa: E402
from instruments.swaption import Swaption  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_PAYER_SWAPTION_1Y_INTO_2Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Zero rate curve used to discount the swap cashflows.
DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Zero rate curve the floating rate is projected from.
PROJECTION_CURVE = "InterestRate.ZAR-JIBAR-3M"

# Swaption volatility cube. Rows of moneyness, expiry, swap tenor and volatility.
VOLATILITY_SURFACE = "InterestYieldVol.ZAR"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Date the option can be exercised.
EXPIRY_DATE = from_trade_file("Option_Expiry_Date")

# First accrual date of the underlying swap.
SWAP_EFFECTIVE_DATE = from_trade_file("Swap_Effective_Date")

# Last payment date of the underlying swap.
SWAP_MATURITY_DATE = from_trade_file("Swap_Maturity_Date")

# Notional of the underlying swap. Use a negative number for a sold swaption.
NOTIONAL = from_trade_file("Principal")

# Fixed rate of the underlying swap, as a decimal.
STRIKE_RATE = from_trade_file("Swap_Rate")

# True for the right to pay fixed, False for the right to receive fixed.
IS_PAYER = from_trade_file("Payer_Receiver", lambda v: v == "Payer")

# "cash" or "physical".
SETTLEMENT_STYLE = "cash"

# Months between fixed payments of the swap.
FIXED_FREQUENCY_MONTHS = 3

# Months between floating payments of the swap.
FLOATING_FREQUENCY_MONTHS = 3

# Holiday calendar for the payment schedule.
CALENDAR = "ZAR"

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "expiry_date": resolve_term(EXPIRY_DATE, deal, "EXPIRY_DATE"),
        "swap_effective_date": resolve_term(SWAP_EFFECTIVE_DATE, deal, "SWAP_EFFECTIVE_DATE"),
        "swap_maturity_date": resolve_term(SWAP_MATURITY_DATE, deal, "SWAP_MATURITY_DATE"),
        "notional": resolve_term(NOTIONAL, deal, "NOTIONAL"),
        "strike_rate": resolve_term(STRIKE_RATE, deal, "STRIKE_RATE"),
        "is_payer": resolve_term(IS_PAYER, deal, "IS_PAYER"),
        "settlement_style": resolve_term(SETTLEMENT_STYLE, deal, "SETTLEMENT_STYLE"),
        "fixed_frequency_months": resolve_term(FIXED_FREQUENCY_MONTHS, deal, "FIXED_FREQUENCY_MONTHS"),
        "floating_frequency_months": resolve_term(FLOATING_FREQUENCY_MONTHS, deal, "FLOATING_FREQUENCY_MONTHS"),
        "calendar": resolve_term(CALENDAR, deal, "CALENDAR"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    underlying_swap = IRSwap(
        name="underlying_swap",
        effective_date=terms["swap_effective_date"],
        maturity_date=terms["swap_maturity_date"],
        notional=float(terms["notional"]),
        receive_leg=SwapLeg(LegType.FLOATING, frequency=terms["floating_frequency_months"],
                            curve_name=PROJECTION_CURVE),
        pay_leg=SwapLeg(LegType.FIXED, frequency=terms["fixed_frequency_months"],
                        fixed_rate=float(terms["strike_rate"])),
        discount_curve_name=DISCOUNT_CURVE,
        interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        schedule_config=ScheduleConfig(calendar=terms["calendar"]),
    )
    instrument = Swaption(
        name="swaption",
        underlying_swap=underlying_swap,
        expiry_date=terms["expiry_date"],
        strike=float(terms["strike_rate"]),
        vol_surface=market.interest_rate_vol_surface(VOLATILITY_SURFACE),
        is_payer=bool(terms["is_payer"]),
        settlement_style=terms["settlement_style"],
    )
    market_state = market.market_state(curves=[DISCOUNT_CURVE, PROJECTION_CURVE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'swaption'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='European swaption',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
