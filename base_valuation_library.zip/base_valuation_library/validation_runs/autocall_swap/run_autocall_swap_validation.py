"""Validation run: base valuation of an autocallable swap and its put leg.

An autocallable swap pays a coupon and ends early the first time the equity is at or above
a trigger level on an observation date. Until then it pays a floating amount each period.
Its downside is a put on the equity that only survives if the swap is never called.

The put can sit in the trade file in two ways, chosen with PUT_LEG_MODE below.

"booking"
    The swap deal has no put. The put is booked next to it as four option deals: a
    European put, an up and in put, a European digital put and an up and in digital put.
    Each of the five deals is valued and compared on its own line.
"autocall"
    The swap deal carries its own put. One line is valued and compared.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the deals and the market data.
2. Reads the swap terms and, in booking mode, the four option deals.
3. Builds the equity market on the valuation date: spot, discount curve, funding curve,
   dividend yield curve and volatility surface.
4. Values the swap by Monte Carlo simulation of the equity on its observation dates.
5. Values the booked options. The two European options use a closed form. The two up and
   in options use the simulated paths.
6. Gets the comparison value of each line from the system being validated.
7. Compares each line and prints a report. A closed form line is compared on the
   difference. A simulated line is compared on its z score, the difference divided by the
   standard error of the simulation.

How to run
----------
From the root folder of the library::

    python validation_runs/autocall_swap/run_autocall_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``autocall_pricer/instruments/autocall/autocall_swap.py``      the swap and its schedule
``autocall_pricer/instruments/autocall/payoff.py``             the payoff on each path
``autocall_pricer/instruments/autocall/put_leg.py``            the four booked options
``autocall_pricer/instruments/autocall/trade_file_loader.py``  reading the deals and curves
``autocall_pricer/models/gbm.py``                              the equity simulation
``docs/autocall_swap.md``                                      the method in words
"""

from __future__ import annotations

import sys
import warnings
from datetime import date, timedelta
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from autocall_pricer.instruments.autocall.autocall_swap import AutocallExpired  # noqa: E402
from autocall_pricer.instruments.autocall.payoff import evaluate_autocall_paths  # noqa: E402
from autocall_pricer.instruments.autocall.put_leg import (  # noqa: E402
    check_swap_against_booking,
    load_put_leg_booking,
    price_put_leg,
    without_put,
)
from autocall_pricer.instruments.autocall.trade_file_loader import (  # noqa: E402
    load_autocall_swap,
    load_correlation,
    load_curve,
    load_vol_surface,
)
from autocall_pricer.market_data.equity_market_data import EquityMarketData  # noqa: E402
from autocall_pricer.models.gbm import GBMEngine  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.trade_file import TradeFile  # noqa: E402
from utils.curve_interpolation import resolve_curve_interpolation  # noqa: E402
from valuation.base_valuation import resolve_comparison_value  # noqa: E402
from valuation.component_report import (  # noqa: E402
    ComponentLine,
    ComponentReport,
    compare_line,
    format_component_report,
    write_component_report,
)

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deals and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The "Reference" field of the autocallable swap deal. None picks the only one in the file.
SWAP_REFERENCE = "AUTOCALL_SWAP"

# How the put is held in the trade file.
#   "booking"  : the put is booked as four separate option deals. The swap is valued
#                without a put, so the put is not counted twice.
#   "autocall" : the swap deal carries its own put and is valued with it.
PUT_LEG_MODE = "booking"

# Booking mode only. Text that the "Reference" of each of the four option deals contains.
# It picks the right four deals when the file holds more than one set. None is enough when
# the file holds exactly one deal of each type.
PUT_LEG_REFERENCE_STEM = None

# Booking mode only. The four deals named one by one, as {deal type: reference}. This wins
# over the stem. Example: {"EquityOptionDeal": "NOTE_1_PUT"}. None uses the stem.
PUT_LEG_REFERENCES = None

# --- The simulation ----------------------------------------------------------
# Number of simulated equity paths. More paths give a smaller standard error.
NUMBER_OF_PATHS = 400_000

# Seed of the random number generator. The same seed gives the same paths.
RANDOM_SEED = 7

# How the volatility of each step of a path is read from the surface.
#   "forward" : each step uses the forward volatility between its two dates.
#   "single"  : every step uses the volatility to the final date.
#   "step"    : each step uses the volatility to its own end date.
VOLATILITY_MODE = "forward"

# --- The digital options of the put leg --------------------------------------
# Half width of the strike spread that replicates a digital option, as a fraction of the
# strike. 0.0 values the digital with one volatility at the strike.
# None reads the value from the trade file (Valuation Configuration > deal type >
# Relative_Digital_Spread) and uses 0.0 when the file has none.
EUROPEAN_DIGITAL_SPREAD = None     # for the European digital put (EquityBinaryOption)
UP_AND_IN_DIGITAL_SPREAD = None    # for the up and in digital put (EquityBarrierBinaryOption)

# Business days after the expiry date that the forward price of the two European options
# is carried to. 0 carries the forward to the expiry date. 2 carries it to the date the
# equity would settle, two business days later. Weekends are skipped. Public holidays are
# not. The discounting and the volatility time always run to the expiry date.
EUROPEAN_FORWARD_LAG_BUSINESS_DAYS = 2

# --- Quanto payout -----------------------------------------------------------
# Only needed when the deal pays in a currency other than the equity's own at a fixed FX
# rate. The equity then drifts at an extra rate of
# minus correlation times equity volatility times FX volatility.
# Give the FX volatility as a number. Give the correlation as a number, or name the
# correlation price factor in the trade file.
QUANTO_FX_VOLATILITY = None            # example: 0.145
QUANTO_CORRELATION = None              # example: -0.25
QUANTO_CORRELATION_FACTOR = None       # example: "Correlation.EquityPrice.X/FxRate.EUR.ZAR"

# --- Curve interpolation -----------------------------------------------------
# Interpolation scheme per curve, to replace the scheme found in the trade file. The keys
# are "discount", "funding" and "dividend". The schemes are "HermiteRT", "Hermite",
# "LinearRT", "Linear" and "ReciprocalTime". Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- The comparison values ---------------------------------------------------
# Value of each line from the system being validated, in the reporting currency. The
# first source that is set is used, in this order.
# 1. Numbers typed in here, as {deal reference: value}.
COMPARISON_VALUES: dict = {}
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = SCRIPT_FOLDER / "sample_comparison_values.csv"
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# A closed form line agrees when the absolute difference is at most ABSOLUTE_TOLERANCE,
# or the relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value
# A simulated line agrees when its z score is at most Z_SCORE_TOLERANCE.
Z_SCORE_TOLERANCE = 3.0

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING BLOCKS
# =============================================================================
def add_business_days(start: date, business_days: int) -> date:
    """Move a date forward by a number of business days, skipping Saturdays and Sundays."""
    day = start
    remaining = business_days
    while remaining > 0:
        day += timedelta(days=1)
        if day.weekday() < 5:
            remaining -= 1
    return day


def curve_interpolation(trade_file: TradeFile, role: str, factor_name: str, notes: list) -> str:
    """Pick the interpolation scheme of one curve and record the choice in the notes."""
    if role in CURVE_INTERPOLATION_OVERRIDES:
        scheme = CURVE_INTERPOLATION_OVERRIDES[role]
        notes.append(f"{role} curve {factor_name}: {scheme} (set by hand in the run script)")
        return scheme
    scheme, how = resolve_curve_interpolation(trade_file.raw, factor_name)
    notes.append(f"{role} curve {factor_name}: {scheme} ({how})")
    return scheme


def build_equity_market(trade_file: TradeFile, deal_info, notes: list) -> EquityMarketData:
    """Build the equity market the simulation and the closed forms read.

    Parameters
    ----------
    trade_file : TradeFile
        The loaded trade file.
    deal_info : AutocallDealInfo
        Names of the price factors the swap deal points to.
    notes : list of str
        Remarks for the report. The interpolation of each curve is added to it.
    """
    path = trade_file.path
    valuation_date = trade_file.valuation_date
    if deal_info.spot is None:
        raise ValueError(f"The trade file has no spot price for EquityPrice.{deal_info.equity}.")

    def curve(role: str, factor_name: str):
        scheme = curve_interpolation(trade_file, role, factor_name, notes)
        return load_curve(path, factor_name, interpolation=scheme).handler(valuation_date)

    return EquityMarketData(
        valuation_date=valuation_date,
        spot=float(deal_info.spot),
        discount_curve=curve("discount", deal_info.discount_factor),
        repo_curve=curve("funding", deal_info.repo_factor),
        div_curve=curve("dividend", deal_info.dividend_factor),
        equity_vol=load_vol_surface(path, deal_info.equity_vol_factor),
    )


def quanto_drift_adjustment(trade_file: TradeFile, market: EquityMarketData, expiry: date,
                            is_quanto: bool, notes: list) -> float:
    """Extra drift of the equity for a quanto payout, per year.

    ``-correlation * equity volatility * FX volatility``. The equity volatility is read at
    the money for the expiry date. Returns zero when the payout is not a quanto.
    """
    correlation = QUANTO_CORRELATION
    if correlation is None and QUANTO_CORRELATION_FACTOR:
        correlation = load_correlation(trade_file.path, QUANTO_CORRELATION_FACTOR)
    if not is_quanto:
        return 0.0
    if QUANTO_FX_VOLATILITY is None or correlation is None:
        raise ValueError(
            "The deal has a quanto payout. Set QUANTO_FX_VOLATILITY and either "
            "QUANTO_CORRELATION or QUANTO_CORRELATION_FACTOR in the run script.")
    time_to_expiry = market.yearfrac(expiry)
    equity_volatility = float(market.vol(expiry=time_to_expiry, moneyness=1.0))
    adjustment = -float(correlation) * equity_volatility * float(QUANTO_FX_VOLATILITY)
    notes.append(f"Quanto drift adjustment per year: {adjustment:+.6f} "
                 f"(correlation {float(correlation):+.4f}, equity volatility {equity_volatility:.4f}, "
                 f"FX volatility {float(QUANTO_FX_VOLATILITY):.4f})")
    return adjustment


def digital_spread(trade_file: TradeFile, deal_type: str, setting) -> float:
    """Half width of the digital strike spread, from the run script or from the trade file."""
    if setting is not None:
        return float(setting)
    return float(trade_file.valuation_setting(deal_type, "Relative_Digital_Spread", 0.0) or 0.0)


def comparison_value_for(reference: str) -> tuple[float | None, str]:
    """Find the comparison value of one line. Returns ``(None, ...)`` when none is given."""
    try:
        return resolve_comparison_value(
            reference, TRADE_JSON_PATH,
            typed_value=COMPARISON_VALUES.get(reference),
            csv_path=COMPARISON_VALUES_CSV,
            package_name=COMPARISON_PACKAGE,
        )
    except KeyError:
        return None, "none given"


# =============================================================================
# THE RUN
# =============================================================================
def main() -> ComponentReport:
    """Value the swap and its put leg, and compare each line with its comparison value."""
    if PUT_LEG_MODE not in ("booking", "autocall"):
        raise ValueError(f"PUT_LEG_MODE must be 'booking' or 'autocall', got {PUT_LEG_MODE!r}")
    notes: list = []

    # Step 1. Read the trade file.
    trade_file = TradeFile(TRADE_JSON_PATH)
    valuation_date = trade_file.valuation_date

    # Step 2. Read the swap terms. deal_info names the price factors the deal points to.
    swap, deal_info = load_autocall_swap(
        TRADE_JSON_PATH, reference=SWAP_REFERENCE, terminal_mode="per_barrier_date")
    booking = (load_put_leg_booking(TRADE_JSON_PATH, PUT_LEG_REFERENCE_STEM, PUT_LEG_REFERENCES)
               if PUT_LEG_MODE == "booking" else None)

    # Step 3. Build the equity market. fx_to_reporting turns payout currency into the
    # reporting currency.
    market = build_equity_market(trade_file, deal_info, notes)
    fx_to_reporting = BaseMarket(trade_file).fx_rate(
        deal_info.payoff_currency, trade_file.reporting_currency)
    is_quanto = swap.payoff_type == "Quanto" or (booking is not None and booking.payoff_type == "Quanto")
    quanto_adjustment = quanto_drift_adjustment(
        trade_file, market, deal_info.expiry_date, is_quanto, notes)

    def new_engine() -> GBMEngine:
        """A fresh simulation engine. The same seed gives the swap and the put leg the same paths."""
        return GBMEngine(n_paths=NUMBER_OF_PATHS, seed=RANDOM_SEED, vol_mode=VOLATILITY_MODE,
                         quanto_adj=quanto_adjustment)

    lines: list[ComponentLine] = []

    # Step 4. Value the swap. A swap that was already called before the valuation date has
    # no cashflows left and is worth zero.
    try:
        schedule = swap.build_schedule(valuation_date, market)
        payoff_inputs = schedule.payoff_kwargs()
        if booking is not None:
            # The put is booked separately, so it is switched off inside the swap.
            for remark in check_swap_against_booking(schedule, booking):
                notes.append(f"Check: {remark}")
            payoff_inputs = without_put(payoff_inputs)
        if booking is None and float(schedule.put_barrier or 0.0) > 0.0:
            # The swap carries its own put. The coupon and the put are simulated off the same
            # random numbers, each with the volatility read at its own level: the trigger
            # level for the coupon and the put barrier for the put.
            paths, put_paths = new_engine().simulate_per_leg(schedule, market)
            swap_result = evaluate_autocall_paths(
                paths, barrier_spot_paths=put_paths, **payoff_inputs)
        else:
            paths = new_engine().simulate(schedule, market)
            swap_result = evaluate_autocall_paths(paths, **payoff_inputs)
        scale = swap.notional * fx_to_reporting
        swap_value = scale * swap_result.pv
        swap_error = abs(scale) * swap_result.std_error
        notes.append(f"Swap legs: coupon {scale * swap_result.autocall_leg:,.2f}, "
                     f"floating {scale * swap_result.floating_leg:,.2f}, "
                     f"put {scale * swap_result.terminal_leg:,.2f}. "
                     f"Chance of an early call {swap_result.prob_autocalled:.2%}.")
    except AutocallExpired as expired:
        swap_value, swap_error = 0.0, 0.0
        notes.append(f"The swap was called before the valuation date and is worth zero: {expired}")
    description = ("Autocallable swap without its put" if booking is not None
                   else "Autocallable swap with its put")
    lines.append(ComponentLine(deal_info.reference, description, "simulation", swap_value, swap_error))

    # Step 5. Value the four booked options.
    if booking is not None:
        for remark in booking.warnings:
            notes.append(f"Check: {remark}")
        european_spread = digital_spread(trade_file, "EquityBinaryOption", EUROPEAN_DIGITAL_SPREAD)
        up_and_in_spread = digital_spread(
            trade_file, "EquityBarrierBinaryOption", UP_AND_IN_DIGITAL_SPREAD)
        forward_date = add_business_days(booking.expiry, EUROPEAN_FORWARD_LAG_BUSINESS_DAYS)
        put_leg = price_put_leg(
            booking, market, new_engine(),
            european_spread=european_spread, contra_spread=up_and_in_spread,
            european_forward_date=forward_date,
        )
        notes.append(f"Digital strike spread: European {european_spread:g}, up and in {up_and_in_spread:g}.")
        notes.append(f"Forward price of the European options carried to {forward_date.isoformat()} "
                     f"({EUROPEAN_FORWARD_LAG_BUSINESS_DAYS} business days after expiry).")
        notes.append(f"Chance that the put is knocked out by an early call: {put_leg.prob_knocked_out:.2%}.")
        vanilla, digital = put_leg.vanilla, put_leg.digital
        lines.append(ComponentLine(booking.vanilla.reference, "European put", "closed form",
                                   fx_to_reporting * vanilla.european_cf))
        lines.append(ComponentLine(booking.vanilla_contra.reference, "Up and in put", "simulation",
                                   fx_to_reporting * vanilla.contra_mc,
                                   abs(fx_to_reporting) * vanilla.contra_mc_se))
        if digital is not None:
            lines.append(ComponentLine(booking.digital.reference, "European digital put",
                                       "closed form", fx_to_reporting * digital.european_cf))
            lines.append(ComponentLine(
                booking.digital_contra.reference, "Up and in digital put", "simulation",
                fx_to_reporting * (digital.contra_mc + digital.contra_skew_delta),
                abs(fx_to_reporting) * digital.contra_mc_se))

    # Steps 6 and 7. Get the comparison value of each line, compare and report.
    sources = set()
    for line in lines:
        line.comparison_value, source = comparison_value_for(line.reference)
        sources.add(source)
        compare_line(line, ABSOLUTE_TOLERANCE, RELATIVE_TOLERANCE, Z_SCORE_TOLERANCE)
    notes.append(f"Comparison values: {', '.join(sorted(sources))}.")
    notes.append(f"Simulation: {NUMBER_OF_PATHS:,} paths, seed {RANDOM_SEED}, "
                 f"volatility mode {VOLATILITY_MODE}.")

    report = ComponentReport(
        title=f"Autocallable swap, put leg mode '{PUT_LEG_MODE}'",
        valuation_date=valuation_date,
        reporting_currency=trade_file.reporting_currency,
        lines=lines,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        z_score_tolerance=Z_SCORE_TOLERANCE,
        notes=notes,
    )
    print(format_component_report(report))
    if OUTPUT_FOLDER is not None:
        saved = write_component_report(report, OUTPUT_FOLDER, deal_info.reference)
        print(f"Report files saved in {saved['text'].parent}")
    return report


if __name__ == "__main__":
    warnings.simplefilter("default")
    main()
