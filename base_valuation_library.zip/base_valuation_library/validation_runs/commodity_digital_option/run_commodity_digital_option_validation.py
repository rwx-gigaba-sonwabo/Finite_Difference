"""Validation run: base valuation of a European commodity digital option.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Picks the commodity digital option to value.
3. Builds the market on the valuation date: forward price curve, discount curve,
   volatility surface and FX rates.
4. Values the option with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/commodity_digital_option/run_commodity_digital_option_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/commodity_digital_option.py``  the instrument and its valuation steps
``models/digital_option_pv.py``              the digital option formulas
``docs/commodity_digital_option.md``         the method in words and formulas
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.commodity_option_builders import build_commodity_digital_option  # noqa: E402
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import (  # noqa: E402
    BaseValuationResult,
    format_report,
    resolve_comparison_value,
    run_base_valuation,
    write_report,
)

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade ---------------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. Needed when the file holds more than one commodity
# digital option. None picks the only one in the file.
TRADE_REFERENCE = "BRENT_DIGITAL_CALL_CASH"

# --- Valuation method --------------------------------------------------------
# Half width of the replicating strike spread, as a fraction of the strike.
#   None : use the value in the trade file (Valuation Configuration >
#          CommodityDigitalOption > Relative_Digital_Spread). Zero if the file has none.
#   0.0  : closed form with one volatility at the strike. Ignores the smile slope.
#   0.01 : call or put spread with strikes 1% either side of the strike.
RELATIVE_DIGITAL_SPREAD = None

# How the forward price is read for a delivery date outside the curve's pillars.
#   "flat"   : hold the first or last price.
#   "linear" : hold the first price, extend the last segment in a straight line.
FORWARD_PRICE_EXTRAPOLATION = "flat"

# Correlation between the commodity price and the FX rate. Only used for a quanto or
# composite payout. None reads it from the trade file.
COMMODITY_FX_CORRELATION = None

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.USD-SOFR": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = SCRIPT_FOLDER / "sample_comparison_values.csv"
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-8      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the commodity digital option and compare it with the comparison value."""
    # Step 1. Read the trade file.
    trade_file = TradeFile(TRADE_JSON_PATH)

    # Step 2. Pick the deal. Its fields come back as a dictionary.
    deal = trade_file.find_deal(reference=TRADE_REFERENCE, deal_type="CommodityDigitalOption")
    trade_reference = deal.get("Reference") or "commodity_digital_option"

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Turn the deal into an instrument. market_state holds the curves and FX
    # rates the instrument reads.
    option, market_state = build_commodity_digital_option(
        deal, market,
        relative_digital_spread=RELATIVE_DIGITAL_SPREAD,
        forward_extrapolation=FORWARD_PRICE_EXTRAPOLATION,
        correlation=COMMODITY_FX_CORRELATION,
    )

    # Step 5. Get the comparison value.
    comparison_value, comparison_source = resolve_comparison_value(
        trade_reference, TRADE_JSON_PATH,
        typed_value=COMPARISON_VALUE,
        csv_path=COMPARISON_VALUES_CSV,
        package_name=COMPARISON_PACKAGE,
    )

    # Step 6. Value the option and compare.
    notes = [f"{curve}: {note}" for curve, note in market.interpolation_notes.items()]
    notes.append(f"Forward price extrapolation: {FORWARD_PRICE_EXTRAPOLATION}")
    notes.append(f"Payout type: {option.payoff_type}. Payout style: {option.payoff_style}.")
    result = run_base_valuation(
        instrument=option,
        market_state=market_state,
        valuation_date=trade_file.valuation_date,
        trade_reference=trade_reference,
        instrument_type="Commodity digital option",
        reporting_currency=trade_file.reporting_currency,
        comparison_value=comparison_value,
        comparison_source=comparison_source,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        notes=notes,
    )

    # Step 7. Report.
    print(format_report(result))
    if OUTPUT_FOLDER is not None:
        saved = write_report(result, OUTPUT_FOLDER)
        print(f"Report files saved in {saved['text'].parent}")
    return result


if __name__ == "__main__":
    main()
