"""Validation run: base valuation of an equity forward.

An agreement to buy shares at an agreed price on a future date. The forward price is the
spot price grown at the carry rate less the dividend yield. The value is the forward
price less the agreed price, times the number of shares, discounted.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/equity_forward/run_equity_forward_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/equity_forward.py``  the instrument
``models/equity_pv.py``  the forward price
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.equity_forward import EquityForward  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_SHARE_FORWARD_1Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Spot price of the share.
SPOT_PRICE = "EquityPrice.ZAR_SHARE"

# Zero rate curve the share price grows on.
CARRY_CURVE = "InterestRate.ZAR-SWAP"

# Continuous dividend yield curve of the share.
DIVIDEND_CURVE = "DividendRate.ZAR_SHARE"

# Zero rate curve used to discount the payoff.
DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Date the shares are exchanged for the agreed price.
MATURITY_DATE = from_trade_file("Maturity_Date")

# Price per share agreed in the contract.
AGREED_FORWARD_PRICE = from_trade_file("Forward_Price")

# Number of shares.
UNITS = from_trade_file("Units")

# True when the shares are bought forward, False when sold forward.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = SCRIPT_FOLDER / "sample_comparison_values.csv"
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "agreed_forward_price": resolve_term(AGREED_FORWARD_PRICE, deal, "AGREED_FORWARD_PRICE"),
        "units": resolve_term(UNITS, deal, "UNITS"),
        "is_buy": resolve_term(IS_BUY, deal, "IS_BUY"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    sign = 1.0 if terms["is_buy"] else -1.0
    instrument = EquityForward(
        name="equity_forward",
        end_date=terms["maturity_date"],
        agreed_forward=float(terms["agreed_forward_price"]),
        nominal=sign * float(terms["units"]),
        spot_name=SPOT_PRICE,
        carry_curve_name=CARRY_CURVE,
        dividend_curve_name=DIVIDEND_CURVE,
        carry_interpolator=market.curve_interpolator(CARRY_CURVE),
        dividend_interpolator=market.curve_interpolator(DIVIDEND_CURVE),
        discount_curve_name=DISCOUNT_CURVE,
        discount_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
    )
    market_state = market.market_state(
        curves=[CARRY_CURVE, DIVIDEND_CURVE, DISCOUNT_CURVE], scalars=[SPOT_PRICE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'equity_forward'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Equity forward',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
