"""Validation run: base valuation of a commodity forward.

An agreement to buy a commodity at an agreed price for one delivery date. The forward
price is read off the commodity forward price curve. The payoff in foreign currency is
converted at the forward FX rate and discounted on the domestic curve, which is the
treatment for a trade collateralised in domestic currency.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/commodity_forward/run_commodity_forward_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/commodity_forward.py``  the instrument
``models/commodity_pv.py``  the valuation

Points to note
--------------
The value is in domestic currency.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

from instruments.commodity_forward import CommodityForward  # noqa: E402
from utils.interpolation import forward_price_interpolator, linear_interpolator  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'BRENT_FORWARD_6M'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Commodity forward price curve. Pillars are Excel serial dates and values are prices in
# foreign currency.
FORWARD_PRICE_CURVE = "ForwardPrice.BRENT"

# Spot FX rate in domestic currency per one unit of foreign currency. Set FX_IS_INVERTED
# to True when the file quotes it the other way round.
FX_SPOT = "FxRate.USD"

# Spread curve added to the domestic money market curve to build the FX forward.
DOMESTIC_BASIS_CURVE = "InterestRate.ZAR-SWAP.ZAR-USD-BASIS"

# Zero rate curve of the foreign currency.
FOREIGN_CURVE = "InterestRate.USD-SOFR"

# Domestic zero rate curve used for discounting.
MONEY_MARKET_CURVE = "InterestRate.ZAR-SWAP"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# Date the commodity price is fixed.
DELIVERY_DATE = from_trade_file("Maturity_Date")

# Agreed price per unit.
STRIKE = 77.5

# Number of commodity units.
UNITS = from_trade_file("Units")

# True when the commodity is bought forward, False when sold.
IS_BUY = from_trade_file("Buy_Sell", is_buy)

# False: the strike and the payoff are in foreign currency. True: the strike is in
# domestic currency and the commodity price is converted at the forward FX rate.
IS_COMPOSITE = False

# Holiday calendar for the payment date and the FX settlement date.
PAYMENT_CALENDAR = "ZAR"

# Holiday calendar for the pricing lag.
PRICING_CALENDAR = "USD"

# Business days added to a fixing date to find the delivery date read on the forward
# curve.
PRICING_LAG_DAYS = 0

# Business days from the fixing date to the payment date.
PAYMENT_LAG_DAYS = 2

# Business days from a trade date to FX settlement.
FX_SETTLEMENT_LAG_DAYS = 2

# True when FX_SPOT is quoted in foreign currency per one unit of domestic currency.
FX_IS_INVERTED = False

# Forward price beyond the last pillar of the curve: "flat" holds the last price,
# "linear" extends the last segment.
FORWARD_PRICE_EXTRAPOLATION = "flat"

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "delivery_date": resolve_term(DELIVERY_DATE, deal, "DELIVERY_DATE"),
        "strike": resolve_term(STRIKE, deal, "STRIKE"),
        "units": resolve_term(UNITS, deal, "UNITS"),
        "is_buy": resolve_term(IS_BUY, deal, "IS_BUY"),
        "is_composite": resolve_term(IS_COMPOSITE, deal, "IS_COMPOSITE"),
        "payment_calendar": resolve_term(PAYMENT_CALENDAR, deal, "PAYMENT_CALENDAR"),
        "pricing_calendar": resolve_term(PRICING_CALENDAR, deal, "PRICING_CALENDAR"),
        "pricing_lag_days": resolve_term(PRICING_LAG_DAYS, deal, "PRICING_LAG_DAYS"),
        "payment_lag_days": resolve_term(PAYMENT_LAG_DAYS, deal, "PAYMENT_LAG_DAYS"),
        "fx_settlement_lag_days": resolve_term(FX_SETTLEMENT_LAG_DAYS, deal, "FX_SETTLEMENT_LAG_DAYS"),
        "fx_is_inverted": resolve_term(FX_IS_INVERTED, deal, "FX_IS_INVERTED"),
        "forward_price_extrapolation": resolve_term(FORWARD_PRICE_EXTRAPOLATION, deal, "FORWARD_PRICE_EXTRAPOLATION"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    instrument = CommodityForward(
        name="commodity_forward",
        delivery_date=terms["delivery_date"],
        strike=float(terms["strike"]),
        notional=float(terms["units"]),
        is_composite=bool(terms["is_composite"]),
        forward_curve_name=FORWARD_PRICE_CURVE,
        fx_spot_name=FX_SPOT,
        domestic_curve_name=DOMESTIC_BASIS_CURVE,
        foreign_curve_name=FOREIGN_CURVE,
        money_market_curve_name=MONEY_MARKET_CURVE,
        payment_calendar=terms["payment_calendar"],
        lag_calendar=terms["pricing_calendar"],
        direction=1 if terms["is_buy"] else -1,
        forward_interpolator=(linear_interpolator if terms["forward_price_extrapolation"] == "flat"
                              else forward_price_interpolator),
        domestic_interpolator=market.curve_interpolator(DOMESTIC_BASIS_CURVE),
        foreign_interpolator=market.curve_interpolator(FOREIGN_CURVE),
        money_market_interpolator=market.curve_interpolator(MONEY_MARKET_CURVE),
        pricing_lag=terms["pricing_lag_days"],
        payment_lag=terms["payment_lag_days"],
        fx_settlement_lag=terms["fx_settlement_lag_days"],
        fx_is_inverted=bool(terms["fx_is_inverted"]),
    )
    market_state = market.market_state(
        curves=[FORWARD_PRICE_CURVE, DOMESTIC_BASIS_CURVE, FOREIGN_CURVE, MONEY_MARKET_CURVE],
        scalars=[FX_SPOT])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'commodity_forward'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Commodity forward',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
