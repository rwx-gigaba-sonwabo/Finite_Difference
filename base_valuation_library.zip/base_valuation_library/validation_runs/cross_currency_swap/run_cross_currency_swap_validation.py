"""Validation run: base valuation of a cross currency swap.

A swap of interest payments in two currencies. Each leg pays a fixed or a floating rate
on its own notional. The notionals are exchanged at the start and at maturity. One leg
can be set to reset its notional to the market FX rate at the start of every period.
Each leg is valued in its own currency and the pay leg is converted at the FX spot rate.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/cross_currency_swap/run_cross_currency_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/cross_currency_swap.py``  the instrument
``instruments/components/cashflow_leg.py``  the leg definition
``models/cashflow_pv.py``  leg values and forward rates

Points to note
--------------
The value is in the receive currency. The dates and frequencies are typed in because the
deal type holds its cashflows as lists.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

import numpy as np  # noqa: E402
from instruments.components.cashflow_leg import CashflowLeg, LegType  # noqa: E402
from instruments.components.schedule_config import ScheduleConfig  # noqa: E402
from instruments.cross_currency_swap import CrossCurrencySwap  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZARUSD_CROSS_CURRENCY_SWAP_3Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Zero rate curve that discounts the receive leg.
RECEIVE_DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Zero rate curve the receive leg floating rate is projected from.
RECEIVE_PROJECTION_CURVE = "InterestRate.ZAR-JIBAR-3M"

# Zero rate curve that discounts the pay leg.
PAY_DISCOUNT_CURVE = "InterestRate.USD-SOFR"

# Zero rate curve the pay leg floating rate is projected from.
PAY_PROJECTION_CURVE = "InterestRate.USD-SOFR"

# FX factor of the receive currency. Its Spot is the value of one unit in the base
# currency of the trade file.
RECEIVE_FX = "FxRate.ZAR"

# FX factor of the pay currency, quoted the same way.
PAY_FX = "FxRate.USD"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# First accrual date of the swap.
EFFECTIVE_DATE = date(2026, 10, 30)

# Last payment date of the swap.
MATURITY_DATE = date(2029, 10, 30)

# Notional of the receive leg, in the receive currency.
RECEIVE_NOTIONAL = from_trade_file("Receive_Principal")

# Notional of the pay leg, in the pay currency.
PAY_NOTIONAL = from_trade_file("Pay_Principal")

# Spread added to the receive leg floating rate, as a decimal.
RECEIVE_SPREAD = from_trade_file("Receive_Margin", default=0.0)

# Spread added to the pay leg floating rate, as a decimal.
PAY_SPREAD = from_trade_file("Pay_Margin", default=0.0)

# Months between receive leg payments.
RECEIVE_FREQUENCY_MONTHS = 3

# Months between pay leg payments.
PAY_FREQUENCY_MONTHS = 3

# True when the notionals are exchanged on the effective date.
EXCHANGE_INITIAL_NOTIONAL = True

# Leg whose notional resets to the market FX rate each period: "pay", "receive" or None
# for fixed notionals.
RESETTING_LEG = None

# Holiday calendar for the payment schedule.
CALENDAR = "ZAR"

# Day count for the accrual fraction of each period.
ACCRUAL_DAY_COUNT = "ACT/365"

# Floating rates that fixed before the valuation date, as {(curve name, period start
# date): rate}. Needed for a period that started before the valuation date.
KNOWN_FLOATING_RATES = {}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "effective_date": resolve_term(EFFECTIVE_DATE, deal, "EFFECTIVE_DATE"),
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "receive_notional": resolve_term(RECEIVE_NOTIONAL, deal, "RECEIVE_NOTIONAL"),
        "pay_notional": resolve_term(PAY_NOTIONAL, deal, "PAY_NOTIONAL"),
        "receive_spread": resolve_term(RECEIVE_SPREAD, deal, "RECEIVE_SPREAD"),
        "pay_spread": resolve_term(PAY_SPREAD, deal, "PAY_SPREAD"),
        "receive_frequency_months": resolve_term(RECEIVE_FREQUENCY_MONTHS, deal, "RECEIVE_FREQUENCY_MONTHS"),
        "pay_frequency_months": resolve_term(PAY_FREQUENCY_MONTHS, deal, "PAY_FREQUENCY_MONTHS"),
        "exchange_initial_notional": resolve_term(EXCHANGE_INITIAL_NOTIONAL, deal, "EXCHANGE_INITIAL_NOTIONAL"),
        "resetting_leg": resolve_term(RESETTING_LEG, deal, "RESETTING_LEG"),
        "calendar": resolve_term(CALENDAR, deal, "CALENDAR"),
        "accrual_day_count": resolve_term(ACCRUAL_DAY_COUNT, deal, "ACCRUAL_DAY_COUNT"),
        "known_floating_rates": resolve_term(KNOWN_FLOATING_RATES, deal, "KNOWN_FLOATING_RATES"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    receive_leg = CashflowLeg(LegType.FLOATING, frequency=terms["receive_frequency_months"],
                              curve_name=RECEIVE_PROJECTION_CURVE, spread=float(terms["receive_spread"]))
    pay_leg = CashflowLeg(LegType.FLOATING, frequency=terms["pay_frequency_months"],
                          curve_name=PAY_PROJECTION_CURVE, spread=float(terms["pay_spread"]))
    instrument = CrossCurrencySwap(
        name="cross_currency_swap",
        effective_date=terms["effective_date"],
        maturity_date=terms["maturity_date"],
        receive_notional=float(terms["receive_notional"]),
        pay_notional=float(terms["pay_notional"]),
        receive_leg=receive_leg,
        pay_leg=pay_leg,
        receive_curve=RECEIVE_DISCOUNT_CURVE,
        pay_curve=PAY_DISCOUNT_CURVE,
        fx_spot_name=RECEIVE_FX,
        receive_curve_interpolator=market.curve_interpolator(RECEIVE_DISCOUNT_CURVE),
        pay_curve_interpolator=market.curve_interpolator(PAY_DISCOUNT_CURVE),
        schedule_config=ScheduleConfig(calendar=terms["calendar"],
                                       day_count=terms["accrual_day_count"]),
        exchange_initial_notional=bool(terms["exchange_initial_notional"]),
        mtm_leg=terms["resetting_leg"],
        # The FX rate between the two legs is the ratio of the two FX factors.
        receive_fx_name=RECEIVE_FX,
        pay_fx_name=PAY_FX,
    )
    curves = sorted({RECEIVE_DISCOUNT_CURVE, RECEIVE_PROJECTION_CURVE,
                     PAY_DISCOUNT_CURVE, PAY_PROJECTION_CURVE})
    market_state = market.market_state(curves=curves, scalars=[RECEIVE_FX, PAY_FX])
    # Rates that have already fixed are passed as past observations.
    fixings = {key: np.array([rate]) for key, rate in terms["known_floating_rates"].items()}
    return instrument, market_state, fixings or None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'cross_currency_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Cross currency swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
