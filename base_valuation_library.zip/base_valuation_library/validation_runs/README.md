# Validation runs

One folder per type of trade. Each folder holds:

| File | What it is |
|---|---|
| `run_<trade type>_validation.py` | The run script. It values one trade and compares the value |
| `sample_trade.json` | A sample trade JSON file, so the script runs as delivered |
| `sample_comparison_values.csv` | Comparison values for the sample, where they exist |
| `output/` | Report files. Created when the script runs |

## What every run script does

1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms from the deal in the file, or from values typed into the script.
3. Builds the market on the valuation date.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it in the `output` folder.

## How to use a run script on your own trade

Open the script and go to the block marked `SETTINGS`. Every setting has a comment above it
that says what it is.

| Setting | What to put there |
|---|---|
| `TRADE_JSON_PATH` | Path of your trade JSON file |
| `TRADE_REFERENCE` | The `Reference` field of the deal to value |
| Market data names | Full names of the price factors the trade reads, for example `InterestRate.ZAR-SWAP` |
| Trade terms | `from_trade_file("Field")` reads a field of the deal. A typed value replaces it |
| `COMPARISON_VALUE` | The value from the system being validated, typed in |
| `COMPARISON_VALUES_CSV` | Or a CSV file with the columns `Reference` and `Value` |
| `COMPARISON_PACKAGE` | Or the import name of an installed valuation package to run on the same file |
| `ABSOLUTE_TOLERANCE`, `RELATIVE_TOLERANCE` | How far apart the two values may be |
| `OUTPUT_FOLDER` | Where the report files go. `None` prints to the screen only |

Then run the script from the root folder of the library, for example:

```bash
python validation_runs/commodity_digital_option/run_commodity_digital_option_validation.py
```

## The runs

| Folder | Trade type | Deal type in the sample file | Instrument file |
|---|---|---|---|
| `autocall_swap` | Autocallable swap and its put leg | `QEDI_CustomAutoCallSwap_V2` and four equity option deals | `autocall_pricer/instruments/autocall/` |
| `bond_forward` | Forward on a fixed coupon bond | `BondForwardDeal` | `instruments/bond_forward.py` |
| `commodity_asian_option` | Commodity Asian option | `EnergySingleOption` | `instruments/commodity_asian.py` |
| `commodity_average_forward` | Commodity average price forward | `CommodityAveragePriceSwapDeal` | `instruments/commodity_average_forward.py` |
| `commodity_barrier_option` | Commodity barrier option, barrier watched all the time | `CommodityBarrierOption` | `instruments/commodity_barrier_option.py` |
| `commodity_digital_option` | European commodity digital option | `CommodityDigitalOption` | `instruments/commodity_digital_option.py` |
| `commodity_forward` | Commodity forward | `CommodityForwardDeal` | `instruments/commodity_forward.py` |
| `commodity_price_swap` | Commodity price swap | `CommodityAveragePriceSwapDeal` | `instruments/commodity_price_swap.py` |
| `credit_default_swap` | Credit default swap | `DealDefaultSwap` | `instruments/cds.py` |
| `cross_currency_swap` | Cross currency swap | `MtMCrossCurrencySwapDeal` | `instruments/cross_currency_swap.py` |
| `dividend_cashflows` | Strip of fixed dividend cashflows | `CFFixedListDeal` | `instruments/dividend_option.py` |
| `equity_asian_option` | Equity Asian option | `EquityDiscreteExplicitAsianOption` | `instruments/equity_asian.py` |
| `equity_forward` | Equity forward | `EquityForwardDeal` | `instruments/equity_forward.py` |
| `equity_option` | European equity option | `EquityOptionDeal` | `instruments/equity_option.py` |
| `equity_total_return_swap` | Equity total return swap | `EquitySwapletListDeal` | `instruments/equity_trs.py` |
| `fx_asian_option` | FX Asian option | `FXDiscreteExplicitAsianOption` | `instruments/fx_asian.py` |
| `fx_barrier_option` | FX barrier option | `FXBarrierOption` | `instruments/fx_barrier_option.py` |
| `fx_forward` | FX forward | `FXForwardDeal` | `instruments/fx_forward.py` |
| `fx_option` | European FX option | `FXOptionDeal` | `instruments/fx_option.py` |
| `fx_swap` | FX swap | `FXSwapDeal` | `instruments/fx_cash_swap.py` |
| `index_linked_swap` | Index linked swap | `YieldInflationCashflowListDeal` | `instruments/index_linked_swap.py` |
| `inflation_linked_bond_forward` | Inflation linked bond forward | `InflationLinkedBondForwardDeal` | `instruments/inflation_linked_bond_forward.py` |
| `interest_rate_swap` | Interest rate swap | `SwapInterestDeal` | `instruments/ir_swap.py` |
| `loan` | Fixed rate loan | `DepositDeal` | `instruments/loan.py` |
| `swaption` | European swaption | `SwaptionDeal` | `instruments/swaption.py` |

## Two kinds of run script

**The commodity digital option, the commodity barrier option and the autocallable swap** read
the whole deal from the trade file, market data names included. Their settings only cover the
valuation method.

**The other run scripts** read the main trade terms from the deal and take the market data
names as settings. Terms that such a deal holds as lists of cashflows, such as the payment
schedule, are typed into the script. Check each of them against the trade before a run.

## About the sample files

The sample trade files hold made up trades and made up market data. They are there to show
the layout and to let every script run. They are not market levels.

The samples of the commodity digital option, the commodity barrier option, the autocallable
swap and the equity forward come with comparison values. The other samples do not, so those
scripts report `NOT COMPARED` until you give a comparison value. See
[docs/validation_status.md](../docs/validation_status.md).
