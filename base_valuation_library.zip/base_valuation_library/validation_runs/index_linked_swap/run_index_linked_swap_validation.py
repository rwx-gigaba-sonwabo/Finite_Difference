"""Validation run: base valuation of an index linked swap.

A swap of an inflation linked leg against a nominal fixed leg. The inflation leg pays a
real coupon on a notional scaled by the growth in the consumer price index, and the
scaled notional at maturity. The nominal leg pays a fixed rate. Both legs are discounted
on the nominal curve. The value is the inflation leg less the nominal leg when the
inflation leg is received.

What this script does
---------------------
1. Reads one trade JSON file. The file holds the trade and the market data.
2. Reads the trade terms. Each term comes from the deal in the file or is typed in below.
3. Builds the market on the valuation date from the price factors named below.
4. Builds the instrument and values it with this library.
5. Gets the comparison value from the system being validated.
6. Compares the two values against the tolerance.
7. Prints a report and saves it to the output folder.

How to run
----------
From the root folder of the library::

    python validation_runs/index_linked_swap/run_index_linked_swap_validation.py

Edit the SETTINGS block below first. As delivered it runs on the sample trade file in
this folder.

Where the pricing lives
-----------------------
``instruments/index_linked_swap.py``  the instrument
``instruments/components/inflation_leg.py``  the inflation leg definition
``models/inflation_pv.py``  index ratios and leg values

Points to note
--------------
The trade terms are typed in because the deal type holds its cashflows as a list. The
index curve is interpolated in a straight line between its pillars.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# Make the library importable when the script is run from any folder.
SCRIPT_FOLDER = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_FOLDER.parents[1]
if str(LIBRARY_ROOT) not in sys.path:
    sys.path.insert(0, str(LIBRARY_ROOT))

import numpy as np  # noqa: E402
from instruments.components.cashflow_leg import CashflowLeg, LegType  # noqa: E402
from instruments.components.inflation_leg import InflationLeg  # noqa: E402
from instruments.components.schedule_config import ScheduleConfig  # noqa: E402
from instruments.index_linked_swap import IndexLinkedSwap  # noqa: E402
from market_data.risk_factor import CurveSlice  # noqa: E402
from utils.interpolation import linear_interpolator  # noqa: E402
from trade_data.base_market import BaseMarket  # noqa: E402
from trade_data.deal_terms import from_trade_file, is_buy, is_call, resolve_term  # noqa: E402,F401
from trade_data.trade_file import TradeFile  # noqa: E402
from valuation.base_valuation import BaseValuationResult  # noqa: E402
from valuation.run_script_support import compare_and_report  # noqa: E402

# =============================================================================
# SETTINGS
# =============================================================================

# --- The trade file ----------------------------------------------------------
# Path of the trade JSON file. It holds the deal and all the market data.
TRADE_JSON_PATH = SCRIPT_FOLDER / "sample_trade.json"

# The deal's "Reference" field. It picks the deal in the file, labels the report and is
# the key used to look up the comparison value. None picks the only deal in the file.
TRADE_REFERENCE = 'ZAR_INDEX_LINKED_SWAP_5Y'

# --- Market data names -------------------------------------------------------
# Full names of the price factors in the trade file that this instrument reads.
# Nominal zero rate curve used to discount both legs.
DISCOUNT_CURVE = "InterestRate.ZAR-SWAP"

# Projected consumer price index levels. Pillars are years from the valuation date,
# values are index levels.
PRICE_INDEX_CURVE = "PriceIndex.ZAR_CPI"

# Interpolation scheme per rate curve, to replace the scheme found in the trade file.
# Example: {"InterestRate.ZAR-SWAP": "Linear"}. Leave empty to use the file's own rules.
CURVE_INTERPOLATION_OVERRIDES: dict = {}

# --- Trade terms -------------------------------------------------------------
# from_trade_file("Field") reads that field of the deal in the trade file.
# Replace it with a typed value to set the term by hand.
# First accrual date of the swap.
EFFECTIVE_DATE = date(2026, 10, 30)

# Last payment date of the swap.
MATURITY_DATE = date(2031, 10, 30)

# Notional amount before index scaling.
NOTIONAL = 100_000_000.0

# Real coupon rate of the inflation leg per year, as a decimal.
REAL_RATE = 0.0425

# Fixed rate of the nominal leg per year, as a decimal.
NOMINAL_RATE = 0.0940

# Index level the notional is scaled from.
BASE_INDEX_LEVEL = 112.4

# Months between an index reference month and the date it applies to.
INDEX_LAG_MONTHS = 4

# Months between inflation leg payments. 0 means one payment at maturity.
INFLATION_FREQUENCY_MONTHS = 6

# Months between nominal leg payments. 0 means one payment at maturity.
NOMINAL_FREQUENCY_MONTHS = 6

# True adds the index scaled notional, paid at maturity, to the inflation leg. The
# nominal leg never pays a notional.
INCLUDE_NOTIONAL_EXCHANGE = True

# True when the inflation leg is received and the nominal leg is paid.
RECEIVE_INFLATION = True

# Holiday calendar for the payment schedule.
CALENDAR = "ZAR"

# Index levels already published, as {first day of the reference month: level}. They are
# used for reference months before the valuation date.
PUBLISHED_INDEX_LEVELS = {date(2026, 5, 1): 111.2, date(2026, 6, 1): 111.5, date(2026, 7, 1): 111.8, date(2026, 8, 1): 112.0, date(2026, 9, 1): 112.2, date(2026, 10, 1): 112.4}

# --- The comparison value ----------------------------------------------------
# Value of the same trade from the system being validated. The first source that is set
# is used, in this order.
# 1. A number typed in here, in the reporting currency.
COMPARISON_VALUE = None
# 2. A CSV file with the columns "Reference" and "Value".
COMPARISON_VALUES_CSV = None
# 3. The import name of an installed valuation package that is run on the trade file.
COMPARISON_PACKAGE = None

# --- Tolerance ---------------------------------------------------------------
# The values agree when the absolute difference is at most ABSOLUTE_TOLERANCE, or the
# relative difference is at most RELATIVE_TOLERANCE.
ABSOLUTE_TOLERANCE = 0.01      # in units of the reporting currency
RELATIVE_TOLERANCE = 1e-6      # as a fraction of the comparison value

# --- Output ------------------------------------------------------------------
# Folder for the report files. None prints to the console only.
OUTPUT_FOLDER = SCRIPT_FOLDER / "output"


# =============================================================================
# BUILDING THE INSTRUMENT
# =============================================================================
def read_trade_terms(deal: dict) -> dict:
    """Turn every trade term setting into its value, reading the deal where asked."""
    return {
        "effective_date": resolve_term(EFFECTIVE_DATE, deal, "EFFECTIVE_DATE"),
        "maturity_date": resolve_term(MATURITY_DATE, deal, "MATURITY_DATE"),
        "notional": resolve_term(NOTIONAL, deal, "NOTIONAL"),
        "real_rate": resolve_term(REAL_RATE, deal, "REAL_RATE"),
        "nominal_rate": resolve_term(NOMINAL_RATE, deal, "NOMINAL_RATE"),
        "base_index_level": resolve_term(BASE_INDEX_LEVEL, deal, "BASE_INDEX_LEVEL"),
        "index_lag_months": resolve_term(INDEX_LAG_MONTHS, deal, "INDEX_LAG_MONTHS"),
        "inflation_frequency_months": resolve_term(INFLATION_FREQUENCY_MONTHS, deal, "INFLATION_FREQUENCY_MONTHS"),
        "nominal_frequency_months": resolve_term(NOMINAL_FREQUENCY_MONTHS, deal, "NOMINAL_FREQUENCY_MONTHS"),
        "include_notional_exchange": resolve_term(INCLUDE_NOTIONAL_EXCHANGE, deal, "INCLUDE_NOTIONAL_EXCHANGE"),
        "receive_inflation": resolve_term(RECEIVE_INFLATION, deal, "RECEIVE_INFLATION"),
        "calendar": resolve_term(CALENDAR, deal, "CALENDAR"),
        "published_index_levels": resolve_term(PUBLISHED_INDEX_LEVELS, deal, "PUBLISHED_INDEX_LEVELS"),
    }


def build_instrument(terms: dict, market: BaseMarket, valuation_date: date):
    """Build the instrument, the market data it reads and its past observations.

    Returns
    -------
    instrument : the priceable instrument
    market_state : dict of market data on the valuation date
    fixings : dict of past observations, or None when the instrument needs none
    """
    inflation_leg = InflationLeg(
        frequency=terms["inflation_frequency_months"],
        fixed_rate=float(terms["real_rate"]),
        cpi_curve_name=PRICE_INDEX_CURVE,
        base_cpi=float(terms["base_index_level"]),
        lag_months=terms["index_lag_months"],
        include_notional_exchange=bool(terms["include_notional_exchange"]),
    )
    nominal_leg = CashflowLeg(LegType.FIXED, frequency=terms["nominal_frequency_months"],
                              fixed_rate=float(terms["nominal_rate"]))
    instrument = IndexLinkedSwap(
        name="index_linked_swap",
        inflation_leg=inflation_leg,
        nominal_leg=nominal_leg,
        effective_date=terms["effective_date"],
        maturity_date=terms["maturity_date"],
        notional=float(terms["notional"]),
        discount_curve_name=DISCOUNT_CURVE,
        discount_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        cpi_interpolator=linear_interpolator,
        forward_interpolator=market.curve_interpolator(DISCOUNT_CURVE),
        inflation_receiver=bool(terms["receive_inflation"]),
        schedule_config=ScheduleConfig(
            calendar=terms["calendar"], business_convention="ModifiedFollowing",
            termination_business_convention="ModifiedFollowing", date_generation="Backward",
            day_count="ACT/365", curve_day_count="ACT/365"),
    )
    # Index levels that are already published are given to the instrument directly.
    instrument._historical_cpi_map = dict(terms["published_index_levels"])
    market_state = market.market_state(curves=[DISCOUNT_CURVE, PRICE_INDEX_CURVE])
    return instrument, market_state, None


# =============================================================================
# THE RUN
# =============================================================================
def main() -> BaseValuationResult:
    """Value the trade and compare it with the comparison value."""
    # Step 1. Read the trade file and pick the deal.
    trade_file = TradeFile(TRADE_JSON_PATH)
    deal = trade_file.find_deal(reference=TRADE_REFERENCE)
    trade_reference = deal.get("Reference") or 'index_linked_swap'

    # Step 2. Read the trade terms.
    terms = read_trade_terms(deal)

    # Step 3. Build the market on the valuation date.
    market = BaseMarket(trade_file, interpolation_overrides=CURVE_INTERPOLATION_OVERRIDES)

    # Step 4. Build the instrument and the market data it reads.
    instrument, market_state, fixings = build_instrument(terms, market, trade_file.valuation_date)

    # Steps 5 to 7. Get the comparison value, value the trade, compare and report.
    return compare_and_report(
        instrument, market_state, trade_file, market,
        trade_reference=trade_reference,
        instrument_type='Index linked swap',
        comparison_value=COMPARISON_VALUE,
        comparison_values_csv=COMPARISON_VALUES_CSV,
        comparison_package=COMPARISON_PACKAGE,
        absolute_tolerance=ABSOLUTE_TOLERANCE,
        relative_tolerance=RELATIVE_TOLERANCE,
        output_folder=OUTPUT_FOLDER,
        fixings=fixings,
        notes=[],
    )


if __name__ == "__main__":
    main()
