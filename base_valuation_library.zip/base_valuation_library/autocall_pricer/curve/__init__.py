"""Curve handling modules."""
