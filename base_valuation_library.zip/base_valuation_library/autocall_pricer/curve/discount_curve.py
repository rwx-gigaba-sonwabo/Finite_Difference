import pandas as pd
import numpy as np
from datetime import date
from math import log, exp


def act365(start_date: date, end_date: date) -> float:
    """ACT/365 day count convention."""
    return (end_date - start_date).days / 365.0

def act360(start_date: date, end_date: date) -> float:
    """ACT/360 day count convention."""
    return (end_date - start_date).days / 360.0


class DiscountYieldCurveHandler:
    def __init__(self, valuation_date: date, df: pd.DataFrame, interpolator, day_count_convention=None, rate_day_count_convention=None):
        """
        Parameters:
            valuation_date: Base valuation date.
            df: DataFrame with 'Date' and 'Rate' columns (continuously compounded rates).
            interpolator: Function that takes (x, y) and returns an interpolation function.
            day_count_convention: Day count for interpolation year fracs (valuation → pillar dates).
                Should always be act365 to match ACT/365 bootstrapping. Defaults to act365.
            rate_day_count_convention: Day count for the τ denominator in forward rate expressions
                (get_simple_forward, get_ois_compounded_rate). Set to act360 for SOFR/ESTR curves.
                Defaults to day_count_convention (act365) if not provided.
        """



        self.valuation_date = valuation_date
        self.day_count_convention = day_count_convention if day_count_convention is not None else act365
        self.rate_day_count_convention = rate_day_count_convention if rate_day_count_convention is not None else self.day_count_convention
        df = df.copy()
        df["Date"] = pd.to_datetime(df["Date"]).dt.date


        self.pillar_dates = df["Date"].tolist()


        self.year_frac = np.array([self.day_count_convention(valuation_date, d) for d in df["Date"]])
        self.rates = np.array(df["Rate"])


        self.interpolator = interpolator(self.year_frac, self.rates)

    def get_rate(self, t: float) -> float:
        """Returns interpolated continuously compounded rate for year fraction t."""
        return float(self.interpolator(t))

    def get_rate_for_date(self, target_date: date) -> float:
        """Returns interpolated continuously compounded rate for target date."""
        t = self.day_count_convention(self.valuation_date, target_date)
        return float(self.interpolator(t))

    def discount_factor(self, t: float) -> float:
        """Returns discount factor for year fraction t."""
        r_t = self.get_rate(t)
        return np.exp(-r_t * t)

    def get_discount_factor_for_date(self, target_date: date) -> float:
        """Returns discount factor for target date."""
        t = self.day_count_convention(self.valuation_date, target_date)
        return self.discount_factor(t)
    
    def flat_forward_cont_rate(self, t1: float, t2: float) -> float:
        """
        Computes forward continuous rate between two year fractions.

        Parameters:
            t1: Start time in years from valuation date.
            t2: End time in years from valuation date.

        Returns:
            Continuous forward rate between t1 and t2.
        """
        if t2 <= t1:
            raise ValueError("t2 must be greater than t1")
        
        df1 = self.discount_factor(t1)
        df2 = self.discount_factor(t2)
        return (log(df1) - log(df2)) / (t2 - t1)

    def flat_forward_cont_rate_between_dates(self, start_date: date, end_date: date) -> float:
        """
        Computes forward continuous rate between two dates.

        Parameters:
            start_date: Start date.
            end_date: End date.

        Returns:
            Continuous forward rate between the dates.
        """
        t1 = self.day_count_convention(self.valuation_date, start_date)
        t2 = self.day_count_convention(self.valuation_date, end_date)
        return self.flat_forward_cont_rate(t1, t2)
    
    def get_simple_forward(self, start_date: date, end_date: date) -> float:
        """
        Computes simple forward rate between two dates.

        Parameters:
            start_date: Start date of the forward period.
            end_date: End date of the forward period.

        Returns:
            Simple forward rate (annualised).
        
        
        
        
        
        
        
        """
        if end_date <= start_date:
            raise ValueError("end_date must be greater than start_date")
        df1 = self.get_discount_factor_for_date(start_date)
        df2 = self.get_discount_factor_for_date(end_date)
        tau = self.rate_day_count_convention(start_date, end_date)
        return (df1 / df2 - 1.0) / tau





    def get_ois_compounded_cashflow_factor(self, start_date: date, end_date: date) -> float:
        """
        Returns the OIS compounded growth factor (DF(t1)/DF(t2) - 1) for a period.

        Represents the total compounded return from daily overnight fixings,
        derived from the discount curve rather than stepping through individual days.
        Multiply by notional to get the raw compounded cashflow.

        Parameters:
            start_date: Start date of the compounding period.
            end_date: End date of the compounding period.

        Returns:
            Compounded cashflow factor: DF(t1)/DF(t2) - 1.
        """
        if end_date <= start_date:
            raise ValueError("end_date must be greater than start_date")
        df1 = self.get_discount_factor_for_date(start_date)
        df2 = self.get_discount_factor_for_date(end_date)
        return df1 / df2 - 1.0

    def get_ois_compounded_rate(self, start_date: date, end_date: date) -> float:
        """
        Returns the OIS compounded rate (annualised) for a period.

        Equivalent to daily-compounded overnight rates expressed as an annualised
        simple rate: (DF(t1)/DF(t2) - 1) / tau. Compatible with add_floating_cashflows
        so that cashflow = N * tau * rate = N * (DF1/DF2 - 1).

        Parameters:
            start_date: Start date of the compounding period.
            end_date: End date of the compounding period.

        Returns:
            Annualised OIS compounded rate.
        """
        if end_date <= start_date:
            raise ValueError("end_date must be greater than start_date")
        tau = self.rate_day_count_convention(start_date, end_date)
        return self.get_ois_compounded_cashflow_factor(start_date, end_date) / tau