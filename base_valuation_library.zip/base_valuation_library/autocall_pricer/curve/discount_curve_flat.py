import numpy as np
import pandas as pd
from datetime import date, timedelta
from math import log, exp


def act365(start_date: date, end_date: date) -> float:
    """ACT/365 day count convention."""
    return (end_date - start_date).days / 365.0


class FlatDiscountCurve:
    """
    Flat discount curve with a constant rate at all maturities.

    Uses a single fixed simple annual rate for all periods. The rate is used directly
    for forward calculations and converted to continuous compounding for discount factors.
    """

    def __init__(self, valuation_date: date, simple_annual_rate: float):
        """
        Parameters:
            valuation_date: Base valuation date.
            simple_annual_rate: Constant simple annual rate (Act/365).
        """
        self.valuation_date = valuation_date
        self.simple_annual_rate = float(simple_annual_rate)
        self.continuous_rate = log(1.0 + self.simple_annual_rate)
        self.pillar_dates = [valuation_date]

    def get_rate(self, t: float) -> float:
        """
        Returns the flat simple annual rate.

        Parameters:
            t: Year fraction from valuation date.

        Returns:
            The constant simple annual rate.
        """
        return self.simple_annual_rate

    def get_rate_for_date(self, target_date: date) -> float:
        """
        Returns the flat simple annual rate for a given date.

        Parameters:
            target_date: Target date.

        Returns:
            The constant simple annual rate.
        """
        return self.simple_annual_rate

    def discount_factor(self, t: float) -> float:
        """
        Returns the discount factor for a given year fraction.

        Parameters:
            t: Year fraction from valuation date.

        Returns:
            Discount factor at time t.
        """
        return np.exp(-self.continuous_rate * t)

    def get_discount_factor_for_date(self, target_date: date) -> float:
        """
        Returns the discount factor for a target date.

        Parameters:
            target_date: Target date.

        Returns:
            Discount factor for the target date.
        """
        t = act365(self.valuation_date, target_date)
        return self.discount_factor(t)

    def flat_forward_cont_rate(self, t1: float, t2: float) -> float:
        """
        Computes the forward continuous rate between two year fractions.

        Parameters:
            t1: Start time in years from valuation date.
            t2: End time in years from valuation date.

        Returns:
            Continuous forward rate between t1 and t2.
        """
        if t2 <= t1:
            raise ValueError("t2 must be greater than t1")

        return self.continuous_rate

    def flat_forward_cont_rate_between_dates(self, start_date: date, end_date: date) -> float:
        """
        Computes the forward continuous rate between two dates.

        Parameters:
            start_date: Start date.
            end_date: End date.

        Returns:
            Continuous forward rate between the dates.
        """
        if end_date <= start_date:
            raise ValueError("end_date must be greater than start_date")

        return self.continuous_rate

    def get_simple_forward(self, start_date: date, end_date: date) -> float:
        """
        Computes the simple forward rate between two dates.

        Parameters:
            start_date: Start date of the forward period.
            end_date: End date of the forward period.

        Returns:
            Simple forward rate (annualised).
        """
        if end_date <= start_date:
            raise ValueError("end_date must be greater than start_date")

        return self.simple_annual_rate


def create_flat_curve_dataframe(
    valuation_date: date,
    simple_annual_rate: float,
    max_maturity_years: int = 30
) -> tuple[pd.DataFrame, callable]:
    """
    Creates a DataFrame and flat interpolator for use with DiscountYieldCurveHandler.

    Parameters:
        valuation_date: Base valuation date.
        simple_annual_rate: Constant rate to use.
        max_maturity_years: Maximum maturity in years for curve pillars (default 30).

    Returns:
        Tuple containing DataFrame with 'Date' and 'Rate' columns and a flat interpolator function.
    """
    pillar_dates = [valuation_date]
    standard_tenors_days = [30, 90, 180, 365, 365*2, 365*3, 365*5, 365*7,
                            365*10, 365*15, 365*20, 365*30]

    for days in standard_tenors_days:
        if days <= max_maturity_years * 365:
            pillar_dates.append(valuation_date + timedelta(days=days))

    df = pd.DataFrame({
        'Date': pillar_dates,
        'Rate': [simple_annual_rate] * len(pillar_dates)
    })

    def flat_interpolator(x_values, y_values):
        constant_rate = simple_annual_rate
        def interpolate(t):
            if isinstance(t, (list, np.ndarray)):
                return np.full_like(t, constant_rate, dtype=float)
            return constant_rate
        return interpolate

    return df, flat_interpolator
