"""Build a zero rate curve object from a list of pillars."""

from __future__ import annotations

from datetime import date, timedelta

import pandas as pd

from autocall_pricer.curve.discount_curve import DiscountYieldCurveHandler
from autocall_pricer.utils.interpolation import (
    cubic_hermite_interp,
    hermite_rt_interp,
    linear_interp,
    linear_rt_interp,
    reciprocal_time_interp,
)

#: Interpolation scheme names and the functions that carry them out.
INTERPOLATION_SCHEMES = {
    "HermiteRT": hermite_rt_interp,
    "Hermite": cubic_hermite_interp,
    "LinearRT": linear_rt_interp,
    "Linear": linear_interp,
    "ReciprocalTime": reciprocal_time_interp,
}


def curve_from_points(valuation_date: date, points, interpolation: str) -> DiscountYieldCurveHandler:
    """Turn ``[(term in years, continuous zero rate), ...]`` into a curve object.

    Each term becomes a date ``term * 365`` days after the valuation date.
    """
    scheme = INTERPOLATION_SCHEMES.get(interpolation)
    if scheme is None:
        raise ValueError(
            f"unsupported interpolation {interpolation!r} (supported: {sorted(INTERPOLATION_SCHEMES)})")
    dates = [valuation_date + timedelta(days=int(round(term * 365))) for term, _ in points]
    frame = pd.DataFrame({"Date": dates, "Rate": [rate for _, rate in points]})
    return DiscountYieldCurveHandler(valuation_date, frame, scheme)
