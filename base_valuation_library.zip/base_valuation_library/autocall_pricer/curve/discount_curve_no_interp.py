import pandas as pd
import numpy as np
from datetime import date, timedelta
from math import log, exp


def act365(start_date: date, end_date: date) -> float:
    """ACT/365 day count convention."""
    return (end_date - start_date).days / 365.0


class YieldCurveHandlerNoInterp:
    """
    Yield curve handler using exact rate lookups from daily dataframe instead of interpolation.
    Works with daily continuously compounded spot rates.
    """

    def __init__(self, valuation_date: date, df: pd.DataFrame):
        """
        Parameters:
            valuation_date: Base valuation date.
            df: DataFrame with 'Date' and 'Rate' columns containing daily rates.
        """
        self.valuation_date = valuation_date
        df = df.copy()
        df["Date"] = pd.to_datetime(df["Date"]).dt.date
        df = df.sort_values("Date").reset_index(drop=True)
        self.rate_df = df.set_index("Date")["Rate"]
        self.pillar_dates = df["Date"].tolist()
        self.year_frac = np.array([act365(valuation_date, d) for d in df["Date"]])
        self.rates = np.array(df["Rate"])
        self.date_to_rate = dict(zip(self.pillar_dates, self.rates))
        self.min_date = df["Date"].min()
        self.max_date = df["Date"].max()

    def get_rate(self, t: float) -> float:
        """
        Returns exact rate for year fraction t by converting to date and looking up rate.

        Parameters:
            t: Year fraction from valuation date.

        Returns:
            Exact rate for the calculated date.
        """
        days = int(round(t * 365))
        target_date = self.valuation_date + timedelta(days=days)
        return self.get_rate_for_date(target_date)

    def get_rate_for_date(self, target_date: date) -> float:
        """
        Returns exact rate for a given date.

        Parameters:
            target_date: Target date.

        Returns:
            Exact rate for the date.
        """
        if target_date < self.min_date or target_date > self.max_date:
            raise ValueError(
                f"Date {target_date} is outside the available range "
                f"({self.min_date} to {self.max_date})"
            )
        if target_date not in self.date_to_rate:
            raise KeyError(
                f"Rate not available for date {target_date}. "
                f"Please ensure the dataframe contains daily rates for all dates."
            )
        return float(self.date_to_rate[target_date])

    def discount_factor(self, t: float) -> float:
        """Returns discount factor for year fraction t."""
        r_t = self.get_rate(t)
        return np.exp(-r_t * t)

    def get_discount_factor_for_date(self, target_date: date) -> float:
        """Returns discount factor for target date."""
        t = act365(self.valuation_date, target_date)
        r_t = self.get_rate_for_date(target_date)
        return np.exp(-r_t * t)

    def flat_forward_cont_rate(self, t1: float, t2: float) -> float:
        """
        Computes forward continuous rate between two year fractions.

        Parameters:
            t1: Start time in years from valuation date.
            t2: End time in years from valuation date.

        Returns:
            Continuous forward rate between t1 and t2.
        """
        if t2 <= t1:
            raise ValueError("t2 must be greater than t1")
        df1 = self.discount_factor(t1)
        df2 = self.discount_factor(t2)
        return (log(df1) - log(df2)) / (t2 - t1)

    def flat_forward_cont_rate_between_dates(self, start_date: date, end_date: date) -> float:
        """
        Computes forward continuous rate between two dates.

        Parameters:
            start_date: Start date.
            end_date: End date.

        Returns:
            Continuous forward rate between the dates.
        """
        t1 = act365(self.valuation_date, start_date)
        t2 = act365(self.valuation_date, end_date)
        return self.flat_forward_cont_rate(t1, t2)

    def get_simple_forward(self, start_date: date, end_date: date) -> float:
        """
        Computes simple forward rate between two dates.

        Parameters:
            start_date: Start date of the forward period.
            end_date: End date of the forward period.

        Returns:
            Simple forward rate (annualised).
        """
        if end_date <= start_date:
            raise ValueError("end_date must be greater than start_date")
        df1 = self.get_discount_factor_for_date(start_date)
        df2 = self.get_discount_factor_for_date(end_date)
        day_count_fraction = act365(start_date, end_date)
        return (df1 / df2 - 1.0) / day_count_fraction
