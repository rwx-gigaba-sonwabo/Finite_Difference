# Autocall pricer

This package values an autocallable equity swap and the options that book its put leg.
It uses Monte Carlo simulation of the share price on the observation dates of the trade.

The run script that uses it is `validation_runs/autocall_swap/run_autocall_swap_validation.py`.
The method is described in [docs/autocall_swap.md](../docs/autocall_swap.md).

## What is in the package

| Folder | What it holds |
|---|---|
| `instruments/autocall/` | The swap, its payoff, the put leg booking and the trade file loader |
| `instruments/base/` | The base class of the instruments in this package |
| `models/` | The simulation engines and the closed form checks |
| `market_data/` | Equity market data and the volatility surfaces |
| `curve/` | Discount curves |
| `utils/` | Interpolation, schedules and JSON helpers |
| `tests/` | Unit tests of this package |

## Main files

| File | What it does |
|---|---|
| `instruments/autocall/autocall_swap.py` | Holds the trade terms and builds the observation schedule |
| `instruments/autocall/payoff.py` | Turns simulated prices into the payoff of each path |
| `instruments/autocall/put_leg.py` | Values the European and barrier options that book the put leg |
| `instruments/autocall/trade_file_loader.py` | Reads the deal, the curves and the surfaces from a trade JSON file |
| `instruments/autocall/manual_pricer.py` | Values a swap from typed inputs, with no trade file |
| `instruments/autocall/compare.py` | Compares a simulated value with a comparison value, using a z score |
| `models/gbm.py` | Lognormal simulation with a forward volatility strip per strike |
| `models/logvar2fj.py` | Two factor stochastic volatility simulation with jumps |
| `models/fx_gbm.py` | Joint simulation of share and FX, used to check the quanto adjustment |
| `models/analytics.py` | Closed form option values used as checks |
| `models/dividends.py` | Forward prices with cash dividends |
| `models/sobol_normals.py` | Sobol random numbers. Needs the optional `torch` package |

## Tests

From the root folder of the library:

```bash
pytest autocall_pricer/tests
```

Expected result: 63 passed.

## Points to note

* A simulated value has sampling noise. The run script reports the standard error next to
  each value and judges the difference with a z score.
* A coupon that is decided on the average of several fixings is not supported. The loader
  stops with an error for such a deal.
* Imports start with `autocall_pricer.` because the folder names `instruments`, `models`,
  `market_data` and `utils` also exist at the root of the library.
