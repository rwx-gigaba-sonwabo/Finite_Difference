from scipy.interpolate import CubicSpline, interp1d
import numpy as np

def cubic_hermite_interp(x, y):
    """
    Creates cubic Hermite interpolator using finite differences.

    Parameters:
        x: Time grid (year fractions, sorted ascending).
        y: Corresponding rate values.

    Returns:
        Interpolation function.
    """
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)

    def interpolate(s):
        if isinstance(s, (list, np.ndarray)):
            return np.array([interpolate(float(si)) for si in s])

        s = float(s)
        n = len(x)

        if s <= x[0]:
            return float(y[0])
        if s >= x[-1]:
            return float(y[-1])

        i = np.searchsorted(x, s) - 1
        i = np.clip(i, 0, n - 2)

        x0 = x[max(i - 1, 0)]
        x1 = x[i]
        x2 = x[i + 1]
        x3 = x[min(i + 2, n - 1)]

        y0 = y[max(i - 1, 0)]
        y1 = y[i]
        y2 = y[i + 1]
        y3 = y[min(i + 2, n - 1)]

        dx01 = x1 - x0
        dx12 = x2 - x1
        dx23 = x3 - x2

        if dx01 == 0:
            d0 = 0.0
        else:
            d0 = (y1 - y0) / dx01

        if dx12 == 0:
            d1 = 0.0
        else:
            dy12 = (y2 - y1) / dx12
            dx02 = x2 - x0
            if dx02 == 0:
                d1 = 0.0
            else:
                d1 = (dy12 - d0) / dx02

        if dx23 == 0 or dx12 == 0:
            d2 = 0.0
        else:
            dy23 = (y3 - y2) / dx23
            dy12 = (y2 - y1) / dx12
            dx13 = x3 - x1
            dx03 = x3 - x0
            if dx03 == 0:
                d2 = 0.0
            else:
                d2 = (dy23 - dy12 - d1 * dx13) / dx03

        if x0 <= s <= x2:
            v = (
                y0
                + d0 * (s - x0)
                + d1 * (s - x0) * (s - x1)
                + d2 * (s - x0) * (s - x1) * (s - x2)
            )
        else:
            v = (
                y1
                + d0 * (s - x1)
                + d1 * (s - x1) * (s - x2)
                + d2 * (s - x1) * (s - x2) * (s - x3)
            )
        return float(v)

    return interpolate

def linear_interpolator(
    x: float,
    x_values: list[float],
    y_values: list[float],
    val_date: float
) -> float:
    """
    Linear interpolation on cumulative hazard rates.

    Parameters:
        x: Target time in years from valuation date.
        x_values: Time points in years from valuation date.
        y_values: Hazard rates corresponding to x_values.
        val_date: Valuation time (usually 0.0).

    Returns:
        Interpolated hazard rate at x.
    """
    if x <= x_values[0]:
        return y_values[0]
    if x >= x_values[-1]:
        return y_values[-1]

    for i in range(1, len(x_values)):
        if x <= x_values[i]:
            t0, t1 = x_values[i - 1], x_values[i]
            r0, r1 = y_values[i - 1], y_values[i]
            H0 = r0 * (t0 - val_date)
            H1 = r1 * (t1 - val_date)
            Hx = H0 + (H1 - H0) * (x - t0) / (t1 - t0)
            interpolated_rate = Hx / (x - val_date)
            return interpolated_rate

    return y_values[-1]

def hermite_rt_interp(x, y, val_date=0.0):
    """
    Hermite RT interpolation in (r * t) space.

    Parameters:
        x: Time grid (year fractions from valuation date, sorted ascending).
        y: Spot rates corresponding to x.
        val_date: Valuation time (default 0.0).

    Returns:
        Interpolator function returning interpolated rates.
    """
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)
    rt = y * (x - val_date)
    n = len(x)
    r_prime = np.zeros_like(rt)

    for i in range(1, n - 1):
        dx1 = x[i] - x[i - 1]
        dx2 = x[i + 1] - x[i]
        if dx1 == 0 or dx2 == 0:
            r_prime[i] = 0.0
        else:
            r_prime[i] = (
                (rt[i + 1] - rt[i]) * (x[i] - x[i - 1]) / dx2
                + (rt[i] - rt[i - 1]) * (x[i + 1] - x[i]) / dx1
            ) / (x[i + 1] - x[i - 1])

    if n >= 3:
        t1, t2, t3 = x[0], x[1], x[2]
        r1, r2, r3 = rt[0], rt[1], rt[2]
        r_prime[0] = (
            (r2 - r1) * (t3 + t2 - 2 * t1) / (t2 - t1)
            - (r3 - r2) * (t2 - t1) / (t3 - t2)
        ) / (t3 - t1)

        tn, tn1, tn2 = x[-1], x[-2], x[-3]
        rn, rn1, rn2 = rt[-1], rt[-2], rt[-3]
        r_prime[-1] = -(
            (rn1 - rn2) * (tn - tn1) / (tn1 - tn2)
            - (rn - rn1) * (2 * tn - tn1 - tn2) / (tn - tn1)
        ) / (tn - tn2)
    else:
        r_prime[0] = r_prime[-1] = 0.0

    def interpolate(t):
        if isinstance(t, (list, np.ndarray)):
            return np.array([interpolate(float(tt)) for tt in t])

        if t <= x[0]:
            return y[0]
        if t >= x[-1]:
            return y[-1]

        i = np.searchsorted(x, t) - 1
        i = np.clip(i, 0, n - 2)

        t1, t2 = x[i], x[i + 1]
        r1, r2 = rt[i], rt[i + 1]
        r1p, r2p = r_prime[i], r_prime[i + 1]
        h = t2 - t1
        m = (t - t1) / h

        rt_interp = (
            (1 - m) ** 2 * (1 + 2 * m) * r1
            + m**2 * (3 - 2 * m) * r2
            + (1 - m) ** 2 * m * h * r1p
            + m**2 * (m - 1) * h * r2p
        )

        if t - val_date == 0:
            return y[0]
        return rt_interp / (t - val_date)

    return interpolate

def cubic_spline(x, y):
    """Cubic spline interpolator with natural boundary conditions."""
    return CubicSpline(x, y, bc_type="natural")

def linear_rt_interp(x, y, val_date=0.0):
    """
    
    """
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)

    # Convert spot rates to r*t
    rt = y*(x - val_date)
    n = len(x)

    def interpolate(t):
        """
        
        """
        if isinstance(t, (list, np.ndarray)):
            return np.array([interpolate(float(tt)) for tt in t])
        
        t = float(t)

        # Flat extrapolation
        if t<= x[0]:
            return float(y[0])
        if t>= x[-1]:
            return float(y[-1])
        
        i = np.searchsorted(x, t) - 1
        i = np.clip(i, 0, n - 2)

        t1, t2 = x[i], x[i + 1]
        rt1, rt2 = rt[i], rt[i + 1]

        rt_interp = rt1 + (rt2 - rt1) * (t - t1) / (t2 - t1)


        if abs(t - val_date) < 1e-10:
            return float(y[0])
        
        return float(rt_interp / (t - val_date))
    
    return interpolate

def linear_interp(x, y):
    """
    Linear interpolation in rate space with flat extrapolation.

    Parameters:
        x: Time grid (year fractions, sorted ascending).
        y: Rates at x.

    Returns:
        Interpolation function.
    """
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)

    def interpolate(t):
        if isinstance(t, (list, np.ndarray)):
            return np.array([interpolate(float(tt)) for tt in t])
        t = float(t)
        if t <= x[0]:
            return float(y[0])
        if t >= x[-1]:
            return float(y[-1])
        return float(np.interp(t, x, y))

    return interpolate


def reciprocal_time_interp(x, y, val_date=0.0):
    """
    Reciprocal-time interpolation: the rate is linear in 1/t. This is the scheme used for
    dividend yield curves, whatever 'Interpolation' field the curve carries. Flat extrapolation
    outside the pillars.

    For pillars (t_i, y_i) and a query t in [t_i, t_{i+1}]:
        alpha = (1/t_i - 1/t) / (1/t_i - 1/t_{i+1})
        y(t)  = y_i (1 - alpha) + y_{i+1} alpha
    i.e. y is linear against 1/t. The per-segment tenor_delta is 1/t_i - 1/t_{i+1}
    with the final segment delta set to 1.0 and t clipped to [min_tenor, max_tenor].

    Parameters:
        x: Time grid (year fractions, sorted ascending).
        y: Rates (dividend yields) at x.
        val_date: unused (present for a uniform interpolator signature).

    Returns:
        Interpolation function.
    """
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)
    n = len(x)
    if n > 1:
        seg = 1.0 / np.clip(x[:-1], 1e-5, np.inf) - 1.0 / np.clip(x[1:], 1e-5, np.inf)
        tenor_delta = np.hstack((seg, [1.0]))               # 1.0 is appended for the last node
    else:
        tenor_delta = np.array([1.0])
    min_tenor = max(1e-5, x.min())
    max_tenor = max(1e-5, x.max())
    max_idx = max(n - 1, 0)

    def interpolate(t):
        if isinstance(t, (list, np.ndarray)):
            return np.array([interpolate(float(tt)) for tt in t])
        t = float(t)
        index = int(np.clip(np.searchsorted(x, t, side="right") - 1, 0, max_idx))
        index_next = int(np.clip(index + 1, 0, max_idx))
        tc = min(max(t, min_tenor), max_tenor)
        alpha = (1.0 / max(x[index], 1e-5) - 1.0 / tc) / tenor_delta[index]
        return float(y[index] * (1.0 - alpha) + alpha * y[index_next])

    return interpolate


def stitched_linear_hermite_rt_inter(x, y, val_date=0.0, stitch_years=1.5):
    """
    """
    x = np.array(x, dtype=float)
    y = np.array(y, dtype=float)

    stitch_idx = int(np.argmin(np.abs(x - stitch_years)))

    x_left = x[:stitch_idx + 1]
    y_left = y[:stitch_idx + 1]

    x_right = x[stitch_idx:]
    y_right = y[stitch_idx:]

    hermite_fn = hermite_rt_interp(x_right, y_right, val_date)

    def _linear_rt(t):
        if t <= x_left[0]:
            return float(y_left[0])
        if t >= x_left[-1]:
            return float(y_left[-1])
        i = np.searchsorted(x_left, t) - 1
        i = np.clip(i, 0, len(x_left) - 2)
        t0, t1 = x_left[i], x_left[i + 1]
        r0, r1 = y_left[i], y_left[i + 1]
        rt0 = r0 * (t0 - val_date)
        rt1 = r1 * (t1 - val_date)
        rt_interp = rt0 + (rt1 - rt0) * (t - t0) / (t1 - t0)
        if t - val_date == 0:
            return float(y_left[0])
        return float(rt_interp / (t - val_date))
    
    def interpolate(t):
        if isinstance(t, (list, np.ndarray)):
            return np.array([interpolate(float(tt)) for tt in t])
        
        t = float(t)
        t_stitch = x[stitch_idx]

        if t <= t_stitch:
            return _linear_rt(t)
        else:
            return float(hermite_fn(t))
        
    return interpolate
