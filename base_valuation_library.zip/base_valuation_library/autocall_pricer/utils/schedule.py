import QuantLib as ql
import pandas as pd
from datetime import date


def generate_cds_cashflow_schedule(
    trade_date: date,
    maturity_date: date,
    valuation_date: date = None,
    tenor_months: int = 3,
    calendar: str = "TARGET",
    business_convention: str = "Following",
    date_generation: str = "CDS",
    day_count: str = "ACT/365",
    pay_tenor_alignment: bool = True,
    extend_final_period_by_one_day: bool = False,
    fixed_rate: float = None,
    nominal: float = None,
) -> pd.DataFrame:
    """
    Generates CDS cashflow schedule using QuantLib.

    Parameters:
        trade_date: Trade date.
        maturity_date: CDS maturity date.
        valuation_date: Optional valuation date for filtering past periods.
        tenor_months: Coupon tenor in months (default 3).
        calendar: Calendar name (e.g. 'TARGET', 'UnitedStates').
        business_convention: Business day convention (default 'Following').
        date_generation: Schedule rule (default 'CDS').
        day_count: Day count convention (default 'ACT/365').
        pay_tenor_alignment: Aligns start to IMM date (default True).
        extend_final_period_by_one_day: Adds 1-day to final period (default False).
        fixed_rate: Optional fixed coupon rate.
        nominal: Optional notional amount.

    Returns:
        DataFrame with columns: 'AccrualStart', 'AccrualEnd', 'PayDate', 'DaysInPeriod', 'YearFrac'.
        If fixed_rate and nominal provided, adds 'Rate' and 'CashPayment'.
    """

    ql_calendar = getattr(ql, calendar)()
    ql_convention = getattr(ql, business_convention)
    ql_rule = getattr(ql.DateGeneration, date_generation)
    daycount_map = {
        "ACT/360": ql.Actual360(),
        "ACT/365": ql.Actual365Fixed(),
        "ACT/365F": ql.Actual365Fixed(),
        "ACT/ACT": ql.ActualActual(ql.ActualActual.ISDA),
        "30/360": ql.Thirty360(ql.Thirty360.BondBasis),
    }
    ql_daycount = daycount_map.get(day_count, ql.Actual360())

    start_date = ql.Date(trade_date.day, trade_date.month, trade_date.year)
    end_date = ql.Date(maturity_date.day, maturity_date.month, maturity_date.year)
    tenor = ql.Period(tenor_months, ql.Months)

    if pay_tenor_alignment:
        start_date = ql.IMM.nextDate(start_date, False)
        if start_date > end_date:
            raise ValueError("Start date beyond maturity after IMM alignment.")

    schedule = ql.Schedule(
        start_date,
        end_date,
        tenor,
        ql_calendar,
        ql_convention,
        ql_convention,
        ql_rule,
        False
    )

    start_dates = []
    end_datess = []
    pay_dates = []
    year_fracs = []
    days_in_period = []

    for i in range(len(schedule) - 1):
        accrual_start = schedule[i]
        end_dates = schedule[i + 1]
        pay_date = ql_calendar.adjust(end_dates, ql_convention)
        year_frac = ql_daycount.yearFraction(accrual_start, end_dates)
        num_days = end_dates - accrual_start
        start_dates.append(ql_to_datetime(accrual_start))
        end_datess.append(ql_to_datetime(end_dates))
        pay_dates.append(ql_to_datetime(pay_date))
        year_fracs.append(year_frac)
        days_in_period.append(num_days)

    df = pd.DataFrame({
        "AccrualStart": start_dates,
        "AccrualEnd": end_datess,
        "PayDate": pay_dates,
        "DaysInPeriod": days_in_period,
        "YearFrac": year_fracs
    })

    if extend_final_period_by_one_day and len(df) > 0:
        from datetime import timedelta
        df.loc[df.index[-1], "AccrualEnd"] = df.iloc[-1]["AccrualEnd"] + timedelta(days=1)
        last_accrual_start = df.iloc[-1]["AccrualStart"]
        last_end_dates = df.iloc[-1]["AccrualEnd"]
        ql_accrual_start = ql.Date(last_accrual_start.day, last_accrual_start.month, last_accrual_start.year)
        ql_end_dates = ql.Date(last_end_dates.day, last_end_dates.month, last_end_dates.year)
        df.loc[df.index[-1], "DaysInPeriod"] = ql_end_dates - ql_accrual_start
        df.loc[df.index[-1], "YearFrac"] = ql_daycount.yearFraction(ql_accrual_start, ql_end_dates)

    if valuation_date is not None:
        df = df[df["AccrualEnd"] >= valuation_date].reset_index(drop=True)

    if fixed_rate is not None and nominal is not None:
        df["Rate"] = fixed_rate
        df["CashPayment"] = nominal * fixed_rate * df["YearFrac"]

    return df


def ql_to_datetime(qdate: ql.Date) -> date:
    """Converts QuantLib Date to Python date."""
    return date(qdate.year(), qdate.month(), qdate.dayOfMonth())



