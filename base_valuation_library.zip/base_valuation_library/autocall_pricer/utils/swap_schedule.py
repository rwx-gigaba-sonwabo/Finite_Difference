import pandas as pd
from datetime import date
from dateutil.relativedelta import relativedelta
from autocall_pricer.curve.discount_curve import DiscountYieldCurveHandler
from autocall_pricer.utils.schedule import ql_to_datetime
import QuantLib as ql

def compute_daily_ois_factor(
    curve: DiscountYieldCurveHandler,
    start_date: date,
    end_date: date,
    calendar: str = "TARGET",
) -> float:
    """
    Computes the OIS compounded cashflow factor by stepping through each business day.

    For each business day i the overnight rate accrues over the calendar days until the
    next business day (covering weekends and holidays). The daily contribution is:
        factor_i = DF(t_i) / DF(t_next_business_day)

    Multiplying these together gives the total compounded return:
        Π(factor_i) - 1 = DF(start) / DF(end) - 1  for a smooth curve, but explicitly
    captures kinks or step-shaped curves (e.g. around central-bank meeting dates).

    Parameters:
        curve: Discount curve used for DF lookups.
        start_date: Start of the compounding period (must be a business day).
        end_date: End of the compounding period (must be a business day).
        calendar: QuantLib calendar name (default 'TARGET').

    Returns:
        Compounded cashflow factor: Π(DF_i / DF_{i+1}) - 1.
    """
    if "." in calendar:
        parts = calendar.split(".")
        calendar_class = getattr(ql, parts[0])
        market = getattr(calendar_class, parts[1])
        ql_calendar = calendar_class(market)
    else:
        ql_calendar = getattr(ql, calendar)()

    current_ql = ql.Date(start_date.day, start_date.month, start_date.year)
    end_ql = ql.Date(end_date.day, end_date.month, end_date.year)

    compound_factor = 1.0

    while current_ql < end_ql:
        # Advance by 1 calendar day then adjust to next business day.
        # This naturally handles weekends (Fri → Mon, 3 days) and holidays.
        next_ql = ql_calendar.advance(current_ql, 1, ql.Days, ql.Following)
        if next_ql > end_ql:
            next_ql = end_ql

        current_py = date(current_ql.year(), current_ql.month(), current_ql.dayOfMonth())
        next_py = date(next_ql.year(), next_ql.month(), next_ql.dayOfMonth())

        df_current = curve.get_discount_factor_for_date(current_py)
        df_next = curve.get_discount_factor_for_date(next_py)
        compound_factor *= df_current / df_next

        current_ql = next_ql

    return compound_factor - 1.0


def prev_business_day(target_date: date, calendar: str = "TARGET") -> date:
    """Returns the business day immediately preceding target_date."""
    if "." in calendar:
        parts = calendar.split(".")
        calendar_class = getattr(ql, parts[0])
        market = getattr(calendar_class, parts[1])
        ql_calendar = calendar_class(market)
    else:
        ql_calendar = getattr(ql, calendar)()
    ql_date = ql.Date(target_date.day, target_date.month, target_date.year)
    prev = ql_date - 1
    prev = ql_calendar.adjust(prev, ql.Preceding)
    return date(prev.year(), prev.month(), prev.dayOfMonth())


def iter_overnight_periods(
    start_date: date,
    end_date: date,
    calendar: str = "TARGET",
) -> list:
    """
    Returns a list of (period_start, period_end) date pairs, one per overnight period,
    stepping through business days from start_date up to (but not including) end_date.

    Weekends and holidays are handled by QuantLib: a Friday period runs to Monday,
    giving three calendar days of accrual for that overnight rate.
    """
    if "." in calendar:
        parts = calendar.split(".")
        calendar_class = getattr(ql, parts[0])
        market = getattr(calendar_class, parts[1])
        ql_calendar = calendar_class(market)
    else:
        ql_calendar = getattr(ql, calendar)()

    current_ql = ql.Date(start_date.day, start_date.month, start_date.year)
    end_ql = ql.Date(end_date.day, end_date.month, end_date.year)

    periods = []
    while current_ql < end_ql:
        next_ql = ql_calendar.advance(current_ql, 1, ql.Days, ql.Following)
        if next_ql > end_ql:
            next_ql = end_ql
        d_start = date(current_ql.year(), current_ql.month(), current_ql.dayOfMonth())
        d_end = date(next_ql.year(), next_ql.month(), next_ql.dayOfMonth())
        periods.append((d_start, d_end))
        current_ql = next_ql

    return periods


def add_forward_rates_to_schedule(
    schedule: pd.DataFrame,
    curve: DiscountYieldCurveHandler,
    frequency: int,
    calendar: str = "TARGET",
    business_convention: str = "Following",
    use_schedule_end_date: bool = True,
    start_col: str = "StartDate",
    end_col: str = "EndDate",
    year_frac_col: str = "YearFrac",
    day_count: str = "ACT/365",
    compounding: bool = False
) -> pd.DataFrame:
    """
    Adds forward rate column to swap schedule.

    Parameters:
        schedule: DataFrame with swap schedule.
        curve: Discount curve for forward rate calculation.
        frequency: Payment frequency in months.
        calendar: QuantLib calendar name (default 'TARGET').
        business_convention: Business day convention (default 'Following').
        use_schedule_end_date: Use schedule end dates if True, calculate with QuantLib if False.
        start_col: Column name for start dates (default 'StartDate').
        end_col: Column name for end dates (default 'EndDate').
        year_frac_col: Column name for year fractions (default 'YearFrac').

    Returns:
        Schedule with additional 'ForwardRate' column.




    """
    schedule = schedule.copy()

    forward_rates = []

    if use_schedule_end_date:
        for _, row in schedule.iterrows():
            start_date = row[start_col]
            end_date = row[end_col]
            if compounding:
                ois_factor = compute_daily_ois_factor(
                    curve, start_date, end_date, calendar
                )
                forward_rate = ois_factor / row[year_frac_col]
            else:
                forward_rate = curve.get_simple_forward(start_date, end_date)
            forward_rates.append(forward_rate)
    else:
        # Calculate end dates using Quantlib
        # Handle calendars with markets (e.g. UnitedStates.Settlement)
        if "." in calendar:
            parts = calendar.split(".")
            calendar_class = getattr(ql, parts[0])
            market = getattr(calendar_class, parts[1])
            ql_calendar = calendar_class(market)
        else:
            ql_calendar = getattr(ql, calendar)()

        ql_convention = getattr(ql, business_convention)
        tenor = ql.Period(frequency, ql.Months)

        for _, row in schedule.iterrows():
            start_date = row[start_col]

            #
            ql_start_date = ql.Date(start_date.day, start_date.month, start_date.year)
            
            #
            ql_end_date = ql_start_date + tenor
            
            #
            ql_end_date = ql_calendar.adjust(ql_end_date, ql_convention)
            
            #
            end_date = ql_to_datetime(ql_end_date)
            
            forward_rate = curve.get_simple_forward(start_date, end_date)
            forward_rates.append(forward_rate)

    schedule["ForwardRate"] = forward_rates
    return schedule


def add_floating_cashflows(
    schedule: pd.DataFrame,
    notional: float,
    forward_rate_col: str = "ForwardRate",
    year_frac_col: str = "YearFrac"
) -> pd.DataFrame:
    """
    Adds floating cashflow column to swap schedule.

    Parameters:
        schedule: DataFrame with forward rates and year fractions.
        notional: Notional amount.
        forward_rate_col: Column name for forward rates (default 'ForwardRate').
        year_frac_col: Column name for year fractions (default 'YearFrac').

    Returns:
        Schedule with additional 'Cashflow' column.
    
    
    """
    schedule = schedule.copy()
    schedule["Cashflow"] = notional * schedule[year_frac_col] * schedule[forward_rate_col]
    return schedule


def generate_swap_leg_schedule(
    effective_date: date,
    maturity_date: date,
    valuation_date: date = None,
    payment_frequency: int = 6,
    payment_offset: int = 0,
    calendar: str = "TARGET",
    business_convention: str = "ModifiedFollowing",
    termination_business_convention: str = "ModifiedFollowing",
    date_generation: str = "Backward",
    day_count: str = "ACT/365",
    end_of_month: bool = False,
) -> pd.DataFrame:
    """
    Generates swap leg schedule using QuantLib.

    Parameters:
        effective_date: Swap start date.
        maturity_date: Swap end date.
        valuation_date: Optional valuation date for filtering past periods.
        payment_frequency: Payment frequency in months (default 6).
        calendar: Calendar name (default 'TARGET').
        business_convention: Business day convention (default 'ModifiedFollowing').
        termination_business_convention: Termination business convention (default 'ModifiedFollowing').
        date_generation: Schedule rule (default 'Backward').
        day_count: Day count convention (default 'ACT/365').
        end_of_month: End of month convention (default False).

    Returns:
        DataFrame with columns: 'StartDate', 'EndDate', 'PayDate', 'DaysInPeriod', 'YearFrac'.
   
    """

    #handle calendars with markets (e.g., "UnitedStates.Settlement")
    if "." in calendar:
        parts = calendar.split(".")
        calendar_class = getattr(ql, parts[0])
        market = getattr(calendar_class, parts[1])
        ql_calendar = calendar_class(market)
    else:
        ql_calendar = getattr(ql, calendar)()
    ql_convention = getattr(ql, business_convention)
    ql_term_convention = getattr(ql, termination_business_convention)
    ql_rule = getattr(ql.DateGeneration, date_generation)

    # map day count conventions to QuantLib classes
    daycount_map = {
        "ACT/360": ql.Actual360(),
        "ACT/365": ql.Actual365Fixed(),
        "ACT/365F": ql.Actual365Fixed(),
        "ACT/ACT": ql.ActualActual(ql.ActualActual.ISDA),
        "30/360": ql.Thirty360(ql.Thirty360.BondBasis),
    }
    ql_daycount = daycount_map.get(day_count, ql.Actual360())

    start_date = ql.Date(effective_date.day, effective_date.month, effective_date.year)
    end_date = ql.Date(maturity_date.day, maturity_date.month, maturity_date.year)
    tenor = ql.Period(payment_frequency, ql.Months)

    schedule = ql.Schedule(
        start_date,
        end_date,
        tenor,
        ql_calendar,
        ql_convention,
        ql_term_convention,
        ql_rule,
        end_of_month
    )

    start_dates = []
    end_dates = []
    pay_dates = []
    year_fracs = []
    days_in_period = []

    for i in range(len(schedule) - 1):
        accrual_start = schedule[i]
        accrual_end = schedule[i + 1]
        #pay_date = ql_calendar.adjust(accrual_end, ql_convention)
        pay_date = ql_calendar.advance(accrual_end, payment_offset, ql.Days, ql_convention)
        year_frac = float((accrual_end - accrual_start) / 365.0) if day_count == "ACT/365" else ql_daycount.yearFraction(accrual_start, accrual_end)
        num_days = accrual_end - accrual_start
        start_dates.append(ql_to_datetime(accrual_start))
        end_dates.append(ql_to_datetime(accrual_end))
        pay_dates.append(ql_to_datetime(pay_date))
        year_fracs.append(year_frac) 
        days_in_period.append(num_days)

    df = pd.DataFrame({
        "StartDate": start_dates,
        "EndDate": end_dates,
        "PayDate": pay_dates,
        "DaysInPeriod": days_in_period,
        "YearFrac": year_fracs
    })

    if valuation_date is not None:
        df = df[df["EndDate"] >= valuation_date].reset_index(drop=True)

    return df
