import json

def pull_4d_IR_vol_surface(filepath, surface_name):
    #pulls data from trade json file
    with open(filepath) as f:
        data = json.load(f)

    # Navigate to Price Factors and pick the curve by its name
    factors = (data.get('Calc', {})
                   .get('MergeMarketData', {})
                   .get('ExplicitMarketData', {})
                   .get('Price Factors', {}))

    curve_item = factors.get(surface_name, {})
    # Extract the data list: Curve -> .Curve -> meta/data
    surface_data = (curve_item.get('Surface', {})
                              .get('.Curve', {})
                              .get('data', []))
    return surface_data