"""
Base instrument class for derivatives pricing.

Provides abstract base class for all financial instruments with standardised
interface for pricing, cashflows, and market data dependencies.
"""

from abc import ABC, abstractmethod
from datetime import date
from typing import Dict, Any, Optional
import pandas as pd


class Instrument(ABC):
    """
    Abstract base class for financial instruments.

    Defines standard interface for instruments (swaps, options, CDS, etc.).
    All pricing is done as of a specific valuation_date with automatic filtering
    for future cashflows.
    """

    @abstractmethod
    def price(self, valuation_date: date, market_data: Optional['MarketData'] = None) -> float:
        """
        Calculate present value of the instrument as of valuation date.

        Args:
            valuation_date: Date as of which to calculate PV.
            market_data: MarketData object for pricing. If None, uses internally stored data.

        Returns:
            Present value in base currency (positive = asset, negative = liability).
        """
        pass

    @abstractmethod
    def get_cashflows(self, valuation_date: date) -> pd.DataFrame:
        """
        Return all future cashflows from valuation_date forward.

        Args:
            valuation_date: Date as of which to extract future cashflows.

        Returns:
            DataFrame with columns: 'payment_date', 'amount', 'leg' (minimum).
            Optional columns: 'currency', 'cashflow_type', 'start_date', 'end_date',
            'notional', 'rate', 'day_count_fraction'.
        """
        pass

    @abstractmethod
    def get_market_dependencies(self) -> Dict[str, Any]:
        """
        Return market data dependencies required for pricing.

        Returns:
            Dictionary with keys: 'discount_curve', 'forward_curves', 'fx_rates',
            'vol_surfaces', 'credit_curves', 'hazard_curves', 'other'.
        """
        pass

    def __repr__(self) -> str:
        """String representation of the instrument."""
        return f"{self.__class__.__name__}()"

    def validate(self) -> bool:
        """
        Validate instrument parameters.

        Returns:
            True if valid, False otherwise.
        """
        return True
