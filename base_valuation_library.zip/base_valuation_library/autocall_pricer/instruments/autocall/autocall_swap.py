"""
AutocallSwap, independent autocallable-swap instrument (validation reference).

Holds the full term sheet and builds the observation-date schedule that
both the Monte Carlo engine (models/) and the payoff evaluator (payoff.py) consume.
Subclasses the project's base Instrument ABC.

Pricing flow:
    swap.build_schedule(valuation_date, eq_market_data) -> PayoffSchedule (static per-date data)
    engine.simulate(schedule, eq_market_data)           -> spot_paths  [n_paths, n_obs]
    evaluate_autocall_paths(spot_paths, **schedule.payoff_kwargs())
The engine is injected at price() time so this class stays independent of the numerics.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from autocall_pricer.instruments.base.instrument import Instrument

class AutocallExpired(Exception):
    """The note already called on a coupon behind the valuation date.
    Such a trade has ended,
    so it has a value of zero. `called_on` is that coupon's date."""

    def __init__(self, called_on: date, level: float, trigger: float):
        self.called_on, self.level, self.trigger = called_on, level, trigger
        super().__init__(f"autocalled on {called_on}: its window printed {level:g} against the "
                         f"trigger {trigger:g}, so the trade has ended, "
                         f"value 0")


# payoff_type values
VANILLA, QUANTO, COMPO = "Vanilla", "Quanto", "Compo"
# autocall trigger direction
CALL, PUT = "Call", "Put"


@dataclass
class PayoffSchedule:
    """
    Static (non-simulated) per-observation-date data for one valuation.

    obs_dates / obs_times are the merged, sorted, future-only observation grid the engine
    simulates spot on. The boolean masks and per-date arrays line up with obs_times and are
    passed straight into evaluate_autocall_paths.
    """

    obs_dates: List[date]
    obs_times: np.ndarray          # [n_obs] year fractions from valuation date
    is_coupon_date: np.ndarray     # [n_obs] bool
    is_barrier_date: np.ndarray    # [n_obs] bool
    is_float_date: np.ndarray      # [n_obs] bool
    thresholds: np.ndarray         # [n_obs]
    coupons: np.ndarray            # [n_obs]
    float_payments: np.ndarray     # [n_obs]
    discount_factors: np.ndarray   # [n_obs] to each observation date (floating + terminal legs)
    coupon_discount_factors: Optional[np.ndarray]  # [n_obs] to coupon PAYMENT dates; None = no lag
    strike: float
    put_barrier: float
    rebate: float
    fx: float
    barrier_already_hit: bool
    autocall_phi: float            # +1 call (S >= H), -1 put (S <= H)
    terminal_mode: str = "economic"  # "economic" | "per_barrier_date", see payoff.py
    # [n_obs] int: the grid column whose spot a row's decision (autocall trigger, put barrier)
    # READS. None = every row reads its own column. A coupon booked with a payment date after its
    # fixing is DECIDED on the fixing's spot but APPLIED on its payment-date row, see AutocallSwap.build_schedule.
    observation_index: Optional[np.ndarray] = None
    # [n_obs] float: the PRINTED level a row's decisions read where its fixing is on or before the
    # valuation date (NaN elsewhere). The decision on a printed level is exact, no step
    observed_levels: Optional[np.ndarray] = None

    @property
    def n_obs(self) -> int:
        return len(self.obs_dates)

    @property
    def obs_index(self) -> np.ndarray:
        """``observation_index``, or the identity where every row reads its own column."""
        if self.observation_index is None:
            return np.arange(self.n_obs)
        return np.asarray(self.observation_index, dtype=int)

    @property
    def trigger_observation_dates(self) -> List[date]:
        """The dates each still-SIMULATED autocall decision reads its spot on, in coupon order,
        a coupon whose fixing has already printed reads no grid date and is left out."""
        live = np.asarray(self.is_coupon_date, dtype=bool) & ~self.observed_mask
        return [self.obs_dates[i] for i in self.obs_index[live]]

    @property
    def observed_mask(self) -> np.ndarray:
        """[n_obs] bool: the rows decided on a printed level rather than a simulated column."""
        if self.observed_levels is None:
            return np.zeros(self.n_obs, dtype=bool)
        return np.isfinite(np.asarray(self.observed_levels, dtype=float))

    def payoff_kwargs(self) -> Dict[str, Any]:
        """Keyword args for evaluate_autocall_paths (everything except spot_paths)."""
        return dict(
            is_coupon_date=self.is_coupon_date,
            is_barrier_date=self.is_barrier_date,
            is_float_date=self.is_float_date,
            thresholds=self.thresholds,
            coupons=self.coupons,
            float_payments=self.float_payments,
            discount_factors=self.discount_factors,
            coupon_discount_factors=self.coupon_discount_factors,
            strike=self.strike,
            put_barrier=self.put_barrier,
            rebate=self.rebate,
            fx=self.fx,
            barrier_already_hit=self.barrier_already_hit,
            autocall_phi=self.autocall_phi,
            terminal_mode=self.terminal_mode,
            observation_index=self.observation_index,
            observed_levels=self.observed_levels,
        )


@dataclass
class AutocallSwap(Instrument):
    """
    Autocallable equity swap (see docs/autocall_swap.md).

    Schedules:
        coupon_schedule: [(obs_date, coupon, threshold_multiplier[, pay_date[, printed]]), ...]
                         The autocall dates. With a pay_date the coupon is decided on obs_date's
                         spot and applied (paid, deal ended) on pay_date, see build_schedule.
                         `printed` is the Price_Fixing level, read once obs_date is behind the
                         valuation date: a called past coupon expires the deal, an unpaid one
                         is decided on it.
        barrier_dates:   [obs_date, ...], put-barrier observation dates; one dated on a coupon's
                         obs_date is observed there and flagged on that coupon's pay_date row.
        float_schedule:  [(pay_date, amount), ...], deterministic floating leg (curve-based
                         floating is added in a later phase); amount is per unit notional.
    Levels:
        strike:      reference level K.
        put_barrier: absolute knock-in level H_put (use from_barrier_pct to set as % of K).
        rebate:      R.
    Rebate / barrier convention:
        terminal_mode: "economic" (default): rebate added to
            every autocall coupon AND paid unconditionally to every survivor (minus a latched
            knock-in loss).
            "per_barrier_date": bare coupon (no
            rebate), and the put payoff fires per flagged barrier date (not latched), gated by
            breach, with no unconditional survivor payment. See payoff.py's module docstring
            for the full term-by-term comparison.
    Notional & FX:
        buy_sell:    +1 buy, -1 sell.
        units:       notional multiplier (N = buy_sell * units).
        payoff_type: Vanilla | Quanto | Compo.
        fix_fx_rate: fixed conversion rate for Quanto payoffs.
        barrier_already_hit: BarrierIsHit, knock-in latched before valuation.
    """

    strike: float
    coupon_schedule: List[Tuple[date, float, float]]
    put_barrier: float = 0.0
    barrier_dates: List[date] = field(default_factory=list)
    float_schedule: List[Tuple[date, float]] = field(default_factory=list)
    rebate: float = 0.0
    buy_sell: int = 1
    units: float = 1.0
    payoff_type: str = VANILLA
    autocall_type: str = CALL   # CALL: autocall when S >= threshold; PUT: when S <= threshold
    fix_fx_rate: float = 1.0
    barrier_already_hit: bool = False
    terminal_mode: str = "economic"   # "economic" | "per_barrier_date", see class docstring

    # ------------------------------------------------------------ constructors
    @classmethod
    def from_barrier_pct(cls, strike: float, barrier_pct: float, **kwargs) -> "AutocallSwap":
        """Build with the put barrier expressed as a fraction of strike."""
        return cls(strike=strike, put_barrier=barrier_pct * strike, **kwargs)

    # -------------------------------------------------------------- properties
    @property
    def notional(self) -> float:
        return self.buy_sell * self.units

    @property
    def fx_factor(self) -> float:
        """Fixed conversion factor phi. Compo forward-scaling is engine-side."""
        return self.fix_fx_rate if self.payoff_type == QUANTO else 1.0

    @property
    def autocall_phi(self) -> float:
        """Trigger direction: +1 call (S >= threshold), -1 put (S <= threshold)."""
        return 1.0 if self.autocall_type == CALL else -1.0

    # ---------------------------------------------------------- schedule build
    def build_schedule(self, valuation_date: date, market_data) -> PayoffSchedule:
        """
        Merge coupon/barrier/float dates into one sorted future-only observation grid and
        produce the per-date arrays payoff.py needs. Discount factors come from
        market_data.df(t); the final observation date is treated as maturity T.
        """
        # coupon_schedule entries are (obs_date, coupon, threshold) or, with a payment date,
        # (obs_date, coupon, threshold, pay_date). The coupon WINDOW
        #:
        # the coupon is DECIDED on the obs_date's spot but APPLIED, paid, the deal ended, on
        # its pay_date row, so a floating payment dated between the two is still paid by a deal
        # that calls. The pay_date row therefore carries the coupon and reads the obs_date's
        # column through `observation_index`; the obs_date is a grid column of its own.
        events = {}                     # event (pay) date -> (coupon, threshold, obs date, printed)
        for entry in self.coupon_schedule:
            obs, c, th = entry[0], entry[1], entry[2]
            pay = entry[3] if len(entry) > 3 else obs
            printed = entry[4] if len(entry) > 4 else None
            if pay < obs:
                raise ValueError(f"coupon paid on {pay} before the fixing {obs} it is decided on")
            if pay in events:
                raise ValueError(f"two coupons are applied on the same date {pay}")
            events[pay] = (c, th, obs, printed)
        # A barrier dated on a coupon's fixing names that coupon, observed on the
        # fixing, flagged (and paid) on the coupon's row
        event_of_obs = {obs: pay for pay, (_, _, obs, _) in events.items()}
        barrier_set = {event_of_obs.get(d, d) for d in self.barrier_dates}
        floats_by_date = {d: a for d, a in self.float_schedule}

        def called(level, th):
            # called when the window's level is AT or beyond threshold * strike
            return self.autocall_phi * (level - th * self.strike) >= 0.0

        # A COUPON BEHIND THE VALUATION DATE THAT CALLED ended the note
        # (AutocallExpired is raised): its printed window decides
        # it, the first such coupon wins
        for pay in sorted(events):
            c, th, obs, printed = events[pay]
            if pay >= valuation_date:
                break
            if printed is not None and called(printed, th):
                raise AutocallExpired(pay, printed, th * self.strike)

        # A FIXING PRINTED, ITS COUPON NOT YET PAID: decided on the print, an exact 0/1. A
        # fixing before the row is read off Price_Fixing and one ON it is the row's own spot
        observed = {}
        for pay, (c, th, obs, printed) in events.items():
            if obs <= valuation_date < pay:
                if obs == valuation_date:
                    printed = float(market_data.spot)
                elif printed is None:
                    raise NotImplementedError(
                        f"the coupon paid on {pay} was decided on the fixing of {obs}, before the "
                        f"valuation date {valuation_date}, and no printed level is carried, "
                        f"load the deal with load_autocall_swap, which reads Price_Fixing")
                elif printed == 0.0:
                    warnings.warn(f"the fixing of {obs} is behind the valuation date and printed "
                                  f"0.0, read as a level of 0 (it logs "
                                  f"'past fixing set to 0')")
                observed[pay] = float(printed)
            elif pay == valuation_date and obs <= valuation_date:
                raise NotImplementedError(
                    f"the coupon paid on {pay} falls ON the valuation date, its cash is today's "
                    f"settlement; value the day before or after")

        all_dates = sorted(
            d for d in set(events) | {e[2] for e in events.values()} | barrier_set
            | set(floats_by_date) if d > valuation_date
        )
        if not all_dates:
            raise ValueError("no future observation dates after valuation_date")

        n = len(all_dates)
        column = {d: j for j, d in enumerate(all_dates)}
        is_coupon = np.zeros(n, dtype=bool)
        is_barrier = np.zeros(n, dtype=bool)
        is_float = np.zeros(n, dtype=bool)
        thresholds = np.zeros(n)
        coupons = np.zeros(n)
        float_pmts = np.zeros(n)
        obs_times = np.empty(n)
        dfs = np.empty(n)
        obs_index = np.arange(n)
        levels = np.full(n, np.nan)

        for j, d in enumerate(all_dates):
            t = market_data.yearfrac(d)
            obs_times[j] = t
            dfs[j] = market_data.df(t)
            if d in events:
                is_coupon[j] = True
                coupons[j], thresholds[j], obs, _ = events[d]
                if d in observed:
                    levels[j] = observed[d]          # printed: no column to read
                else:
                    obs_index[j] = column[obs]
            if d in barrier_set:
                is_barrier[j] = True
            if d in floats_by_date:
                is_float[j] = True
                float_pmts[j] = floats_by_date[d]

        lagged = bool((obs_index != np.arange(n)).any())
        return PayoffSchedule(
            obs_dates=all_dates,
            obs_times=obs_times,
            is_coupon_date=is_coupon,
            is_barrier_date=is_barrier,
            is_float_date=is_float,
            thresholds=thresholds,
            coupons=coupons,
            float_payments=float_pmts,
            # the coupon's row IS its payment date, so the row's own discount factor is the one
            discount_factors=dfs,
            coupon_discount_factors=None,
            strike=self.strike,
            put_barrier=self.put_barrier,
            rebate=self.rebate,
            fx=self.fx_factor,
            barrier_already_hit=self.barrier_already_hit,
            autocall_phi=self.autocall_phi,
            terminal_mode=self.terminal_mode,
            observation_index=obs_index if lagged else None,
            observed_levels=levels if np.isfinite(levels).any() else None,
        )

    # ------------------------------------------------------- Instrument API
    def price(self, valuation_date: date, market_data=None, engine=None) -> float:
        """
        Present value = notional * MC payoff. Requires a Monte Carlo `engine` (models/)
        Phase 3) exposing simulate(schedule, market_data) -> spot_paths [n_paths, n_obs].
        """
        if market_data is None or engine is None:
            raise NotImplementedError(
                "AutocallSwap.price requires market_data and a Monte Carlo engine "
                "(models/). Use build_schedule + evaluate_autocall_paths directly "
                "when no engine is given."
            )
        from autocall_pricer.instruments.autocall.payoff import evaluate_autocall_paths

        schedule = self.build_schedule(valuation_date, market_data)
        spot_paths = engine.simulate(schedule, market_data)
        result = evaluate_autocall_paths(spot_paths, **schedule.payoff_kwargs())
        return self.notional * result.pv

    def get_cashflows(self, valuation_date: date) -> pd.DataFrame:
        """
        Contingent cashflow schedule (undiscounted, per unit notional). Amounts are the
        maximum/eventual payments, actual receipt is path-dependent (autocall/barrier).
        """
        rows = []
        for entry in self.coupon_schedule:
            d, c, th = entry[0], entry[1], entry[2]      # entry may be 3- or 4-tuple (with pay date)
            pay = entry[3] if len(entry) > 3 else d
            if d > valuation_date:
                rows.append(dict(payment_date=pay, amount=self.rebate + c, leg="autocall",
                                 cashflow_type="coupon+rebate", rate=th))
        for d, a in self.float_schedule:
            if d > valuation_date:
                rows.append(dict(payment_date=d, amount=-a, leg="floating",
                                 cashflow_type="float", rate=np.nan))
        return pd.DataFrame(rows).sort_values("payment_date").reset_index(drop=True) \
            if rows else pd.DataFrame(columns=["payment_date", "amount", "leg"])

    def get_market_dependencies(self) -> Dict[str, Any]:
        deps: Dict[str, Any] = {
            "discount_curve": True,
            "forward_curves": ["repo", "dividend"],
            "vol_surfaces": ["equity"],
            "fx_rates": [],
            "other": [],
        }
        if self.payoff_type in (QUANTO, COMPO):
            deps["fx_rates"] = ["equity_fx"]
            deps["vol_surfaces"].append("fx")
            deps["other"].append("corr_equity_fx")
        return deps

    def validate(self) -> bool:
        if not self.coupon_schedule:
            raise ValueError("coupon_schedule is empty")
        if self.strike <= 0:
            raise ValueError("strike must be positive")
        if self.put_barrier < 0:
            raise ValueError("put_barrier must be non-negative")
        if self.terminal_mode not in ("economic", "per_barrier_date"):
            raise ValueError(
                f"terminal_mode must be 'economic' or 'per_barrier_date', got {self.terminal_mode!r}")
        if self.payoff_type not in (VANILLA, QUANTO, COMPO):
            raise ValueError(f"unknown payoff_type {self.payoff_type!r}")
        if self.autocall_type not in (CALL, PUT):
            raise ValueError(f"autocall_type must be {CALL!r} or {PUT!r}")
        if self.buy_sell not in (1, -1):
            raise ValueError("buy_sell must be +1 or -1")
        return True
