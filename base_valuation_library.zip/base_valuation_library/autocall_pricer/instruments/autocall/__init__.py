"""Autocallable swap: the instrument, its payoff and its booked put leg."""

from .autocall_swap import COMPO, QUANTO, VANILLA, AutocallSwap, PayoffSchedule
from .compare import Comparison, compare, compare_manual_result
from .manual_pricer import ManualAutocallInputs, ManualResult, price_manual
from .payoff import PayoffResult, evaluate_autocall_paths
from .put_leg import (
    PutLegBooking,
    PutLegResult,
    check_swap_against_booking,
    load_put_leg_booking,
    price_put_leg,
    print_put_leg_report,
    without_put,
)
from .trade_file_loader import CurveData, load_autocall_swap, load_curve, load_vol_surface

__all__ = [
    "AutocallSwap", "PayoffSchedule", "PayoffResult", "evaluate_autocall_paths",
    "ManualAutocallInputs", "ManualResult", "price_manual",
    "Comparison", "compare", "compare_manual_result",
    "CurveData", "load_curve", "load_vol_surface", "load_autocall_swap",
    "PutLegBooking", "PutLegResult", "load_put_leg_booking", "price_put_leg", "without_put",
    "check_swap_against_booking", "print_put_leg_report",
    "VANILLA", "QUANTO", "COMPO",
]
