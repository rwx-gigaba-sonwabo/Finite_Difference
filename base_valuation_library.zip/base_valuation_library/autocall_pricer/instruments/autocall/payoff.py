"""Payoff of an autocallable swap on simulated equity paths.

The function takes the simulated equity price on each observation date and works out, path
by path, what the swap pays. Every event is a plain yes or no on that path. The value is the
average of the discounted payments over all paths.

Events on each observation date, in date order
----------------------------------------------
Autocall
    The swap is called when the price is at or above ``threshold * strike``. The coupon of
    that date is paid and the swap ends on that path.
Floating payment
    Paid on its date for as long as the swap has not been called.
Put barrier
    Checked on the flagged barrier dates of a path that is still alive.

Two conventions for the rebate and the put (``terminal_mode``)
--------------------------------------------------------------
"economic" (default)
    The rebate is added to every autocall coupon and is paid at the final date on every
    path that was never called. A path that touched the put barrier on any barrier date
    loses ``1 - S_T / strike`` at the final date. The touch is remembered once it happens.
"per_barrier_date"
    The coupon is paid without the rebate. On each flagged barrier date, a path that is
    still alive and is below the barrier on that date receives
    ``rebate - (1 - S_j / strike)``, discounted from that date. Nothing is remembered from
    one barrier date to the next and nothing extra is paid to paths that never breach.
    ``barrier_already_hit`` has no effect in this mode.

Two entry points
----------------
``evaluate_autocall_paths`` returns the averages: the value, its standard error and the
value of each leg.

``payoff_per_path`` returns the same amounts for each path. It can also be told which rows
are already settled. A settled row still decides whether the swap was called or the barrier
was touched, but it adds no value.

All amounts are per unit of notional. The caller multiplies by the notional.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

# Marker used in the schedules for "this date is not an X date".
NOT_A_DATE = -1.0


@dataclass
class PayoffResult:
    """Outcome of a Monte Carlo payoff evaluation."""

    pv: float               # mean discounted payoff per unit notional (before N scaling)
    std_error: float        # Monte Carlo standard error of `pv`
    n_paths: int
    # per-leg decomposition (mean discounted, per unit notional) for diagnostics
    autocall_leg: float
    terminal_leg: float     # terminal_mode="per_barrier_date": the SUMMED non-latched per-barrier-date
                            # payments, not a single settlement at T, same field, different
                            # meaning; see evaluate_autocall_paths' terminal_mode docstring.
    floating_leg: float
    # diagnostics
    prob_autocalled: float  # fraction of paths that autocalled before T
    prob_knocked_in: float  # fraction of surviving paths knocked in at T (diagnostic latch,
                            # tracked in both modes; only feeds the payoff in "economic" mode)


@dataclass
class PathPayoff:
    """Per-path outcome of one payoff evaluation (payoff_per_path), per unit notional. What
    evaluate_autocall_paths averages over every path, and what a conditional pricer
    averages over its inner axis only."""

    autocall_pv: np.ndarray          # [n_paths] discounted autocall/coupon receipts
    floating_pv: np.ndarray          # [n_paths] discounted floating leg, positive = paid away
    terminal_payoff: np.ndarray      # [n_paths] put/terminal leg (PayoffResult.terminal_leg)
    alive: np.ndarray                # [n_paths] bool, not autocalled by the last row
    knocked_in: np.ndarray           # [n_paths] bool, the down-and-in latch
    autocalled_before_T: np.ndarray  # [n_paths] bool

    @property
    def total(self) -> np.ndarray:
        return self.autocall_pv + self.terminal_payoff - self.floating_pv


def evaluate_autocall_paths(
    spot_paths: np.ndarray,        # [n_paths, n_obs] simulated spot at each observation date
    *,
    barrier_spot_paths: np.ndarray = None,  # [n_paths, n_obs], optional, a SEPARATE path for
                                    # the barrier observation + terminal payoff, built with the
                                    # volatility at the put barrier (GBMEngine.simulate_per_leg). None (default,
                                    # and the only behaviour before this parameter existed) ->
                                    # use spot_paths for everything, as every engine except
                                    # GBMEngine's own simulate_per_leg still does.
    is_coupon_date: np.ndarray,    # [n_obs] bool, an autocall/coupon observation
    is_barrier_date: np.ndarray,   # [n_obs] bool, a put-barrier observation
    is_float_date: np.ndarray,     # [n_obs] bool, a floating-leg payment date
    thresholds: np.ndarray,        # [n_obs] theta_j (autocall multiplier); ignored where not coupon
    coupons: np.ndarray,           # [n_obs] c_j; ignored where not coupon
    float_payments: np.ndarray,    # [n_obs] F_k (deterministic leg value); ignored where not float
    discount_factors: np.ndarray,  # [n_obs] D_j to each observation date (floating + terminal)
    coupon_discount_factors: np.ndarray = None,  # [n_obs] to coupon PAYMENT dates; None -> use D_j
    strike: float,
    put_barrier: float,
    rebate: float,
    fx: float = 1.0,               # phi: fixed quanto/compo conversion factor
    barrier_already_hit: bool = False,  # BarrierIsHit, knocked in before valuation
    autocall_phi: float = 1.0,     # +1 call (autocall when S >= H); -1 put (when S <= H)
    terminal_mode: str = "economic",  # "economic" (default, unchanged) | "per_barrier_date"
    observation_index: np.ndarray = None,  # [n_obs] int, the column each row's autocall and
                                    # barrier decisions READ; None = its own. A coupon decided on
                                    # its fixing and applied on its later payment row reads the
                                    # fixing's column (PayoffSchedule.observation_index).
    observed_levels: np.ndarray = None,  # [n_obs] float, NaN where simulated: a row whose fixing
                                    # has already printed reads this level, an exact decision
) -> PayoffResult:
    """
    Evaluate the autocallable-swap payoff over simulated paths.

    Returns discounted PV per unit notional (the caller multiplies by N = Buy/Sell * Units).

    terminal_mode="economic" (default, unchanged from before this switch existed) implements
    The payoff:
        V = E[ sum_j 1[autocall_j] (R + c_j) phi D_j
               + 1[survive to T] V_terminal phi D_T
               - sum_k 1[alive at t_k] F_k phi D_k ]
    with V_terminal = R - 1[knocked in] * (K - S_T)^+ / K.

    terminal_mode="per_barrier_date" values the put per barrier date instead:
        V = E[ sum_j 1[autocall_j] c_j phi D_j                          (no rebate here)
               + sum_j 1[alive at t_j] 1[S_j <= H] (R - (1 - S_j/K)) phi D_j   (per barrier
                                                                          date, NOT latched)
               - sum_k 1[alive at t_k] F_k phi D_k ]
    See the module docstring for the full comparison.
    """
    pp = payoff_per_path(
        spot_paths, barrier_spot_paths=barrier_spot_paths, is_coupon_date=is_coupon_date,
        is_barrier_date=is_barrier_date, is_float_date=is_float_date, thresholds=thresholds,
        coupons=coupons, float_payments=float_payments, discount_factors=discount_factors,
        coupon_discount_factors=coupon_discount_factors, strike=strike, put_barrier=put_barrier,
        rebate=rebate, fx=fx, barrier_already_hit=barrier_already_hit, autocall_phi=autocall_phi,
        terminal_mode=terminal_mode, observation_index=observation_index,
        observed_levels=observed_levels,
    )
    n_paths = spot_paths.shape[0]
    total = pp.total

    std_error = float(total.std(ddof=1) / np.sqrt(n_paths)) if n_paths > 1 else 0.0

    return PayoffResult(
        pv=float(total.mean()),
        std_error=std_error,
        n_paths=n_paths,
        autocall_leg=float(pp.autocall_pv.mean()),
        terminal_leg=float(pp.terminal_payoff.mean()),
        floating_leg=float(pp.floating_pv.mean()),
        prob_autocalled=float(pp.autocalled_before_T.mean()),
        prob_knocked_in=float((pp.knocked_in & pp.alive).mean()),
    )


def payoff_per_path(
    spot_paths: np.ndarray,        # [n_paths, n_obs] simulated spot at each observation date
    *,
    barrier_spot_paths: np.ndarray = None,  # [n_paths, n_obs], optional, a SEPARATE path for
                                    # the barrier observation + terminal payoff, built with the
                                    # volatility at the put barrier (GBMEngine.simulate_per_leg). None (default,
                                    # and the only behaviour before this parameter existed) ->
                                    # use spot_paths for everything, as every engine except
                                    # GBMEngine's own simulate_per_leg still does.
    is_coupon_date: np.ndarray,    # [n_obs] bool, an autocall/coupon observation
    is_barrier_date: np.ndarray,   # [n_obs] bool, a put-barrier observation
    is_float_date: np.ndarray,     # [n_obs] bool, a floating-leg payment date
    thresholds: np.ndarray,        # [n_obs] theta_j (autocall multiplier); ignored where not coupon
    coupons: np.ndarray,           # [n_obs] c_j; ignored where not coupon
    float_payments: np.ndarray,    # [n_obs] F_k (deterministic leg value); ignored where not float
    discount_factors: np.ndarray,  # [n_obs] D_j to each observation date (floating + terminal)
    coupon_discount_factors: np.ndarray = None,  # [n_obs] to coupon PAYMENT dates; None -> use D_j
    strike: float,
    put_barrier: float,
    rebate: float,
    fx: float = 1.0,               # phi: fixed quanto/compo conversion factor
    barrier_already_hit: bool = False,  # BarrierIsHit, knocked in before valuation
    autocall_phi: float = 1.0,     # +1 call (autocall when S >= H); -1 put (when S <= H)
    terminal_mode: str = "economic",  # "economic" (default, unchanged) | "per_barrier_date"
    observation_index: np.ndarray = None,  # [n_obs] int, the column each row's autocall and
                                    # barrier decisions READ; None = its own. A coupon decided on
                                    # its fixing and applied on its later payment row reads the
                                    # fixing's column (PayoffSchedule.observation_index).
    observed_levels: np.ndarray = None,  # [n_obs] float, NaN where simulated: a row whose fixing
                                    # has already printed reads this level, an exact decision
    live_rows: np.ndarray = None,  # [n_obs] bool; None = every row live. A row that is NOT live
                                    # is already SETTLED: it still moves the path state (an
                                    # autocall kills, a breach latches) but books no value. A
                                    # conditional pricer valuing at a date t marks the
                                    # rows dated before t this way; see module docstring.
) -> "PathPayoff":
    """
    The autocallable-swap payoff PER PATH, the loop evaluate_autocall_paths averages, exposed so
    a conditional pricer can average over its own inner axis only.
    Discounted, per unit notional.

    Beyond evaluate_autocall_paths: ``float_payments`` may be per-path [n_paths, n_obs] (a floating
    leg forecast off a simulated curve), ``barrier_already_hit`` may be a per-path bool array, and
    ``live_rows`` marks the rows that still book value.

    terminal_mode="economic" (default, unchanged from before this switch existed) implements
    The payoff:
        V = E[ sum_j 1[autocall_j] (R + c_j) phi D_j
               + 1[survive to T] V_terminal phi D_T
               - sum_k 1[alive at t_k] F_k phi D_k ]
    with V_terminal = R - 1[knocked in] * (K - S_T)^+ / K.

    terminal_mode="per_barrier_date" values the put per barrier date instead:
        V = E[ sum_j 1[autocall_j] c_j phi D_j                          (no rebate here)
               + sum_j 1[alive at t_j] 1[S_j <= H] (R - (1 - S_j/K)) phi D_j   (per barrier
                                                                          date, NOT latched)
               - sum_k 1[alive at t_k] F_k phi D_k ]
    See the module docstring for the full comparison.
    """
    if terminal_mode not in ("economic", "per_barrier_date"):
        raise ValueError(f"terminal_mode must be 'economic' or 'per_barrier_date', got {terminal_mode!r}")

    n_paths, n_obs = spot_paths.shape
    _validate_schedule_shapes(
        n_obs, is_coupon_date, is_barrier_date, is_float_date,
        thresholds, coupons,
    )
    fp = np.asarray(float_payments, dtype=float)
    per_path_fp = fp.ndim == 2
    if fp.shape != ((n_paths, n_obs) if per_path_fp else (n_obs,)):
        raise ValueError(f"float_payments must be [n_obs] or [n_paths, n_obs], got {fp.shape}")
    live = np.ones(n_obs, dtype=bool) if live_rows is None else np.asarray(live_rows, dtype=bool)
    if live.shape != (n_obs,):
        raise ValueError(f"live_rows must be shape {(n_obs,)}, got {live.shape}")
    if barrier_spot_paths is not None and barrier_spot_paths.shape != (n_paths, n_obs):
        raise ValueError(
            f"barrier_spot_paths must be {(n_paths, n_obs)}, got {barrier_spot_paths.shape}"
        )
    barrier_paths = barrier_spot_paths if barrier_spot_paths is not None else spot_paths
    obs_idx = np.arange(n_obs) if observation_index is None else np.asarray(observation_index, dtype=int)
    if obs_idx.shape != (n_obs,) or np.any(obs_idx > np.arange(n_obs)) or np.any(obs_idx < 0):
        raise ValueError("observation_index must be [n_obs] and read a column at or before its row")
    printed = (np.full(n_obs, np.nan) if observed_levels is None
               else np.asarray(observed_levels, dtype=float))

    def read(paths, j):
        """The spot row j's decisions read: its printed level, else its (fixing's) column."""
        return np.full(n_paths, printed[j]) if np.isfinite(printed[j]) else paths[:, obs_idx[j]]

    # Discount factors may be deterministic [n_obs] or per-path stochastic [n_paths, n_obs]
    # (the latter carries the Radon-Nikodym weight for quanto foreign-measure pricing).
    df = np.asarray(discount_factors, dtype=float)
    per_path_df = df.ndim == 2
    if per_path_df:
        if df.shape != (n_paths, n_obs):
            raise ValueError(f"per-path discount_factors must be {(n_paths, n_obs)}, got {df.shape}")
    elif df.shape[0] != n_obs:
        raise ValueError(f"discount_factors length {df.shape[0]}, expected n_obs={n_obs}")

    def _dfac(j, mask):
        """Discount for observation j over a path mask (scalar or per-path)."""
        return df[mask, j] if per_path_df else df[j]

    # Coupon leg may discount to a lagged PAYMENT date (deterministic [n_obs]); when not given,
    # it falls back to the observation-date discount (which may be per-path, e.g. quanto weights).
    cdf_provided = coupon_discount_factors is not None
    cdf = np.asarray(coupon_discount_factors, dtype=float) if cdf_provided else None
    if cdf_provided and cdf.shape != (n_obs,):
        raise ValueError(f"coupon_discount_factors must be shape {(n_obs,)}, got {cdf.shape}")

    def _cdfac(j, mask):
        """Discount for the coupon paid on autocall at observation j (payment-date if given)."""
        return cdf[j] if cdf_provided else _dfac(j, mask)

    alive = np.ones(n_paths, dtype=bool)              # not yet autocalled
    autocall_pv = np.zeros(n_paths)                   # discounted autocall+coupon receipts
    floating_pv = np.zeros(n_paths)                   # discounted floating paid away
    barrier_pv = np.zeros(n_paths)                    # two curve mode only: summed, non-latched
                                                       # per-barrier-date put payments
    knocked_in = np.broadcast_to(np.asarray(barrier_already_hit, dtype=bool),
                                 (n_paths,)).copy()  # down-and-in latch (diagnostic in
                                                       # Two curve mode, see module docstring)
    autocalled_before_T = np.zeros(n_paths, dtype=bool)

    for j in range(n_obs):
        # the spot this row's decisions read: its own, or its coupon's fixing
        S_j = read(spot_paths, j)

        # (3) floating leg is paid while alive, at the START of processing the date
        # (before this date's potential autocall termination).
        if is_float_date[j] and live[j]:
            amount = fp[alive, j] if per_path_fp else fp[j]
            floating_pv[alive] += fx * amount * _dfac(j, alive)

        # (1) autocall test
        if is_coupon_date[j]:
            trigger = thresholds[j] * strike
            # call: autocall when S >= H; put: when S <= H  (phi*(S-H) >= 0 covers both)
            fires = alive & (autocall_phi * (S_j - trigger) >= 0)
            # In "per_barrier_date" mode the coupon is bare `coup`; "economic" adds rebate on every
            # autocall
            coupon_amount = coupons[j] if terminal_mode == "per_barrier_date" else (rebate + coupons[j])
            if live[j]:
                autocall_pv[fires] += fx * coupon_amount * _cdfac(j, fires)
            alive[fires] = False
            autocalled_before_T[fires] = True

        # (2) barrier observation; only meaningful for still-alive paths. Reads barrier_paths,
        # not spot_paths, the put leg's own strip when the caller gave one (see the
        # barrier_spot_paths parameter above), the same path otherwise.
        if is_barrier_date[j]:
            S_bar_j = read(barrier_paths, j)
            breach = alive & (S_bar_j <= put_barrier)
            knocked_in |= breach          # latched, diagnostic (and used by "economic" below)
            if terminal_mode == "per_barrier_date" and live[j]:
                # crisp, NOT latched, fires on every flagged date a live path breaches, at
                # THAT date's own spot and discount factor:
                # payment = D[j] * fx * breach * (rebate - (1 - S_j / strike)),
                # where `breach` is 1 on a path below the barrier and 0 otherwise.
                d_j = df[:, j] if per_path_df else df[j]
                barrier_pv += fx * breach.astype(float) * (rebate - (1.0 - S_bar_j / strike)) * d_j

    S_T = read(barrier_paths, n_obs - 1)    # the last row's fixing (or print) where it is a coupon
    D_T = df[:, -1] if per_path_df else df[-1]

    if terminal_mode == "per_barrier_date" or not live[-1]:
        # no unconditional survivor payment, the barrier block above already booked every
        # put-related cashflow (a settled terminal row
        # books nothing either: barrier_pv is zero in "economic" mode)
        terminal_payoff = barrier_pv
    else:
        # (terminal) survivors settle the down-and-in put at T = last observation date
        put_loss = np.where(knocked_in, np.maximum(strike - S_T, 0.0) / strike, 0.0)
        terminal_payoff = np.where(alive, fx * (rebate - put_loss) * D_T, 0.0)

    return PathPayoff(
        autocall_pv=autocall_pv,
        floating_pv=floating_pv,
        terminal_payoff=terminal_payoff,
        alive=alive,
        knocked_in=knocked_in,
        autocalled_before_T=autocalled_before_T,
    )


def _validate_schedule_shapes(n_obs, *arrays) -> None:
    """Raise if any per-observation array is not length n_obs."""
    for a in arrays:
        a = np.asarray(a)
        if a.shape[0] != n_obs:
            raise ValueError(
                f"schedule array has length {a.shape[0]}, expected n_obs={n_obs}"
            )
