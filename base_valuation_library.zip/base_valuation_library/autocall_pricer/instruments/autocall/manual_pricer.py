"""
Manual-input autocall pricer, the 'clarity' entry point for a validation.

Every input is supplied explicitly (no JSON, no market-data loading) so you can see exactly
what goes into the price and line it up against the deal being validated. Rates are
CONTINUOUS; curves are built so their continuous rate
equals the number you type (avoids the simple-vs-continuous foot-gun in FlatDiscountCurve).

Usage:
    from autocall_pricer.instruments.autocall.manual_pricer import ManualAutocallInputs, price_manual
    res = price_manual(ManualAutocallInputs(...))
    print(res.report())
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional, Sequence, Tuple, Union

import numpy as np

from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
from autocall_pricer.instruments.autocall.autocall_swap import AutocallSwap, VANILLA, QUANTO
from autocall_pricer.instruments.autocall.payoff import evaluate_autocall_paths
from autocall_pricer.market_data.equity_market_data import EquityMarketData
from autocall_pricer.models.gbm import GBMEngine
from autocall_pricer.models.fx_gbm import CorrelatedGBMEngine
from autocall_pricer.models.dividends import Dividend, CASH


def flat_curve(valuation_date: date, cont_rate: float) -> FlatDiscountCurve:
    """FlatDiscountCurve whose CONTINUOUS rate equals cont_rate."""
    return FlatDiscountCurve(valuation_date, float(np.exp(cont_rate) - 1.0))


def _as_list(x, n: int) -> List[float]:
    """Broadcast a scalar to length n, or pass a length-n sequence through."""
    if np.isscalar(x):
        return [float(x)] * n
    seq = list(x)
    if len(seq) != n:
        raise ValueError(f"expected scalar or length-{n} sequence, got length {len(seq)}")
    return [float(v) for v in seq]


@dataclass
class ManualAutocallInputs:
    """All autocall + market inputs, entered by hand. Continuous rates."""

    valuation_date: date
    spot: float
    # rates (continuous). For vanilla same-currency, r_foreign == r_domestic.
    r_domestic: float        # payoff-currency discount rate
    r_foreign: float         # equity funding / repo rate
    div_yield: float         # continuous dividend yield (0 if using cash_dividends)
    vol: float               # equity vol (flat)

    # deal
    strike: float
    observation_dates: Sequence[date]
    coupons: Union[float, Sequence[float]]        # per obs date (scalar broadcasts)
    thresholds: Union[float, Sequence[float]] = 1.0
    rebate: float = 0.0
    barrier_pct: Optional[float] = None           # put barrier as % of strike (None = no barrier)
    barrier_dates: Optional[Sequence[date]] = None  # default: all observation_dates
    buy_sell: int = 1
    units: float = 1.0
    barrier_already_hit: bool = False

    # quanto (payoff_type='Quanto'); FX simulated for the cross-check
    payoff_type: str = VANILLA
    fix_fx_rate: float = 1.0
    fx_vol: float = 0.0
    corr_equity_fx: float = 0.0

    # discrete cash dividends (list of (ex_date, cash_amount)); overrides div_yield if set
    cash_dividends: Optional[Sequence[Tuple[date, float]]] = None

    # monte carlo
    n_paths: int = 200_000
    seed: int = 12345

    def build_market(self) -> EquityMarketData:
        divs = None
        if self.cash_dividends:
            divs = [Dividend(d, a, CASH) for d, a in self.cash_dividends]
        return EquityMarketData(
            valuation_date=self.valuation_date,
            spot=self.spot,
            discount_curve=flat_curve(self.valuation_date, self.r_domestic),
            repo_curve=flat_curve(self.valuation_date, self.r_foreign),
            div_curve=flat_curve(self.valuation_date, self.div_yield),
            equity_vol=self.vol,
            fx_vol=self.fx_vol,
            corr_equity_fx=self.corr_equity_fx,
            discrete_dividends=divs,
        )

    def build_deal(self) -> AutocallSwap:
        obs = list(self.observation_dates)
        n = len(obs)
        coupons = _as_list(self.coupons, n)
        thresholds = _as_list(self.thresholds, n)
        coupon_schedule = list(zip(obs, coupons, thresholds))
        barrier_dates = list(self.barrier_dates) if self.barrier_dates is not None else obs
        common = dict(
            strike=self.strike, coupon_schedule=coupon_schedule,
            barrier_dates=(barrier_dates if self.barrier_pct is not None else []),
            rebate=self.rebate, buy_sell=self.buy_sell, units=self.units,
            payoff_type=self.payoff_type, fix_fx_rate=self.fix_fx_rate,
            barrier_already_hit=self.barrier_already_hit,
        )
        if self.barrier_pct is not None:
            return AutocallSwap.from_barrier_pct(barrier_pct=self.barrier_pct, **common)
        return AutocallSwap(put_barrier=0.0, **common)


@dataclass
class ManualResult:
    inputs: ManualAutocallInputs
    schedule: object
    pv_unit: float
    pv_notional: float
    std_error: float
    autocall_leg: float
    terminal_leg: float
    floating_leg: float
    prob_autocalled: float
    prob_knocked_in: float
    forwards: List[float]

    def report(self) -> str:
        i = self.inputs
        lines = []
        add = lines.append
        add("=" * 66)
        add("  AUTOCALL MANUAL VALIDATION PRICE")
        add("=" * 66)
        add("  Market inputs (continuous rates)")
        add(f"    valuation date   : {i.valuation_date}")
        add(f"    spot             : {i.spot:.4f}")
        add(f"    r_domestic       : {i.r_domestic:.4%}")
        add(f"    r_foreign (repo) : {i.r_foreign:.4%}")
        if i.cash_dividends:
            add(f"    dividends        : CASH {list(i.cash_dividends)}")
        else:
            add(f"    div yield        : {i.div_yield:.4%}")
        add(f"    vol              : {i.vol:.4%}")
        if i.payoff_type == QUANTO:
            add(f"    QUANTO           : fixFX={i.fix_fx_rate}  fx_vol={i.fx_vol:.4%}  "
                f"corr={i.corr_equity_fx:+.3f}")
        add("  Deal")
        add(f"    strike           : {i.strike:.4f}")
        add(f"    put barrier      : "
            f"{'%.4f (%.0f%%)' % (i.barrier_pct*i.strike, i.barrier_pct*100) if i.barrier_pct else 'none'}")
        add(f"    rebate           : {i.rebate:.4f}")
        add(f"    notional (N)     : {i.buy_sell*i.units:,.2f}")
        add("  Observation schedule  (t, DF, forward, threshold*K, coupon)")
        s = self.schedule
        coupons = _as_list(i.coupons, len(i.observation_dates))
        for j, d in enumerate(s.obs_dates):
            add(f"    {d}  t={s.obs_times[j]:5.3f}  DF={s.discount_factors[j]:.5f}  "
                f"F={self.forwards[j]:8.4f}  H={s.thresholds[j]*i.strike:8.4f}  c={coupons[j]:.4f}")
        add("-" * 66)
        add(f"  PV per unit        : {self.pv_unit:12.5f}  +/- {self.std_error:.5f}")
        add(f"  PV x notional      : {self.pv_notional:16,.2f}")
        add(f"    autocall leg     : {self.autocall_leg:12.5f}")
        add(f"    terminal leg     : {self.terminal_leg:12.5f}")
        add(f"    floating leg     : {self.floating_leg:12.5f}")
        add(f"  P(autocalled)      : {self.prob_autocalled:6.3f}")
        add(f"  P(knock-in | surv) : {self.prob_knocked_in:6.3f}")
        add("=" * 66)
        return "\n".join(lines)


def price_manual(inputs: ManualAutocallInputs) -> ManualResult:
    """Build market + deal from explicit inputs and Monte-Carlo the PV."""
    mkt = inputs.build_market()
    deal = inputs.build_deal()
    deal.validate()
    sched = deal.build_schedule(inputs.valuation_date, mkt)
    forwards = [mkt.forward(float(t)) for t in sched.obs_times]

    if inputs.payoff_type == QUANTO:
        # explicit correlated-FX simulation under the foreign measure (Phase 5)
        S, w = CorrelatedGBMEngine(n_paths=inputs.n_paths, seed=inputs.seed).simulate_quanto(sched, mkt)
        kwargs = sched.payoff_kwargs()
        kwargs["discount_factors"] = w
        res = evaluate_autocall_paths(S, **kwargs)
    else:
        S = GBMEngine(n_paths=inputs.n_paths, seed=inputs.seed).simulate(sched, mkt)
        res = evaluate_autocall_paths(S, **sched.payoff_kwargs())

    return ManualResult(
        inputs=inputs, schedule=sched,
        pv_unit=res.pv, pv_notional=deal.notional * res.pv, std_error=res.std_error,
        autocall_leg=res.autocall_leg, terminal_leg=res.terminal_leg, floating_leg=res.floating_leg,
        prob_autocalled=res.prob_autocalled, prob_knocked_in=res.prob_knocked_in,
        forwards=forwards,
    )
