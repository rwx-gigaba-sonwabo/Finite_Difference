"""Reading an autocallable swap and its market data from a trade JSON file.

The functions here turn the content of a trade file into the objects the autocall pricer
uses. They do no pricing.

``load_curve``
    A zero rate curve or a dividend yield curve, by its full price factor name.
``load_vol_surface``
    An equity volatility surface. Three layouts are read: a grid of moneyness, expiry and
    volatility, a set of SVI parameters per tenor, and a parametric skew per tenor.
``load_correlation``
    A single correlation number.
``load_autocall_swap``
    The swap deal itself, as an :class:`AutocallSwap`, plus the names of the price factors
    the deal points to.

Conventions of the file that the readers follow
-----------------------------------------------
* Rates are continuously compounded on an actual/365 basis.
* A dividend yield curve is interpolated in a straight line in one over time.
* The coupon table and the threshold table are matched row by row, so they must have the
  same number of rows.
* Each coupon is decided on the price fixing date that closes its window and is paid on
  its own coupon date.
* The put barrier is a fraction of the strike for the first deal type and an absolute
  level for the second version of the deal type.
* Floating amounts are read from the deal's table as the cash amount of each period per
  unit of notional.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

from autocall_pricer.curve.discount_curve import DiscountYieldCurveHandler
from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
from autocall_pricer.instruments.autocall.autocall_swap import AutocallSwap
from autocall_pricer.market_data.equity_market_data import EquityMarketData
from autocall_pricer.utils.interpolation import (
    hermite_rt_interp, cubic_hermite_interp, linear_rt_interp, linear_interp,
    reciprocal_time_interp,
)

Number = Union[float, Sequence[float]]

# The curve "Interpolation" field of the trade file -> our interpolator (utils/interpolation.py)
_INTERP_BY_NAME = {
    "HermiteRT": hermite_rt_interp,      # Hermite in r*t space
    "Hermite": cubic_hermite_interp,     # Hermite in rate space
    "LinearRT": linear_rt_interp,        # linear in r*t space
    "Linear": linear_interp,             # linear in rate space
    "ReciprocalTime": reciprocal_time_interp,  # linear in 1/t
}

# Dividend yields are always interpolated in reciprocal time, whatever the Interpolation field says.
DIVIDEND_INTERP = "ReciprocalTime"


# ============================================================================ curves
@dataclass
class CurveData:
    """
    A zero curve pulled from the trade JSON file. Rates are CONTINUOUS, ACT/365
    (df = exp(-r(t) t)), the convention of the InterestRate and DividendRate curves in the trade file.
    The SAME CurveData feeds both the pricer, through handler(), and a trade file, through json_curve().
    """

    data: List[Tuple[float, float]]       # [(term_years, continuous_zero_rate), ...]
    interpolation: str = "HermiteRT"
    source: str = ""                      # factor key it came from (for the report)

    def handler(self, valuation_date: date) -> DiscountYieldCurveHandler:
        """Our-side curve object (term -> date via ACT/365, so t is recovered exactly)."""
        interp = _INTERP_BY_NAME.get(self.interpolation)
        if interp is None:
            raise ValueError(f"unsupported Interpolation {self.interpolation!r} "
                             f"(supported: {sorted(_INTERP_BY_NAME)})")
        dates = [valuation_date + timedelta(days=int(round(t * 365))) for t, _ in self.data]
        df = pd.DataFrame({"Date": dates, "Rate": [r for _, r in self.data]})
        return DiscountYieldCurveHandler(valuation_date, df, interp)

    def json_curve(self) -> Dict[str, Any]:
        """The curve in trade file layout, carrying the same [term, rate] points."""
        return {".Curve": {"meta": [], "data": [[float(t), float(r)] for t, r in self.data]}}

    def cont_zero(self, valuation_date: date, t: float) -> float:
        """Continuous zero rate to year fraction t (for a representative scalar drift)."""
        if t <= 0:
            return float(self.data[0][1])
        return -math.log(self.handler(valuation_date).discount_factor(t)) / t


def load_curve(json_path: Union[str, Path], factor_key: str,
               interpolation: Optional[str] = None) -> CurveData:
    """
    Pull a zero curve out of the trade JSON file by factor key, e.g.
    "InterestRate.ZAR-SWAP.ZAR-OIS-FUNDING" (discount) or "DividendRate.TESTEQ".

    Handles both JSON layouts: a deal file (Calc > MergeMarketData > ExplicitMarketData >
    Price Factors) and a standalone market file (MarketData > Price Factors). interpolation
    overrides the factor's own "Interpolation" field when given.
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob["MarketData"]["Price Factors"]
    if factor_key not in pf:
        raise KeyError(f"{factor_key!r} not in Price Factors. Available: {sorted(pf)}")
    node = pf[factor_key]
    data = [(float(t), float(r)) for t, r in node["Curve"][".Curve"]["data"]]
    # The Interpolation field is ignored on dividend curves, which always use reciprocal
    # time; interest/other curves use their own field (HermiteRT default). Explicit arg wins.
    if interpolation is not None:
        interp = interpolation
    elif factor_key.startswith("DividendRate"):
        interp = DIVIDEND_INTERP
    else:
        interp = node.get("Interpolation", "HermiteRT")
    return CurveData(data=data, interpolation=interp, source=factor_key)


# re-exported for a single import point alongside load_curve/load_vol_surface, the actual
# implementation lives in market_data/logvar2fj_params.py (LogVar2FJEngine's own home)
from autocall_pricer.market_data.logvar2fj_params import load_logvar2fj_params, load_spot_model  # noqa: E402,F401

# re-exported likewise, implementation lives in market_data/svi_surface.py
from autocall_pricer.market_data.svi_surface import load_svi_surface  # noqa: E402,F401


def load_vol_surface(json_path: Union[str, Path], factor_key: str):
    """
    Pull an equity implied-vol surface out of the trade JSON file by factor
    key, e.g. "EquityPriceVol.TESTEQ". Same two JSON layouts as load_curve. Dispatches on the
    factor's own Surface_Type:

      - "Explicit" (default if absent): raw [[moneyness, expiry, vol], ...] triples ->
        EquityVolSurface (market_data.vol_surface). ``moneyness`` here is a RATIO (spot/strike).
      - "SVI": per-tenor SVI params -> market_data.svi_surface.SVISurface (variance-space
        tenor blend, see that module's own docstring).
      - "Skew": a 6-region parametric skew -> market_data.skew_surface.SkewSurface
        (VOL-space tenor blend, confirmed different from SVI's, see that module's docstring).
      SVI and Skew surfaces need the ABSOLUTE STRIKE, not a moneyness ratio, they set
      needs_strike = True, which EquityMarketData.vol() checks and handles automatically; a
      caller using .get_vol() directly must pass strike, not moneyness, for those two.

    Any of the three plugs straight into EquityMarketData(equity_vol=surface) in place of a
    flat float, so any difference between the two pricers is model, not data, the same way
    load_curve() feeds both sides off one discount/dividend curve.

    The "Malz" and "Relative_Forward" surface types are not read by this loader.
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob["MarketData"]["Price Factors"]
    if factor_key not in pf:
        raise KeyError(f"{factor_key!r} not in Price Factors. Available: {sorted(pf)}")
    node = pf[factor_key]
    surface_type = node.get("Surface_Type", "Explicit")
    if surface_type == "Explicit":
        from autocall_pricer.market_data.vol_surface import EquityVolSurface
        data = node["Surface"][".Curve"]["data"]
        return EquityVolSurface.from_triples(data)
    if surface_type == "SVI":
        return load_svi_surface(json_path, factor_key)
    if surface_type == "Skew":
        from autocall_pricer.market_data.skew_surface import load_skew_surface
        return load_skew_surface(json_path, factor_key)
    raise NotImplementedError(
        f"{factor_key!r} is Surface_Type={surface_type!r}; only 'Explicit', 'SVI' and 'Skew' "
        f"are supported by this loader")


def load_correlation(json_path: Union[str, Path], factor_key: str) -> float:
    """
    Pull a scalar correlation out of the trade JSON file by factor key, e.g.
    "Correlation.EquityPrice.JPY_NKY_BBG.JPY/FxRate.JPY.ZAR", the quanto equity/FX
    correlation of a quanto payoff (see models/logvar2fj.py's module
    docstring for how ``LogVar2FJEngine`` consumes it as ``rho_fx``). Same two JSON layouts
    as load_curve. The currency pair in the key is named in alphabetical order; no
    sign correction is applied here, pass the correlation exactly as the factor states it,
    against a currency pair built the same way.
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob["MarketData"]["Price Factors"]
    if factor_key not in pf:
        raise KeyError(f"{factor_key!r} not in Price Factors. Available: {sorted(pf)}")
    return float(pf[factor_key]["Value"])


# ===================================================================== autocall deal (JSON)
# Deal type names of the autocallable swap in the trade file.
_AUTOCALL_DEAL_OBJECTS = {"QEDI_CustomAutoCallSwap", "QEDI_CustomAutoCallSwap_V2"}


def _deal_ts(node: Any) -> date:
    """A trade file {'.Timestamp': 'YYYY-MM-DD...'} node (or a bare ISO date string) -> date."""
    if isinstance(node, dict) and ".Timestamp" in node:
        return date.fromisoformat(node[".Timestamp"][:10])
    if isinstance(node, str):
        return date.fromisoformat(node[:10])
    raise ValueError(f"not a timestamp node: {node!r}")


def _deal_date_value_rows(rows: Sequence) -> List[Tuple[date, float]]:
    """A trade file table of [date, value] rows (Autocall_Coupons/_Thresholds/_Floating, Price_Fixing)
    -> [(date, value), ...] in JSON ROW ORDER, not resorted. Autocall_Thresholds pairs with
    Autocall_Coupons by POSITION, not by date (see load_autocall_swap's own docstring), so
    preserving row order here is load-bearing, not incidental."""
    return [(_deal_ts(row[0]), float(row[1])) for row in rows]


def _deal_date_only_rows(rows: Sequence) -> List[date]:
    """Read the barrier dates table. It has one column, so each row is either a date or a
    list holding one date. It is not a list of date and value pairs like the other tables."""
    return [_deal_ts(row[0] if isinstance(row, (list, tuple)) else row) for row in rows]


def _find_autocall_deals(node: Any) -> List[Dict[str, Any]]:
    """Depth-first search of the deal tree of the trade file for every autocallable swap
    `.Deal` dict, wherever it sits (netting sets nest arbitrarily)."""
    found: List[Dict[str, Any]] = []
    if isinstance(node, dict):
        deal = node.get(".Deal")
        if isinstance(deal, dict) and deal.get("Object") in _AUTOCALL_DEAL_OBJECTS:
            found.append(deal)
        for v in node.values():
            found.extend(_find_autocall_deals(v))
    elif isinstance(node, list):
        for v in node:
            found.extend(_find_autocall_deals(v))
    return found


@dataclass
class AutocallDealInfo:
    """Everything load_autocall_swap() read off the deal besides the AutocallSwap itself,
    chiefly the market data names that follow from this deal's own Equity/Discount_Rate/
    Equity_Volatility/Dividends fields into, so build_market() can pass them straight to
    load_curve / load_vol_surface without hand-typing them."""

    reference: str
    object_type: str                 # "QEDI_CustomAutoCallSwap" | "QEDI_CustomAutoCallSwap_V2"
    currency: str
    payoff_currency: str
    equity: str
    discount_rate: str
    equity_volatility: str
    dividends: str
    expiry_date: date
    spot: Optional[float]            # EquityPrice.<equity>'s own "Spot", if this JSON carries it
    discount_factor: str             # "InterestRate.<Discount_Rate>"
    dividend_factor: str             # "DividendRate.<Dividends>"
    equity_vol_factor: str           # "EquityPriceVol.<Equity_Volatility>"
    repo_factor: str                 # "InterestRate.<EquityPrice.<equity>.Interest_Rate>",
                                      # the equity's OWN funding curve (quanto/compo deals need
                                      # this distinct from discount_factor, the PAYOFF currency's
                                      # curve); falls back to discount_factor when this JSON's
                                      # EquityPrice.<equity> factor is absent or names none.


def coupon_fixings(coupons: Sequence[date], fixings: Sequence[date],
                   declared: Optional[Dict[date, date]] = None,
                   base_date: Optional[date] = None) -> Dict[date, date]:
    """Each coupon date -> the Price_Fixing date it is DECIDED on, the coupon itself being paid on its own date.

    - DECLARED by `Coupon_Observations` (coupon -> fixing) where authored, subject to these
      checks: every coupon named, the fixing booked, on or before its coupon, after the coupon
      before it.
    - Otherwise DERIVED: a coupon's window is every fixing after its predecessor's date up to and
      including its own; the coupons are the FUTURE ones (on or after `base_date`) and the fixings
      those after the last past coupon. The partition must give each coupon a non-empty window
      and leave no fixing after the last coupon. Where every window after the first holds one
      fixing, the fixings before the first coupon's own are its strike observation and dropped.
    - A window of more than one fixing is an AVERAGE, which this pricer does not value: refused.

    Past coupons (before `base_date`) are returned observed on their own date, they are
    dropped from the schedule anyway.
    """
    coupons = list(coupons)
    if declared:
        named = [declared.get(c) for c in coupons]
        booked = set(fixings)
        for c, f in zip(coupons, named):
            if f is None or f not in booked or f > c:
                raise ValueError(f"Coupon_Observations: the coupon of {c} names fixing {f}, which "
                                 f"is missing, not a Price_Fixing row, or after the coupon")
        if any(b <= a for a, b in zip(named, named[1:])) or any(
                f <= c for c, f in zip(coupons, named[1:])):
            raise ValueError("Coupon_Observations does not pair each coupon with a fixing of its "
                             "own after the coupon before it")
        return dict(zip(coupons, named))

    future = sorted(c for c in coupons if base_date is None or c >= base_date)
    if not future:
        return {c: c for c in coupons}
    prior = [c for c in coupons if c < future[0]]
    fx = sorted(f for f in fixings if not prior or f > max(prior))
    ends = (np.searchsorted(np.array(fx, dtype="datetime64[D]"),
                            np.array(future, dtype="datetime64[D]"), "right") - 1) if fx else None
    if ends is None or ends[0] < 0 or not (np.diff(ends) > 0).all() or ends[-1] != len(fx) - 1:
        raise ValueError(
            f"the price fixings {[str(f) for f in fx]} do not give each coupon "
            f"{[str(c) for c in future]} a window of its own")
    windows = np.diff(np.r_[-1, ends])
    # A FIRST window's extra fixings (the strike observation) are dropped only where every
    # later window holds one; a lone coupon's several fixings stay an average
    if (windows[1:] > 1).any() or (windows.size == 1 and windows[0] > 1):
        raise ValueError(
            f"a coupon window holds {int(windows.max())} fixings, an AVERAGING window, which "
            f"this pricer (one fixing per coupon) does not value")
    out = {c: c for c in coupons if c < future[0]}
    out.update({c: fx[e] for c, e in zip(future, ends)})
    return out


def load_autocall_swap(json_path: Union[str, Path], *, reference: Optional[str] = None,
                       autocall_type: str = "Call",
                       terminal_mode: str = "per_barrier_date",
                       observation: str = "fixing") -> Tuple[AutocallSwap, AutocallDealInfo]:
    """
    Build an AutocallSwap straight off a QEDI_CustomAutoCallSwap[_V2] `.Deal` block in a
    the trade JSON file, no hand-typed coupon/threshold/floating schedule to keep in sync with
    the real term sheet. Pass `reference` to disambiguate when the job carries more than one
    autocall deal.

    How each field of the deal is read:

    - OBSERVATION vs PAYMENT (`observation`, default "fixing"): each coupon is
      decided on the `Price_Fixing` row closing its window and paid
      on the `Autocall_Coupons` date (see `coupon_fixings`). So each coupon_schedule entry is
      (fixing date, coupon, threshold, coupon date): AutocallSwap.build_schedule tests the
      trigger on the fixing's spot and applies the call on the coupon row, so a floating
      payment dated between the two is still paid. With no Price_Fixing table, or
      observation="coupon", the coupon date is both.
    - THRESHOLDS pair with coupons BY POSITION, not by date: a
      threshold row belongs to the coupon row of its own POSITION whatever date it carries.
      Autocall_Coupons and Autocall_Thresholds must therefore be the same length; a mismatch is
      refused rather than silently zip-truncated. Autocall_Thresholds absent/empty defaults
      every threshold to 1.0 (ATM).
    - BARRIER is a FRACTION of strike (`* Strike_Price`) on the first version of the deal type,
      but the second version of the deal type holds it as an
      ABSOLUTE level. This loader applies whichever scaling matches the deal's own `Object`.
    - `Rebate`, `FixFXRate` and `BarrierIsHit` are optional fields that a deal may leave out.
      `Rebate` defaults to 0.0 and `FixFXRate` to 1.0. `BarrierIsHit` counts as true when the
      key is PRESENT at all, whatever its value.
    - `Autocall_Floating`'s raw per-row value is read straight through as that period's cash
      amount (fraction of notional).
      This IS an approximation for the
      forward-starting periods of the second version: it only uses
      Autocall_Floating's value directly for periods that have ALREADY fixed
      (`start < base_date`); unfixed future periods are forecast off the `Forecast_Rate` curve
      (e.g. "ZAR-JIBAR-3M") at valuation time,
      which this loader does not replicate. Whatever value the JSON carries for a future period
      is used as-is, correct if the export already snapshot a projected rate into that row,
      silently wrong if it is a stale placeholder. There is no reliable way to tell the two
      apart from the JSON alone, so this is not checked.
    - An AVERAGING window (more than one fixing per coupon, beyond a dropped strike
      observation) is refused rather than silently mispriced, this pricer reads one fixing.

    NOT read from the deal (the deal has no field for it, so it stays a caller choice):
    `autocall_type` (the trigger direction Call/Put; the deal is always an
    upward threshold test)
    and `terminal_mode` (the two rebate and barrier conventions of this pricer,
    see AutocallSwap's own class docstring).
    """
    blob = json.loads(Path(json_path).read_text())
    try:
        deal_tree = blob["Calc"]["Deals"]
    except KeyError:
        raise ValueError(f"{json_path}: not the trade JSON file (no Calc.Deals)") from None
    deals = _find_autocall_deals(deal_tree)
    if reference is not None:
        deals = [d for d in deals if d.get("Reference") == reference]
    if not deals:
        raise ValueError(
            f"no QEDI_CustomAutoCallSwap[_V2] deal found in {json_path}"
            + (f" with Reference={reference!r}" if reference else ""))
    if len(deals) > 1:
        refs = [d.get("Reference") for d in deals]
        raise ValueError(
            f"{len(deals)} QEDI_CustomAutoCallSwap[_V2] deals found in {json_path}: {refs}, "
            f"pass reference=... to pick one")
    deal = deals[0]
    object_type = deal.get("Object")

    coupons = _deal_date_value_rows(deal["Autocall_Coupons"])
    thresholds_raw = deal.get("Autocall_Thresholds", [])
    if thresholds_raw:
        thresholds = _deal_date_value_rows(thresholds_raw)
        if len(thresholds) != len(coupons):
            raise ValueError(
                f"Autocall_Coupons has {len(coupons)} rows but Autocall_Thresholds has "
                f"{len(thresholds)}. They are paired by POSITION, so they must be the same length")
        threshold_values = [v for _, v in thresholds]
    else:
        threshold_values = [1.0] * len(coupons)

    if observation not in ("fixing", "coupon"):
        raise ValueError(f"observation must be 'fixing' or 'coupon', got {observation!r}")
    fixing_rows = _deal_date_value_rows(deal.get("Price_Fixing", []))
    if observation == "fixing" and fixing_rows:
        base = (blob["Calc"].get("Calculation", {}) or {}).get("Base_Date")
        # Coupon_Observations holds [coupon date, fixing date] rows
        declared = {_deal_ts(c): _deal_ts(f) for c, f in deal.get("Coupon_Observations", [])}
        coupon_dates, fixing_dates = [d for d, _ in coupons], [d for d, _ in fixing_rows]
        observed = coupon_fixings(coupon_dates, fixing_dates, declared,
                                  _deal_ts(base) if base else None)
        # A coupon dated before the valuation date is paired with its fixing over the WHOLE
        # schedule, so a past coupon reads its fixing from that pairing
        whole = coupon_fixings(coupon_dates, fixing_dates, declared, None)
        printed = dict(fixing_rows)
        base_d = _deal_ts(base) if base else None
        # (fixing it is decided on, coupon, threshold, payment date = the coupon row's own date,
        #  the Price_Fixing level, read by build_schedule once the fixing is behind the
        #  valuation date: a called past coupon expires the deal, an unpaid one decides on it)
        coupon_schedule = []
        for (d, c), h in zip(coupons, threshold_values):
            fix = whole[d] if base_d is not None and d < base_d else observed[d]
            coupon_schedule.append((fix, c, h, d, printed.get(fix)))
    else:
        # legacy: the coupon date is both the observation and the payment (no Price_Fixing, or
        # observation="coupon" asked for explicitly)
        coupon_schedule = [(d, c, h) for (d, c), h in zip(coupons, threshold_values)]

    floats_raw = deal.get("Autocall_Floating", [])
    float_schedule = _deal_date_value_rows(floats_raw) if floats_raw else []

    barrier_dates_raw = deal.get("Barrier_Dates", [])
    barrier_dates = _deal_date_only_rows(barrier_dates_raw) if barrier_dates_raw else []

    strike = float(deal["Strike_Price"])
    raw_barrier = float(deal.get("Barrier", 0.0))
    put_barrier = raw_barrier if object_type == "QEDI_CustomAutoCallSwap_V2" else raw_barrier * strike
    if put_barrier > 0.0 and not barrier_dates:
        # NOT a safe silent default: evaluate_autocall_paths' terminal_mode="per_barrier_date" (every
        # script in this family uses it) only ever prices the put through the is_barrier_date
        # loop, `barrier_pv` stays all-zero and so does the reported terminal leg when no date
        # is flagged, even though put_barrier itself is a real nonzero number on the returned
        # AutocallSwap. A deal with a real Barrier and no Barrier_Dates would silently price as
        # swap-only with no error at all, so this is refused instead.
        raise ValueError(
            f"Barrier={raw_barrier:g} (put_barrier={put_barrier:g}) but Barrier_Dates is empty, "
            f"the put/barrier leg would silently price as 0 (evaluate_autocall_paths only reads "
            f"put_barrier on flagged is_barrier_date rows). Add Barrier_Dates to the deal, or "
            f"confirm this booking is genuinely swap-only and set Barrier to 0 in the JSON")

    currency = deal.get("Currency", "")
    payoff_currency = deal.get("Payoff_Currency") or currency
    equity = deal["Equity"]
    discount_rate = deal.get("Discount_Rate") or currency
    equity_volatility = deal.get("Equity_Volatility") or equity
    dividends = deal.get("Dividends") or equity

    payoff_type = deal.get("Payoff_Type", "Standard")
    payoff_type = {"Standard": "Vanilla"}.get(payoff_type, payoff_type)

    swap = AutocallSwap(
        strike=strike,
        coupon_schedule=coupon_schedule,
        put_barrier=put_barrier,
        barrier_dates=barrier_dates,
        float_schedule=float_schedule,
        rebate=float(deal.get("Rebate", 0.0)),
        buy_sell=1 if str(deal.get("Buy_Sell", "Buy")).lower().startswith("b") else -1,
        units=float(deal.get("Units", 1.0)),
        payoff_type=payoff_type,
        autocall_type=autocall_type,
        fix_fx_rate=float(deal.get("FixFXRate", 1.0)),
        barrier_already_hit=deal.get("BarrierIsHit") is not None,
        terminal_mode=terminal_mode,
    )

    # spot + the equity's own funding curve: try this SAME JSON's own EquityPrice.<equity>
    # factor first (some exports carry it inline); spot is None if absent, the caller must
    # then supply it another way. The
    # repo rate falls back to discount_rate when the equity factor names no curve of its own.
    spot = None
    repo_rate = discount_rate
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob.get("MarketData", {}).get("Price Factors", {})
    eq_node = pf.get(f"EquityPrice.{equity}")
    if eq_node is not None:
        if "Spot" in eq_node:
            spot = float(eq_node["Spot"])
        if eq_node.get("Interest_Rate"):
            repo_rate = eq_node["Interest_Rate"]

    info = AutocallDealInfo(
        reference=deal.get("Reference", ""),
        object_type=object_type,
        currency=currency,
        payoff_currency=payoff_currency,
        equity=equity,
        discount_rate=discount_rate,
        equity_volatility=equity_volatility,
        dividends=dividends,
        expiry_date=_deal_ts(deal["Expiry_Date"]),
        spot=spot,
        discount_factor=f"InterestRate.{discount_rate}",
        dividend_factor=f"DividendRate.{dividends}",
        equity_vol_factor=f"EquityPriceVol.{equity_volatility}",
        repo_factor=f"InterestRate.{repo_rate}",
    )
    return swap, info
