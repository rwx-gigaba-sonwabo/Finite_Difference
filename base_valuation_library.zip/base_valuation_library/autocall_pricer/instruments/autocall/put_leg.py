"""The put leg of an autocallable swap when it is booked as separate option deals.

The booking
-----------
One autocallable swap comes with four option deals in the same trade file:

==========================  ========================================================
Deal type                   What it is
==========================  ========================================================
EquityOptionDeal            European put, sold. Strike below the initial level.
EquityBarrierOption         Up and in put, bought. Same strike and size. Its barrier
                            is the autocall level, checked on the coupon dates.
EquityBinaryOption          European cash digital put, sold. Same strike.
EquityBarrierBinaryOption   Up and in cash digital put, bought. Same strike, barrier
                            and dates.
==========================  ========================================================

A European option plus its up and in partner is an up and out option. The put is only alive
on paths that never closed above the autocall level on a coupon date, which are the paths
on which the swap was never called. The two pairs together give the full loss of the note
below the strike.

How each deal is valued here
----------------------------
European put and European digital put
    Closed form with the Black model on the forward price, with the volatility read at the
    strike. With a digital strike spread above zero the digital is valued as a spread of
    two puts, each with the volatility at its own strike, so the slope of the smile is
    included.
Up and in put and up and in digital put
    Monte Carlo simulation. The equity is simulated on the future barrier dates and the
    expiry with the volatility read at the option's own strike. A path counts as knocked in
    when it closes above the barrier on a barrier date. Barrier dates in the past use the
    observed closing level in the deal. With a digital strike spread above zero the up and
    in digital is valued as a spread of two up and in puts.

Each pair is reported in two ways that estimate the same number: both deals from the
simulation, and the closed form European plus the simulated up and in option. The second
has less noise.

What is supported
-----------------
Put options, up and in barriers checked on listed dates, cash digitals, no cash rebate, a
payout in the equity's own currency or a quanto payout, and a continuous dividend yield.
Anything else stops with an error that names the unsupported term.
"""

from __future__ import annotations

import json
import math
import warnings
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np

from autocall_pricer.instruments.autocall.compare import compare
from autocall_pricer.models.analytics import black76, black76_d1_d2, norm_cdf

_VANILLA = "EquityOptionDeal"
_DIGITAL = "EquityBinaryOption"
_VANILLA_CONTRA = "EquityBarrierOption"
_DIGITAL_CONTRA = "EquityBarrierBinaryOption"
_OBJECTS = (_VANILLA, _DIGITAL, _VANILLA_CONTRA, _DIGITAL_CONTRA)


# ============================================================================== booking
@dataclass
class BookedOption:
    """One of the four option deals, as booked."""

    object_type: str
    reference: str
    sign: float                    # +1 Buy, -1 Sell
    size: float                    # Units (vanilla legs) | Payoff / Cash_Payoff (digital legs)
    strike: float
    expiry: date
    pay_date: date                 # Settlement_Date if booked, else expiry
    mtm: Optional[float]           # the JSON's own MtM field, reference only
    barrier: Optional[float] = None
    barrier_rows: List[Tuple[date, Optional[float]]] = field(default_factory=list)
    # the deal's own Settlement_Date: a KNOCKED-IN contra becomes the European it now is, settled
    # there (else at expiry)
    settlement: Optional[date] = None

    @property
    def is_contra(self) -> bool:
        return self.object_type in (_VANILLA_CONTRA, _DIGITAL_CONTRA)

    @property
    def knocked_in_pay_date(self) -> date:
        """Date this deal is discounted from once it has knocked in (a contra), else pay_date."""
        return (self.settlement or self.expiry) if self.is_contra else self.pay_date


@dataclass
class PutLegBooking:
    """The put leg's booked deals plus the market-factor keys they price off."""

    vanilla: BookedOption
    vanilla_contra: BookedOption
    digital: Optional[BookedOption]
    digital_contra: Optional[BookedOption]
    equity: str
    payoff_type: str               # "Vanilla" | "Quanto"
    spot: Optional[float]
    discount_factor: str
    dividend_factor: str
    equity_vol_factor: str
    repo_factor: str
    warnings: List[str] = field(default_factory=list)

    @property
    def deals(self) -> List[BookedOption]:
        return [d for d in (self.vanilla, self.vanilla_contra, self.digital, self.digital_contra)
                if d is not None]

    @property
    def expiry(self) -> date:
        return self.vanilla.expiry


def _ts(node: Any) -> date:
    if isinstance(node, dict) and ".Timestamp" in node:
        return date.fromisoformat(node[".Timestamp"][:10])
    if isinstance(node, str):
        return date.fromisoformat(node[:10])
    raise ValueError(f"not a timestamp node: {node!r}")


def _barrier_rows(rows: Sequence) -> List[Tuple[date, Optional[float]]]:
    """Barrier monitoring rows: a bare date, or [date, Observed]; an
    Observed of '' / None reads blank."""
    out = []
    for row in rows or []:
        if isinstance(row, (list, tuple)):
            obs = row[1] if len(row) > 1 and row[1] not in ("", None) else None
            out.append((_ts(row[0]), None if obs is None else float(obs)))
        else:
            out.append((_ts(row), None))
    return out


def _find_deals(node: Any) -> List[Dict[str, Any]]:
    found: List[Dict[str, Any]] = []
    if isinstance(node, dict):
        deal = node.get(".Deal")
        if isinstance(deal, dict) and deal.get("Object") in _OBJECTS:
            found.append(deal)
        for v in node.values():
            found.extend(_find_deals(v))
    elif isinstance(node, list):
        for v in node:
            found.extend(_find_deals(v))
    return found


def _pick(deals, object_type, stem, references, required):
    ref = (references or {}).get(object_type)
    pool = [d for d in deals if d.get("Object") == object_type]
    if ref is not None:
        pool = [d for d in pool if d.get("Reference") == ref]
    elif stem:
        pool = [d for d in pool if stem in str(d.get("Reference", ""))]
    if len(pool) > 1:
        raise ValueError(
            f"{len(pool)} {object_type} deals match: {[d.get('Reference') for d in pool]}, "
            f"narrow reference_stem or name it in references={{'{object_type}': ...}}")
    if not pool:
        if required:
            raise ValueError(f"no {object_type} deal found"
                             + (f" with Reference containing {stem!r}" if stem else ""))
        return None
    return pool[0]


def _booked(deal: Dict[str, Any]) -> BookedOption:
    obj = deal["Object"]
    ref = deal.get("Reference", "")
    if deal.get("Option_Type", "Put") != "Put":
        raise NotImplementedError(f"{ref}: Option_Type {deal.get('Option_Type')!r}; only Put")
    if obj == _DIGITAL and str(deal.get("Payoff_Style", "Cash")).lower() != "cash":
        raise NotImplementedError(f"{ref}: Payoff_Style {deal.get('Payoff_Style')!r}; only Cash")
    if obj in (_VANILLA_CONTRA, _DIGITAL_CONTRA):
        if deal.get("Barrier_Type") != "Up_And_In":
            raise NotImplementedError(
                f"{ref}: Barrier_Type {deal.get('Barrier_Type')!r}; only Up_And_In (the autocall "
                f"contra) is supported")
        if float(deal.get("Cash_Rebate", 0.0) or 0.0) != 0.0:
            raise NotImplementedError(f"{ref}: Cash_Rebate != 0 is not supported")
        if not deal.get("Barrier_Dates"):
            raise NotImplementedError(
                f"{ref}: no Barrier_Dates, a continuously monitored contra is not supported")
    size_field = {_VANILLA: "Units", _VANILLA_CONTRA: "Units",
                  _DIGITAL: "Payoff", _DIGITAL_CONTRA: "Cash_Payoff"}[obj]
    expiry = _ts(deal["Expiry_Date"])
    settle = deal.get("Settlement_Date")
    mtm = deal.get("MtM")
    return BookedOption(
        object_type=obj,
        reference=ref,
        sign=1.0 if str(deal.get("Buy_Sell", "Buy")).lower().startswith("b") else -1.0,
        size=float(deal.get(size_field, 0.0) or 0.0),
        strike=float(deal["Strike_Price"]),
        expiry=expiry,
        # the barrier pricers discount to the last observation (= expiry); the Europeans to
        # their Settlement_Date when booked
        pay_date=_ts(settle) if settle and obj in (_VANILLA, _DIGITAL) else expiry,
        mtm=None if mtm is None else float(mtm),
        barrier=float(deal["Barrier_Price"]) if "Barrier_Price" in deal else None,
        barrier_rows=_barrier_rows(deal.get("Barrier_Dates")),
        settlement=_ts(settle) if settle else None,
    )


def load_put_leg_booking(json_path: Union[str, Path], reference_stem: Optional[str] = None,
                         references: Optional[Dict[str, str]] = None) -> PutLegBooking:
    """Find the put leg's option deals in the trade JSON file.

    ``reference_stem`` (e.g. "ZARFNIB19-BSD3E") keeps deals whose Reference contains it; with
    no stem a JSON holding exactly one deal of each type needs nothing. ``references`` names a
    deal per Object explicitly and wins over the stem. The vanilla pair is required; the digital
    pair is optional but must come as a pair.

    Inconsistencies across the deals (strike, units/payoff, expiry, barrier, dates, signs) are
    collected in ``booking.warnings`` and warned, not refused, the deals are priced as booked.
    """
    blob = json.loads(Path(json_path).read_text())
    try:
        deals = _find_deals(blob["Calc"]["Deals"])
    except KeyError:
        raise ValueError(f"{json_path}: not the trade JSON file (no Calc.Deals)") from None

    raw = {obj: _pick(deals, obj, reference_stem, references, obj in (_VANILLA, _VANILLA_CONTRA))
           for obj in _OBJECTS}
    if (raw[_DIGITAL] is None) != (raw[_DIGITAL_CONTRA] is None):
        missing = _DIGITAL if raw[_DIGITAL] is None else _DIGITAL_CONTRA
        raise ValueError(f"the digital pair is incomplete: no {missing} deal found")

    base = raw[_VANILLA]
    for d in raw.values():
        if d is None:
            continue
        for key in ("Equity", "Payoff_Type", "Payoff_Currency", "Discount_Rate"):
            if d.get(key) != base.get(key):
                raise ValueError(f"{d.get('Reference')}: {key}={d.get(key)!r} differs from the "
                                 f"vanilla's {base.get(key)!r}, these deals price off one market")
    payoff_type = {"Standard": "Vanilla", None: "Vanilla"}.get(base.get("Payoff_Type"),
                                                            base.get("Payoff_Type"))
    if payoff_type not in ("Vanilla", "Quanto"):
        raise NotImplementedError(f"Payoff_Type {payoff_type!r}; only Vanilla/Quanto")

    booked = {obj: (_booked(d) if d is not None else None) for obj, d in raw.items()}
    v, vc, dg, dc = (booked[o] for o in (_VANILLA, _VANILLA_CONTRA, _DIGITAL, _DIGITAL_CONTRA))

    notes: List[str] = []

    def check(cond, msg):
        if not cond:
            notes.append(msg)

    for e, c in ((v, vc), (dg, dc)):
        if e is None:
            continue
        check(c.sign == -e.sign, f"{c.reference} is not the opposite side of {e.reference}")
        check(math.isclose(c.size, e.size, rel_tol=1e-9),
              f"{c.reference} size {c.size:,.4f} != {e.reference} size {e.size:,.4f}, the pair "
              f"is NOT a clean up-and-out (a zero contra leaves the European un-knocked-out)")
        check(math.isclose(c.strike, e.strike, rel_tol=1e-12),
              f"{c.reference} strike {c.strike} != {e.reference} strike {e.strike}")
        check(c.expiry == e.expiry, f"{c.reference} expiry {c.expiry} != {e.reference} {e.expiry}")
    if dc is not None:
        check(math.isclose(dc.barrier, vc.barrier, rel_tol=1e-12),
              f"digital contra barrier {dc.barrier} != vanilla contra barrier {vc.barrier}")
        check([d for d, _ in dc.barrier_rows] == [d for d, _ in vc.barrier_rows],
              "the two contras' Barrier_Dates differ")
        check(dg.expiry == v.expiry, f"digital expiry {dg.expiry} != vanilla expiry {v.expiry}")
    for n in notes:
        warnings.warn(n, stacklevel=2)

    equity = base["Equity"]
    discount_rate = base.get("Discount_Rate") or base.get("Currency")
    dividends = base.get("Dividends") or equity
    equity_vol = base.get("Equity_Volatility") or equity
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob.get("MarketData", {}).get("Price Factors", {})
    eq_node = pf.get(f"EquityPrice.{equity}") or {}
    spot = float(eq_node["Spot"]) if "Spot" in eq_node else None
    repo = eq_node.get("Interest_Rate") or discount_rate

    return PutLegBooking(
        vanilla=v, vanilla_contra=vc, digital=dg, digital_contra=dc,
        equity=equity, payoff_type=payoff_type, spot=spot,
        discount_factor=f"InterestRate.{discount_rate}",
        dividend_factor=f"DividendRate.{dividends}",
        equity_vol_factor=f"EquityPriceVol.{equity_vol}",
        repo_factor=f"InterestRate.{repo}",
        warnings=notes,
    )


# ========================================================================= closed forms
def black_put(forward, strike, vol, tau):
    """Undiscounted Black put."""
    return float(black76(forward, strike, vol, tau, w=-1.0))


def digital_put_flat(forward, strike, vol, tau):
    """Undiscounted cash-or-nothing put, N(-d2), the closed form at sigma(K)."""
    _, d2 = black76_d1_d2(forward, strike, vol, tau)
    return float(norm_cdf(-d2))


def digital_put_spread(forward, strike, eps, vol_lo, vol_hi, tau):
    """Digital put valued as a strike spread, undiscounted:
    w * (V(K(1-eps)) - V(K(1+eps))) / (2 eps) / K with w = -1, each put at its OWN vol."""
    lo = black_put(forward, strike * (1.0 - eps), vol_lo, tau)
    hi = black_put(forward, strike * (1.0 + eps), vol_hi, tau)
    return (hi - lo) / (2.0 * eps * strike)


# ============================================================================== pricing
@dataclass
class LegResult:
    """One up-and-out leg (a European + its Up_And_In contra), in currency."""

    label: str
    european_cf: float             # the booked European in closed form, under the leg's method:
                                   # flat Black, or the spread digital ("per_barrier_date"/"consistent")
    european_mc: float             # the European off the MC paths (its payoff under the method)
    european_mc_se: float
    contra_mc: float               # the booked Up_And_In contra, MC (its payoff under the method)
    contra_mc_se: float
    uo_mc: float                   # European + contra, both MC, on the same paths
    uo_mc_se: float
    skew_delta: float              # "per_barrier_date" only: closed-form spread - flat on the EUROPEAN
    european_booked_mtm: Optional[float] = None
    contra_booked_mtm: Optional[float] = None
    # "per_barrier_date" only, and only where the contra has ALREADY knocked in: it is then valued
    # as the European digital it became, under that type's spread, the same correction
    contra_skew_delta: float = 0.0

    @property
    def uo(self) -> float:
        """THE number to compare: full MC + the closed-form corrections."""
        return self.uo_mc + self.skew_delta + self.contra_skew_delta

    @property
    def uo_se(self) -> float:
        return self.uo_mc_se

    @property
    def uo_parity(self) -> float:
        """Cross-check: closed-form European + MC contra, with lower noise."""
        return self.european_cf + self.contra_mc + self.contra_skew_delta

    @property
    def uo_parity_se(self) -> float:
        return self.contra_mc_se


@dataclass
class PutLegResult:
    vanilla: LegResult
    digital: Optional[LegResult]
    grid_dates: List[date]
    grid_times: np.ndarray
    is_monitor: np.ndarray         # [n_grid] bool, a future Barrier_Date
    strip_vols: np.ndarray         # sigma(K, t_j) the strip is built from
    mean_spot: np.ndarray          # E[S_j] off the paths
    forwards: np.ndarray           # quanto-bent forward F(t_j)
    prob_knocked_out: float        # P(any monitored close > barrier), incl. already-observed
    already_hit: bool
    quanto_adj: float
    digital_spread: float
    n_paths: int
    total_se: float                # SE of the summed per-path payoff (both legs share the paths)
    digital_method: str = "flat"   # see DIGITAL_METHODS ("custom" where the two eps differ)
    contra_spread: float = 0.0     # the contra's eps (digital_spread is the European's)

    @property
    def total(self) -> float:
        return self.vanilla.uo + (self.digital.uo if self.digital else 0.0)


def _se(x: np.ndarray) -> float:
    return float(x.std(ddof=1) / math.sqrt(x.size)) if x.size > 1 else 0.0


#: How the digitals' smile slope is treated. `Relative_Digital_Spread` is set PER DEAL
#: TYPE, so the European digital (EquityBinaryOption) and its
#: contra (EquityBarrierBinaryOption) each take an eps of their own; the three configurations:
#:   "flat"      0 / 0   every digital the flat indicator 1{S_T < K} on the K strip
#:   "european"  eps / 0 the closed-form spread on the European digital only, the contra flat (and,
#:                       once knocked in, the spread European digital it folds into)
#:   "both"      eps / eps  the contra too: a strike spread of up-and-in PUTS at K(1 -+ eps), each
#:                       strike on ITS OWN strip deciding its own knock-in, one shared draw,
#:                       so the digital is consistent with its own barrier-put prices
#: Legacy names: "per_barrier_date" = "european", "consistent" = "both".
DIGITAL_METHODS = ("flat", "european", "both")
_METHOD_ALIASES = {"consistent": "both"}


def _method_label(e_eps: float, c_eps: float) -> str:
    if e_eps == 0.0 and c_eps == 0.0:
        return "flat"
    if c_eps == 0.0:
        return "european"
    return "both" if e_eps == c_eps else "custom"


def price_put_leg(booking: PutLegBooking, mkt, engine, *,
                  european_spread: Optional[float] = None, contra_spread: Optional[float] = None,
                  digital_spread: float = 0.0, digital_method: Optional[str] = None,
                  european_forward_date: Optional[date] = None,
                  ) -> PutLegResult:
    """Price the booked put leg on one fixed-strike GBM path set.

    ``mkt`` is an EquityMarketData whose valuation_date is the valuation date of the trade file; ``engine`` a
    GBMEngine carrying the n_paths/seed/RNG and, for a Quanto booking, the quanto_adj (ATM
    -rho sigma_S sigma_FX at this booking's expiry).

    ``european_spread`` / ``contra_spread`` are the two `Relative_Digital_Spread` options:
    the one set on EquityBinaryOption and the one on EquityBarrierBinaryOption (0 = off). Where
    neither is given, the legacy pair (``digital_method``, ``digital_spread``) is read instead,
    see DIGITAL_METHODS; with no method, eps > 0 means "european" and eps = 0 "flat".

    The vanilla leg is the same under every setting: a vanilla is no strike-derivative, and
    sigma(K, T) already prices it exactly.

    ``european_forward_date`` moves the forward price used by the closed form of the two
    European options. By default the forward is carried to the expiry date. When a later date
    is given, for example the expiry plus a settlement lag, the forward is carried to that
    date. The volatility time and the discounting are not changed, and neither are the
    simulated paths.
    """
    val = mkt.valuation_date
    v, vc, dg, dc = booking.vanilla, booking.vanilla_contra, booking.digital, booking.digital_contra
    if booking.expiry <= val:
        raise ValueError(f"the put leg expired on {booking.expiry} (valuation date {val})")
    if european_spread is not None or contra_spread is not None:
        e_eps, c_eps = float(european_spread or 0.0), float(contra_spread or 0.0)
    else:
        method = _METHOD_ALIASES.get(digital_method, digital_method) or (
            "european" if digital_spread > 0.0 else "flat")
        if method not in DIGITAL_METHODS:
            raise ValueError(f"digital_method must be one of {DIGITAL_METHODS} (or a legacy "
                             f"alias {tuple(_METHOD_ALIASES)}), got {digital_method!r}")
        if method != "flat" and not 0.0 < digital_spread < 1.0:
            raise ValueError(f"digital_method {method!r} needs digital_spread in (0, 1), got "
                             f"{digital_spread}")
        e_eps = 0.0 if method == "flat" else float(digital_spread)
        c_eps = float(digital_spread) if method == "both" else 0.0
    for name, eps in (("european_spread", e_eps), ("contra_spread", c_eps)):
        if not 0.0 <= eps < 1.0:
            raise ValueError(f"{name} must be in [0, 1), got {eps}")

    strike, barrier = vc.strike, vc.barrier
    if dc is not None and not math.isclose(dc.strike, strike, rel_tol=1e-12):
        raise NotImplementedError("the two contras have different strikes, they would need "
                                  "two strips; not supported")

    # --- monitoring: observed rows are resolved up front, the rest by simulation -------
    already_hit = False
    future: List[date] = []
    for d, observed in vc.barrier_rows:
        if d > booking.expiry:
            warnings.warn(f"Barrier_Date {d} is after expiry {booking.expiry}; ignored")
            continue
        if d <= val:
            if observed is None:
                raise ValueError(
                    f"{vc.reference}: Barrier_Date {d} is on/before the valuation date {val} and "
                    f"its Observed close is blank. A missing fixing is not a missed barrier. "
                    f"Author the close")
            if observed == 0.0:
                warnings.warn(f"{vc.reference}: Barrier_Date {d} is past and its Observed close is "
                              f"0.0, read as a real close of 0 (never above the barrier). "
                              f"Almost certainly a placeholder")
            already_hit |= observed >= barrier
        else:
            future.append(d)

    grid_dates = sorted(set(future) | {booking.expiry})
    times = np.array([mkt.yearfrac(d) for d in grid_dates])
    is_monitor = np.array([d in set(future) for d in grid_dates])
    # the contra's spread legs walk K(1 -+ eps) strips off the SAME draw as the K strip, so the K
    # paths, and every flat number, are bit-identical whatever the setting. A contra already
    # knocked in has folded into the European it became and walks nothing of its own
    contra_strips = c_eps > 0.0 and dg is not None and not already_hit
    k_lo, k_hi = strike * (1.0 - c_eps), strike * (1.0 + c_eps)
    strips = engine.simulate_at_strikes(times, mkt, [strike, k_lo, k_hi] if contra_strips
                                        else [strike])
    paths = strips[0]
    n = paths.shape[0]

    def knocked_in(p):
        return np.full(n, already_hit) | (p[:, is_monitor] > barrier).any(axis=1)

    S_T, hit = paths[:, -1], knocked_in(paths)

    T = mkt.yearfrac(booking.expiry)
    q_adj = float(getattr(engine, "quanto_adj", 0.0))
    fwd_T = mkt.forward(T) * math.exp(q_adj * T)
    # forward used by the closed form of the European options, carried to a later date if asked
    T_fwd = T if european_forward_date is None else mkt.yearfrac(european_forward_date)
    fwd_cf = mkt.forward(T_fwd) * math.exp(q_adj * T_fwd)
    sig_K = mkt.vol(expiry=T, moneyness=mkt.spot / strike)
    df = lambda d: mkt.df(mkt.yearfrac(d))                                  # noqa: E731

    def contra_df(contra):
        # a contra already knocked in IS its European, settled on that deal's settlement date
        return df(contra.knocked_in_pay_date if already_hit else contra.pay_date)

    def leg(label, euro, contra, e_payoff, c_payoff, cf_unit):
        """The booked pair on the paths: each deal its own sign, size and discount date."""
        df_e, df_c = df(euro.pay_date), contra_df(contra)
        e_path = euro.sign * euro.size * e_payoff * df_e
        c_path = contra.sign * contra.size * c_payoff * df_c
        return e_path, c_path, LegResult(
            label=label,
            european_cf=euro.sign * euro.size * cf_unit * df_e,
            european_mc=float(e_path.mean()), european_mc_se=_se(e_path),
            contra_mc=float(c_path.mean()), contra_mc_se=_se(c_path),
            uo_mc=float((e_path + c_path).mean()), uo_mc_se=_se(e_path + c_path),
            skew_delta=0.0,
            european_booked_mtm=euro.mtm, contra_booked_mtm=contra.mtm,
        )

    put_T = np.maximum(v.strike - S_T, 0.0)
    v_e, v_c, van = leg("up-and-out vanilla put", v, vc, put_T, put_T * hit,
                        black_put(fwd_cf, v.strike, sig_K, T))
    total_path = v_e + v_c

    def spread_digital(eps):
        """Closed-form spread digital put at relative half-width eps, undiscounted."""
        vol_lo = mkt.vol(expiry=T, moneyness=mkt.spot / (dg.strike * (1.0 - eps)))
        vol_hi = mkt.vol(expiry=T, moneyness=mkt.spot / (dg.strike * (1.0 + eps)))
        return digital_put_spread(fwd_cf, dg.strike, eps, vol_lo, vol_hi, T)

    dig = None
    if dg is not None:
        flat = digital_put_flat(fwd_cf, dg.strike, sig_K, T)
        e_cf = spread_digital(e_eps) if e_eps > 0.0 else flat
        ind = (S_T < dg.strike).astype(float)
        e_payoff, e_adjust = ind, (e_cf - flat)             # flat MC + closed-form correction
        if contra_strips:
            # 1{S_T<K} 1{hit} = d/dK [(K - S_T)^+ 1{hit}]: the contra as a strike spread of
            # up-and-in PUTS, each strike on its own strip (strips[1], strips[2]) deciding its own
            # knock-in
            lo, hi = strips[1], strips[2]
            put_lo, put_hi = np.maximum(k_lo - lo[:, -1], 0.0), np.maximum(k_hi - hi[:, -1], 0.0)
            width = 2.0 * c_eps * dg.strike
            c_payoff = (put_hi * knocked_in(hi) - put_lo * knocked_in(lo)) / width
            if e_eps == c_eps:
                # the European on the SAME strike-spread paths: its MC converges to the closed
                # form and pairs path by path with the contra, the lower-noise up-and-out
                e_payoff, e_adjust = (put_hi - put_lo) / width, 0.0
        else:
            c_payoff = ind * hit
        d_e, d_c, dig = leg("up-and-out digital put", dg, dc, e_payoff, c_payoff, e_cf)
        dig.skew_delta = dg.sign * dg.size * df(dg.pay_date) * e_adjust
        if already_hit and e_eps > 0.0:
            # a knocked-in contra IS the European digital it became, so it takes
            # the European's eps, not its own
            dig.contra_skew_delta = dc.sign * dc.size * contra_df(dc) * (e_cf - flat)
        total_path = total_path + d_e + d_c

    res = PutLegResult(
        vanilla=van, digital=dig,
        grid_dates=grid_dates, grid_times=times, is_monitor=is_monitor,
        strip_vols=np.array([mkt.vol(expiry=float(t), moneyness=mkt.spot / strike) for t in times]),
        mean_spot=paths.mean(axis=0),
        forwards=np.array([mkt.forward(float(t)) * math.exp(q_adj * float(t)) for t in times]),
        prob_knocked_out=float(hit.mean()), already_hit=already_hit,
        quanto_adj=q_adj, digital_spread=e_eps, n_paths=n,
        total_se=_se(total_path), digital_method=_method_label(e_eps, c_eps),
        contra_spread=c_eps,
    )
    return res


# ======================================================= autocall-script integration helpers
def without_put(payoff_kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """evaluate_autocall_paths kwargs with the swap's own put switched off, for pricing the
    swap alongside a separately booked put leg (PUT_LEG_MODE = "booking")."""
    out = dict(payoff_kwargs)
    out["is_barrier_date"] = np.zeros_like(np.asarray(out["is_barrier_date"], dtype=bool))
    out["put_barrier"] = 0.0
    return out


def check_swap_against_booking(schedule, booking: PutLegBooking) -> List[str]:
    """What a separately booked put leg should agree with in the swap: no put of its own
    (else it is counted twice), contras monitored on the prints the swap's autocall reads (each
    coupon's fixing, `PayoffSchedule.trigger_observation_dates`) at the trigger level."""
    notes = []
    if float(getattr(schedule, "put_barrier", 0.0) or 0.0) > 0.0 and np.any(schedule.is_barrier_date):
        notes.append(f"the swap deal carries its own put (barrier {schedule.put_barrier:g}), "
                     f"booking mode DROPS it so the put is not counted twice. Check that the "
                     f"swap deal being compared has Barrier 0, or that its value includes the put as well")
    coupon = np.asarray(schedule.is_coupon_date, dtype=bool)
    # what the contras must monitor is what the swap's autocall READS: each coupon's fixing,
    # not its payment date
    observed = (schedule.trigger_observation_dates if hasattr(schedule, "trigger_observation_dates")
                else [d for d, c in zip(schedule.obs_dates, coupon) if c])
    # the schedule holds future dates only, so compare like with like
    future_contra = sorted(d for d, _ in booking.vanilla_contra.barrier_rows
                           if d >= min(schedule.obs_dates))
    if sorted(observed) != future_contra:
        notes.append(f"contra Barrier_Dates {[d.isoformat() for d in future_contra]} != the swap's "
                     f"autocall observation dates {[d.isoformat() for d in sorted(observed)]}, "
                     f"the booked put would knock out on different prints than the swap calls on")
    levels = sorted(set(np.round(np.asarray(schedule.thresholds)[coupon] * schedule.strike, 6)))
    if any(not math.isclose(lv, booking.vanilla_contra.barrier, rel_tol=1e-6) for lv in levels):
        notes.append(f"contra Barrier_Price {booking.vanilla_contra.barrier:g} vs the swap's "
                     f"trigger levels {levels}, one barrier cannot follow a stepped ladder; "
                     f"the booking (priced here) and the swap's own autocall then disagree")
    for n in notes:
        warnings.warn(n, stacklevel=2)
    return notes


# ================================================================================ report
def print_put_leg_report(res: PutLegResult, booking: PutLegBooking,
                         comparison_uo_vanilla: Optional[float] = None,
                         comparison_uo_digital: Optional[float] = None) -> None:
    """The put leg's table, the same in every validate script."""
    import pandas as pd

    print("-" * 72)
    print("PUT LEG (as booked: European + Up_And_In contra per leg = up-and-out)")
    for d in booking.deals:
        extra = f"  barrier {d.barrier:,.4f}" if d.barrier is not None else ""
        mtm = f"  JSON MtM {d.mtm:,.2f}" if d.mtm is not None else ""
        print(f"  {d.object_type:<26} {'Buy ' if d.sign > 0 else 'Sell'} size {d.size:,.4f}  "
              f"K {d.strike:,.4f}{extra}  pay {d.pay_date}{mtm}")
        print(f"      {d.reference}")
    for w in booking.warnings:
        print(f"  WARNING: {w}")
    sched = pd.DataFrame({
        "date": [d.isoformat() for d in res.grid_dates],
        "t": np.round(res.grid_times, 4),
        "monitored": res.is_monitor,
        "sigma(K,t)": np.round(res.strip_vols, 6),
        "forward": np.round(res.forwards, 4),
        "E[S]": np.round(res.mean_spot, 4),
    })
    sched["fwd_err"] = (sched["E[S]"] - sched["forward"]).round(4)
    print(f"Strip at K={booking.vanilla_contra.strike:,.4f}; quanto_adj={res.quanto_adj:+.6f}/yr; "
          f"paths {res.n_paths:,}")
    print(sched.to_string(index=False))
    print(f"P(knocked out)      : {res.prob_knocked_out:8.3%}"
          + ("  (ALREADY HIT on an observed date)" if res.already_hit else ""))
    print(f"Digital skew        : {res.digital_method!r}, Relative_Digital_Spread "
          f"EquityBinaryOption = {res.digital_spread:g}, EquityBarrierBinaryOption = "
          f"{res.contra_spread:g}")

    rows = []
    for lg in (res.vanilla, res.digital):
        if lg is None:
            continue
        rows.append({
            "leg": lg.label,
            "European CF": f"{lg.european_cf:,.2f}",
            "European MC": f"{lg.european_mc:,.2f} +/- {lg.european_mc_se:,.0f}",
            "contra MC": f"{lg.contra_mc:,.2f} +/- {lg.contra_mc_se:,.0f}",
            "skew adj": f"{lg.skew_delta + lg.contra_skew_delta:,.2f}",
            "UO (MC+adj)": f"{lg.uo:,.2f} +/- {lg.uo_se:,.0f}",
            "UO parity": f"{lg.uo_parity:,.2f} +/- {lg.uo_parity_se:,.0f}",
        })
    print(pd.DataFrame(rows).to_string(index=False))
    print(f"Put leg total (MC+adj): {res.total:,.2f} +/- {res.total_se:,.2f}")

    for lg, rf in ((res.vanilla, comparison_uo_vanilla), (res.digital, comparison_uo_digital)):
        if lg is not None and rf is not None:
            compare(lg.label, lg.uo, lg.uo_se, rf)
            compare(lg.label + " (parity)", lg.uo_parity, lg.uo_parity_se, rf)
    if comparison_uo_vanilla is not None and (res.digital is None or comparison_uo_digital is not None):
        compare("put leg total", res.total, res.total_se,
                comparison_uo_vanilla + (comparison_uo_digital or 0.0))


def compare_digital_methods(booking: PutLegBooking, mkt, engine, digital_spread: float,
                            comparison_flat: Optional[float] = None,
                            comparison_european: Optional[float] = None,
                            comparison_both: Optional[float] = None,
                            comparison_spread: Optional[float] = None) -> Dict[str, PutLegResult]:
    """The three configurations of the two `Relative_Digital_Spread` options on the SAME
    draws, and the up-and-out digital's table.

    ``comparison_flat`` is the comparison value of digital + digital contra with both options 0,
    ``comparison_european`` with eps on EquityBinaryOption only (``comparison_spread`` is its legacy
    name), ``comparison_both`` with eps on both deal types.
    """
    import pandas as pd

    comparison_european = comparison_european if comparison_european is not None else comparison_spread
    eps = digital_spread
    settings = {"flat": (0.0, 0.0), "european": (eps, 0.0), "both": (eps, eps)}
    results = {m: price_put_leg(booking, mkt, engine, european_spread=e, contra_spread=c)
               for m, (e, c) in settings.items()}
    if booking.digital is None:
        print("no digital pair booked, the three settings coincide")
        return results
    targets = {"flat": comparison_flat, "european": comparison_european, "both": comparison_both}
    rows = []
    for m, res in results.items():
        lg, rf = res.digital, targets[m]
        e, c = settings[m]
        rows.append({
            "setting": m, "eps (Binary / BarrierBinary)": f"{e:g} / {c:g}",
            "UO digital (MC+adj)": f"{lg.uo:,.2f} +/- {lg.uo_se:,.0f}",
            "UO parity": f"{lg.uo_parity:,.2f} +/- {lg.uo_parity_se:,.0f}",
            "comparison": "" if rf is None else f"{rf:,.2f}",
            "z": "" if rf is None else f"{abs(lg.uo - rf) / lg.uo_se:.2f}" if lg.uo_se else "inf",
        })
    print("-" * 72)
    print("DIGITAL SKEW: the three spread configurations on one draw (vanilla leg identical)")
    print(pd.DataFrame(rows).to_string(index=False))
    flat, eur, both = (results[m].digital.uo_parity for m in ("flat", "european", "both"))
    print(f"  skew on the European only (european - flat): {eur - flat:+,.2f}")
    print(f"  skew on both deals        (both - flat)    : {both - flat:+,.2f}")
    print(f"  contra skew               (european - both): {eur - both:+,.2f}  (what spreading the "
          f"European alone {'over' if eur > both else 'under'}values the booked side by")
    return results
