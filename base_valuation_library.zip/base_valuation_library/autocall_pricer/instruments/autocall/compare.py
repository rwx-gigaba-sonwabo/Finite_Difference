"""Comparison of a simulated value with a second value for the same trade.

A simulated value carries sampling noise, so a difference only means something when it is
larger than that noise. The comparison reports the difference, the relative difference and
the z score. The z score is the difference divided by the standard error of the simulated
value. A z score of up to about 3 or 4 is in line with agreement.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Comparison:
    label: str
    ours_pv: float
    ours_std_error: float
    comparison_pv: float

    @property
    def diff(self) -> float:
        return self.ours_pv - self.comparison_pv

    @property
    def rel_diff(self) -> float:
        return self.diff / self.comparison_pv if self.comparison_pv else float("nan")

    @property
    def z_score(self) -> float:
        """|diff| in units of our MC standard error."""
        return abs(self.diff) / self.ours_std_error if self.ours_std_error > 0 else float("inf")

    def consistent(self, z_tol: float = 4.0) -> bool:
        return self.z_score <= z_tol

    def report(self) -> str:
        flag = "OK " if self.consistent() else "*** "
        return (
            f"{flag}{self.label:<28}  library {self.ours_pv:14,.4f} +/- {self.ours_std_error:.4f}  "
            f"| comparison {self.comparison_pv:14,.4f}  | diff {self.diff:+.4f} "
            f"({self.rel_diff:+.3%})  z={self.z_score:.2f}"
        )


def compare(label: str, ours_pv: float, ours_std_error: float, comparison_pv: float) -> Comparison:
    """Build a Comparison and print its one-line report."""
    c = Comparison(label, ours_pv, ours_std_error, comparison_pv)
    print(c.report())
    return c


def compare_manual_result(label: str, manual_result, comparison_pv: float,
                          use_notional: bool = True) -> Comparison:
    """
    Compare a ManualResult (from manual_pricer.price_manual) against a comparison PV.
    use_notional=True compares PV x notional (the scale of a trade value).
    """
    if use_notional:
        n = manual_result.inputs.buy_sell * manual_result.inputs.units
        return compare(label, manual_result.pv_notional, manual_result.std_error * abs(n), comparison_pv)
    return compare(label, manual_result.pv_unit, manual_result.std_error, comparison_pv)
