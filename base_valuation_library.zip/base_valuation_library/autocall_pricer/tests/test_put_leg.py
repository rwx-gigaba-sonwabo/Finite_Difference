"""
Tests for instruments/autocall/put_leg.py, the autocall put leg priced
(European put + Up_And_In contra, vanilla and digital), and GBMEngine.simulate_at_strike.

Run:  python -m pytest test/autocall/test_put_leg.py -q
"""

import json
import sys
import warnings
from datetime import date
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from autocall_pricer.instruments.autocall.put_leg import (                              # noqa: E402
    BookedOption, PutLegBooking, load_put_leg_booking, price_put_leg, without_put,
    digital_put_flat, digital_put_spread,
)
from autocall_pricer.curve.curve_builders import curve_from_points                  # noqa: E402
from autocall_pricer.market_data.equity_market_data import EquityMarketData             # noqa: E402
from autocall_pricer.market_data.vol_surface import EquityVolSurface                    # noqa: E402
from autocall_pricer.models.gbm import GBMEngine                                        # noqa: E402

VAL = date(2026, 6, 1)
EXPIRY = date(2031, 6, 2)
SETTLE = date(2031, 6, 9)
MONITOR = [date(2027, 6, 2), date(2028, 6, 2), date(2029, 6, 4), date(2030, 6, 3), EXPIRY]
S0, K, B = 100.0, 70.0, 100.0
UNITS, PAYOFF = 1_000.0, 30_000.0


def _curve(r):
    return curve_from_points(VAL, [(0.0, r), (30.0, r)], "Linear")


def _mkt(vol=0.25):
    return EquityMarketData(VAL, S0, discount_curve=_curve(0.07), repo_curve=_curve(0.03),
                            div_curve=_curve(0.02), equity_vol=vol)


def _skew_surface():
    # moneyness = spot/strike: low strikes (high moneyness) carry the higher vol
    rows = []
    for t in (0.5, 2.0, 6.0):
        for m, v in ((0.8, 0.18), (1.0, 0.22), (1.25, 0.28), (1.43, 0.32), (1.7, 0.36)):
            rows.append([m, t, v])
    return EquityVolSurface.from_triples(rows)


def _booking(barrier=B, rows=None, digital_contra_size=PAYOFF):
    rows = rows if rows is not None else [(d, None) for d in MONITOR]

    def opt(obj, sign, size, pay=EXPIRY, barrier_=None, rows_=()):
        return BookedOption(obj, obj, sign, size, K, EXPIRY, pay, None, barrier_, list(rows_))

    return PutLegBooking(
        vanilla=opt("EquityOptionDeal", -1.0, UNITS),
        vanilla_contra=opt("EquityBarrierOption", 1.0, UNITS, barrier_=barrier, rows_=rows),
        digital=opt("EquityBinaryOption", -1.0, PAYOFF, pay=SETTLE),
        digital_contra=opt("EquityBarrierBinaryOption", 1.0, digital_contra_size,
                           barrier_=barrier, rows_=rows),
        equity="EQ", payoff_type="Vanilla", spot=S0, discount_factor="", dividend_factor="",
        equity_vol_factor="", repo_factor="",
    )


def _engine(n=200_000, seed=7):
    return GBMEngine(n_paths=n, seed=seed)


# ------------------------------------------------------------------------------ engine
def test_simulate_at_strike_matches_forward_and_strip_variance():
    mkt = _mkt(_skew_surface())
    times = np.array([mkt.yearfrac(d) for d in MONITOR])
    paths = _engine(400_000).simulate_at_strike(times, mkt, K)
    for j, t in enumerate(times):
        assert paths[:, j].mean() == pytest.approx(mkt.forward(t), rel=3e-3)
    # cumulative log-variance to each date = sigma(K, t)^2 t
    var = np.log(paths).var(axis=0)
    target = [mkt.vol(expiry=t, moneyness=S0 / K) ** 2 * t for t in times]
    np.testing.assert_allclose(var, target, rtol=1e-2)


# ----------------------------------------------------------------------------- pricing
def test_unreachable_barrier_gives_the_european():
    mkt = _mkt()
    res = price_put_leg(_booking(barrier=1e9), mkt, _engine())
    assert res.prob_knocked_out == 0.0
    for lg in (res.vanilla, res.digital):
        assert lg.contra_mc == 0.0
        assert abs(lg.uo - lg.european_cf) < 4 * lg.uo_se
        assert lg.uo_parity == pytest.approx(lg.european_cf)


def test_up_and_out_is_european_plus_contra_per_path():
    res = price_put_leg(_booking(), _mkt(), _engine())
    for lg in (res.vanilla, res.digital):
        assert lg.uo_mc == pytest.approx(lg.european_mc + lg.contra_mc, rel=1e-12)
        assert lg.contra_mc > 0.0 > lg.uo_mc            # long contra, short up-and-out
        assert abs(lg.uo - lg.uo_parity) < 4 * lg.uo_se  # two estimators, one number
    assert 0.0 < res.prob_knocked_out < 1.0


def test_zero_digital_contra_leaves_the_digital_un_knocked_out():
    res = price_put_leg(_booking(digital_contra_size=0.0), _mkt(), _engine())
    assert res.digital.contra_mc == 0.0
    assert res.digital.uo == pytest.approx(res.digital.european_mc)


def test_already_observed_hit_kills_the_leg():
    rows = [(date(2026, 3, 1), 105.0)] + [(d, None) for d in MONITOR]
    res = price_put_leg(_booking(rows=rows), _mkt(), _engine(20_000))
    assert res.already_hit and res.prob_knocked_out == 1.0
    assert res.vanilla.uo == pytest.approx(0.0, abs=1e-6)
    # NOT zero: the digital pays on its Settlement_Date, the contra at expiry, so the knocked-in pair leaves Payoff * P(S_T<K) * (DF_T - DF_settle)
    mkt = _mkt()
    gap = mkt.df(mkt.yearfrac(EXPIRY)) - mkt.df(mkt.yearfrac(SETTLE))
    assert 0.0 < res.digital.uo < PAYOFF * gap


def test_past_blank_observation_is_refused():
    rows = [(date(2026, 3, 1), None)] + [(d, None) for d in MONITOR]
    with pytest.raises(ValueError, match="Observed close is blank"):
        price_put_leg(_booking(rows=rows), _mkt(), _engine(1_000))


# --------------------------------------------------------------------------------- skew
def test_spread_digital_converges_to_flat_on_a_flat_surface():
    F, T = 110.0, 5.0
    flat = digital_put_flat(F, K, 0.25, T)
    assert digital_put_spread(F, K, 1e-4, 0.25, 0.25, T) == pytest.approx(flat, rel=1e-6)
    res = price_put_leg(_booking(), _mkt(0.25), _engine(2_000), digital_spread=0.01)
    assert abs(res.digital.skew_delta) < 1e-3 * PAYOFF


def test_negative_skew_makes_the_short_digital_put_less_negative():
    mkt = _mkt(_skew_surface())
    off = price_put_leg(_booking(), mkt, _engine(2_000))
    on = price_put_leg(_booking(), mkt, _engine(2_000), digital_spread=0.01)
    assert off.digital.skew_delta == 0.0
    assert on.digital.skew_delta > 0.0
    # the skew touches the European digital only: MC numbers are identical
    assert on.digital.uo_mc == off.digital.uo_mc
    assert on.vanilla.uo == off.vanilla.uo


# ------------------------------------------------------------------------- integration
def test_without_put_switches_off_the_swap_put():
    kw = {"is_barrier_date": np.array([False, True]), "put_barrier": 70.0, "strike": 100.0}
    out = without_put(kw)
    assert not out["is_barrier_date"].any() and out["put_barrier"] == 0.0
    assert kw["put_barrier"] == 70.0                     # caller's dict untouched


def _deal(obj, ref, **f):
    return {"Instrument": {".Deal": {"Object": obj, "Reference": ref, "Currency": "EUR",
                                     "Discount_Rate": "ZAR-SWAP", "Payoff_Currency": "ZAR",
                                     "Payoff_Type": "Quanto", "Equity": "EQ",
                                     "Equity_Volatility": "EQ.EUR", "Strike_Price": K,
                                     "Option_Type": "Put",
                                     "Expiry_Date": {".Timestamp": EXPIRY.isoformat()}, **f}}}


def test_loader_reads_the_four_deals(tmp_path):
    rows = [[{".Timestamp": d.isoformat()}, 0.0] for d in MONITOR]
    deals = [
        _deal("EquityOptionDeal", "X-VANILLA-PUT70", Buy_Sell="Sell", Units=UNITS, MtM=-1.0),
        _deal("EquityBarrierOption", "X-VANILLA-PUTCONTRA70", Buy_Sell="Buy", Units=UNITS,
              Barrier_Type="Up_And_In", Barrier_Price=B, Cash_Rebate=0.0, Barrier_Dates=rows),
        _deal("EquityBinaryOption", "X-DIGI-PUT30", Buy_Sell="Sell", Payoff=PAYOFF,
              Payoff_Style="Cash", Settlement_Date={".Timestamp": SETTLE.isoformat()}),
        _deal("EquityBarrierBinaryOption", "X-DIGI-PUTCONTRA30", Buy_Sell="Buy", Cash_Payoff=0.0,
              Barrier_Type="Up_And_In", Barrier_Price=B, Barrier_Dates=rows),
        _deal("EquityOptionDeal", "OTHER-PUT", Buy_Sell="Buy", Units=5.0),
    ]
    blob = {"Calc": {"Deals": {"Deals": {"Children": deals}},
                     "MergeMarketData": {"ExplicitMarketData": {"Price Factors": {
                         "EquityPrice.EQ": {"Spot": S0, "Interest_Rate": "EUR-SWAP"}}}}}}
    path = tmp_path / "job.json"
    path.write_text(json.dumps(blob))

    with pytest.raises(ValueError, match="2 EquityOptionDeal"):
        load_put_leg_booking(path)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        bk = load_put_leg_booking(path, reference_stem="X-")
    assert bk.vanilla.sign == -1.0 and bk.vanilla_contra.sign == 1.0
    assert bk.digital.pay_date == SETTLE and bk.digital_contra.pay_date == EXPIRY
    assert bk.vanilla_contra.barrier_rows[0] == (MONITOR[0], 0.0)
    assert bk.spot == S0 and bk.repo_factor == "InterestRate.EUR-SWAP"
    assert bk.payoff_type == "Quanto" and bk.vanilla.mtm == -1.0
    assert any("NOT a clean up-and-out" in str(w.message) for w in caught)


# ------------------------------------------------------------- the three digital methods
def test_several_strikes_share_one_draw_and_the_first_is_simulate_at_strike():
    mkt = _mkt(_skew_surface())
    times = np.array([mkt.yearfrac(d) for d in MONITOR])
    one = _engine(2_000).simulate_at_strike(times, mkt, K)
    many = _engine(2_000).simulate_at_strikes(times, mkt, [K, K * 0.99, K * 1.01])
    np.testing.assert_array_equal(one, many[0])
    # same z, different strip: the log-returns are proportional draw by draw
    assert np.corrcoef(np.log(many[1][:, 0]), np.log(many[2][:, 0]))[0, 1] > 0.9999


def test_flat_ignores_eps_and_the_default_reads_eps_as_european():
    mkt = _mkt(_skew_surface())
    flat = price_put_leg(_booking(), mkt, _engine(20_000), digital_spread=0.01,
                         digital_method="flat")
    plain = price_put_leg(_booking(), mkt, _engine(20_000))
    assert flat.digital.uo == plain.digital.uo and flat.digital_method == "flat"
    assert price_put_leg(_booking(), mkt, _engine(2_000),
                         digital_spread=0.01).digital_method == "european"
    with pytest.raises(ValueError, match="needs digital_spread"):
        price_put_leg(_booking(), mkt, _engine(2_000), digital_method="consistent")


def test_the_vanilla_leg_is_identical_under_every_method():
    mkt = _mkt(_skew_surface())
    legs = [price_put_leg(_booking(), mkt, _engine(50_000), digital_spread=0.01,
                          digital_method=m).vanilla.uo for m in ("flat", "european", "consistent")]
    assert legs[0] == legs[1] == legs[2]


def test_consistent_european_half_converges_to_the_closed_form_spread():
    res = price_put_leg(_booking(), _mkt(_skew_surface()), _engine(400_000),
                        digital_spread=0.01, digital_method="consistent")
    lg = res.digital
    assert abs(lg.european_mc - lg.european_cf) < 4 * lg.european_mc_se
    assert abs(lg.uo - lg.uo_parity) < 4 * lg.uo_se


def test_consistent_is_flat_on_a_flat_surface():
    mkt = _mkt(0.25)
    flat = price_put_leg(_booking(), mkt, _engine(400_000), digital_method="flat").digital
    cons = price_put_leg(_booking(), mkt, _engine(400_000), digital_spread=0.01,
                         digital_method="consistent").digital
    assert abs(cons.uo_parity - flat.uo_parity) < 4 * (cons.uo_parity_se + flat.uo_parity_se)


def test_on_a_negative_skew_consistent_lies_between_flat_and_european():
    # short digital put: flat overstates the loss, the mixed setting (European spread, contra flat)
    # understates it, the consistent pair sits between
    mkt = _mkt(_skew_surface())
    r = {m: price_put_leg(_booking(), mkt, _engine(400_000), digital_spread=0.01,
                          digital_method=m).digital.uo_parity
         for m in ("flat", "european", "consistent")}
    assert r["flat"] < r["consistent"] < r["european"]


def test_a_knocked_in_contra_folds_into_the_spread_european_under_european_and_consistent():
    rows = [(date(2026, 3, 1), 105.0)] + [(d, None) for d in MONITOR]
    mkt = _mkt(_skew_surface())
    rf = price_put_leg(_booking(rows=rows), mkt, _engine(200_000), digital_spread=0.01,
                       digital_method="european").digital
    cons = price_put_leg(_booking(rows=rows), mkt, _engine(200_000), digital_spread=0.01,
                         digital_method="consistent").digital
    assert rf.contra_skew_delta == pytest.approx(-rf.skew_delta * mkt.df(mkt.yearfrac(EXPIRY))
                                                 / mkt.df(mkt.yearfrac(SETTLE)))
    # the pair cancels to the settlement residue: payoff x P(S_T<K) x (DF_T - DF_settle)
    gap = mkt.df(mkt.yearfrac(EXPIRY)) - mkt.df(mkt.yearfrac(SETTLE))
    for lg in (rf, cons):
        assert 0.0 < lg.uo < PAYOFF * gap
    assert abs(rf.uo_parity - cons.uo_parity) < 4 * (rf.uo_parity_se + cons.uo_parity_se)


def test_a_knocked_in_contra_is_discounted_to_its_own_settlement():
    rows = [(date(2026, 3, 1), 105.0)] + [(d, None) for d in MONITOR]
    bk = _booking(rows=rows)
    bk.vanilla_contra.settlement = SETTLE
    mkt = _mkt()
    res = price_put_leg(bk, mkt, _engine(50_000))
    # vanilla pair: European at expiry, the folded contra at SETTLE, a residue, not zero
    assert res.vanilla.uo != pytest.approx(0.0, abs=1e-6)
    assert res.vanilla.contra_mc == pytest.approx(
        -res.vanilla.european_mc * mkt.df(mkt.yearfrac(SETTLE)) / mkt.df(mkt.yearfrac(EXPIRY)))


def test_compare_digital_methods_prices_all_three_on_one_draw(capsys):
    from autocall_pricer.instruments.autocall.put_leg import compare_digital_methods
    out = compare_digital_methods(_booking(), _mkt(_skew_surface()), _engine(20_000), 0.01,
                                  comparison_flat=-1.0, comparison_spread=-1.0, comparison_both=-1.0)
    assert set(out) == {"flat", "european", "both"}
    assert out["flat"].vanilla.uo == out["both"].vanilla.uo
    assert "contra skew" in capsys.readouterr().out


# ------------------------------------------------- the two per-deal-type spreads
def test_the_two_spreads_map_onto_the_legacy_methods():
    mkt = _mkt(_skew_surface())
    for legacy, (e, c) in (("european", (0.01, 0.0)), ("consistent", (0.01, 0.01))):
        a = price_put_leg(_booking(), mkt, _engine(20_000), digital_spread=0.01,
                          digital_method=legacy).digital
        b = price_put_leg(_booking(), mkt, _engine(20_000), european_spread=e,
                          contra_spread=c).digital
        assert a.uo == b.uo and a.uo_parity == b.uo_parity


def test_a_contra_spread_alone_leaves_the_european_flat():
    mkt = _mkt(_skew_surface())
    flat = price_put_leg(_booking(), mkt, _engine(200_000)).digital
    contra_only = price_put_leg(_booking(), mkt, _engine(200_000), contra_spread=0.01)
    lg = contra_only.digital
    assert contra_only.digital_method == "custom" and lg.skew_delta == 0.0
    assert lg.european_mc == flat.european_mc            # same K strip, same draw
    assert lg.contra_mc != flat.contra_mc                # the contra now spreads


def test_a_knocked_in_contra_folds_under_the_european_spread_not_its_own():
    rows = [(date(2026, 3, 1), 105.0)] + [(d, None) for d in MONITOR]
    mkt = _mkt(_skew_surface())
    # contra eps alone: the folded EquityBinaryOption reads ITS type's option, 0 -> flat
    contra_only = price_put_leg(_booking(rows=rows), mkt, _engine(20_000), contra_spread=0.01)
    flat = price_put_leg(_booking(rows=rows), mkt, _engine(20_000))
    assert contra_only.digital.uo == flat.digital.uo
    assert contra_only.digital.contra_skew_delta == 0.0


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
