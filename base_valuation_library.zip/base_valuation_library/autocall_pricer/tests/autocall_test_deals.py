"""
Shared deal specs for two sided autocall validation.

ONE spec per deal drives BOTH sides:
  - to_trade_file_deal(spec)  -> the ".Deal" node for the trade JSON file
  - to_our_swap(spec)       -> an AutocallSwap for our independent Monte Carlo

so the two pricers cannot silently diverge on inputs.

SWAP COMPONENT ONLY, every deal has Barrier = 0, no Barrier_Dates and no Rebate, so the
terminal/put leg is identically zero. What is being validated is:
  - the contingent COUPON leg (paid once, on the first observation that triggers), and
  - the FLOATING leg (paid while the note is still alive).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional, Sequence, Tuple

# ------------------------------------------------------------------ market (shared)
BASE_DATE = date(2026, 1, 1)
CCY = "ZAR"
EQUITY = "TESTEQ"
DISCOUNT = "ZAR-SWAP"

SPOT = 100.0
STRIKE = 100.0
VOL = 0.25
R = 0.03      # continuous discount / funding rate
Q = 0.015     # continuous dividend yield


def ts(d: date):
    return {".Timestamp": d.isoformat()}


@dataclass
class DealSpec:
    """One autocall (swap component only)."""

    reference: str
    obs_dates: Sequence[date]                 # autocall observation dates
    coupons: Sequence[float]                  # coupon per observation date
    thresholds: Sequence[float]               # autocall trigger as a fraction of strike
    float_schedule: Sequence[Tuple[date, float]] = field(default_factory=list)
    units: float = 1.0
    strike: float = STRIKE
    description: str = ""

    def __post_init__(self):
        n = len(self.obs_dates)
        if len(self.coupons) != n or len(self.thresholds) != n:
            raise ValueError(f"{self.reference}: coupons/thresholds must match obs_dates length")

    @property
    def expiry(self) -> date:
        return max(self.obs_dates)


# ------------------------------------------------------------------ the deal matrix
def _annual(n, start_year=2027):
    return [date(start_year + i, 1, 1) for i in range(n)]


def _semi(n, start=date(2026, 7, 1)):
    out, y, m = [], start.year, start.month
    for _ in range(n):
        out.append(date(y, m, 1))
        m += 6
        if m > 12:
            m -= 12
            y += 1
    return out


DEALS: List[DealSpec] = [
    DealSpec(
        reference="AC_1C",
        obs_dates=_annual(1),
        coupons=[6.0],
        thresholds=[1.00],
        description="baseline: single coupon = closed-form digital D*c*N(d2)",
    ),
    DealSpec(
        reference="AC_3C",
        obs_dates=_annual(3),
        coupons=[6.0] * 3,
        thresholds=[1.00] * 3,
        description="3 annual coupons, flat 100% trigger",
    ),
    DealSpec(
        reference="AC_3C_STEPDOWN",
        obs_dates=_annual(3),
        coupons=[6.0] * 3,
        thresholds=[1.00, 0.95, 0.90],
        description="step-down triggers 100/95/90% - per-date thresholds",
    ),
    DealSpec(
        reference="AC_3C_VARCOUPON",
        obs_dates=_annual(3),
        coupons=[5.0, 6.0, 7.0],
        thresholds=[1.00] * 3,
        description="rising coupons 5/6/7 - per-date coupon amounts",
    ),
    DealSpec(
        reference="AC_1C_FLOAT",
        obs_dates=_annual(1),
        coupons=[6.0],
        thresholds=[1.00],
        float_schedule=[(date(2026, 7, 1), 2.0)],
        description="1 coupon + 1 floating BEFORE it (floating paid with certainty)",
    ),
    DealSpec(
        reference="AC_3C_FLOAT",
        obs_dates=_annual(3),
        coupons=[6.0] * 3,
        thresholds=[1.00] * 3,
        float_schedule=[(d, 2.0) for d in _annual(3)],
        description="full swap: 3 coupons + 3 floating on the same dates",
    ),
    DealSpec(
        reference="AC_5C_SEMI",
        obs_dates=_semi(5),
        coupons=[3.0] * 5,
        thresholds=[1.00] * 5,
        float_schedule=[(d, 1.0) for d in _semi(5)],
        description="5 semi-annual coupons + floating - longer schedule, more survival steps",
    ),
    DealSpec(
        reference="AC_3C_DEEP",
        obs_dates=_annual(3),
        coupons=[6.0] * 3,
        thresholds=[1.20] * 3,
        description="hard 120% trigger - low autocall probability (tail behaviour)",
    ),
    DealSpec(
        reference="AC_3C_EASY",
        obs_dates=_annual(3),
        coupons=[6.0] * 3,
        thresholds=[0.80] * 3,
        description="easy 80% trigger - almost always autocalls at the first date",
    ),
]


# ------------------------------------------------------------------ trade file side
def to_trade_file_deal(spec: DealSpec) -> dict:
    """Build the '.Deal' node for the trade JSON file (swap component only)."""
    return {
        ".Deal": {
            "Object": "QEDI_CustomAutoCallSwap",
            "Reference": spec.reference,
            "Tags": [],
            # EquityOptionBase fields
            "Buy_Sell": "Buy",
            "Currency": CCY,
            "Discount_Rate": DISCOUNT,
            "Equity": EQUITY,
            "Equity_Volatility": EQUITY,
            "Dividends": EQUITY,
            "Expiry_Date": ts(spec.expiry),
            "Option_Type": "Call",
            "Payoff_Currency": CCY,
            "Strike_Price": spec.strike,
            # autocall-specific
            "Units": spec.units,
            "Settlement_Style": "Cash",
            "Option_On_Forward": "No",
            "Option_Style": "European",
            "Payoff_Type": "Standard",
            # SWAP ONLY: no put barrier, no barrier dates, no rebate
            "Barrier": 0.0,
            "Barrier_Dates": [],
            "Autocall_Coupons": [[ts(d), c] for d, c in zip(spec.obs_dates, spec.coupons)],
            "Autocall_Thresholds": [[ts(d), th] for d, th in zip(spec.obs_dates, spec.thresholds)],
            # one price fixing per coupon date, so no coupon is an average
            "Price_Fixing": [[ts(d), 0.0] for d in spec.obs_dates],
            "Autocall_Floating": [[ts(d), a] for d, a in spec.float_schedule],
        }
    }


# ------------------------------------------------------------------ library side
def to_our_swap(spec: DealSpec):
    """Build the equivalent AutocallSwap for our independent engine."""
    from autocall_pricer.instruments.autocall import AutocallSwap

    return AutocallSwap(
        strike=spec.strike,
        coupon_schedule=[(d, c, th) for d, c, th in
                         zip(spec.obs_dates, spec.coupons, spec.thresholds)],
        float_schedule=list(spec.float_schedule),
        put_barrier=0.0,     # swap only
        rebate=0.0,          # swap only
        barrier_dates=[],
        buy_sell=1,
        units=spec.units,
        payoff_type="Vanilla",
    )


def our_market():
    """Flat-curve equity market matching the JSON's ExplicitMarketData."""
    import numpy as np
    from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
    from autocall_pricer.market_data.equity_market_data import EquityMarketData

    def curve(cont_rate):   # FlatDiscountCurve stores a SIMPLE rate; make continuous == input
        return FlatDiscountCurve(BASE_DATE, float(np.exp(cont_rate) - 1.0))

    return EquityMarketData(
        valuation_date=BASE_DATE, spot=SPOT,
        discount_curve=curve(R), repo_curve=curve(R), div_curve=curve(Q),
        equity_vol=VOL,
    )
