"""
Phase 2 checks: AutocallSwap term-sheet container, schedule builder, and EquityMarketData.

Run: python -m pytest test/autocall/test_phase2_instrument.py -q
"""

from datetime import date

import numpy as np

try:
    import pytest
except ImportError:  # allow standalone run without pytest installed
    import contextlib

    class _ApproxShim:
        def __init__(self, expected, rel=1e-9, abs=1e-12):
            self.expected, self.rel, self.abs = expected, rel, abs

        def __eq__(self, other):
            return abs(other - self.expected) <= max(
                self.abs, self.rel * abs(self.expected))

    class _PytestShim:
        @staticmethod
        def approx(expected, rel=1e-9, abs=1e-12):
            return _ApproxShim(expected, rel, abs)

        @staticmethod
        @contextlib.contextmanager
        def raises(exc):
            try:
                yield
            except exc:
                return
            raise AssertionError(f"expected {exc.__name__} was not raised")

    pytest = _PytestShim()

from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
from autocall_pricer.instruments.autocall import AutocallSwap, QUANTO, evaluate_autocall_paths
from autocall_pricer.market_data.equity_market_data import EquityMarketData


def make_market(val=date(2026, 1, 1), spot=100.0, r=0.03, q=0.01, vol=0.20,
                fx_vol=0.0, corr=0.0):
    """Flat-curve equity market for testing."""
    return EquityMarketData(
        valuation_date=val,
        spot=spot,
        discount_curve=FlatDiscountCurve(val, r),
        repo_curve=FlatDiscountCurve(val, r),
        div_curve=FlatDiscountCurve(val, q),
        equity_vol=vol,
        fx_vol=fx_vol,
        corr_equity_fx=corr,
    )


def make_deal(**kwargs):
    """3-year annual autocall, 100% trigger, 5% coupon, 70% barrier."""
    val = date(2026, 1, 1)
    obs = [date(2027, 1, 1), date(2028, 1, 1), date(2029, 1, 1)]
    coupon_schedule = [(d, 5.0, 1.0) for d in obs]
    defaults = dict(
        strike=100.0,
        coupon_schedule=coupon_schedule,
        barrier_dates=obs,
        rebate=100.0,
        buy_sell=1,
        units=1.0,
    )
    defaults.update(kwargs)
    return AutocallSwap.from_barrier_pct(barrier_pct=0.70, **defaults), val


def test_forward_and_discount_are_curve_consistent():
    mkt = make_market(r=0.03, q=0.01, spot=100.0)
    # F(t) = S * exp((r-q)t) with simple->continuous conversion used by FlatDiscountCurve
    t = 2.0
    r_cont = np.log(1.03)
    q_cont = np.log(1.01)
    assert mkt.forward(t) == pytest.approx(100.0 * np.exp((r_cont - q_cont) * t), rel=1e-12)
    assert mkt.df(t) == pytest.approx(np.exp(-r_cont * t), rel=1e-12)
    # log_drift over a step equals integrated (r-q)
    assert mkt.log_drift(1.0, 2.0) == pytest.approx((r_cont - q_cont) * 1.0, rel=1e-12)


def test_schedule_merges_and_orders_dates():
    deal, val = make_deal()
    mkt = make_market()
    sched = deal.build_schedule(val, mkt)
    assert sched.n_obs == 3
    assert sched.obs_dates == sorted(sched.obs_dates)
    assert sched.is_coupon_date.all()
    assert sched.is_barrier_date.all()
    assert not sched.is_float_date.any()
    # discount factors strictly decreasing in time
    assert np.all(np.diff(sched.discount_factors) < 0)
    # thresholds and coupons populated
    assert np.allclose(sched.thresholds, 1.0)
    assert np.allclose(sched.coupons, 5.0)


def test_schedule_drops_past_dates():
    deal, _ = make_deal()
    mkt = make_market(val=date(2027, 6, 1))
    sched = deal.build_schedule(date(2027, 6, 1), mkt)
    # only the 2028 and 2029 observations remain
    assert sched.n_obs == 2
    assert all(d > date(2027, 6, 1) for d in sched.obs_dates)


def test_barrier_pct_sets_absolute_level():
    deal, _ = make_deal()
    assert deal.put_barrier == pytest.approx(70.0)


def test_quanto_fx_factor():
    deal, _ = make_deal(payoff_type=QUANTO, fix_fx_rate=1.25)
    assert deal.fx_factor == pytest.approx(1.25)
    plain, _ = make_deal()
    assert plain.fx_factor == 1.0


def test_price_via_injected_paths_matches_notional_scaling():
    """End-to-end: schedule -> hand-made 'paths' -> payoff, with notional scaling."""
    deal, val = make_deal(units=1000.0)
    mkt = make_market()
    sched = deal.build_schedule(val, mkt)

    # One path that autocalls immediately at obs 1 (spot 110 >= 100 trigger):
    # pays (rebate+coupon)=105 discounted to t1.
    paths = np.array([[110.0, 110.0, 110.0]])
    res = evaluate_autocall_paths(paths, **sched.payoff_kwargs())
    expected_unit = 105.0 * sched.discount_factors[0]
    assert res.pv == pytest.approx(expected_unit, rel=1e-12)
    assert deal.notional * res.pv == pytest.approx(1000.0 * expected_unit, rel=1e-12)


def test_get_cashflows_and_validate():
    deal, val = make_deal()
    assert deal.validate() is True
    cfs = deal.get_cashflows(val)
    assert len(cfs) == 3
    assert (cfs["amount"] == 105.0).all()  # rebate 100 + coupon 5
    with pytest.raises(ValueError):
        AutocallSwap(strike=-1, coupon_schedule=[(date(2027, 1, 1), 5.0, 1.0)]).validate()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = 0
    for fn in fns:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"FAIL  {fn.__name__}: {type(exc).__name__}: {exc}")
        else:
            passed += 1
            print(f"ok    {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
