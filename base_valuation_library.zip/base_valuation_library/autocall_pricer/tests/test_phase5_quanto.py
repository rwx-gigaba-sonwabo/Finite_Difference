"""
Phase 5 checks: correlated FX GBM reproduces the analytic quanto adjustment.

HEADLINE (test_quanto_emerges_from_fx_simulation): a European quanto priced three ways, 
  (i)  analytic  : fixFX * e^{-r_d T} * Black76(quanto_forward, ...)   [the -rho.sigS.sigX in the fwd]
  (ii) domestic  : GBMEngine with quanto_adj = -rho.sigS.sigX          [analytic analytic adj]
  (iii) FX-sim   : CorrelatedGBMEngine under Q^f, NO adjustment in S    [adjustment must EMERGE]
must all agree within MC error. (iii) never codes the adjustment, it falls out of Cov(S, 1/X).

Run: PYTHONPATH=. python test/autocall/test_phase5_quanto.py
"""

from datetime import date

import numpy as np

from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
from autocall_pricer.instruments.autocall import AutocallSwap, evaluate_autocall_paths
from autocall_pricer.market_data.equity_market_data import EquityMarketData
from autocall_pricer.models.gbm import GBMEngine
from autocall_pricer.models.fx_gbm import CorrelatedGBMEngine
from autocall_pricer.models.analytics import quanto_forward, quanto_option_price

VAL = date(2026, 1, 1)
# continuous rates: foreign funding r_f (repo), dividend q, domestic r_d (discount)
R_F, Q, R_D = 0.04, 0.015, 0.02
SIG_S, SIG_X, RHO = 0.25, 0.12, 0.35
FIXFX = 1.30


def _curve(cont_rate):
    return FlatDiscountCurve(VAL, np.exp(cont_rate) - 1.0)


def market(spot=100.0, rho=RHO, sig_x=SIG_X):
    return EquityMarketData(
        valuation_date=VAL, spot=spot,
        discount_curve=_curve(R_D),   # domestic / payoff ccy
        repo_curve=_curve(R_F),       # foreign equity funding r_f
        div_curve=_curve(Q),
        equity_vol=SIG_S, fx_vol=sig_x, corr_equity_fx=rho,
    )


def _euro_schedule(mkt, expiry=date(2029, 1, 1), strike=100.0):
    """Single-observation 'European' via the autocall container (coupon date only, threshold huge)."""
    deal = AutocallSwap(strike=strike, coupon_schedule=[(expiry, 0.0, 1.0)])
    return deal.build_schedule(VAL, mkt)


def test_quanto_forward_analytic_sign():
    """Positive correlation lowers the quanto forward (adjustment is -rho.sigS.sigX)."""
    T = 3.0
    f0 = quanto_forward(100.0, R_F, Q, 0.0, SIG_S, SIG_X, T)
    fpos = quanto_forward(100.0, R_F, Q, 0.5, SIG_S, SIG_X, T)
    fneg = quanto_forward(100.0, R_F, Q, -0.5, SIG_S, SIG_X, T)
    assert fpos < f0 < fneg


def test_quanto_emerges_from_fx_simulation():
    """HEADLINE: FX-simulation quanto price matches analytic without coding the adjustment."""
    mkt = market()
    T = (date(2029, 1, 1) - VAL).days / 365.0
    K = 105.0

    analytic = quanto_option_price(mkt.spot, K, R_F, R_D, Q, RHO, SIG_S, SIG_X, T, FIXFX, "call")

    # (ii) domestic measure, analytic adjustment coded in as a drift shift
    sched = _euro_schedule(mkt, strike=K)
    adj = -RHO * SIG_S * SIG_X
    S_dom = GBMEngine(n_paths=1_000_000, seed=1, quanto_adj=adj).simulate(sched, mkt)[:, -1]
    D_d = np.exp(-R_D * T)
    payoff = np.maximum(S_dom - K, 0.0)
    pv_dom = FIXFX * D_d * payoff.mean()
    se_dom = FIXFX * D_d * payoff.std(ddof=1) / np.sqrt(S_dom.shape[0])

    # (iii) FX simulation under Q^f, NO adjustment in S; adjustment emerges via measure change
    S_for, w = CorrelatedGBMEngine(n_paths=1_000_000, seed=1).simulate_quanto(sched, mkt)
    disc_payoff = np.maximum(S_for[:, -1] - K, 0.0) * w[:, -1]
    pv_fx = FIXFX * disc_payoff.mean()
    se_fx = FIXFX * disc_payoff.std(ddof=1) / np.sqrt(S_for.shape[0])

    print(f"    analytic {analytic:.4f} | domestic-adj {pv_dom:.4f} (se {se_dom:.4f}) "
          f"| FX-sim {pv_fx:.4f} (se {se_fx:.4f})")
    assert abs(pv_dom - analytic) < 4 * se_dom, (pv_dom, analytic)
    assert abs(pv_fx - analytic) < 4 * se_fx, (pv_fx, analytic)


def test_fx_sim_recovers_quanto_forward():
    """Under Q^f, the RN-weighted expectation of S_T reproduces the quanto forward."""
    mkt = market()
    sched = _euro_schedule(mkt)
    T = float(sched.obs_times[-1])
    S_for, w = CorrelatedGBMEngine(n_paths=1_000_000, seed=4).simulate_quanto(sched, mkt)
    # E^{Q^d}[S_T] = E^{Q^f}[S_T * w_T] / e^{-r_d T}
    mc_qfwd = (S_for[:, -1] * w[:, -1]).mean() / np.exp(-R_D * T)
    analytic_qfwd = quanto_forward(mkt.spot, R_F, Q, RHO, SIG_S, SIG_X, T)
    se = (S_for[:, -1] * w[:, -1]).std(ddof=1) / np.sqrt(S_for.shape[0]) / np.exp(-R_D * T)
    assert abs(mc_qfwd - analytic_qfwd) < 4 * se, (mc_qfwd, analytic_qfwd)


def test_quanto_autocall_domestic_vs_fx_sim():
    """Full quanto autocall: domestic-adjusted engine vs FX-simulation must agree."""
    mkt = market()
    obs = [date(2027, 1, 1), date(2028, 1, 1), date(2029, 1, 1)]
    deal = AutocallSwap.from_barrier_pct(
        strike=100.0, barrier_pct=0.70, coupon_schedule=[(d, 6.0, 1.0) for d in obs],
        barrier_dates=obs, rebate=100.0, payoff_type="Quanto", fix_fx_rate=FIXFX)
    sched = deal.build_schedule(VAL, mkt)

    # domestic-adjusted: fx=FIXFX and deterministic domestic DFs from schedule
    adj = -RHO * SIG_S * SIG_X
    S_dom = GBMEngine(n_paths=500_000, seed=8, quanto_adj=adj).simulate(sched, mkt)
    pv_dom = evaluate_autocall_paths(S_dom, **sched.payoff_kwargs())

    # FX-simulation: fx=FIXFX (schedule.fx), per-path RN discount weights override the DFs
    S_for, w = CorrelatedGBMEngine(n_paths=500_000, seed=8).simulate_quanto(sched, mkt)
    kwargs = sched.payoff_kwargs()
    kwargs["discount_factors"] = w
    pv_fx = evaluate_autocall_paths(S_for, **kwargs)

    diff = abs(pv_dom.pv - pv_fx.pv)
    tol = 4 * (pv_dom.std_error + pv_fx.std_error)
    print(f"    quanto autocall: domestic {pv_dom.pv:.4f} vs FX-sim {pv_fx.pv:.4f} "
          f"(diff {diff:.4f}, tol {tol:.4f})")
    assert diff < tol, (pv_dom.pv, pv_fx.pv, diff, tol)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = 0
    for fn in fns:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"FAIL  {fn.__name__}: {type(exc).__name__}: {exc}")
        else:
            passed += 1
            print(f"ok    {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
