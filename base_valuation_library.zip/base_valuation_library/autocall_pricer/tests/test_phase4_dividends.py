"""
Phase 4 checks: discrete dividends (cash + proportional) and reconciliation to continuous yield.

  1. Cash-dividend forward: E[S_T] matches the analytic escrowed-funding forward.
  2. Proportional divs sized to a yield reproduce the continuous-yield paths EXACTLY.
  3. Cash divs: equivalent-yield forward matches, and the autocall price is close to the
     continuous model at that equivalent yield (approximate reconciliation).

Run: PYTHONPATH=. python test/autocall/test_phase4_dividends.py
"""

from datetime import date

import numpy as np

from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
from autocall_pricer.instruments.autocall import AutocallSwap, evaluate_autocall_paths
from autocall_pricer.market_data.equity_market_data import EquityMarketData
from autocall_pricer.models.gbm import GBMEngine
from autocall_pricer.models.dividends import (
    Dividend, CASH, cash_dividend_forward, yield_to_proportional_schedule,
    proportional_schedule_to_yield, cash_schedule_equivalent_yield,
)

VAL = date(2026, 1, 1)
OBS = [date(2027, 1, 1), date(2028, 1, 1), date(2029, 1, 1)]
R_CONT = 0.03  # continuous funding rate used throughout this module


def _curve(cont_rate):
    """FlatDiscountCurve whose CONTINUOUS rate equals cont_rate (it stores a simple rate)."""
    return FlatDiscountCurve(VAL, np.exp(cont_rate) - 1.0)


def market(spot=100.0, r=R_CONT, q=0.0, vol=0.25, divs=None):
    """All rates are continuous; curves are built so continuous_rate == the given value."""
    return EquityMarketData(
        valuation_date=VAL, spot=spot,
        discount_curve=_curve(r),
        repo_curve=_curve(r),
        div_curve=_curve(q),
        equity_vol=vol, discrete_dividends=divs,
    )


def schedule(mkt):
    deal = AutocallSwap(strike=100.0, coupon_schedule=[(d, 0.0, 1.0) for d in OBS])
    return deal.build_schedule(VAL, mkt)


def test_cash_dividend_forward_matches_analytic():
    """E[S_j] under cash divs equals the escrowed-funding forward at each obs date."""
    divs = [Dividend(date(2026, 7, 1), 2.0, CASH),
            Dividend(date(2027, 7, 1), 2.5, CASH),
            Dividend(date(2028, 7, 1), 3.0, CASH)]
    mkt = market(divs=divs)
    sched = schedule(mkt)
    paths = GBMEngine(n_paths=500_000, seed=21).simulate(sched, mkt)
    for j, t in enumerate(sched.obs_times):
        analytic = cash_dividend_forward(mkt.spot, R_CONT, divs, VAL, float(t))
        se = paths[:, j].std(ddof=1) / np.sqrt(paths.shape[0])
        assert abs(paths[:, j].mean() - analytic) < 4 * se, \
            f"t={t}: MC {paths[:,j].mean():.4f} vs analytic {analytic:.4f} (se {se:.4f})"


def test_proportional_divs_reconcile_continuous_yield_exactly():
    """Proportional divs sized to yield q reproduce the continuous-yield paths bit-for-bit."""
    q = 0.02
    # continuous-yield market (Phase 3 path)
    cont = market(q=q)
    cont_paths = GBMEngine(n_paths=100_000, seed=99).simulate(schedule(cont), cont)

    # discrete proportional divs at the obs dates, sized to the same yield; funding r, div 0
    prop = yield_to_proportional_schedule(q, OBS, VAL)
    disc = market(q=0.0, divs=prop)
    disc_paths = GBMEngine(n_paths=100_000, seed=99).simulate(schedule(disc), disc)

    assert np.allclose(cont_paths, disc_paths, rtol=1e-9, atol=1e-8)
    # round-trip the converter
    T = (OBS[-1] - VAL).days / 365.0
    assert abs(proportional_schedule_to_yield(prop, T, VAL) - q) < 1e-12


def test_cash_equivalent_yield_forward_and_price():
    """Cash divs vs continuous model at the equivalent yield: forwards match at T; price close."""
    divs = [Dividend(date(2027, 6, 1), 2.0, CASH),
            Dividend(date(2028, 6, 1), 2.0, CASH)]
    mkt_cash = market(divs=divs)
    T = (OBS[-1] - VAL).days / 365.0
    q_eq = cash_schedule_equivalent_yield(mkt_cash.spot, R_CONT, divs, VAL, T)

    # forwards at T agree by construction of the equivalent yield
    f_cash = cash_dividend_forward(mkt_cash.spot, R_CONT, divs, VAL, T)
    f_cont = market(q=q_eq).forward(T)
    assert abs(f_cash - f_cont) < 1e-8

    # price a real autocall both ways; cash vs equivalent-yield continuous should be close
    deal = AutocallSwap.from_barrier_pct(
        strike=100.0, barrier_pct=0.70, coupon_schedule=[(d, 6.0, 1.0) for d in OBS],
        barrier_dates=OBS, rebate=100.0)

    s_cash = deal.build_schedule(VAL, mkt_cash)
    pv_cash = evaluate_autocall_paths(
        GBMEngine(n_paths=300_000, seed=7).simulate(s_cash, mkt_cash), **s_cash.payoff_kwargs())

    mkt_cont = market(q=q_eq)
    s_cont = deal.build_schedule(VAL, mkt_cont)
    pv_cont = evaluate_autocall_paths(
        GBMEngine(n_paths=300_000, seed=7).simulate(s_cont, mkt_cont), **s_cont.payoff_kwargs())

    # approximate reconciliation: within ~0.5 currency units (cash-vs-yield timing gap)
    diff = abs(pv_cash.pv - pv_cont.pv)
    print(f"    cash PV {pv_cash.pv:.4f} vs equiv-yield PV {pv_cont.pv:.4f} (diff {diff:.4f})")
    assert diff < 0.5, diff


def test_cash_divs_lower_forward_than_no_divs():
    """Sanity: cash dividends reduce the forward and thus the autocall value."""
    T = (OBS[-1] - VAL).days / 365.0
    f_no = market().forward(T)
    f_div = cash_dividend_forward(100.0, R_CONT, [Dividend(date(2027, 6, 1), 5.0, CASH)], VAL, T)
    assert f_div < f_no


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = 0
    for fn in fns:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"FAIL  {fn.__name__}: {type(exc).__name__}: {exc}")
        else:
            passed += 1
            print(f"ok    {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
