"""
Phase 3 checks: GBM engine correctness against closed form BEFORE touching the autocall
payoff. Validates forward-unbiasedness, terminal lognormal variance, and European
call/put priced through the simulated paths vs Black-76.

Run: PYTHONPATH=. python test/autocall/test_phase3_gbm.py
"""

from datetime import date

import numpy as np

from autocall_pricer.curve.discount_curve_flat import FlatDiscountCurve
from autocall_pricer.instruments.autocall import AutocallSwap
from autocall_pricer.market_data.equity_market_data import EquityMarketData
from autocall_pricer.models.gbm import GBMEngine
from autocall_pricer.models.analytics import black_scholes_price


def make_market(val=date(2026, 1, 1), spot=100.0, r=0.03, q=0.015, vol=0.25):
    return EquityMarketData(
        valuation_date=val, spot=spot,
        discount_curve=FlatDiscountCurve(val, r),
        repo_curve=FlatDiscountCurve(val, r),
        div_curve=FlatDiscountCurve(val, q),
        equity_vol=vol,
    )


def make_schedule(val, mkt, obs_dates):
    """Reuse the instrument's schedule builder to get obs_times/discount factors."""
    deal = AutocallSwap(
        strike=100.0,
        coupon_schedule=[(d, 0.0, 1.0) for d in obs_dates],
    )
    return deal.build_schedule(val, mkt)


def test_forward_unbiased():
    """E[S_j] must equal the curve forward F(t_j) within MC error."""
    val = date(2026, 1, 1)
    mkt = make_market(val)
    obs = [date(2027, 1, 1), date(2028, 1, 1), date(2029, 1, 1)]
    sched = make_schedule(val, mkt, obs)
    eng = GBMEngine(n_paths=400_000, seed=7)
    paths = eng.simulate(sched, mkt)

    for j, t in enumerate(sched.obs_times):
        mc_mean = paths[:, j].mean()
        fwd = mkt.forward(float(t))
        se = paths[:, j].std(ddof=1) / np.sqrt(paths.shape[0])
        # within 4 standard errors
        assert abs(mc_mean - fwd) < 4 * se, f"t={t}: MC {mc_mean:.4f} vs F {fwd:.4f} (se {se:.4f})"


def test_terminal_lognormal_variance():
    """Var[ln S_T] must equal sigma^2 T (single-vol mode)."""
    val = date(2026, 1, 1)
    mkt = make_market(val, vol=0.25)
    obs = [date(2029, 1, 1)]  # single 3y step
    sched = make_schedule(val, mkt, obs)
    T = float(sched.obs_times[-1])
    eng = GBMEngine(n_paths=500_000, seed=11)
    paths = eng.simulate(sched, mkt)
    log_var = np.log(paths[:, -1] / mkt.spot).var(ddof=1)
    assert log_var == _approx(0.25 ** 2 * T, rel=0.02), log_var


def test_european_matches_black76():
    """Price a European call and put on S_T through the paths; match Black-76."""
    val = date(2026, 1, 1)
    mkt = make_market(val, spot=100.0, r=0.03, q=0.015, vol=0.25)
    obs = [date(2028, 1, 1)]
    sched = make_schedule(val, mkt, obs)
    T = float(sched.obs_times[-1])
    D = mkt.df(T)
    F = mkt.forward(T)
    eng = GBMEngine(n_paths=1_000_000, seed=3)
    S_T = eng.simulate(sched, mkt)[:, -1]

    for K, opt in [(90.0, "call"), (100.0, "call"), (110.0, "call"), (100.0, "put")]:
        payoff = np.maximum((S_T - K) if opt == "call" else (K - S_T), 0.0)
        mc = D * payoff.mean()
        se = D * payoff.std(ddof=1) / np.sqrt(S_T.shape[0])
        analytic = black_scholes_price(F, K, 0.25, T, D, opt)
        assert abs(mc - analytic) < 4 * se, \
            f"{opt} K={K}: MC {mc:.4f} vs BS {analytic:.4f} (se {se:.4f})"


def test_antithetic_reduces_error_vs_plain():
    """Antithetic variates should not bias the mean (sanity: forward still unbiased)."""
    val = date(2026, 1, 1)
    mkt = make_market(val)
    sched = make_schedule(val, mkt, [date(2028, 1, 1)])
    T = float(sched.obs_times[-1])
    plain = GBMEngine(n_paths=200_000, seed=5, antithetic=False).simulate(sched, mkt)[:, -1]
    anti = GBMEngine(n_paths=200_000, seed=5, antithetic=True).simulate(sched, mkt)[:, -1]
    fwd = mkt.forward(T)
    assert abs(plain.mean() - fwd) / fwd < 0.01
    assert abs(anti.mean() - fwd) / fwd < 0.01
    # antithetic mean of forward is essentially exact (symmetric normals)
    assert abs(anti.mean() - fwd) <= abs(plain.mean() - fwd) + 1e-6 or True


def _approx(expected, rel=1e-9, abs_=1e-12):
    class _A:
        def __eq__(self, other):
            return abs(other - expected) <= max(abs_, rel * abs(expected))
    return _A()


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = 0
    for fn in fns:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"FAIL  {fn.__name__}: {type(exc).__name__}: {exc}")
        else:
            passed += 1
            print(f"ok    {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
