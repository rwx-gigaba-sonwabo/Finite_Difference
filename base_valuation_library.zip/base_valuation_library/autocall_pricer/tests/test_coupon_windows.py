"""
Coupons decided on their Price_Fixing and paid on their Autocall_Coupons date, the coupon
window:
the loader's pairing, the schedule's observation index, the payoff reading the fixing while
applying the call on the coupon row, the per-column vol strip levels, and the booking check.

Run:  python -m pytest test/autocall/test_coupon_windows.py -q
"""

import json
import sys
import warnings
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from autocall_pricer.instruments.autocall.autocall_swap import AutocallSwap                   # noqa: E402
from autocall_pricer.instruments.autocall.payoff import evaluate_autocall_paths               # noqa: E402
from autocall_pricer.instruments.autocall.put_leg import (                                    # noqa: E402
    BookedOption, PutLegBooking, check_swap_against_booking,
)
from autocall_pricer.instruments.autocall.trade_file_loader import coupon_fixings, load_autocall_swap  # noqa: E402
from autocall_pricer.curve.curve_builders import curve_from_points                        # noqa: E402
from autocall_pricer.market_data.equity_market_data import EquityMarketData                   # noqa: E402
from autocall_pricer.market_data.vol_surface import EquityVolSurface                          # noqa: E402
from autocall_pricer.models.gbm import GBMEngine                                              # noqa: E402

VAL = date(2026, 1, 1)
FIX = [date(2027, 1, 4), date(2028, 1, 3), date(2029, 1, 2)]
PAY = [d + timedelta(days=5) for d in FIX]


def _mkt(vol=0.25):
    c = lambda r: curve_from_points(VAL, [(0.0, r), (30.0, r)], "Linear")   # noqa: E731
    return EquityMarketData(VAL, 100.0, c(0.03), c(0.03), c(0.01), vol)


def _swap(**kw):
    rows = [(f, 0.06, th, p) for f, p, th in zip(FIX, PAY, (1.0, 0.9, 0.85))]
    return AutocallSwap(strike=100.0, coupon_schedule=rows, terminal_mode="per_barrier_date", **kw)


# ------------------------------------------------------------------------ the pairing
def test_each_coupon_is_decided_on_the_fixing_closing_its_window():
    assert coupon_fixings(PAY, FIX) == dict(zip(PAY, FIX))


def test_a_strike_fixing_before_the_first_window_is_dropped():
    strike_fix = date(2026, 1, 2)
    assert coupon_fixings(PAY, [strike_fix] + FIX) == dict(zip(PAY, FIX))


def test_an_averaging_window_is_refused():
    with pytest.raises(ValueError, match="AVERAGING"):
        coupon_fixings(PAY, FIX[:1] + [FIX[1] - timedelta(days=30), FIX[1]] + FIX[2:])


def test_a_fixing_after_the_last_coupon_is_refused():
    with pytest.raises(ValueError, match="window of its own"):
        coupon_fixings(PAY, FIX + [PAY[-1] + timedelta(days=1)])


def test_past_coupons_filter_the_fixings():
    # base date after the first coupon: only the later two coupons have windows
    out = coupon_fixings(PAY, FIX, base_date=PAY[0] + timedelta(days=1))
    assert out[PAY[1]] == FIX[1] and out[PAY[2]] == FIX[2]


def test_a_declared_pairing_wins_and_is_held_to_the_pairing_rules():
    declared = dict(zip(PAY, FIX))
    assert coupon_fixings(PAY, FIX, declared) == declared
    with pytest.raises(ValueError):
        coupon_fixings(PAY, FIX, {**declared, PAY[0]: PAY[0] + timedelta(days=1)})


# ----------------------------------------------------------------------- the schedule
def test_the_call_is_applied_on_the_coupon_row_and_reads_the_fixing():
    s = _swap().build_schedule(VAL, _mkt())
    assert s.obs_dates == sorted(FIX + PAY)
    rows = np.flatnonzero(s.is_coupon_date)
    assert [s.obs_dates[j] for j in rows] == PAY
    assert s.trigger_observation_dates == FIX
    assert list(s.thresholds[rows]) == [1.0, 0.9, 0.85]
    assert s.coupon_discount_factors is None        # the coupon row IS the payment date


def test_a_barrier_dated_on_a_fixing_is_flagged_on_its_coupon_row():
    s = _swap(put_barrier=70.0, barrier_dates=[FIX[-1]]).build_schedule(VAL, _mkt())
    j = int(np.flatnonzero(s.is_barrier_date)[0])
    assert s.obs_dates[j] == PAY[-1] and s.obs_dates[s.obs_index[j]] == FIX[-1]


def test_without_a_payment_date_the_schedule_is_unchanged():
    s = AutocallSwap(strike=100.0, coupon_schedule=[(f, 0.06, 1.0) for f in FIX]).build_schedule(
        VAL, _mkt())
    assert s.obs_dates == FIX and s.observation_index is None


# ------------------------------------------------------- fixings already printed
from autocall_pricer.instruments.autocall.autocall_swap import AutocallExpired    # noqa: E402


def _printed(levels):
    """The swap with each coupon carrying its Price_Fixing level (the loader's 5-tuples)."""
    rows = [(f, 0.06, th, p, lv) for f, p, th, lv in zip(FIX, PAY, (1.0, 0.9, 0.85), levels)]
    return AutocallSwap(strike=100.0, coupon_schedule=rows, terminal_mode="per_barrier_date",
                        float_schedule=[(PAY[0], 0.01), (PAY[1], 0.01)])


def test_a_past_coupon_that_called_expires_the_deal():
    with pytest.raises(AutocallExpired) as e:
        _printed([101.0, 0.0, 0.0]).build_schedule(PAY[0] + timedelta(days=1), _mkt())
    assert e.value.called_on == PAY[0] and e.value.level == 101.0


def test_a_past_coupon_below_its_trigger_leaves_the_deal_alive():
    s = _printed([99.0, 0.0, 0.0]).build_schedule(PAY[0] + timedelta(days=1), _mkt())
    assert PAY[0] not in s.obs_dates and s.observed_levels is None


def test_a_printed_unpaid_coupon_that_called_pays_once_and_ends():
    val = FIX[0] + timedelta(days=1)                 # fixing printed, coupon not yet paid
    s = _printed([105.0, 0.0, 0.0]).build_schedule(val, _mkt())
    j = s.obs_dates.index(PAY[0])
    assert s.observed_levels[j] == 105.0 and FIX[0] not in s.obs_dates
    S = np.full((4, s.n_obs), 50.0)                 # whatever the paths do afterwards
    res = evaluate_autocall_paths(S, **s.payoff_kwargs())
    assert res.prob_autocalled == 1.0
    assert res.autocall_leg == pytest.approx(0.06 * s.discount_factors[j])
    # the float on the coupon's own date is paid (float before coupon); the later one is not
    assert res.floating_leg == pytest.approx(0.01 * s.discount_factors[j])


def test_a_printed_unpaid_coupon_below_its_trigger_is_decided_not_called():
    s = _printed([95.0, 0.0, 0.0]).build_schedule(FIX[0] + timedelta(days=1), _mkt())
    S = np.full((4, s.n_obs), 50.0)
    assert evaluate_autocall_paths(S, **s.payoff_kwargs()).prob_autocalled == 0.0


def test_a_fixing_on_the_valuation_date_reads_todays_spot():
    s = _printed([0.0, 0.0, 0.0]).build_schedule(FIX[0], _mkt())
    assert s.observed_levels[s.obs_dates.index(PAY[0])] == 100.0      # the market's spot


def test_a_printed_fixing_without_its_level_is_refused():
    with pytest.raises(NotImplementedError, match="no printed level"):
        _swap().build_schedule(FIX[0] + timedelta(days=1), _mkt())


def test_a_printed_coupon_sets_no_strip_level():
    s = _printed([95.0, 0.0, 0.0]).build_schedule(FIX[0] + timedelta(days=1), _mkt())
    # columns: PAY0 (printed) FIX1 PAY1 FIX2 PAY2, PAY0 steps on the next fixing's strip
    assert list(GBMEngine._column_levels(s)) == [0.9, 0.9, 0.85, 0.85, 0.85]
    assert s.trigger_observation_dates == FIX[1:]


# ------------------------------------------------------------------------- the payoff
def test_the_trigger_reads_the_fixing_and_a_float_on_the_coupon_date_is_still_paid():
    s = _swap(float_schedule=[(PAY[0], 0.01)]).build_schedule(VAL, _mkt())
    # path 0: above the trigger on the first FIXING, below it on the payment date -> calls
    # path 1: below on the fixing, above on the payment date -> does not call there
    S = np.array([[105.0, 95.0, 50.0, 50.0, 50.0, 50.0],
                  [95.0, 105.0, 50.0, 50.0, 50.0, 50.0]])
    res = evaluate_autocall_paths(S, **s.payoff_kwargs())
    assert res.prob_autocalled == pytest.approx(0.5)
    # both paths pay the float: the call is applied on the coupon row, after its float
    assert res.floating_leg == pytest.approx(0.01 * s.discount_factors[1])
    assert res.autocall_leg == pytest.approx(0.5 * 0.06 * s.discount_factors[1])


# ---------------------------------------------------------------------- the vol strip
def test_each_column_reads_the_level_of_the_fixing_closing_its_window():
    s = _swap().build_schedule(VAL, _mkt())
    lv = GBMEngine._column_levels(s)
    # columns: FIX0 PAY0 FIX1 PAY1 FIX2 PAY2
    assert list(lv) == [1.0, 0.9, 0.9, 0.85, 0.85, 0.85]


def test_the_strip_telescopes_to_each_fixings_own_level():
    surf = EquityVolSurface.from_triples(
        [[m, t, v] for t in (0.5, 2.0, 5.0) for m, v in ((0.9, 0.2), (1.0, 0.22), (1.2, 0.26))])
    mkt = _mkt(surf)
    s = _swap().build_schedule(VAL, mkt)
    coupon_paths, _ = GBMEngine(n_paths=400_000, seed=3).simulate_per_leg(s, mkt)
    levels = (1.0, 0.9, 0.85)

    def cum_var(k, lvl):        # sigma(level, T_k)^2 T_k, the strip at one level to fixing k
        t = mkt.yearfrac(FIX[k]) if k >= 0 else 0.0
        return mkt.vol(expiry=t, moneyness=mkt.spot / (lvl * 100.0)) ** 2 * t if t else 0.0

    for k, f in enumerate(FIX):
        # each fixing-to-fixing interval on ITS fixing's level, the payment row splitting it
        expected = sum(cum_var(i, lvl) - cum_var(i - 1, lvl) for i, lvl in enumerate(levels[:k + 1]))
        assert np.log(coupon_paths[:, s.obs_dates.index(f)]).var() == pytest.approx(
            expected, rel=1.5e-2)


# ------------------------------------------------------------------- the booking check
def _booking(dates):
    rows = [(d, None) for d in dates]
    opt = lambda obj, b=None, r=(): BookedOption(obj, obj, 1.0, 1.0, 70.0, FIX[-1], FIX[-1],  # noqa
                                                 None, b, list(r))
    return PutLegBooking(opt("EquityOptionDeal"), opt("EquityBarrierOption", 100.0, rows), None,
                         None, "EQ", "Vanilla", 100.0, "", "", "", "")


def test_contras_on_the_fixings_agree_with_the_swap_and_on_the_coupon_dates_do_not():
    s = _swap().build_schedule(VAL, _mkt())
    s.thresholds[:] = np.where(s.is_coupon_date, 1.0, 0.0)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        assert check_swap_against_booking(s, _booking(FIX)) == []
        notes = check_swap_against_booking(s, _booking(PAY))
    assert any("observation dates" in n for n in notes)
    assert caught


# ------------------------------------------------------------------------- the loader
def test_the_loader_pairs_coupons_with_their_fixings(tmp_path):
    ts = lambda d: {".Timestamp": d.isoformat()}                        # noqa: E731
    deal = {"Object": "QEDI_CustomAutoCallSwap", "Reference": "AC", "Currency": "ZAR",
            "Equity": "EQ", "Strike_Price": 100.0, "Expiry_Date": ts(PAY[-1]), "Units": 1.0,
            "Barrier": 0.0, "Barrier_Dates": [],
            "Autocall_Coupons": [[ts(p), 6.0] for p in PAY],
            "Autocall_Thresholds": [[ts(f), th] for f, th in zip(FIX, (1.0, 0.9, 0.85))],
            "Price_Fixing": [[ts(date(2025, 12, 31)), 100.0]] + [[ts(f), 0.0] for f in FIX]}
    blob = {"Calc": {"Calculation": {"Base_Date": ts(VAL)},
                     "Deals": {"Deals": {"Children": [{"Instrument": {".Deal": deal}}]}}}}
    path = tmp_path / "ac.json"
    path.write_text(json.dumps(blob))
    swap, _ = load_autocall_swap(path)
    assert [(e[0], e[3]) for e in swap.coupon_schedule] == list(zip(FIX, PAY))
    assert [e[4] for e in swap.coupon_schedule] == [0.0, 0.0, 0.0]     # Price_Fixing levels
    legacy, _ = load_autocall_swap(path, observation="coupon")
    assert [e[0] for e in legacy.coupon_schedule] == PAY and len(legacy.coupon_schedule[0]) == 3


def test_the_loader_carries_past_prints_so_a_called_note_expires(tmp_path):
    ts = lambda d: {".Timestamp": d.isoformat()}                        # noqa: E731
    base = PAY[0] + timedelta(days=10)
    deal = {"Object": "QEDI_CustomAutoCallSwap", "Reference": "AC", "Currency": "ZAR",
            "Equity": "EQ", "Strike_Price": 100.0, "Expiry_Date": ts(PAY[-1]), "Units": 1.0,
            "Barrier": 0.0, "Barrier_Dates": [],
            "Autocall_Coupons": [[ts(p), 6.0] for p in PAY],
            "Autocall_Thresholds": [[ts(f), 1.0] for f in FIX],
            # strike fixing, then the first coupon's window PRINTED above its trigger
            "Price_Fixing": [[ts(date(2025, 12, 31)), 100.0], [ts(FIX[0]), 104.0],
                             [ts(FIX[1]), 0.0], [ts(FIX[2]), 0.0]]}
    blob = {"Calc": {"Calculation": {"Base_Date": ts(base)},
                     "Deals": {"Deals": {"Children": [{"Instrument": {".Deal": deal}}]}}}}
    path = tmp_path / "called.json"
    path.write_text(json.dumps(blob))
    swap, _ = load_autocall_swap(path)
    assert swap.coupon_schedule[0][0] == FIX[0] and swap.coupon_schedule[0][4] == 104.0
    with pytest.raises(AutocallExpired):
        swap.build_schedule(base, _mkt())


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-q"]))
