import numpy as np


class IRVol:
    """Interest rate volatility surface for swaptions and caps/floors.

    Input DataFrame must have columns: Moneyness, Expiry, Maturity, Vol.
    Expiry and Maturity are year fractions. Moneyness convention is caller-defined
    (absolute strike, log-moneyness, offset from ATM, etc.).

    Interpolation order: Maturity → Expiry → Moneyness.
    All interpolation is linear with flat extrapolation outside the surface range.
    """

    def __init__(self, vol_data: list) -> None:
        arr = np.asarray(vol_data, dtype=np.float64)  # (N, 4): moneyness, expiry, maturity, vol
        self._maturities = np.unique(arr[:, 2])

        # {maturity: {expiry: (moneyness_nodes, vol_nodes)}}
        self._surface: dict = {}

        for mat in self._maturities:
            mat_rows = arr[np.isclose(arr[:, 2], mat)]
            expiries = np.unique(mat_rows[:, 1])
            self._surface[float(mat)] = {}
            for exp in expiries:
                exp_rows = mat_rows[np.isclose(mat_rows[:, 1], exp)]
                order = np.argsort(exp_rows[:, 0])
                self._surface[float(mat)][float(exp)] = (
                    exp_rows[order, 0],
                    exp_rows[order, 3],
                )

    def _vol_at_expiry_maturity(self, moneyness: float, expiry: float, maturity: float) -> float:
        m_nodes, v_nodes = self._surface[maturity][expiry]
        return float(np.interp(moneyness, m_nodes, v_nodes))

    def _vol_at_maturity(self, moneyness: float, swaption_expiry: float, maturity: float) -> float:
        expiries = np.array(sorted(self._surface[maturity].keys()))
        idx = int(np.searchsorted(expiries, swaption_expiry))

        if idx == 0:
            return self._vol_at_expiry_maturity(moneyness, float(expiries[0]), maturity)
        if idx == len(expiries):
            return self._vol_at_expiry_maturity(moneyness, float(expiries[-1]), maturity)

        e2 = float(expiries[idx])
        if np.isclose(swaption_expiry, e2):
            return self._vol_at_expiry_maturity(moneyness, e2, maturity)

        e1 = float(expiries[idx - 1])
        v1 = self._vol_at_expiry_maturity(moneyness, e1, maturity)
        v2 = self._vol_at_expiry_maturity(moneyness, e2, maturity)
        w = (swaption_expiry - e1) / (e2 - e1)
        return v1 + w * (v2 - v1)

    def get_vol(self, moneyness: float, swaption_expiry: float, swap_maturity: float) -> float:
        """Return interpolated swaption / cap / floor volatility.

        Parameters
        ----------
        moneyness : float
            Strike moneyness (convention matches the input data).
        swaption_expiry : float
            Time to swaption expiry in year fractions.
        swap_maturity : float
            Underlying swap (or caplet) maturity in year fractions.

        Returns
        -------
        float
            Implied volatility.
        """
        maturities = self._maturities
        idx = int(np.searchsorted(maturities, swap_maturity))

        if idx == 0:
            return self._vol_at_maturity(moneyness, swaption_expiry, float(maturities[0]))
        if idx == len(maturities):
            return self._vol_at_maturity(moneyness, swaption_expiry, float(maturities[-1]))

        m2 = float(maturities[idx])
        if np.isclose(swap_maturity, m2):
            return self._vol_at_maturity(moneyness, swaption_expiry, m2)

        m1 = float(maturities[idx - 1])
        v1 = self._vol_at_maturity(moneyness, swaption_expiry, m1)
        v2 = self._vol_at_maturity(moneyness, swaption_expiry, m2)
        w = (swap_maturity - m1) / (m2 - m1)
        return v1 + w * (v2 - v1)


class EquityVolSurface:
    """
    analytic (moneyness, expiry, vol) implied equity vol surface, the shape of a job
    JSON's ``EquityPriceVol.<equity>.Surface`` (``[[moneyness, expiry, vol], ...]`` triples).

    Interpolation is
    linear IN VOL along both moneyness and expiry, flat
    extrapolation outside the surface's own range. Moneyness convention is spot / strike, matching what
    ``EquityMarketData.vol()`` passes in.

    Exposes ``get_vol(moneyness, expiry, maturity=None)`` so an instance can be dropped
    straight into ``EquityMarketData(equity_vol=surface)`` in place of a flat float.
    """

    def __init__(self, moneyness, expiry, vol_grid) -> None:
        self.moneyness = np.asarray(moneyness, dtype=np.float64)
        self.expiry = np.asarray(expiry, dtype=np.float64)
        self.vol_grid = np.asarray(vol_grid, dtype=np.float64)   # shape (n_expiry, n_moneyness)

    @classmethod
    def from_triples(cls, data) -> "EquityVolSurface":
        """Build from raw ``[[moneyness, expiry, vol], ...]`` rows."""
        arr = np.asarray(data, dtype=np.float64)
        mny = np.unique(arr[:, 0])
        exp = np.unique(arr[:, 1])
        grid = np.full((exp.size, mny.size), np.nan)
        mi = {m: i for i, m in enumerate(mny)}
        ei = {e: i for i, e in enumerate(exp)}
        for m, e, v in arr:
            grid[ei[e], mi[m]] = v
        # fill any gaps (a sparse/ragged surface) by interpolating along moneyness per row
        for i in range(grid.shape[0]):
            row = grid[i]
            if np.any(np.isnan(row)) and not np.all(np.isnan(row)):
                good = ~np.isnan(row)
                grid[i] = np.interp(mny, mny[good], row[good])
        return cls(mny, exp, grid)

    def get_vol(self, moneyness: float, expiry: float, maturity: float = None) -> float:
        """Vol at (moneyness, expiry); ``maturity`` is accepted for interface parity and unused."""
        m, t = float(moneyness), float(expiry)
        cols = [float(np.interp(m, self.moneyness, self.vol_grid[i]))
               for i in range(self.expiry.size)]
        if self.expiry.size == 1:
            return cols[0]
        return float(np.interp(t, self.expiry, cols))
