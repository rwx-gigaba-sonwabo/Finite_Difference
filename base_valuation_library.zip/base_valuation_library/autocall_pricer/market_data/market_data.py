"""
Market data container for pricing instruments.

Provides MarketData class for storing and accessing curves. Instruments store
curve names and retrieve actual curves from this container at pricing time.
"""

from datetime import date
from typing import Dict, Any
from dataclasses import dataclass, field


@dataclass
class MarketData:
    """
    Container for market data required to price instruments.

    Attributes:
        valuation_date: Date as of which this market data is valid.
        discount_curves: Dict mapping curve name to curve object.
        forward_curves: Dict mapping curve name to curve object.
        credit_curves: Dict mapping entity name to credit/hazard curve object.
    """

    valuation_date: date
    discount_curves: Dict[str, Any] = field(default_factory=dict)
    forward_curves: Dict[str, Any] = field(default_factory=dict)
    credit_curves: Dict[str, Any] = field(default_factory=dict)

    def get_discount_curve(self, curve_name: str) -> Any:
        """
        Returns discount curve by name.

        Args:
            curve_name: Curve name.

        Returns:
            Curve object.
        """
        if curve_name not in self.discount_curves:
            raise KeyError(f"Discount curve '{curve_name}' not found in market data")
        return self.discount_curves[curve_name]

    def get_forward_curve(self, curve_name: str) -> Any:
        """
        Returns forward curve by name.

        Args:
            curve_name: Curve name.

        Returns:
            Curve object.
        """
        if curve_name not in self.forward_curves:
            raise KeyError(f"Forward curve '{curve_name}' not found in market data")
        return self.forward_curves[curve_name]

    def get_credit_curve(self, entity: str) -> Any:
        """
        Returns credit/hazard curve for entity.

        Args:
            entity: Entity name.

        Returns:
            Credit/hazard curve object.
        """
        if entity not in self.credit_curves:
            raise KeyError(f"Credit curve for '{entity}' not found in market data")
        return self.credit_curves[entity]

    def clone(self) -> 'MarketData':
        """
        Creates copy of market data.

        Returns:
            New MarketData instance with same data.
        """
        return MarketData(
            valuation_date=self.valuation_date,
            discount_curves=self.discount_curves.copy(),
            forward_curves=self.forward_curves.copy(),
            credit_curves=self.credit_curves.copy()
        )

    def __repr__(self) -> str:
        return (
            f"MarketData(valuation_date={self.valuation_date}, "
            f"discount_curves={list(self.discount_curves.keys())}, "
            f"forward_curves={list(self.forward_curves.keys())}, "
            f"credit_curves={list(self.credit_curves.keys())})"
        )
