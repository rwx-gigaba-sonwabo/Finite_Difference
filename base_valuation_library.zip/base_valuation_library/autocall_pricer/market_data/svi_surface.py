"""Equity volatility surface given as SVI parameters, one set per tenor.

For each tenor the total variance at log moneyness ``k`` is

    w(k) = a + b * (rho * (k - m) + sqrt((k - m)**2 + sigma**2))

The five parameters are fitted for each tenor on its own and stored as curves by tenor.

How a volatility is read
------------------------
1. The moneyness is ``k = ln(strike / ATM_Ref)`` when the surface is sticky in strike, and
   ``k = ln(strike / forward)`` when it is sticky in moneyness. The strike itself is needed,
   not a ratio of spot to strike.
2. The SVI formula is evaluated at the two tenors around the expiry.
3. The two results are interpolated in a straight line in variance, and the square root is
   taken.

The module also turns the surface into option prices on a grid of moneyness and maturity,
and writes them to a CSV file. That is useful as input to a model calibration that needs
prices instead of volatilities.

The surface is read from a trade JSON file with ``load_svi_surface``.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Callable, List, Optional, Sequence, Union

import numpy as np

from autocall_pricer.models.analytics import black_scholes_price


class _NetCarryCurve:
    """Combines a raw funding curve and a dividend-yield curve into one NET cost-of-carry
    curve (r - q): discount_factor(t) = funding.discount_factor(t) / div.discount_factor(t)
    = exp(-(r-q)*t). Elsewhere in this project EquityMarketData.repo_curve is documented as
    the RAW funding rate 'r' (div_curve is the separate 'q'), generate_svi_option_grid's
    own lagged-forward convention instead expects repo_curve to be the curve ALREADY netted
    against dividends. Use net_carry_curve() below to build one from the two raw curves
    rather than silently dropping dividends by passing a raw funding curve as repo_curve."""

    def __init__(self, funding_curve, div_curve):
        self._funding = funding_curve
        self._div = div_curve

    def discount_factor(self, t: float) -> float:
        return float(self._funding.discount_factor(t)) / float(self._div.discount_factor(t))


def net_carry_curve(funding_curve, div_curve) -> _NetCarryCurve:
    """funding_curve: the raw 'r' curve (e.g. the discount/repo curve before netting).
    div_curve: the continuous dividend yield 'q' curve. Returns a curve object suitable
    for EquityMarketData.repo_curve under generate_svi_option_grid's net-cost-of-carry
    convention."""
    return _NetCarryCurve(funding_curve, div_curve)


# ============================================================================ surface
@dataclass
class SVISurface:
    """Per-tenor SVI surface. Build via ``load_svi_surface``; ``get_vol`` is the
    only method a caller normally needs."""

    tenor: np.ndarray         # [n_tenors], ascending, years
    atm_ref: np.ndarray       # [n_tenors]
    a: np.ndarray             # [n_tenors]
    b: np.ndarray             # [n_tenors]
    rho: np.ndarray           # [n_tenors]
    m: np.ndarray             # [n_tenors]
    sigma: np.ndarray         # [n_tenors]
    moneyness_rule: str = "Sticky_Strike"
    source: str = ""

    #: tells EquityMarketData.vol() to pass the ABSOLUTE STRIKE here, not a spot/strike ratio
    #: (a Sticky_Strike surface divides by its own ATM reference)
    #:; see that method's own docstring.
    needs_strike = True

    def _tenor_bracket(self, t: float):
        """(idx, idx_next, alpha) s.t. t = (1-alpha)*tenor[idx] + alpha*tenor[idx_next],
        flat extrapolation beyond the first/last knot (idx == idx_next there, alpha unused),
        the same as SkewSurface's own bracket logic."""
        knots = self.tenor
        if t <= knots[0]:
            return 0, 0, 0.0
        if t >= knots[-1]:
            n = len(knots) - 1
            return n, n, 0.0
        idx = int(np.clip(np.searchsorted(knots, t) - 1, 0, len(knots) - 2))
        alpha = (t - knots[idx]) / (knots[idx + 1] - knots[idx])
        return idx, idx + 1, float(alpha)

    def atm_ref_at(self, expiry: float) -> float:
        """ATM_Ref(expiry), linearly tenor-interpolated, what Sticky_Strike moneyness divides
        strike by."""
        i, j, alpha = self._tenor_bracket(expiry)
        return float(self.atm_ref[i] * (1.0 - alpha) + self.atm_ref[j] * alpha)

    def _svi_variance_at(self, idx: int, moneyness: float) -> float:
        k = moneyness - self.m[idx]
        return float(self.a[idx] + self.b[idx] * (
            self.rho[idx] * k + np.sqrt(k * k + self.sigma[idx] * self.sigma[idx])))

    def get_vol(self, strike: Optional[float], expiry: float, forward: Optional[float] = None) -> float:
        """Implied vol at (strike, expiry). ``forward`` is required only for
        Moneyness_Rule='Sticky_Moneyness'; this surface's own rule decides which is used.

        ``strike=None`` means TRUE ATM: x=0 directly, bypassing spot/ATM_Ref
        entirely, NOT ``log(spot/ATM_Ref(expiry))`` (which is only exactly 0 if spot happens
        to equal that tenor's own ATM_Ref). Use this, not a spot-derived strike, wherever you
        want the surface's own notion of ATM (e.g. the quanto adjustment's equity vol read)."""
        if strike is None:
            moneyness = 0.0
        elif self.moneyness_rule == "Sticky_Strike":
            moneyness = np.log(strike / self.atm_ref_at(expiry))
        elif self.moneyness_rule == "Sticky_Moneyness":
            if forward is None:
                raise ValueError("Sticky_Moneyness needs the option's own forward")
            moneyness = np.log(strike / forward)
        else:
            raise NotImplementedError(f"Moneyness_Rule={self.moneyness_rule!r} not supported")

        i, j, alpha = self._tenor_bracket(expiry)
        var_i = self._svi_variance_at(i, moneyness)
        var_j = self._svi_variance_at(j, moneyness)
        variance = var_i * (1.0 - alpha) + var_j * alpha   # BLEND VARIANCE, not vol
        return float(np.sqrt(max(variance, 0.0)))


def load_svi_surface(json_path: Union[str, Path], factor_key: str) -> SVISurface:
    """
    Pull an SVI surface out of the trade JSON file by factor key, e.g.
    "EquityPriceVol.USD_SPX.USD". Same two JSON layouts as the other loaders (deal file:
    Calc > MergeMarketData > ExplicitMarketData > Price Factors; standalone: MarketData >
    Price Factors).
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob["MarketData"]["Price Factors"]
    if factor_key not in pf:
        raise KeyError(f"{factor_key!r} not in Price Factors. Available: {sorted(pf)}")
    node = pf[factor_key]
    if node.get("Surface_Type") != "SVI":
        raise ValueError(
            f"{factor_key!r} is Surface_Type={node.get('Surface_Type')!r}, not 'SVI'")

    def curve(name: str) -> np.ndarray:
        pts = sorted((float(t), float(v)) for t, v in node[name][".Curve"]["data"])
        return np.array(pts, dtype=float)

    atm_ref, a, b, rho, m, sigma = (curve(x) for x in ("ATM_Ref", "a", "b", "rho", "m", "sigma"))
    tenor = atm_ref[:, 0]
    for name, arr in (("a", a), ("b", b), ("rho", rho), ("m", m), ("sigma", sigma)):
        if arr.shape[0] != tenor.shape[0] or not np.allclose(arr[:, 0], tenor):
            raise ValueError(
                f"{factor_key!r}: {name!r}'s tenor knots don't match ATM_Ref's, "
                f"the six SVI curves are expected to share one tenor grid")

    return SVISurface(
        tenor=tenor, atm_ref=atm_ref[:, 1], a=a[:, 1], b=b[:, 1], rho=rho[:, 1],
        m=m[:, 1], sigma=sigma[:, 1],
        moneyness_rule=node.get("Moneyness_Rule", "Sticky_Strike"), source=factor_key,
    )


# ============================================================================ back-solve
@dataclass
class SVIOptionQuote:
    """One grid point's backed-out option, in the shape asked for: enough to stand in as a
    market quote for a downstream calibration (e.g. Heston)."""

    expiry_date: date
    settlement_date: date
    contract_size: float
    option_type: str          # "call" | "put"
    strike: float
    quoted_price: float       # contract_size * Black-76 price off the SVI-implied vol
    # kept alongside for sanity-checking the grid, not part of the requested schema
    vol: float = field(repr=False, default=0.0)
    moneyness_pct: float = field(repr=False, default=0.0)
    maturity_years: float = field(repr=False, default=0.0)
    # the ACTUAL forward/discount factor used to price this quote (lag-adjusted if
    # spot_lag_days/settlement_lag_days != 0), write_heston_csv reads these back rather
    # than recomputing from market_data, so the back-solved r/q always stay exactly
    # consistent with what priced this quote, lagged or not.
    forward: float = field(repr=False, default=0.0)
    discount_factor: float = field(repr=False, default=0.0)


def _default_option_type(moneyness_pct: float) -> str:
    """OTM convention: put below ATM, call at/above, the standard choice for a vol-surface
    calibration target (OTM options are what the surface is actually quoted against)."""
    return "put" if moneyness_pct < 1.0 else "call"


def generate_svi_option_grid(
    svi_surface: SVISurface,
    market_data,                 # EquityMarketData-shaped: .spot, .discount_curve, .repo_curve
    valuation_date: date,
    moneyness_pcts: Sequence[float],               # e.g. np.arange(0.6, 1.21, 0.05), strike = pct * ATM_Ref(T)
    maturities_years: Sequence[float],
    contract_size: float = 1.0,
    spot_lag_days: float = 0.0,
    settlement_lag_days: float = 0.0,
    option_type_rule: Callable[[float], str] = _default_option_type,
) -> List[SVIOptionQuote]:
    """
    Every (moneyness_pct, maturity) combination -> one SVIOptionQuote. Strike is ALWAYS
    pct * ATM_Ref(maturity) (this surface's own Sticky_Strike reference), unaffected by
    either lag below, since it's the surface's own tenor grid, not a settlement mechanic.

    Settlement / spot lag convention (t = valuation date, T = expiry, both in years; lags
    given in CALENDAR days and converted /365):
      - The SVI vol lookup and the Black-76 d1/d2 variance term both use T (unlagged),
        the smile and time value are pinned to expiry, not to settlement.
      - The FORWARD accounts for both lags:
            F(T) = S * DF_discount(spot_lag) / DF_repo(T + settle_lag)
        DF_discount = market_data.discount_curve (pure cash discounting), spot is only
        deliverable spot_lag days after t, so its present value is discounted back over
        [t, t+spot_lag]. DF_repo = market_data.repo_curve, taken as the NET cost-of-carry
        curve (already nets out dividends; no separate div_curve term), the asset isn't
        exchanged/financed until settle_lag days after expiry, so it grows the forward out
        to T + settle_lag, not just T.
      - The option's own PAYOFF discount factor also uses T + settle_lag, not T (cash
        doesn't move until settlement): discount_factor = DF_discount(T + settle_lag).
      So black_scholes_price is called with expiry=T (drives d1/d2) but a discount_factor
      evaluated at T + settle_lag.

    Both lags default to 0 (unlagged, i.e. identical to this function's original
    behaviour: F(T) = S*div_df(T)/repo_df(T), discount_factor = disc_df(T)).

    Each returned quote carries the forward/discount_factor actually used to price it
    (SVIOptionQuote.forward/.discount_factor), write_heston_csv reads these back rather
    than recomputing, so the exported r/q stay exactly consistent with these prices even
    when the lags are nonzero.
    """
    quotes: List[SVIOptionQuote] = []
    disc, repo = market_data.discount_curve, market_data.repo_curve
    spot_lag_years = spot_lag_days / 365.0
    for T in maturities_years:
        atm_ref = svi_surface.atm_ref_at(T)
        settle_lag_years = settlement_lag_days / 365.0
        T_settle = T + settle_lag_years
        forward = market_data.spot * float(disc.discount_factor(spot_lag_years)) \
            / float(repo.discount_factor(T_settle))
        discount_factor = float(disc.discount_factor(T_settle))
        expiry_date = valuation_date + timedelta(days=round(T * 365))
        settlement_date = expiry_date + timedelta(days=round(settlement_lag_days))
        for pct in moneyness_pcts:
            strike = pct * atm_ref
            vol = svi_surface.get_vol(strike, T, forward=forward)
            option_type = option_type_rule(pct)
            price = black_scholes_price(forward, strike, vol, T, discount_factor, option_type)
            quotes.append(SVIOptionQuote(
                expiry_date=expiry_date, settlement_date=settlement_date,
                contract_size=contract_size, option_type=option_type, strike=strike,
                quoted_price=contract_size * price, vol=vol, moneyness_pct=pct,
                maturity_years=T, forward=forward, discount_factor=discount_factor,
            ))
    return quotes


def write_heston_csv(quotes: List[SVIOptionQuote], market_data, path: Union[str, Path]) -> None:
    """
    Write ``quotes`` to a CSV file for a model calibration to read (header ``T,K,price,type,r,q``), so a calibration can read this file with
    ``INPUT = "csv"`` / ``CSV_FILE = <this path>`` in run_calibration.py, no cross-module import
    needed.

    r/q are back-solved PER QUOTE from quote.forward / quote.discount_factor, the EXACT
    forward and discount factor generate_svi_option_grid used to price that quote, not
    recomputed independently from market_data.forward(T)/.df(T). This matters whenever that
    grid was generated with a nonzero spot_lag_days/settlement_lag_days: quote.forward and
    quote.discount_factor already reflect the lag (see generate_svi_option_grid's own
    docstring), so solving
        r(T) = -ln(quote.discount_factor) / T
        q(T) = r(T) - ln(quote.forward / spot) / T
    gives an (r, q) pair whose PLAIN, unlagged Black-76 (``S0*exp((r-q)*T)``, discount
    ``exp(-r*T)``, as heston_calibration.py's own implied_vol() assumes) reproduces the
    SAME forward and discount factor, so inverting this CSV's price recovers exactly the
    SVI-implied vol the quote was generated from, lagged or not.

    ``price`` is PER UNIT of the underlying (divided by contract_size), MarketData.from_prices'
    own implied_vol() assumes a unit notional, matching spot's own units. bid/ask columns are
    omitted (not written as blanks) since these are theoretical, SVI-implied prices with no real
    market spread, use WEIGHTS != "spread" on the calibration side.
    """
    spot = market_data.spot
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["T", "K", "price", "type", "r", "q"])
        for quote in quotes:
            T = quote.maturity_years
            r = -np.log(quote.discount_factor) / T
            q = r - np.log(quote.forward / spot) / T
            price_per_unit = quote.quoted_price / quote.contract_size
            w.writerow([T, quote.strike, price_per_unit, quote.option_type, r, q])
