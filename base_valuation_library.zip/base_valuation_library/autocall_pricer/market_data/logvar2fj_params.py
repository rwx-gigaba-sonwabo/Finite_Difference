"""
LogVar2FJModelParameters, market-data container for the LogVar2FJ stochastic-vol-with-jumps
spot model.

Two log-variance OU factors (slow ``ell``, fast ``s``) plus a normal-inverse-Gaussian (NIG)
residual on the idiosyncratic variance clock. ``models/logvar2fj.py`` simulates the model.

Layout of the ``LogVar2FJModelParameters.<underlying>`` price factor in the trade file:
    {
      "Kappa_L": <float>, "Sigma_L": <float>, "Rho_L": <float>, "Kappa_S": <float>,
      "Cap_A": <float or null>, "Steps_Per_Year": <float>, "C_Min": <float>,
      "Residual_Law": "NIG" | "Gaussian",
      "Property_Aliases": ..., "On_Guard": ..., "Skew_Gradient": ..., "Stickiness_Band": ...,
                                    # ^ calibration diagnostics, recorded, not used for pricing
      "Xi_Curve": {".Curve": {"meta": [], "data": [[t_years, value], ...]}},
      "Rho_S":    {".Curve": {"meta": [], "data": [[t_years, value], ...]}},
      "Beta":     {".Curve": {"meta": [], "data": [[t_years, value], ...]}},
      "Sigma_S":  {".Curve": {"meta": [], "data": [[t_years, value], ...]}},
      "Alpha":    {".Curve": {"meta": [], "data": [[t_years, value], ...]}}
    }

All five curves are PIECEWISE CONSTANT on calendar-time buckets whose knots are the bucket
START times (in years from valuation date), a single knot at 0 is the constant-parameter
model. ``Xi_Curve`` is the expected forward variance E_0[h_t] (what a variance swap pays);
the OU mean level the slow factor reverts to is DERIVED from it, not supplied directly.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple, Union

import numpy as np


@dataclass
class BucketedCurve:
    """A piecewise-CONSTANT curve: the value in force at t is the one at the last knot <= t."""

    knots: np.ndarray     # [n] year fractions, ascending
    values: np.ndarray    # [n]

    @classmethod
    def from_points(cls, points) -> "BucketedCurve":
        pts = sorted((float(t), float(v)) for t, v in points)
        return cls(knots=np.array([t for t, _ in pts]),
                   values=np.array([v for _, v in pts]))

    def at(self, t) -> np.ndarray:
        """Value in force at year-fraction(s) t (scalar or array)."""
        t = np.atleast_1d(np.asarray(t, dtype=float))
        idx = np.clip(np.searchsorted(self.knots, t, side="right") - 1, 0, len(self.knots) - 1)
        return self.values[idx]

    def bucket_index(self, t) -> np.ndarray:
        """Which bucket (0-indexed) each t falls in, used to detect a bucket boundary
        inside a fixing interval (drawing one NIG piece per bucket the interval spans)."""
        t = np.atleast_1d(np.asarray(t, dtype=float))
        return np.clip(np.searchsorted(self.knots, t, side="right") - 1, 0, len(self.knots) - 1)

    def is_single_bucket(self) -> bool:
        return len(self.knots) <= 1


@dataclass
class LogVar2FJParams:
    """One underlying's calibrated LogVar2FJ parameters."""

    # scalars
    kappa_l: float
    sigma_l: float
    rho_l: float
    kappa_s: float
    cap_a: float               # None -> unbounded (min(l+s, cap_a) with cap_a=+inf)
    steps_per_year: float
    c_min: float
    residual_law: str          # "NIG" | "Gaussian"

    # curves (bucketed, piecewise constant)
    xi_curve: BucketedCurve    # E_0[h_t], expected forward variance
    rho_s: BucketedCurve
    sigma_s: BucketedCurve
    alpha: BucketedCurve
    beta: BucketedCurve

    source: str = ""

    def validate(self) -> None:
        for name, curve in (("Rho_S", self.rho_s), ("Beta", self.beta),
                            ("Sigma_S", self.sigma_s), ("Alpha", self.alpha)):
            if len(curve.knots) == 0:
                raise ValueError(f"{self.source}: {name} curve is empty")
        if self.residual_law not in ("NIG", "Gaussian"):
            raise ValueError(f"{self.source}: Residual_Law must be 'NIG' or 'Gaussian', "
                             f"got {self.residual_law!r}")
        # the guard the factor itself asserts at load: c(t) = 1 - Rho_S(t)^2 - Rho_L^2 >= C_Min
        c = 1.0 - self.rho_s.values ** 2 - self.rho_l ** 2
        if np.any(c < self.c_min - 1e-9):
            raise ValueError(
                f"{self.source}: idiosyncratic share c(t)={c.min():.4f} falls below "
                f"C_Min={self.c_min} on at least one bucket")


def _curve_data(node: Any) -> list:
    if isinstance(node, dict) and ".Curve" in node:
        return node[".Curve"]["data"]
    raise ValueError("not a .Curve node")


def load_logvar2fj_params(json_path: Union[str, Path], factor_key: str) -> LogVar2FJParams:
    """
    Pull a ``LogVar2FJModelParameters.<underlying>`` price factor out of a trade file or a
    market-data JSON. Handles both JSON layouts: a deal job
    (``Calc.MergeMarketData.ExplicitMarketData.Price Factors``) and a standalone market-data
    file (``MarketData.Price Factors``).
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    pf = None
    for path in (
        lambda b: b["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"],
        lambda b: b["MarketData"]["Price Factors"],
    ):
        try:
            pf = path(blob)
            break
        except KeyError:
            continue
    if pf is None:
        raise KeyError("could not find 'Price Factors' under either the job or market-data layout")
    if factor_key not in pf:
        matches = sorted(k for k in pf if k.startswith("LogVar2FJModelParameters"))
        raise KeyError(f"{factor_key!r} not in Price Factors. LogVar2FJ factors present: {matches}")
    node = pf[factor_key]

    def curve(name: str) -> BucketedCurve:
        return BucketedCurve.from_points(_curve_data(node[name]))

    cap_a = node.get("Cap_A")
    return LogVar2FJParams(
        kappa_l=float(node["Kappa_L"]), sigma_l=float(node["Sigma_L"]),
        rho_l=float(node["Rho_L"]), kappa_s=float(node["Kappa_S"]),
        cap_a=float(cap_a) if cap_a is not None else None,
        steps_per_year=float(node["Steps_Per_Year"]), c_min=float(node["C_Min"]),
        residual_law=str(node["Residual_Law"]),
        xi_curve=curve("Xi_Curve"), rho_s=curve("Rho_S"), sigma_s=curve("Sigma_S"),
        alpha=curve("Alpha"), beta=curve("Beta"), source=factor_key)


def load_spot_model(json_path: Union[str, Path], deal_type: str) -> Dict[str, Any]:
    """
    Read a deal type's ``Valuation Configuration`` block from a trade JSON file, e.g.
    ``load_spot_model(path, "QEDI_CustomAutoCallSwap_V2") -> {"SpotModel": "LogVar2FJ"}``.
    Returns {} if the deal type has no Valuation Configuration entry (-> SpotModel: 'None').
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    vc = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"].get("Valuation Configuration", {})
    return dict(vc.get(deal_type, {}))
