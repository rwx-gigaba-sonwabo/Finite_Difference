"""Parametric equity volatility skew, one set of parameters per tenor.

Each tenor has a volatility at the money and parameters for the slope and the curvature of
the smile on each side, with separate treatment of the far wings. The parameters are
stored as curves by tenor: ``ATM_Vol``, ``s``, ``L``, ``R``, ``C``, ``D``, ``lam`` and
``rho``, with a shared reference level ``ATM_Ref``.

How a volatility is read
------------------------
1. The moneyness is ``x = ln(strike / ATM_Ref)`` when the surface is sticky in strike, and
   ``x = ln(strike / forward)`` when it is sticky in moneyness. The strike itself is needed,
   not a ratio of spot to strike.
2. The smile of each of the two tenors around the expiry is evaluated at ``x``.
3. The two volatilities are interpolated in a straight line in volatility.

The surface is read from a trade JSON file with ``load_skew_surface``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import numpy as np


@dataclass
class SkewSurface:
    """Per-tenor parametric Skew surface. Build via ``load_skew_surface``; ``get_vol`` is the
    only method a caller normally needs. ``needs_strike = True`` tells EquityMarketData.vol()
    to pass the ABSOLUTE STRIKE here rather than a spot/strike ratio (see that method's own
    docstring)."""

    tenor: np.ndarray        # [n_tenors], ascending, years
    atm_ref: np.ndarray      # [n_tenors]
    atm_vol: np.ndarray      # [n_tenors]
    s: np.ndarray            # [n_tenors]
    L: np.ndarray            # [n_tenors]
    R: np.ndarray            # [n_tenors]
    C: np.ndarray            # [n_tenors]
    D: np.ndarray            # [n_tenors]
    lam: np.ndarray          # [n_tenors]
    rho: np.ndarray          # [n_tenors]
    moneyness_rule: str = "Sticky_Strike"
    source: str = ""

    needs_strike = True

    def _tenor_bracket(self, t: float):
        """(idx, idx_next, alpha) s.t. t = (1-alpha)*tenor[idx] + alpha*tenor[idx_next],
        flat extrapolation beyond the first/last knot
        (identical to SVISurface's own bracket logic)."""
        knots = self.tenor
        if t <= knots[0]:
            return 0, 0, 0.0
        if t >= knots[-1]:
            n = len(knots) - 1
            return n, n, 0.0
        idx = int(np.clip(np.searchsorted(knots, t) - 1, 0, len(knots) - 2))
        alpha = (t - knots[idx]) / (knots[idx + 1] - knots[idx])
        return idx, idx + 1, float(alpha)

    def atm_ref_at(self, expiry: float) -> float:
        """ATM_Ref(expiry), linearly tenor-interpolated, same role as in SVISurface."""
        i, j, alpha = self._tenor_bracket(expiry)
        return float(self.atm_ref[i] * (1.0 - alpha) + self.atm_ref[j] * alpha)

    def _calc_skew(self, idx: int, x: float) -> float:
        """The 6-region skew formula at tenor index ``idx``, evaluated at log-moneyness x."""
        atm_vol, s, L, R, C, D = (float(self.atm_vol[idx]), float(self.s[idx]), float(self.L[idx]),
                                  float(self.R[idx]), float(self.C[idx]), float(self.D[idx]))
        lam, rho = float(self.lam[idx]), float(self.rho[idx])

        # gamma/beta/alpha divide by C*lam (resp. D*rho), genuinely undefined, not merely an
        # ignorable warning, when either factor is zero. atm_vol/s/L/R/C/D/lam/rho are plain
        # Python floats (cast above), so a zero denominator is a real ZeroDivisionError,
        # np.errstate only suppresses NUMPY's own float warnings and does nothing for native
        # Python division, which was the bug here: the lam_ok/rho_ok guard below existed but
        # ran AFTER the division already blew up, not before it. The convention for
        # this degenerate case is a FLAT wing (left_flat/right_flat), so the fix is to skip the
        # division entirely when it's unsafe, not to merely silence a warning that was never
        # numpy's to suppress. Also gates on C/D != 0 (not just lam/rho), since both sit in the
        # same denominator, the original guard missed that half of the case.
        lam_ok = (lam != 0.0) and (C != 0.0)
        rho_ok = (rho != 0.0) and (D != 0.0)

        if lam_ok:
            s2LC = s + 2.0 * L * C
            gamma = s2LC / (-2.0 * C * lam)
            beta = s2LC * (1.0 + 1.0 / lam)
            alpha = atm_vol + C * ((s - beta) + C * (L - gamma))

        if rho_ok:
            s2RD = s + 2.0 * R * D
            gamma_r = s2RD / (-2.0 * D * rho)
            beta_r = s2RD * (1.0 + 1.0 / rho)
            alpha_r = atm_vol + D * ((s - beta_r) + D * (R - gamma_r))

        left_flat = atm_vol + C * (s + L * C)     # fallback when lam/C degenerate (left wing flat)
        right_flat = atm_vol + D * (s + R * D)    # fallback when rho/D degenerate (right wing flat)

        if x <= (1.0 + lam) * C:
            return (alpha + C * (beta * (1.0 + lam) + gamma * (1.0 + lam) ** 2 * C)
                   if lam_ok else left_flat)
        if x <= C:
            return (alpha + x * (beta + gamma * x)) if lam_ok else left_flat
        if x <= 0.0:
            return atm_vol + x * (s + L * x)
        if x <= D:
            return atm_vol + x * (s + R * x)
        if x < (1.0 + rho) * D:
            return (alpha_r + x * (beta_r + gamma_r * x)) if rho_ok else right_flat
        return (alpha_r + D * (beta_r * (1.0 + rho) + gamma_r * (1.0 + rho) ** 2 * D)
               if rho_ok else right_flat)

    def get_vol(self, strike: Optional[float], expiry: float, forward: Optional[float] = None) -> float:
        """Implied vol at (strike, expiry). ``forward`` is required only for
        Moneyness_Rule='Sticky_Moneyness'; this surface's own rule decides which is used.

        ``strike=None`` means TRUE ATM: x=0 directly, bypassing spot/ATM_Ref
        entirely (see SVISurface.get_vol's own identical note)."""
        if strike is None:
            x = 0.0
        elif self.moneyness_rule == "Sticky_Strike":
            x = float(np.log(strike / self.atm_ref_at(expiry)))
        elif self.moneyness_rule == "Sticky_Moneyness":
            if forward is None:
                raise ValueError("Sticky_Moneyness needs the option's own forward")
            x = float(np.log(strike / forward))
        else:
            raise NotImplementedError(f"Moneyness_Rule={self.moneyness_rule!r} not supported")

        i, j, alpha = self._tenor_bracket(expiry)
        vol_prior = self._calc_skew(i, x)
        vol_post = self._calc_skew(j, x)
        return float(vol_prior * (1.0 - alpha) + vol_post * alpha)   # VOL-space blend (not variance)


def load_skew_surface(json_path: Union[str, Path], factor_key: str) -> SkewSurface:
    """
    Pull a Skew surface out of the trade JSON file by factor key, e.g.
    "EquityPriceVol.JPY_NKY_BBG.JPY". Same two JSON layouts as load_svi_surface.
    """
    with open(json_path) as fh:
        blob = json.load(fh)
    try:
        pf = blob["Calc"]["MergeMarketData"]["ExplicitMarketData"]["Price Factors"]
    except KeyError:
        pf = blob["MarketData"]["Price Factors"]
    if factor_key not in pf:
        raise KeyError(f"{factor_key!r} not in Price Factors. Available: {sorted(pf)}")
    node = pf[factor_key]
    if node.get("Surface_Type") != "Skew":
        raise ValueError(
            f"{factor_key!r} is Surface_Type={node.get('Surface_Type')!r}, not 'Skew'")

    def curve(name: str) -> np.ndarray:
        pts = sorted((float(t), float(v)) for t, v in node[name][".Curve"]["data"])
        return np.array(pts, dtype=float)

    atm_ref, atm_vol, s, L, R, C, D, lam, rho = (
        curve(x) for x in ("ATM_Ref", "ATM_Vol", "s", "L", "R", "C", "D", "lam", "rho"))
    tenor = atm_ref[:, 0]
    for name, arr in (("ATM_Vol", atm_vol), ("s", s), ("L", L), ("R", R), ("C", C),
                      ("D", D), ("lam", lam), ("rho", rho)):
        if arr.shape[0] != tenor.shape[0] or not np.allclose(arr[:, 0], tenor):
            raise ValueError(
                f"{factor_key!r}: {name!r}'s tenor knots don't match ATM_Ref's, "
                f"the nine Skew curves are expected to share one tenor grid")

    return SkewSurface(
        tenor=tenor, atm_ref=atm_ref[:, 1], atm_vol=atm_vol[:, 1], s=s[:, 1], L=L[:, 1],
        R=R[:, 1], C=C[:, 1], D=D[:, 1], lam=lam[:, 1], rho=rho[:, 1],
        moneyness_rule=node.get("Moneyness_Rule", "Sticky_Strike"), source=factor_key,
    )
