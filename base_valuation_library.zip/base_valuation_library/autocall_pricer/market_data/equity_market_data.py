"""
Equity market-data container for autocall / equity-derivative pricing.

Extends the generic MarketData concept with the fields an equity Monte Carlo needs:
spot, repo (funding/carry) curve, continuous dividend-yield curve, an equity vol surface
(or flat vol), and the FX vol / equity-FX correlation used for quanto & compo payoffs.

Curve objects are duck-typed: any object exposing `discount_factor(t: float) -> float`
(year-fraction based, e.g. curve.FlatDiscountCurve) works for the discount / repo / div
curves. Vol may be a flat float or any object exposing
`get_vol(moneyness, expiry, maturity)`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any, Callable, Optional

import numpy as np


def act365(start: date, end: date) -> float:
    """ACT/365 year fraction (matches curve.discount_curve_flat.act365)."""
    return (end - start).days / 365.0


def atm_vol_of(surface, expiry: float, forward: Optional[float] = None) -> float:
    """TRUE ATM vol of any flat-float/EquityVolSurface/SVISurface/SkewSurface, standalone,
    the same dispatch EquityMarketData.atm_vol() uses for equity_vol, exposed here so a
    surface that ISN'T wrapped in an EquityMarketData (e.g. an FXVol surface read for a
    quanto drift) can be read the same way. See EquityMarketData.atm_vol's
    own docstring for why "true ATM" (x=0 directly) differs from moneyness=1.0 on a
    Sticky_Strike SVI/Skew surface."""
    if isinstance(surface, (int, float, np.floating)):
        return float(surface)
    if getattr(surface, "needs_strike", False):
        return float(surface.get_vol(None, expiry, forward=forward))
    return float(surface.get_vol(1.0, expiry, expiry))


@dataclass
class EquityMarketData:
    """
    Market data required to Monte-Carlo an equity autocall.

    Attributes:
        valuation_date: as-of date.
        spot: current underlying spot level.
        discount_curve: payoff-currency discounting; needs discount_factor(t).
        repo_curve: equity funding/carry rate curve (the 'r' in r - q); discount_factor(t).
        div_curve: continuous dividend-yield curve (the 'q'); discount_factor(t).
        equity_vol: flat vol (float) or surface object with get_vol(moneyness, expiry, mat).
        fx_vol: FX vol for quanto/compo drift-vol adjustment (flat, annualised).
        corr_equity_fx: correlation between equity and FX log-returns.
        discrete_dividends: optional list of (ex_date, cash_amount); used in Phase 4.
        day_count: year-fraction function (default ACT/365).
    """

    valuation_date: date
    spot: float
    discount_curve: Any
    repo_curve: Any
    div_curve: Any
    equity_vol: Any
    fx_vol: float = 0.0
    corr_equity_fx: float = 0.0
    discrete_dividends: Optional[list] = None
    day_count: Callable[[date, date], float] = act365

    # ------------------------------------------------------------------ times
    def yearfrac(self, d: date) -> float:
        """Year fraction from valuation_date to d."""
        return self.day_count(self.valuation_date, d)

    # -------------------------------------------------------------- discounting
    def df(self, t: float) -> float:
        """Discount factor to year fraction t (payoff currency)."""
        return float(self.discount_curve.discount_factor(t))

    # ------------------------------------------------------------------ forward
    def forward(self, t: float) -> float:
        """
        Equity forward to year fraction t under the continuous-yield model:
            F(t) = spot * exp((r - q) t) = spot * div_df(t) / repo_df(t)
        where repo_df = exp(-r t), div_df = exp(-q t).
        """
        repo_df = float(self.repo_curve.discount_factor(t))
        div_df = float(self.div_curve.discount_factor(t))
        return self.spot * div_df / repo_df

    def log_drift(self, t0: float, t1: float) -> float:
        """
        Integrated log-drift of the forward over [t0, t1], i.e. ln(F(t1)/F(t0)).
        This is the (r - q) contribution to the GBM step and is curve-consistent by
        construction. Quanto/vol adjustments are applied on top by the engine.
        """
        f0 = self.forward(t0) if t0 > 0 else self.spot
        f1 = self.forward(t1)
        return float(np.log(f1 / f0))

    def repo_growth_log(self, t0: float, t1: float) -> float:
        """
        Integrated funding (repo) rate over [t0, t1] = r*(t1-t0) for flat curves.
        Used as the GBM drift in DISCRETE-dividend mode, where dividends are applied as
        explicit drops rather than a continuous yield (so div_curve is not used here).
        """
        df0 = float(self.repo_curve.discount_factor(t0)) if t0 > 0 else 1.0
        df1 = float(self.repo_curve.discount_factor(t1))
        return float(-np.log(df1 / df0))

    # ---------------------------------------------------------------------- vol
    def vol(self, expiry: float, moneyness: float = 1.0, maturity: Optional[float] = None) -> float:
        """
        Equity vol for the given expiry (year fraction) and moneyness.
        Flat float is returned as-is; a surface is queried via get_vol.

        ``moneyness`` here is spot/strike (a ratio), matching market_data.vol_surface.
        EquityVolSurface's own convention for "Explicit" (raw triples) surfaces.
        SVI and Skew surfaces (market_data/svi_surface.py, market_data/skew_surface.py) need
        the ABSOLUTE STRIKE instead: a Sticky_Strike surface divides by ATM_Ref "later", so it takes the raw
        strike, not a ratio. Those surfaces set a `needs_strike = True` class attribute; this
        recovers strike = spot / moneyness (moneyness is already spot/strike) and also
        supplies this market's own forward(expiry), for the Sticky_Moneyness case those
        surfaces also support.
        """
        if isinstance(self.equity_vol, (int, float, np.floating)):
            return float(self.equity_vol)
        mat = maturity if maturity is not None else expiry
        if getattr(self.equity_vol, "needs_strike", False):
            strike = self.spot / moneyness if moneyness else self.spot
            return float(self.equity_vol.get_vol(strike, expiry, forward=self.forward(expiry)))
        return float(self.equity_vol.get_vol(moneyness, expiry, mat))

    def atm_vol(self, expiry: float) -> float:
        """TRUE ATM vol at this expiry (x = 0 on the surface, which only coincides with moneyness 1.0 if spot happens to equal
        that tenor's own ATM_Ref). Use this instead of ``vol(expiry, moneyness=1.0)`` wherever
        you want the surface's own ATM read (e.g. the quanto carry adjustment's equity vol),
        which is genuinely a different number from the deal's own trigger/barrier-strike vol
        on a skewed surface, not an approximation of it."""
        return atm_vol_of(self.equity_vol, expiry, forward=self.forward(expiry))
