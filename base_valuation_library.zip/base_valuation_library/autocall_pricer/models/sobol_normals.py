"""Normal random numbers from a scrambled Sobol sequence.

A Sobol sequence is a low discrepancy sequence. Its points fill the unit cube more evenly
than pseudo random points, which can lower the sampling noise of a simulation.

This module draws one block of points of a given width (the number of dimensions) and
length (the number of samples) and turns them into standard normal numbers.

Fixed settings
--------------
* The scramble seed is the constant ``QUASI_SEED``. It does not depend on any seed chosen
  by the caller.
* The stream starts at the constant offset ``QUASI_ANCHOR``.
* A request is identified by its width, its length and an index. The same request always
  returns the same block. The position in the stream is
  ``QUASI_ANCHOR + index * span * sample_size``.
* A block wider than the generator's largest dimension is drawn in chunks.

The module needs the ``torch`` package, which supplies the Sobol generator.
"""

from __future__ import annotations

import numpy as np
import torch

#: Fixed scramble seed of the Sobol sequence. It does not depend on any seed the caller sets.
QUASI_SEED = 1234

#: Fixed starting offset into the Sobol stream.
QUASI_ANCHOR = 1024

#: Largest number of dimensions the Sobol generator supports in one draw.
SOBOL_MAX_DIMENSION = 21201

_CLAMP_MARGIN = 1.0e-6


def sobol_position(dimension: int, sample_size: int, index: int = 0) -> int:
    """Position in the Sobol stream where one (dimension, sample_size, index) request starts."""
    span = -(-dimension // SOBOL_MAX_DIMENSION)   # number of chunks, rounded up
    return QUASI_ANCHOR + index * span * sample_size


def sobol_uniforms(dimension: int, sample_size: int, index: int = 0) -> np.ndarray:
    """Scrambled Sobol points in the unit cube for one (dimension, sample_size, index)
    request, shape [sample_size, dimension]. The generator is moved forward to the start
    position of the request, so the same request always returns the same points.
    """
    position = sobol_position(dimension, sample_size, index)
    chunks = []
    at = position
    for start in range(0, dimension, SOBOL_MAX_DIMENSION):
        width = min(SOBOL_MAX_DIMENSION, dimension - start)
        engine = torch.quasirandom.SobolEngine(dimension=width, scramble=True, seed=QUASI_SEED)
        engine.fast_forward(at)
        chunks.append(engine.draw(sample_size, dtype=torch.float64))
        at += sample_size
    sample = chunks[0] if len(chunks) == 1 else torch.cat(chunks, dim=1)
    u = sample.clamp(min=_CLAMP_MARGIN, max=1.0 - _CLAMP_MARGIN)
    return u.numpy()


def sobol_normals(dimension: int, sample_size: int, index: int = 0) -> np.ndarray:
    """sobol_uniforms() inverse-CDF'd to standard normals via scipy.stats.norm.ppf, NOT
    a hand-coded inverse (see this module's own docstring). Shape
    [sample_size, dimension]."""
    from scipy.stats import norm
    return norm.ppf(sobol_uniforms(dimension, sample_size, index))
