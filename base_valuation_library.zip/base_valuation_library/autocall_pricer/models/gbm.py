"""Monte Carlo simulation of an equity price on the observation dates of an autocallable swap.

The equity follows a lognormal process with a continuous dividend yield. Between two
observation dates the step has a closed form, so each step is drawn exactly and there is no
discretisation error:

    ln S_j = ln S_(j-1) + ln(F(t_j) / F(t_(j-1))) - variance_j / 2 + sqrt(variance_j) * Z_j

``F(t)`` is the forward price to time ``t`` and ``Z_j`` is a standard normal draw. The
average of the simulated prices at each date equals the forward price, up to sampling noise.

How the variance of each step is chosen (``vol_mode``)
------------------------------------------------------
"forward" (default)
    The variance of step ``j`` is ``sigma(t_j)**2 * t_j - sigma(t_(j-1))**2 * t_(j-1)``, where
    ``sigma(t)`` is the volatility read off the surface for time ``t``. The total variance to
    every observation date then equals the surface's own.
"single"
    Every step uses the volatility for the final date. Only the final date has the right
    total variance.
"step"
    Each step uses the volatility for its own end date as if it applied to that step alone.

Which point of the volatility smile is read
-------------------------------------------
``simulate`` reads the surface at one moneyness for the whole trade, spot over strike.

``simulate_per_leg`` reads it per leg. The coupon paths use the volatility at each coupon's
trigger level. The put paths use the volatility at the put barrier. Both sets of paths are
built from the same random numbers. Use it when the trigger levels step down over time, or
when the put barrier sits at a different point of a sloped smile than the trigger.

``simulate_at_strike`` and ``simulate_at_strikes`` build paths with the volatility read at
given strikes. The booked put leg uses them.

Random numbers (``rng_source``)
-------------------------------
"numpy" (default)
    Pseudo random normal draws from a seeded generator. With ``antithetic`` on, each draw is
    used a second time with its sign flipped, which lowers the sampling noise.
"sobol"
    Low discrepancy Sobol points turned into normal draws, from ``models/sobol_normals.py``.
    The points are used as they come, without the sign flipped copies, and ``seed`` is not
    used because the Sobol sequence has its own fixed scramble seed. This option needs the
    ``torch`` package.

Quanto payout
-------------
``quanto_adj`` adds a constant to the drift per year. For a payout converted at a fixed FX
rate it is minus the correlation times the equity volatility times the FX volatility.
"""

from __future__ import annotations

import warnings

import numpy as np


class GBMEngine:
    def __init__(
        self,
        n_paths: int = 100_000,
        seed: int | None = None,
        antithetic: bool = True,
        single_vol: bool | None = None,
        vol_mode: str | None = None,
        quanto_adj: float = 0.0,
        rng_source: str = "numpy",
        sobol_index: int = 0,
    ):
        """
        Args:
            n_paths: number of simulated paths (rounded down to even if antithetic).
            seed: RNG seed for reproducibility. Ignored (with a warning) if rng_source="sobol".
            antithetic: use antithetic variates (halves independent normals). Forced to
                False (with a warning if explicitly True) if rng_source="sobol", see
                module docstring.
            single_vol: legacy flag; True -> vol_mode "single", False -> "step". None
                (default) defers to vol_mode. Ignored if vol_mode is given explicitly.
            vol_mode: "single" | "step" | "forward" (see module docstring). None (and
                single_vol also None, i.e. nothing specified at all) now defaults to
                "forward", not "single".
                Passing single_vol explicitly still works
                as before.
            quanto_adj: annualised drift shift added each step (the domestic-measure
                quanto adjustment -rho*sigma_S*sigma_FX; 0 for vanilla). This is the
                analytic quanto drift; the FX-simulation cross-check lives in
                models/fx_gbm.py and must reproduce the same price.
            rng_source: "numpy" (default) | "sobol", see module docstring's own "RANDOM
                NUMBER SOURCE" section for exactly what "sobol" does and doesn't replicate.
            sobol_index: which (dimension, sample_size) draw of the fixed Sobol stream
                to read when rng_source="sobol" (models/sobol_normals.py); 0 (default) is
                the first draw of that shape. Ignored under rng_source="numpy".
        """
        if rng_source not in ("numpy", "sobol"):
            raise ValueError(f"rng_source must be 'numpy' or 'sobol', got {rng_source!r}")
        if rng_source == "sobol":
            if antithetic:
                warnings.warn(
                    "GBMEngine(rng_source='sobol'): antithetic forced to False. The Sobol block "
                    "is drawn once and "
                    "consumed RAW, with no antithetic mirroring. "
                    "See the module docstring.",
                    stacklevel=2,
                )
                antithetic = False
            if seed is not None:
                warnings.warn(
                    "GBMEngine(rng_source='sobol'): `seed` is ignored. The "
                    "Sobol stream uses a FIXED scramble seed (QUASI_SEED=1234, "
                    "models/sobol_normals.py), deliberately not derived from the job's own "
                    "Random_Seed field, which this replicates exactly.",
                    stacklevel=2,
                )
        self.n_paths = n_paths
        self.seed = seed
        self.antithetic = antithetic
        self.single_vol = single_vol
        self.rng_source = rng_source
        self.sobol_index = sobol_index
        if vol_mode is not None:
            self.vol_mode = vol_mode
        elif single_vol is not None:
            self.vol_mode = "single" if single_vol else "step"
        else:
            self.vol_mode = "forward"
        if self.vol_mode not in ("single", "step", "forward"):
            raise ValueError(f"vol_mode must be 'single', 'step' or 'forward', got {self.vol_mode!r}")
        self.quanto_adj = quanto_adj

    # ------------------------------------------------------------------ normals
    def _draw_normals(self, n_paths: int, n_steps: int) -> np.ndarray:
        """[n_paths, n_steps] standard normals. rng_source="sobol" reads the fixed
        Sobol stream (dimension=n_steps, sample_size=n_paths, index=self.sobol_index) via
        models/sobol_normals.py, imported here (not at module level) so this file stays
        torch-free under the "numpy" default, see the module docstring's own "RANDOM
        NUMBER SOURCE" section."""
        if self.rng_source == "sobol":
            from autocall_pricer.models.sobol_normals import sobol_normals
            return sobol_normals(dimension=n_steps, sample_size=n_paths, index=self.sobol_index)
        rng = np.random.default_rng(self.seed)
        if self.antithetic:
            half = n_paths // 2
            z = rng.standard_normal((half, n_steps))
            return np.concatenate([z, -z], axis=0)
        return rng.standard_normal((n_paths, n_steps))

    # -------------------------------------------------------------------- vols
    def _step_variances(self, times, market_data, moneyness: float = 1.0) -> np.ndarray:
        """
        Per-step integrated variances for a strictly increasing time grid [n].

        ``moneyness`` is the ONE slice through the surface used for every lookup below,
        that is spot0 / strike, fixed at
        the valuation-date spot (not re-derived per step). ``simulate`` computes this once
        and passes it down; callers with no strike concept (moneyness=1.0, ATM) get the
        previous behaviour.

        "single":  terminal-date term vol applied uniformly -> var_j = sigma(t_n)^2 * dt_j.
        "step":    each step uses the term vol at its own end date as a local vol ->
                   var_j = sigma(t_j)^2 * dt_j (NOT term-variance consistent for j < n).
        "forward": var_j = sigma(t_j)^2 t_j - sigma(t_{j-1})^2 t_{j-1}, so the cumulative
                   variance to every t_j is exactly sigma(t_j)^2 t_j (each fixing its own
                   term vol; invariant to later dates).
        """
        times = np.asarray(times, dtype=float)
        prev = np.concatenate([[0.0], times[:-1]])
        dt = times - prev
        if self.vol_mode == "single":
            s = market_data.vol(expiry=float(times[-1]), moneyness=moneyness)
            return (s * s) * dt
        if self.vol_mode == "step":
            s = np.array([market_data.vol(expiry=float(t), moneyness=moneyness) for t in times])
            return (s * s) * dt
        # forward: differences of cumulative term variance sigma(t)^2 * t
        cum = np.array([market_data.vol(expiry=float(t), moneyness=moneyness) ** 2 * t for t in times])
        var = cum - np.concatenate([[0.0], cum[:-1]])
        if np.any(var < -1e-12):
            raise ValueError(
                "negative forward variance: the vol term structure is calendar-arbitrageable "
                "(sigma(t)^2 * t must be non-decreasing)"
            )
        return np.maximum(var, 0.0)

    @staticmethod
    def _moneyness(schedule, market_data) -> float:
        """spot0 / strike. Falls back to 1.0
        (ATM) if the schedule carries no strike (e.g. a non-autocall caller)."""
        strike = getattr(schedule, "strike", None)
        if not strike:
            return 1.0
        return float(market_data.spot) / float(strike)

    @staticmethod
    def _forward_var_at_strike(times, market_data, abs_strike: float) -> np.ndarray:
        """Per-step forward variance (cumulative-variance differences, "forward" mode's own
        construction) at a FIXED ABSOLUTE STRIKE:
        the whole cumulative-variance curve is built
        at this ONE strike across every fixing, then forward-differenced. Used by
        simulate_per_leg to build one strip per distinct coupon threshold level and another
        for the put leg at its own barrier strike, never called by simulate() itself,
        which uses one deal-level moneyness instead (see _moneyness)."""
        times = np.asarray(times, dtype=float)
        moneyness = float(market_data.spot) / float(abs_strike) if abs_strike else 1.0
        cum = np.array([market_data.vol(expiry=float(t), moneyness=moneyness) ** 2 * t for t in times])
        var = cum - np.concatenate([[0.0], cum[:-1]])
        if np.any(var < -1e-12):
            raise ValueError(
                "negative forward variance: the vol term structure is calendar-arbitrageable "
                "(sigma(t)^2 * t must be non-decreasing)"
            )
        return np.maximum(var, 0.0)

    @staticmethod
    def _paths_from_var(spot0: float, drift: np.ndarray, var: np.ndarray, z: np.ndarray) -> np.ndarray:
        """Exact-lognormal path from a given per-step drift/variance and SHARED normal draws
        z [n_paths, n_steps], the one place both simulate() and simulate_per_leg() turn
        (drift, var, z) into spot_paths, so two paths built from the same z (different var)
        are the same underlying realisation in a different vol world. This is the
        "same uniforms, different strip" construction of the put leg."""
        sd = np.sqrt(var)
        log_incr = (drift - 0.5 * var) + sd * z
        # steps are the LAST axis: [n_paths, n_steps] here, [n_outer, n_inner, n_steps] from
        # simulate_conditional, identical to axis=1 for the 2-D case
        log_paths = np.cumsum(log_incr, axis=-1)
        return spot0 * np.exp(log_paths)

    # ---------------------------------------------------------------- simulate
    def simulate(self, schedule, market_data) -> np.ndarray:
        """
        Simulate spot on the observation grid.

        Continuous-yield mode (no discrete_dividends): drift = ln F(t_j)/F(t_{j-1}) from
        the repo & dividend curves. Discrete-dividend mode: drift = funding (repo) growth
        and dividends are applied as explicit drops at their ex-dates.

        Returns:
            spot_paths [n_paths, n_obs], simulated spot at each observation date.
        """
        divs = getattr(market_data, "discrete_dividends", None)
        if divs:
            return self._simulate_discrete(schedule, market_data, divs)
        return self._simulate_continuous(schedule, market_data)

    def _simulate_continuous(self, schedule, market_data) -> np.ndarray:
        obs_times = np.asarray(schedule.obs_times, dtype=float)
        n_obs = obs_times.shape[0]
        prev_times = np.concatenate([[0.0], obs_times[:-1]])
        dt = obs_times - prev_times
        if np.any(dt <= 0):
            raise ValueError("observation times must be strictly increasing and > 0")

        # integrated (r - q) drift for each step: ln F(t_j)/F(t_{j-1}), plus quanto shift
        drift = np.array([market_data.log_drift(float(t0), float(t1))
                          for t0, t1 in zip(prev_times, obs_times)]) + self.quanto_adj * dt
        moneyness = self._moneyness(schedule, market_data)
        var = self._step_variances(obs_times, market_data, moneyness)   # per-step integrated variance

        n_paths = self.n_paths - (self.n_paths % 2) if self.antithetic else self.n_paths
        z = self._draw_normals(n_paths, n_obs)
        return self._paths_from_var(market_data.spot, drift, var, z)

    # ------------------------------------------------------------- per-leg
    def simulate_per_leg(self, schedule, market_data):
        """Multi-smile-slice GBM: a SEPARATE forward-vol strip per distinct
        coupon threshold level (the coupon/trigger leg) and another for the put leg at its
        own barrier strike, not simulate()'s single deal-level moneyness slice.
        Both legs walk off the SAME random draws (same path realisation, different vol per
        step), the "same uniforms, different strip" construction of the put leg.

        Returns (coupon_paths, put_paths), [n_paths, n_obs] each. put_paths IS coupon_paths
        (same array) when schedule.put_barrier <= 0 (no put leg to separate).

        Continuous-yield drift only (no discrete-dividend support here, matching the scope
        every other engine in this project builds its quanto/compo core around); raises if
        market_data carries discrete_dividends.
        """
        if getattr(market_data, "discrete_dividends", None):
            raise NotImplementedError(
                "simulate_per_leg does not support discrete dividends, use simulate() "
                "(single-slice) for a discrete-dividend market, or ask for this to be extended"
            )
        obs_times = np.asarray(schedule.obs_times, dtype=float)
        n_obs = obs_times.shape[0]
        prev_times = np.concatenate([[0.0], obs_times[:-1]])
        dt = obs_times - prev_times
        if np.any(dt <= 0):
            raise ValueError("observation times must be strictly increasing and > 0")

        drift = np.array([market_data.log_drift(float(t0), float(t1))
                          for t0, t1 in zip(prev_times, obs_times)]) + self.quanto_adj * dt

        strike = float(schedule.strike)
        levels = self._column_levels(schedule)

        coupon_var = np.empty(n_obs)
        for level in np.unique(levels):
            strip = self._forward_var_at_strike(obs_times, market_data, level * strike)
            mask = levels == level
            coupon_var[mask] = strip[mask]

        n_paths = self.n_paths - (self.n_paths % 2) if self.antithetic else self.n_paths
        z = self._draw_normals(n_paths, n_obs)
        coupon_paths = self._paths_from_var(market_data.spot, drift, coupon_var, z)

        put_barrier = float(getattr(schedule, "put_barrier", 0.0) or 0.0)
        if put_barrier <= 0.0:
            return coupon_paths, coupon_paths

        rebate = float(getattr(schedule, "rebate", 0.0) or 0.0)
        # The put strike convention: a Rebate=0 leg is a
        # full loss below the barrier, struck THERE; with a rebate it is the level the
        # payoff crosses zero instead, strike*(1-rebate), which DEGENERATES to <= 0 once
        # rebate >= 1.0 (a real, common value in this project's own example deals: the
        # breach payoff rebate - (1-S/strike) is then strictly positive for every S > 0, so
        # there IS no strike where it crosses zero). Querying a vol surface at a
        # non-positive strike is meaningless (log(strike/ATM_Ref) undefined at/below 0), so
        # fall back to the barrier level itself, the only other level this leg naturally
        # references, rather than erroring or extrapolating off a surface at strike 0.
        put_strike = put_barrier if rebate == 0.0 else strike * (1.0 - rebate)
        if put_strike <= 0.0:
            put_strike = put_barrier
        put_var = self._forward_var_at_strike(obs_times, market_data, put_strike)
        put_paths = self._paths_from_var(market_data.spot, drift, put_var, z)
        return coupon_paths, put_paths

    @staticmethod
    def _column_levels(schedule) -> np.ndarray:
        """The trigger level each grid column's strip is read at: that of the FIXING closing the
        window the column lies in, every
        fixing carrying its coupon's level, and its equity strip stepping fixing to fixing. A
        column between two fixings (a floating date, a lagged coupon's payment row) splits that
        interval on the SAME strip, so its variance telescopes; after the last
        fixing the last level holds (nothing reads those columns' spot). With no coupon at all
        every column reads ATM."""
        n = len(schedule.obs_times)
        is_coupon = np.asarray(schedule.is_coupon_date, dtype=bool)
        # a coupon decided on an ALREADY-PRINTED fixing is no simulated fixing: the equity
        # strip steps straight on to the next one, so it sets no column's level
        printed = getattr(schedule, "observed_mask", None)
        if printed is not None:
            is_coupon = is_coupon & ~np.asarray(printed, dtype=bool)
        idx = getattr(schedule, "obs_index", None)
        idx = np.arange(n) if idx is None else np.asarray(idx, dtype=int)
        fix_cols = idx[is_coupon]
        fix_levels = np.asarray(schedule.thresholds, dtype=float)[is_coupon]
        if fix_cols.size == 0:
            return np.ones(n)
        order = np.argsort(fix_cols)
        fix_cols, fix_levels = fix_cols[order], fix_levels[order]
        nxt = np.minimum(np.searchsorted(fix_cols, np.arange(n), side="left"), fix_cols.size - 1)
        return fix_levels[nxt]

    # ------------------------------------------------------- one fixed strike (option deals)
    def simulate_at_strike(self, times, market_data, abs_strike: float) -> np.ndarray:
        """Spot on an arbitrary time grid, every step read off ONE forward-vol strip at a fixed
        absolute strike, which reads the strip at the OPTION's strike across every monitoring
        date. Used by instruments/autocall/put_leg.py to price the put leg the way it is
        booked (separate option deals), on that booking's own grid rather than an autocall
        schedule's.

        ``vol_mode`` does not apply: the strip is always the forward (cumulative-variance
        difference) construction at ``abs_strike``. Drift and quanto shift as simulate_per_leg.
        Continuous-yield only.

        Returns spot_paths [n_paths, len(times)].
        """
        return self.simulate_at_strikes(times, market_data, [abs_strike])[0]

    def simulate_at_strikes(self, times, market_data, abs_strikes) -> list:
        """``simulate_at_strike`` for several strikes off ONE draw of normals: each strike its own
        forward-vol strip, every strip walked by the same z, common random numbers by
        construction, which a strike-difference of option prices (a digital as a spread of puts,
        each at its own smile point) needs to stay low-noise. The first strike's paths are
        bit-identical to ``simulate_at_strike`` at that strike.

        Returns a list of spot_paths [n_paths, len(times)], one per strike, in order.
        """
        if getattr(market_data, "discrete_dividends", None):
            raise NotImplementedError("simulate_at_strike does not support discrete dividends")
        times = np.asarray(times, dtype=float)
        prev = np.concatenate([[0.0], times[:-1]])
        dt = times - prev
        if times.size == 0 or np.any(dt <= 0):
            raise ValueError("times must be non-empty, strictly increasing and > 0")
        drift = np.array([market_data.log_drift(float(t0), float(t1))
                          for t0, t1 in zip(prev, times)]) + self.quanto_adj * dt
        n_paths = self.n_paths - (self.n_paths % 2) if self.antithetic else self.n_paths
        z = self._draw_normals(n_paths, times.size)
        return [self._paths_from_var(market_data.spot, drift,
                                     self._forward_var_at_strike(times, market_data, k), z)
                for k in abs_strikes]

    # ----------------------------------------------------- conditional (inner paths)
    @staticmethod
    def simulate_conditional(spot0, drift, var, z) -> np.ndarray:
        """Inner paths conditional on an OUTER scenario state: from each
        outer path's own spot, drift and variance strip, every inner path walked by the SAME
        normals ``z`` (common random numbers across outer paths).

        Args:
            spot0: [n_outer] the outer scenario's spot at the conditioning date.
            drift: [n_outer, n_steps] or [n_steps] integrated log-forward increments per step
                (carry - dividend, plus any quanto shift), from that outer path's own curves.
            var:   [n_outer, n_steps] or [n_steps] integrated forward variance per step (a
                strip at one strike, read from the conditioning date, _forward_var_at_strike's
                construction on the remaining tenors).
            z:     [n_inner, n_steps] standard normals.

        Returns spot paths [n_outer, n_inner, n_steps]. Exact lognormal, no discretisation
        error, the same _paths_from_var every other simulate method uses.
        """
        spot0 = np.asarray(spot0, dtype=float).reshape(-1, 1, 1)
        drift = np.asarray(drift, dtype=float)
        var = np.asarray(var, dtype=float)
        drift = drift[:, None, :] if drift.ndim == 2 else drift[None, None, :]
        var = var[:, None, :] if var.ndim == 2 else var[None, None, :]
        return GBMEngine._paths_from_var(spot0, drift, var, np.asarray(z, dtype=float)[None, :, :])

    def _simulate_discrete(self, schedule, market_data, dividends) -> np.ndarray:
        """
        Level-space simulation over a merged grid of observation ∪ ex-dates. Drift between
        grid points is the funding (repo) growth; at each ex-date a dividend drop is applied
        BEFORE the spot is recorded for any observation coinciding with that date. Cash
        dividends are subtracted in level space (floored at 0); proportional multiply by (1-δ).
        """
        from autocall_pricer.models.dividends import CASH, PROPORTIONAL

        obs_times = np.asarray(schedule.obs_times, dtype=float)
        n_obs = obs_times.shape[0]

        # ex-times aligned to a single vol at expiry; build event grid
        ex_times = np.array([market_data.yearfrac(d.ex_date) for d in dividends])
        # dividends strictly after valuation and up to (incl.) last observation
        keep = (ex_times > 0) & (ex_times <= obs_times[-1] + 1e-12)
        ex_times, dividends = ex_times[keep], [d for d, k in zip(dividends, keep) if k]

        grid = np.unique(np.concatenate([obs_times, ex_times]))
        prev = np.concatenate([[0.0], grid[:-1]])
        if np.any(grid - prev <= 0):
            raise ValueError("merged grid must be strictly increasing")

        dt = grid - prev
        # grid[-1] == obs_times[-1] (ex-dates are kept only up to the last observation), so
        # "single" mode still reads the terminal-observation vol as before.
        moneyness = self._moneyness(schedule, market_data)
        var = self._step_variances(grid, market_data, moneyness)   # per-step integrated variance
        sd = np.sqrt(var)
        drift = np.array([market_data.repo_growth_log(float(t0), float(t1))
                          for t0, t1 in zip(prev, grid)]) + self.quanto_adj * dt

        n_paths = self.n_paths - (self.n_paths % 2) if self.antithetic else self.n_paths
        z = self._draw_normals(n_paths, grid.shape[0])

        # map grid point -> list of dividend drops, and grid point -> obs column index
        div_at = {i: [] for i in range(grid.shape[0])}
        for t_ex, d in zip(ex_times, dividends):
            div_at[int(np.searchsorted(grid, t_ex))].append(d)
        obs_col = {int(np.searchsorted(grid, t)): j for j, t in enumerate(obs_times)}

        S = np.full(n_paths, market_data.spot, dtype=float)
        out = np.empty((n_paths, n_obs))
        for k in range(grid.shape[0]):
            S = S * np.exp(drift[k] - 0.5 * var[k] + sd[k] * z[:, k])
            for d in div_at[k]:
                if d.kind == CASH:
                    S = np.maximum(S - d.amount, 0.0)
                elif d.kind == PROPORTIONAL:
                    S = S * (1.0 - d.amount)
                else:
                    raise ValueError(f"unknown dividend kind {d.kind!r}")
            if k in obs_col:
                out[:, obs_col[k]] = S
        return out
