"""
Monte Carlo simulation models for the independent autocall validator.

GBMEngine simulates equity spot on an instrument's observation grid; analytics.py holds
closed-form references used to validate the engine.
"""

from .gbm import GBMEngine
from .fx_gbm import CorrelatedGBMEngine
from .analytics import black_scholes_price, quanto_forward, quanto_option_price
from .dividends import (
    CASH,
    PROPORTIONAL,
    Dividend,
    cash_dividend_forward,
    cash_schedule_equivalent_yield,
    proportional_schedule_to_yield,
    yield_to_proportional_schedule,
)

__all__ = [
    "GBMEngine",
    "CorrelatedGBMEngine",
    "black_scholes_price",
    "quanto_forward",
    "quanto_option_price",
    "Dividend",
    "CASH",
    "PROPORTIONAL",
    "cash_dividend_forward",
    "cash_schedule_equivalent_yield",
    "proportional_schedule_to_yield",
    "yield_to_proportional_schedule",
]
