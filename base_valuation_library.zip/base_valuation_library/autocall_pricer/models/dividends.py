"""
Discrete dividend models and reconciliation to a continuous yield.

Two discrete kinds:
  - CASH: actual cash amount D_i subtracted from spot at ex-date (the realistic model;
    reconciles to a continuous yield only approximately, via an equivalent yield).
  - PROPORTIONAL: spot multiplied by (1 - delta_i) at ex-date (collapses EXACTLY to a
    continuous yield; used as a self-consistency check against the Phase 3 continuous model).

Cash-dividend forward (escrowed-funding convention, used by the engine and its checks):
    F(T) = S0 * exp(r T) - sum_{t_i <= T} D_i * exp(r (T - t_i))
i.e. spot grows at the funding rate r and each cash dividend is subtracted and grows at r
thereafter. Between ex-dates the process is GBM with drift r; at each ex-date the cash is
removed. Large cash divs on a low spot can push a path near/below zero, paths are floored
at zero and this regime is flagged as outside the model's validity.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Callable, List

import numpy as np

CASH = "cash"
PROPORTIONAL = "proportional"


def act365(start: date, end: date) -> float:
    return (end - start).days / 365.0


@dataclass
class Dividend:
    """A single discrete dividend. `amount` is a cash amount (CASH) or a fraction (PROPORTIONAL)."""

    ex_date: date
    amount: float
    kind: str = CASH


# --------------------------------------------------------------------- forwards
def cash_dividend_forward(
    spot: float, r: float, dividends: List[Dividend], valuation_date: date, T: float,
    day_count: Callable[[date, date], float] = act365,
) -> float:
    """
    Analytic forward under the cash-dividend (escrowed-funding) model to year fraction T.
    r is a continuous funding rate (flat). Only dividends with ex-time <= T contribute.
    """
    fwd = spot * np.exp(r * T)
    for d in dividends:
        if d.kind != CASH:
            continue
        t_i = day_count(valuation_date, d.ex_date)
        if 0 < t_i <= T + 1e-12:
            fwd -= d.amount * np.exp(r * (T - t_i))
    return float(fwd)


# ---------------------------------------------------------------- reconciliation
def yield_to_proportional_schedule(
    q: float, ex_dates: List[date], valuation_date: date,
    day_count: Callable[[date, date], float] = act365,
) -> List[Dividend]:
    """
    Proportional dividends that reproduce a continuous yield q EXACTLY at each ex-date:
        delta_i = 1 - exp(-q * (t_i - t_{i-1}))   =>   prod_{t_k<=t}(1-delta_k) = exp(-q t).
    """
    schedule: List[Dividend] = []
    prev = 0.0
    for d in sorted(ex_dates):
        t = day_count(valuation_date, d)
        delta = 1.0 - np.exp(-q * (t - prev))
        schedule.append(Dividend(d, float(delta), PROPORTIONAL))
        prev = t
    return schedule


def proportional_schedule_to_yield(
    dividends: List[Dividend], T: float, valuation_date: date,
    day_count: Callable[[date, date], float] = act365,
) -> float:
    """Equivalent continuous yield of a proportional schedule over [0, T] (exact)."""
    log_keep = 0.0
    for d in dividends:
        if d.kind != PROPORTIONAL:
            continue
        t_i = day_count(valuation_date, d.ex_date)
        if 0 < t_i <= T + 1e-12:
            log_keep += np.log(1.0 - d.amount)
    return float(-log_keep / T)


def cash_schedule_equivalent_yield(
    spot: float, r: float, dividends: List[Dividend], valuation_date: date, T: float,
    day_count: Callable[[date, date], float] = act365,
) -> float:
    """
    Approximate continuous yield q such that S0*exp((r-q)T) equals the cash-dividend
    forward F(T). Used to compare a cash-dividend deal against a continuous yield model:
        q = r - (1/T) ln( F_cash(T) / S0 ).
    This matches the forward at T only (not the full term structure), hence approximate.
    """
    fwd = cash_dividend_forward(spot, r, dividends, valuation_date, T, day_count)
    return float(r - np.log(fwd / spot) / T)
