"""
Closed-form references for validating the Monte Carlo engine.

Black-Scholes in forward (Black-76) form so it stays consistent with the engine's
forward-based drift: price = D * [omega (F N(omega d1) - K N(omega d2))].
"""

from __future__ import annotations

import numpy as np
from scipy.stats import norm


def black_scholes_price(
    forward: float,
    strike: float,
    vol: float,
    expiry: float,
    discount_factor: float,
    option: str = "call",
) -> float:
    """
    Black-76 European option price on a forward.

    Args:
        forward: forward level F to expiry.
        strike: strike K.
        vol: annualised lognormal vol.
        expiry: time to expiry in years.
        discount_factor: D(0, expiry).
        option: 'call' or 'put'.

    Returns:
        Present value of the option.
    """
    omega = 1.0 if option == "call" else -1.0
    if expiry <= 0 or vol <= 0:
        return discount_factor * max(omega * (forward - strike), 0.0)
    std = vol * np.sqrt(expiry)
    d1 = (np.log(forward / strike) + 0.5 * std * std) / std
    d2 = d1 - std
    return float(discount_factor * omega * (forward * norm.cdf(omega * d1)
                                            - strike * norm.cdf(omega * d2)))


def quanto_forward(spot: float, r_f: float, q: float, rho: float,
                   vol_s: float, vol_fx: float, t: float) -> float:
    """
    Quanto forward of a foreign asset paid in domestic currency at a fixed FX rate:
        F_q(t) = S0 * exp((r_f - q - rho * vol_s * vol_fx) * t).
    The -rho*vol_s*vol_fx term is the analytic quanto drift adjustment.
    """
    return float(spot * np.exp((r_f - q - rho * vol_s * vol_fx) * t))


def quanto_option_price(spot: float, strike: float, r_f: float, r_d: float, q: float,
                        rho: float, vol_s: float, vol_fx: float, t: float,
                        fix_fx_rate: float = 1.0, option: str = "call") -> float:
    """
    European quanto option: fix_fx_rate * e^{-r_d t} * Black76 on the quanto forward,
    with equity vol vol_s. r_d discounts in the domestic (payoff) currency.
    """
    fq = quanto_forward(spot, r_f, q, rho, vol_s, vol_fx, t)
    disc = np.exp(-r_d * t)
    return fix_fx_rate * black_scholes_price(fq, strike, vol_s, t, disc, option)


# ---------------------------------------------------------------------------
# Black model on a forward price, and the standard normal distribution
# ---------------------------------------------------------------------------
_EPS = 1e-12

# --------------------------------------------------------------------------- normal
def norm_cdf(x):
    """Standard normal CDF (vectorised)."""
    return norm.cdf(x)


def norm_pdf(x):
    """Standard normal PDF (vectorised)."""
    return norm.pdf(x)


def norm_icdf(x):
    """Standard normal quantile (vectorised); argument clamped to the open interval (0, 1)."""
    return norm.ppf(np.clip(x, _EPS, 1.0 - _EPS))


# --------------------------------------------------------------------- Black-76 core
def black76_d1_d2(forward, strike, vol, tau):
    """The Black-76 d1, d2 (no discounting)."""
    forward = np.asarray(forward, dtype=float)
    strike = np.asarray(strike, dtype=float)
    std = np.asarray(vol, dtype=float) * np.sqrt(np.maximum(np.asarray(tau, dtype=float), 0.0))
    with np.errstate(divide="ignore", invalid="ignore"):
        d1 = (np.log(forward / strike) + 0.5 * std * std) / std
    return d1, d1 - std


def black76(forward, strike, vol, tau, w=1.0, *, discount=1.0):
    """
    Black-76 European option on a forward, present value.

        price = discount * w * (F N(w d1) - K N(w d2))

    Args:
        forward: forward level F to expiry.
        strike:  strike K.
        vol:     lognormal volatility (annualised).
        tau:     time to expiry in years.
        w:       +1 call, -1 put.
        discount: discount factor D(0, expiry).
    """
    forward = np.asarray(forward, dtype=float)
    strike = np.asarray(strike, dtype=float)
    tau = np.asarray(tau, dtype=float)
    std = np.asarray(vol, dtype=float) * np.sqrt(np.maximum(tau, 0.0))
    intrinsic = np.maximum(w * (forward - strike), 0.0)
    d1, d2 = black76_d1_d2(forward, strike, vol, tau)
    priced = w * (forward * norm_cdf(w * d1) - strike * norm_cdf(w * d2))
    return discount * np.where(std > 0.0, priced, intrinsic)


def cash_or_nothing(forward, strike, vol, tau, w=1.0, *, cash=1.0, discount=1.0):
    """
    Cash-or-nothing digital: pays ``cash`` iff  w*(S_T - K) > 0  at expiry.
        value = discount * cash * N(w d2)
    The analytic building block of an autocall coupon (coupon paid iff S_T >= H).
    """
    forward = np.asarray(forward, dtype=float)
    strike = np.asarray(strike, dtype=float)
    tau = np.asarray(tau, dtype=float)
    std = np.asarray(vol, dtype=float) * np.sqrt(np.maximum(tau, 0.0))
    _, d2 = black76_d1_d2(forward, strike, vol, tau)
    prob = np.where(std > 0.0, norm_cdf(w * d2), (w * (forward - strike) > 0.0).astype(float))
    return discount * cash * prob


def asset_or_nothing(forward, strike, vol, tau, w=1.0, *, discount=1.0):
    """Asset-or-nothing digital: pays S_T iff w*(S_T - K) > 0.  value = discount * F * N(w d1)."""
    forward = np.asarray(forward, dtype=float)
    d1, _ = black76_d1_d2(forward, strike, vol, tau)
    return discount * forward * norm_cdf(w * d1)
