"""Monte Carlo simulation of an equity price under a stochastic volatility model with jumps.

The model is called LogVar2FJ. Its inputs are described in
``market_data/logvar2fj_params.py``.

The model in short
------------------
Variance
    The logarithm of the daily variance is the sum of two mean reverting factors, a slow
    one and a fast one. The variance can be capped.
Leverage
    The same random numbers that move the two variance factors also move the equity return,
    with a loading for each factor. This links falls in the price to rises in volatility.
Residual
    The part of the return that the two factors do not explain is drawn each day from a
    normal inverse Gaussian distribution, or from a normal distribution. This gives the
    return its fat tails and its skew.
Drift
    The drift is set so that the average simulated price at each date equals the forward
    price.

How it is used
--------------
The engine simulates the model day by day and returns the equity price on the observation
dates of the trade. It has the same ``simulate(schedule, market_data)`` call as the
lognormal engine in ``models/gbm.py``, so either engine can feed the autocall payoff.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from scipy.stats import norm

from autocall_pricer.market_data.logvar2fj_params import LogVar2FJParams

_TINY = 1e-300


# ============================================================================ pure math
def _ou_step_weights(kappa: float, sigma, dt: np.ndarray):
    """(phi, w) of the exact OU transition y_{k+1} = phi*y_k + w*e_k over step length dt.
    sigma may be a scalar or an array matching dt (a bucketed lever read at each step start)."""
    dt = np.asarray(dt, dtype=float)
    if kappa <= 1e-10:
        return np.ones_like(dt), np.asarray(sigma) * np.sqrt(dt)
    phi = np.exp(-kappa * dt)
    var_frac = np.maximum(-np.expm1(-2.0 * kappa * dt) / (2.0 * kappa), 0.0)
    return phi, np.asarray(sigma) * np.sqrt(var_frac)


def _state_variance_path(kappa: float, sigma, deltas: np.ndarray) -> np.ndarray:
    """Deterministic Var(y_t) at each of the n+1 grid times for ONE OU factor started at 0,
    the closed-form recursion Var_{k+1} = phi_k^2 Var_k + w_k^2."""
    phi, w = _ou_step_weights(kappa, sigma, deltas)
    var = np.zeros(len(deltas) + 1)
    for k in range(len(deltas)):
        var[k + 1] = phi[k] ** 2 * var[k] + w[k] ** 2
    return var


def _nig_budget(A, alpha, beta):
    """(delta, mu, gamma) of the NIG increment that spends idiosyncratic variance A.
    gamma = sqrt(alpha^2 - beta^2); delta = A*gamma^3/alpha^2 makes A the IG shape's own
    clock; mu is the drift compensator forcing E[exp(X)] = 1."""
    gamma = np.sqrt(np.maximum(alpha * alpha - beta * beta, _TINY))
    delta = A * gamma ** 3 / (alpha * alpha)
    mu = -delta * (2.0 * beta + 1.0) / (
        np.sqrt(np.maximum(alpha * alpha - (beta + 1.0) ** 2, _TINY)) + gamma)
    return delta, mu, gamma


def _ig_cdf(x, m, lam):
    """Inverse-Gaussian CDF, mean/shape form, the exponential term through the log to avoid
    overflow at the clocks a daily grid produces."""
    r = np.sqrt(lam / np.maximum(x, _TINY))
    term1 = norm.cdf(r * (x / m - 1.0))
    log_term2 = 2.0 * lam / m + norm.logcdf(-r * (x / m + 1.0))
    return term1 + np.exp(np.clip(log_term2, -700, 700))


def _ig_pdf(x, m, lam):
    x = np.maximum(x, _TINY)
    return np.sqrt(lam / (2.0 * np.pi * x ** 3)) * np.exp(
        -lam * (x - m) ** 2 / (2.0 * m * m * x))


def _ig_quantile(u, m, lam, expand: int = 3, steps: int = 34, tol: float = 1e-11):
    """F_IG^-1(u; m, lam), safeguarded Newton with a bisection fallback from a lognormal
    moment-matched start, bracketed by geometric expansion. A fixed-budget scheme
    (no gradient correction steps are taken,
    we need the value, not a clean gradient, and ig_root already converges to `tol`)."""
    m = np.maximum(m, _TINY)
    lam = np.maximum(lam, _TINY)
    lo = m * 1e-8
    hi = m * 200.0 + 200.0 * m * m / lam
    for _ in range(expand):
        hi = np.where(_ig_cdf(hi, m, lam) < u, hi * 4.0, hi)
    sx = np.sqrt(np.log1p(m / lam))
    x = m * np.exp(sx * norm.ppf(np.clip(u, 1e-15, 1 - 1e-15)) - 0.5 * sx * sx)
    x = np.minimum(np.maximum(x, lo * 2.0), hi * 0.5)
    for _ in range(steps):
        F = _ig_cdf(x, m, lam)
        done = np.abs(F - u) < tol
        lo = np.where(F < u, x, lo)
        hi = np.where(F > u, x, hi)
        f = np.maximum(_ig_pdf(x, m, lam), _TINY)
        step = x - (F - u) / f
        bad = ~np.isfinite(step) | (step <= lo) | (step >= hi)
        x = np.where(done, x, np.where(bad, np.sqrt(np.maximum(lo * hi, _TINY)), step))
    return x


def nig_residual_draw(A, alpha, beta, u, gaussian: bool = False):
    """One day's residual increment (mean_shift, mixer) spending idiosyncratic clock A, via
    the Newton/bisection IG quantile (a scheme that inverts a
    SPECIFIC given uniform, as quasi-random draws need). Kept as the reference
    implementation for cross-checking ``_ig_sample_msh`` below; ``LogVar2FJEngine`` uses the
    fast path instead since a literal path simulator has no such uniform to honour.
    gaussian=True is the Residual_Law='Gaussian' limit: no mixer, the clock IS the variance.
    """
    if gaussian:
        return -0.5 * A, A
    delta, mu, gamma = _nig_budget(A, alpha, beta)
    m = delta / np.maximum(gamma, _TINY)
    lam = delta * delta
    G = _ig_quantile(u, m, lam)
    return mu + beta * G, G


def _ig_sample_msh(m, lam, rng: np.random.Generator) -> np.ndarray:
    """
    Exact Inverse-Gaussian sampler, Michael-Schucany-Haas (1976), one normal draw, one
    uniform, closed-form algebra, NO iteration. Used in place of ``_ig_quantile`` inside the
    simulator: inverting a SPECIFIC uniform by Newton is only needed for
    a controlled (quasi-random) draw; a literal full-path simulator has no
    such constraint and MSH is both exact and far cheaper per step.

    m, lam: mean/shape (IG(m, lam), matching ``_ig_quantile``'s parametrisation) as arrays.
    """
    m = np.maximum(m, _TINY)
    lam = np.maximum(lam, _TINY)
    y = rng.standard_normal(m.shape) ** 2
    x = m + (m * m * y) / (2.0 * lam) - (m / (2.0 * lam)) * np.sqrt(
        np.maximum(4.0 * m * lam * y + m * m * y * y, 0.0))
    u = rng.random(m.shape)
    return np.where(u <= m / (m + x), x, m * m / np.maximum(x, _TINY))


def nig_residual_draw_fast(A, alpha, beta, rng: np.random.Generator, gaussian: bool = False):
    """Exact-but-fast counterpart of ``nig_residual_draw``, via ``_ig_sample_msh``. This is
    what ``LogVar2FJEngine`` calls; ``nig_residual_draw`` (Newton) exists to verify the two
    agree in distribution (see test/... cross-check)."""
    if gaussian:
        return -0.5 * A, A
    delta, mu, gamma = _nig_budget(A, alpha, beta)
    m = delta / np.maximum(gamma, _TINY)
    lam = delta * delta
    G = _ig_sample_msh(m, lam, rng)
    return mu + beta * G, G


def _cap(x, cap_a: Optional[float]):
    return x if cap_a is None else np.minimum(x, cap_a)


# ============================================================================ engine
@dataclass
class LogVar2FJState:
    """Carried state between calls, exposed for diagnostics / seeding a later valuation."""

    ell: np.ndarray
    s: np.ndarray


class LogVar2FJEngine:
    """
    Full-path LogVar2FJ simulator: ``.simulate(schedule, market_data) -> spot_paths``.

    ``schedule`` needs only ``obs_times`` (year fractions, strictly increasing), the same
    minimal interface ``GBMEngine`` in ``models/gbm.py`` consumes, so this drops straight into
    ``AutocallSwap.price`` / any script already using ``GBMEngine``.
    """

    def __init__(self, params: LogVar2FJParams, n_paths: int = 100_000,
                 seed: Optional[int] = None, antithetic: bool = True,
                 steps_per_year: Optional[float] = None,
                 rho_fx: float = 0.0, fx_vol_surface=None):
        params.validate()
        self.params = params
        self.n_paths = n_paths
        self.seed = seed
        self.antithetic = antithetic
        # the number of steps per year belongs to the fitted parameters
        # ("the clock belongs to the fitted block, not the deal"), we honour the factor's
        # own value unless the caller explicitly overrides it for a convergence study
        self.steps_per_year = steps_per_year or params.steps_per_year
        # quanto: Correlation.EquityPrice.<Equity_Volatility>/FxRate.<sorted ccy pair> and the
        # FXVol.<sorted ccy pair> surface (ATM only), see module docstring. rho_fx=0.0 or
        # fx_vol_surface=None (either) skips the term entirely, bit-identical to no quanto.
        self.rho_fx = rho_fx
        self.fx_vol_surface = fx_vol_surface

    # ------------------------------------------------------------ internal daily grid
    def _daily_grid(self, t_max: float) -> np.ndarray:
        n = max(int(round(t_max * self.steps_per_year)), 1)
        return np.linspace(0.0, t_max, n + 1)

    # ------------------------------------------------------------------ simulate
    def simulate(self, schedule, market_data, ell0: Optional[float] = None,
                s0: Optional[float] = None) -> np.ndarray:
        """
        Returns spot_paths [n_paths, n_obs] at schedule.obs_times.

        ell0/s0 seed the variance state at t=0 (None -> re-seed at (L*(0), 0), the
        convention for a row with no carried state from an outer process).
        """
        p = self.params
        obs_times = np.asarray(schedule.obs_times, dtype=float)
        n_obs = obs_times.shape[0]
        if np.any(np.diff(obs_times) <= 0) or obs_times[0] <= 0:
            raise ValueError("obs_times must be strictly increasing and > 0")

        grid = self._daily_grid(obs_times[-1])
        deltas = np.diff(grid)
        n_steps = len(deltas)
        # map each observation date onto its nearest grid point (steps_per_year is chosen so
        # this lands within numerical noise of an exact day)
        obs_idx = np.searchsorted(grid, obs_times - 1e-9)

        n = self.n_paths - (self.n_paths % 2) if self.antithetic else self.n_paths
        rng = np.random.default_rng(self.seed)

        # L*(t) at every grid time, from the deterministic OU-variance recursion (state_variance)
        sigma_s_grid = p.sigma_s.at(grid[:-1])          # lever value in force at each step START
        var_s = _state_variance_path(p.kappa_s, sigma_s_grid, deltas)
        var_l = _state_variance_path(p.kappa_l, p.sigma_l, deltas)
        state_var = var_s + var_l                        # [n_steps+1]
        xi_grid = p.xi_curve.at(grid)
        l_star = np.log(np.maximum(xi_grid, _TINY)) - 0.5 * state_var   # [n_steps+1]

        rho_s_grid = p.rho_s.at(grid[:-1])
        alpha_grid = p.alpha.at(grid[:-1])
        beta_grid = p.beta.at(grid[:-1])
        phi_s, w_s = _ou_step_weights(p.kappa_s, sigma_s_grid, deltas)
        phi_l, w_l = _ou_step_weights(p.kappa_l, p.sigma_l, deltas)

        # quanto per-day loading q_k = rho_fx * sigma_FX,k * sqrt(dt_k), sigma_FX,k the FX
        # pair's FORWARD (not cumulative) ATM vol for step k, bootstrapped off the surface's
        # cumulative variance, so an early step's
        # variance is not double-counted into a later one.
        quanto_load = None
        if self.fx_vol_surface is not None and self.rho_fx != 0.0:
            atm_vol_grid = np.array([self.fx_vol_surface.get_vol(1.0, float(t), float(t))
                                     for t in grid])
            cum_var = atm_vol_grid * atm_vol_grid * grid
            fwd_var = np.maximum(np.diff(cum_var), 1e-12)
            sigma_fx_grid = np.sqrt(fwd_var / deltas)
            quanto_load = self.rho_fx * sigma_fx_grid * np.sqrt(deltas)   # [n_steps]

        ell = np.full(n, l_star[0] if ell0 is None else ell0)
        s = np.full(n, 0.0 if s0 is None else s0)
        log_s = np.full(n, np.log(market_data.spot))

        out = np.empty((n, n_obs))
        obs_col = {int(idx): j for j, idx in enumerate(obs_idx)}
        gaussian = p.residual_law == "Gaussian"

        for k in range(n_steps):
            t0, t1 = float(grid[k]), float(grid[k + 1])
            dt = deltas[k]

            eta_l = rng.standard_normal(n)
            eta_s = rng.standard_normal(n)
            if self.antithetic:
                half = n // 2
                eta_l[half:] = -eta_l[:half]
                eta_s[half:] = -eta_s[:half]
                # the NIG residual's own randomness is NOT antithetic-paired here (MSH is not
                # a simple inverse-CDF map); the leverage/diffusive part above carries the
                # variance reduction

            x = ell + s                                    # state going INTO this step
            V = dt * np.exp(_cap(x, p.cap_a))
            sqrtV = np.sqrt(V)
            rho_s_k, rho_l = rho_s_grid[k], p.rho_l
            idio = 1.0 - rho_s_k * rho_s_k - rho_l * rho_l

            lever = -0.5 * (rho_s_k * rho_s_k + rho_l * rho_l) * V
            m_lev = lever + rho_l * sqrtV * eta_l + rho_s_k * sqrtV * eta_s
            A = np.maximum(idio * V, 0.0)
            # NIG as a normal-variance mixture: X = mu_A + beta*G + sqrt(G)*Z, Z~N(0,1) fresh
            # each day. The compensator mu_A forces E[exp(X)] = 1 for this FULL mixture, not
            # (mu_A + beta*G) alone, dropping the sqrt(G)*Z term breaks forward-consistency.
            drift, G = nig_residual_draw_fast(A, alpha_grid[k], beta_grid[k], rng, gaussian=gaussian)
            z_residual = rng.standard_normal(n)
            residual = drift + np.sqrt(np.maximum(G, 0.0)) * z_residual

            carry = market_data.log_drift(t0, t1)          # curve-consistent (r-q) integral
            log_s = log_s + carry + m_lev + residual
            if quanto_load is not None:
                log_s = log_s - quanto_load[k] * sqrtV

            # advance the variance state for the next step
            s = phi_s[k] * s + w_s[k] * eta_s
            ell = l_star[k + 1] + phi_l[k] * (ell - l_star[k]) + w_l[k] * eta_l

            if (k + 1) in obs_col:
                out[:, obs_col[k + 1]] = np.exp(log_s)

        self.last_state = LogVar2FJState(ell=ell, s=s)
        return out
