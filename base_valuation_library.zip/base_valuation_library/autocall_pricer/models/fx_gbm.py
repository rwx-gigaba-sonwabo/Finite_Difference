"""
Correlated equity-FX GBM engine for quanto validation.

The point of this module: the main pricer values a quanto by applying the
ANALYTIC drift adjustment b_adj = -rho*sigma_S*sigma_FX and never simulates FX. Here we
simulate (S, FX) as correlated GBMs and price the quanto payoff via a change of measure,
so that adjustment must EMERGE from the correlation rather than being coded in.

Measure setup
-------------
S is a foreign-currency asset; the payoff is paid in the domestic (payoff) currency at a
FIXED rate `fix_fx_rate`. Let X = domestic-per-foreign FX. We simulate under the FOREIGN
risk-neutral measure Q^f, where:

    dS/S = (r_f - q) dt + sigma_S dW_S           # NATURAL foreign drift, NO quanto term
    dX/X = (r_d - r_f + sigma_X^2) dt + sigma_X dW_X
    corr(dW_S, dW_X) = rho

A domestic cashflow C at time t has time-0 domestic value (numeraire = foreign MMA in
domestic units, N^f_t = X_t e^{r_f t}):

    PV = X_0 * E^{Q^f}[ C / (X_t e^{r_f t}) ] = E^{Q^f}[ C * w_t ],
        w_t = (X_0 / X_t) e^{-r_f t}.

For the quanto autocall, C = fix_fx_rate * (payoff in S-terms). So we hand the payoff
evaluator the per-path stochastic discount weights w_t (shape [n_paths, n_obs]) and set the
FX conversion factor to fix_fx_rate. The -rho*sigma_S*sigma_FX drift never appears in the
S dynamics; it is produced entirely by Cov(payoff(S), 1/X).

r_f = repo_curve rate, q = div_curve, r_d = discount_curve (payoff currency),
sigma_X = fx_vol, rho = corr_equity_fx. X_0 is arbitrary (cancels) and set to 1.
"""

from __future__ import annotations

import numpy as np


class CorrelatedGBMEngine:
    def __init__(self, n_paths: int = 200_000, seed: int | None = None, antithetic: bool = True):
        self.n_paths = n_paths
        self.seed = seed
        self.antithetic = antithetic

    def _draw(self, n_paths: int, n_steps: int, rho: float):
        """Two correlated standard-normal fields via Cholesky, with antithetics."""
        rng = np.random.default_rng(self.seed)
        n = n_paths // 2 if self.antithetic else n_paths
        z1 = rng.standard_normal((n, n_steps))
        z2 = rng.standard_normal((n, n_steps))
        w_s = z1
        w_x = rho * z1 + np.sqrt(max(1.0 - rho * rho, 0.0)) * z2
        if self.antithetic:
            w_s = np.concatenate([w_s, -w_s], axis=0)
            w_x = np.concatenate([w_x, -w_x], axis=0)
        return w_s, w_x

    def simulate_quanto(self, schedule, market_data):
        """
        Simulate (S, X) under Q^f and return:
            S_paths       [n_paths, n_obs]  foreign-drift spot at each observation date
            disc_weights  [n_paths, n_obs]  w_t = (X_0/X_t) e^{-r_f t}
        Feed disc_weights as `discount_factors` and fx=fix_fx_rate into the payoff.
        """
        obs = np.asarray(schedule.obs_times, dtype=float)
        n_obs = obs.shape[0]
        prev = np.concatenate([[0.0], obs[:-1]])
        dt = obs - prev

        sigma_s = market_data.vol(expiry=float(obs[-1]), moneyness=1.0)
        sigma_x = float(market_data.fx_vol)
        rho = float(market_data.corr_equity_fx)

        # per-step integrated rates
        rf_dt = np.array([market_data.repo_growth_log(float(a), float(b)) for a, b in zip(prev, obs)])
        rq_dt = np.array([market_data.log_drift(float(a), float(b)) for a, b in zip(prev, obs)])  # (r_f - q)dt
        rd_dt = np.array([_disc_growth(market_data, float(a), float(b)) for a, b in zip(prev, obs)])

        n_paths = self.n_paths - (self.n_paths % 2) if self.antithetic else self.n_paths
        w_s, w_x = self._draw(n_paths, n_obs, rho)

        # S under Q^f: natural foreign drift (r_f - q), NO quanto adjustment
        log_s = np.cumsum(rq_dt - 0.5 * sigma_s * sigma_s * dt + sigma_s * np.sqrt(dt) * w_s, axis=1)
        S_paths = market_data.spot * np.exp(log_s)

        # X = DOM/FOR under Q^f: drift (r_d - r_f + sigma_X^2); log-drift = (r_d-r_f) + 0.5 sigma_X^2
        log_x = np.cumsum((rd_dt - rf_dt) + 0.5 * sigma_x * sigma_x * dt
                          + sigma_x * np.sqrt(dt) * w_x, axis=1)
        X_paths = np.exp(log_x)  # X_0 = 1

        # cumulative funding discount e^{-r_f t_j} = product of repo DFs = exp(-cumsum(rf_dt))
        disc_rf = np.exp(-np.cumsum(rf_dt))            # [n_obs]
        disc_weights = disc_rf[np.newaxis, :] / X_paths  # (X_0/X_t) e^{-r_f t}, X_0=1
        return S_paths, disc_weights


def _disc_growth(market_data, t0: float, t1: float) -> float:
    """Integrated domestic (discount-curve) rate over [t0, t1] = r_d (t1 - t0)."""
    df0 = float(market_data.discount_curve.discount_factor(t0)) if t0 > 0 else 1.0
    df1 = float(market_data.discount_curve.discount_factor(t1))
    return float(-np.log(df1 / df0))
