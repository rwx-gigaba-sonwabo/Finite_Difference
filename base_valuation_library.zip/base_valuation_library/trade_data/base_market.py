"""The market on the valuation date, built from the price factors of a trade JSON file.

A base valuation prices a trade once, on one date, off one set of market data. This module
turns the price factors in the file into the objects the pricers use:

* zero rate curves, with the interpolation scheme the file asks for,
* FX spot rates and cross rates,
* commodity forward price curves and the fixing date to delivery date mapping,
* volatility surfaces,
* correlations.

It also packs raw curves and spot values into a ``market_state`` dictionary. That is the
single input every instrument in ``instruments/`` prices from.

Naming
------
Price factors are named ``"<Type>.<Name>"``, for example ``"InterestRate.USD-SOFR"``.
Most methods accept the short name (``"USD-SOFR"``) or the full name.

Spread curves
-------------
An interest rate name with dots is a base curve plus spreads. ``"ZAR-SWAP.ZAR-USD-BASIS"``
means the zero rate of ``InterestRate.ZAR-SWAP`` plus the spread stored in
``InterestRate.ZAR-SWAP.ZAR-USD-BASIS``. Each layer is interpolated with its own scheme
and the rates are added.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Callable

import numpy as np

from market_data.moneyness_vol_surface import MoneynessVolSurface
from market_data.risk_factor import CurveSlice, RiskFactorSlice, ScalarSlice
from market_data.yield_curve import YieldCurve
from trade_data.trade_file import TradeFile, TradeFileError
from utils.curve_interpolation import interpolator, resolve_curve_interpolation

#: Day zero of the Excel serial date system. Forward price curves use serial dates as pillars.
EXCEL_EPOCH = date(1899, 12, 30)

#: Days in a year for each day count name a rate curve can carry in the file.
DAYS_IN_YEAR = {"ACT_365": 365.0, "ACT_360": 360.0, "ACT_365_ISDA": 365.0}


def date_to_excel_serial(day: date) -> float:
    """Number of days from the Excel epoch to ``day``."""
    return float((day - EXCEL_EPOCH).days)


def excel_serial_to_date(serial: float) -> date:
    """Calendar date for an Excel serial number."""
    return EXCEL_EPOCH + timedelta(days=int(round(float(serial))))


def full_factor_name(factor_type: str, name: str) -> str:
    """Return ``"<factor_type>.<name>"`` unless ``name`` already starts with the type."""
    return name if name.startswith(factor_type + ".") else f"{factor_type}.{name}"


@dataclass(frozen=True)
class ZeroRateCurve:
    """A zero rate curve on the valuation date, possibly a base curve plus spreads.

    Attributes
    ----------
    name : str
        Full name of the curve as asked for.
    layers : tuple of YieldCurve
        The base curve first, then one curve per spread. Their rates are added.
    days_in_year : float
        Divisor that turns calendar days into the curve's year fraction.
    interpolation : tuple of str
        Scheme used for each layer, in the same order as ``layers``.
    """

    name: str
    layers: tuple
    days_in_year: float
    interpolation: tuple

    def year_fraction(self, start: date, end: date) -> float:
        """Time from ``start`` to ``end`` in years, on the curve's own day count."""
        return (end - start).days / self.days_in_year

    def zero_rate(self, t: float) -> float:
        """Continuously compounded zero rate for a time ``t`` in years."""
        return float(sum(layer.get_rate(float(t))[0] for layer in self.layers))

    def discount_factor(self, t: float) -> float:
        """Discount factor ``exp(-zero_rate(t) * t)`` for a time ``t`` in years."""
        return float(np.exp(-self.zero_rate(t) * t))


@dataclass(frozen=True)
class ReferencePrice:
    """How a commodity fixing date maps onto a delivery date on a forward price curve.

    A commodity option fixes against a published reference price. On each fixing date the
    reference price is the forward price of one delivery date. The mapping from fixing date
    to delivery date is stored as a curve of Excel serial dates.

    Attributes
    ----------
    name : str
        Short name of the reference price.
    forward_price_name : str
        Short name of the forward price curve the reference reads.
    fixing_curve : np.ndarray, shape (n, 2)
        Column 0 is the fixing date and column 1 the delivery date, both as Excel serials.
    """

    name: str
    forward_price_name: str
    fixing_curve: np.ndarray

    def delivery_serial(self, fixing_date: date) -> float:
        """Excel serial of the delivery date that ``fixing_date`` fixes against.

        Linear between the mapping's points and flat outside them.
        """
        return float(np.interp(
            date_to_excel_serial(fixing_date), self.fixing_curve[:, 0], self.fixing_curve[:, 1]))

    def delivery_date(self, fixing_date: date) -> date:
        """Delivery date that ``fixing_date`` fixes against, rounded to a whole day."""
        return excel_serial_to_date(self.delivery_serial(fixing_date))


class BaseMarket:
    """Market data on the valuation date, read from one trade JSON file.

    Parameters
    ----------
    trade_file : TradeFile
        The loaded trade JSON file.
    interpolation_overrides : dict, optional
        ``{full curve name: scheme name or interpolator factory}``. Use it to force a
        scheme for one curve instead of the scheme resolved from the file.

    Attributes
    ----------
    valuation_date : date
        The date the market data belongs to.
    interpolation_notes : dict
        ``{full curve name: note}`` saying which scheme each curve was read with and why.
        Filled as curves are used, and printed by the run scripts.
    """

    def __init__(self, trade_file: TradeFile, interpolation_overrides: dict | None = None) -> None:
        self.trade_file = trade_file
        self.valuation_date: date = trade_file.valuation_date
        self._overrides = dict(interpolation_overrides or {})
        self.interpolation_notes: dict[str, str] = {}

    # --------------------------------------------------------- interpolation
    def curve_interpolator(self, full_name: str) -> Callable:
        """Return the interpolator factory to read one curve with.

        The scheme comes from ``interpolation_overrides`` when the curve is listed there,
        and from the trade file's own interpolation rules otherwise.
        """
        if full_name in self._overrides:
            scheme = self._overrides[full_name]
            label = scheme if isinstance(scheme, str) else getattr(scheme, "__name__", "custom")
            self.interpolation_notes[full_name] = f"{label} (set by hand in the run script)"
            return interpolator(scheme)
        scheme, how = resolve_curve_interpolation(self.trade_file.raw, full_name)
        self.interpolation_notes[full_name] = f"{scheme} ({how})"
        return interpolator(scheme)

    # ----------------------------------------------------------- rate curves
    def zero_rate_curve(self, name: str, factor_type: str = "InterestRate") -> ZeroRateCurve:
        """Build a zero rate curve, adding any spread layers named in ``name``.

        Parameters
        ----------
        name : str
            Short or full curve name. Dots after the base name add spread curves.
        factor_type : str
            Price factor type of the curve. ``"InterestRate"`` unless stated.
        """
        short = name[len(factor_type) + 1:] if name.startswith(factor_type + ".") else name
        parts = short.split(".")
        layers, schemes, days_in_year = [], [], None
        for depth in range(1, len(parts) + 1):
            layer_name = full_factor_name(factor_type, ".".join(parts[:depth]))
            if not self.trade_file.has_price_factor(layer_name):
                if depth == 1:
                    raise TradeFileError(f"Curve {layer_name!r} is not in the trade file.")
                continue
            points = self.trade_file.curve_points(layer_name)
            layers.append(YieldCurve(points[:, 0], points[:, 1], self.curve_interpolator(layer_name)))
            schemes.append(self.interpolation_notes[layer_name].split(" ")[0])
            if days_in_year is None:
                day_count = self.trade_file.price_factor(layer_name).get("Day_Count") or "ACT_365"
                if day_count not in DAYS_IN_YEAR:
                    raise NotImplementedError(
                        f"{layer_name}: day count {day_count!r} is not supported. "
                        f"Supported: {sorted(DAYS_IN_YEAR)}")
                days_in_year = DAYS_IN_YEAR[day_count]
        return ZeroRateCurve(full_factor_name(factor_type, short), tuple(layers),
                             days_in_year or 365.0, tuple(schemes))

    # -------------------------------------------------------------------- FX
    def fx_spot(self, currency: str) -> float:
        """Value of one unit of ``currency`` in the file's base currency."""
        factor = self.trade_file.price_factor(full_factor_name("FxRate", currency))
        return float(factor["Spot"])

    def fx_rate(self, from_currency: str, to_currency: str) -> float:
        """Units of ``to_currency`` that one unit of ``from_currency`` buys today."""
        if from_currency == to_currency:
            return 1.0
        return self.fx_spot(from_currency) / self.fx_spot(to_currency)

    def fx_interest_rate_name(self, currency: str) -> str:
        """Short name of the interest rate curve that carries ``currency`` forward."""
        factor = self.trade_file.price_factor(full_factor_name("FxRate", currency))
        curve = factor.get("Interest_Rate")
        if not curve:
            raise TradeFileError(f"FxRate.{currency} names no Interest_Rate curve.")
        return str(curve)

    def fx_forward_rate(self, from_currency: str, to_currency: str, t: float) -> float:
        """Forward FX rate for a time ``t`` in years, by covered interest parity.

        ``spot * exp((r_to - r_from) * t)``, in units of ``to_currency`` per one unit of
        ``from_currency``. Each currency grows on the curve its FX factor names.
        """
        if from_currency == to_currency:
            return 1.0
        r_from = self.zero_rate_curve(self.fx_interest_rate_name(from_currency)).zero_rate(t)
        r_to = self.zero_rate_curve(self.fx_interest_rate_name(to_currency)).zero_rate(t)
        return self.fx_rate(from_currency, to_currency) * float(np.exp((r_to - r_from) * t))

    # ------------------------------------------------------------ commodities
    def reference_price(self, name: str) -> ReferencePrice:
        """Read the fixing date to delivery date mapping of a commodity reference price."""
        full = full_factor_name("ReferencePrice", name)
        factor = self.trade_file.price_factor(full)
        forward_name = factor.get("ForwardPrice")
        if not forward_name:
            raise TradeFileError(f"{full} names no ForwardPrice curve.")
        return ReferencePrice(
            name=full.split(".", 1)[1],
            forward_price_name=str(forward_name),
            fixing_curve=self.trade_file.curve_points(full, "Fixing_Curve"))

    def forward_price_currency(self, name: str) -> str:
        """Currency a forward price curve is quoted in."""
        return str(self.trade_file.price_factor(full_factor_name("ForwardPrice", name))["Currency"])

    # ----------------------------------------------------------- volatilities
    def vol_surface(self, full_name: str):
        """Build the volatility surface stored under a full price factor name.

        Supported surface types are ``Explicit`` (moneyness is underlying over strike) and
        ``Relative_Forward`` (moneyness is strike minus forward, over forward). ``Malz``
        surfaces quoted in delta are built with :class:`market_data.vol_surface.FXVolSurface`.
        """
        factor = self.trade_file.price_factor(full_name)
        surface_type = factor.get("Surface_Type") or "Explicit"
        if surface_type == "Explicit":
            return MoneynessVolSurface(factor["Surface"], "ratio")
        if surface_type == "Relative_Forward":
            return MoneynessVolSurface(factor["Surface"], "relative_forward")
        if surface_type == "Malz":
            from market_data.vol_surface import FXVolSurface
            return FXVolSurface(factor["Delta_Surface"], "Malz")
        raise NotImplementedError(
            f"{full_name}: surface type {surface_type!r} is not supported by this reader. "
            f"Supported: Explicit, Relative_Forward, Malz.")

    def equity_vol_skew(self, full_name: str):
        """Build a parametric equity volatility skew from its term structures.

        The factor stores one curve per parameter: ``ATM_Vol``, ``s``, ``L``, ``R``, ``C``,
        ``D``, ``lam``, ``rho`` and ``ATM_Ref``. Each curve is a list of ``[tenor, value]``.
        """
        from market_data.vol_surface import BenchmarkVolSkew
        factor = self.trade_file.price_factor(full_name)
        try:
            return BenchmarkVolSkew(
                factor["ATM_Vol"], factor["s"], factor["L"], factor["R"], factor["C"],
                factor["D"], factor["lam"], factor["rho"], factor["ATM_Ref"])
        except KeyError as missing:
            raise TradeFileError(f"{full_name} has no skew parameter {missing}.") from missing

    def delta_vol_surface(self, full_name: str):
        """Build an FX volatility surface quoted in delta, from the ``Delta_Surface`` field."""
        from market_data.vol_surface import MalzVol
        return MalzVol(np.asarray(self.trade_file.price_factor(full_name)["Delta_Surface"]).tolist())

    def interest_rate_vol_surface(self, full_name: str):
        """Build a swaption volatility cube from rows of moneyness, expiry, tenor and volatility."""
        from market_data.vol_surface import IRVol
        return IRVol(np.asarray(self.trade_file.price_factor(full_name)["Surface"]).tolist())

    def relative_moneyness_vol_surface(self, full_name: str):
        """Build a commodity surface quoted in ``(strike - forward) / forward`` moneyness."""
        from market_data.vol_surface import NonPreciousCommodityVol
        return NonPreciousCommodityVol(
            np.asarray(self.trade_file.price_factor(full_name)["Surface"]).tolist())

    # ----------------------------------------------------------- correlations
    def correlation(self, factor_a: str, factor_b: str) -> float:
        """Correlation between two price factors, looked up in either name order."""
        for name in (f"Correlation.{factor_a}/{factor_b}", f"Correlation.{factor_b}/{factor_a}"):
            if self.trade_file.has_price_factor(name):
                return float(self.trade_file.price_factor(name)["Value"])
        raise TradeFileError(f"No correlation between {factor_a} and {factor_b} in the trade file.")

    # ----------------------------------------------------------- market state
    def curve_slice(self, full_name: str, field: str = "Curve") -> CurveSlice:
        """Pack one curve's pillars into the slice type the instruments read."""
        points = self.trade_file.curve_points(full_name, field)
        return CurveSlice(values=points[:, 1], tenors=points[:, 0])

    def scalar_slice(self, full_name: str, field: str = "Spot") -> ScalarSlice:
        """Pack one number, such as a spot price, into the slice type the instruments read."""
        return ScalarSlice(values=np.array([float(self.trade_file.price_factor(full_name)[field])]))

    def hazard_rate_slice(self, full_name: str) -> CurveSlice:
        """Turn a survival probability curve into a curve of average hazard rates.

        The file stores ``-ln(survival probability)`` at each tenor. Dividing by the tenor
        gives the average hazard rate ``h`` to that tenor, so that survival to time ``t``
        is ``exp(-h(t) * t)``. Read the result with the ``LinearRT`` scheme, which is
        linear in ``h * t`` and so linear in the stored quantity.
        """
        points = self.trade_file.curve_points(full_name)
        tenors = points[:, 0]
        return CurveSlice(values=points[:, 1] / np.maximum(tenors, 1e-10), tenors=tenors)

    def recovery_rate(self, full_name: str, default: float = 0.4) -> float:
        """Recovery rate stored on a survival probability factor, or ``default``."""
        value = self.trade_file.price_factor(full_name).get("Recovery_Rate")
        return float(default if value in (None, "") else value)

    def market_state(self, curves=(), scalars=(), extra: dict | None = None
                     ) -> dict[str, RiskFactorSlice]:
        """Build the ``market_state`` dictionary one instrument prices from.

        Parameters
        ----------
        curves : iterable of str
            Full names of curve factors to include. ``None`` entries are skipped.
        scalars : iterable of str
            Full names of single value factors to include, read from their ``Spot`` field.
        extra : dict, optional
            Ready made slices to add, keyed by the name the instrument expects.

        Returns
        -------
        dict
            ``{full factor name: slice}`` holding one market scenario, today's.
        """
        state: dict[str, RiskFactorSlice] = {}
        for name in curves:
            if name:
                state[name] = self.curve_slice(name)
        for name in scalars:
            if name:
                state[name] = self.scalar_slice(name)
        state.update(extra or {})
        return state
