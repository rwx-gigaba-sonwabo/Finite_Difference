"""Reading trade terms for a run script, either from the deal in the trade file or typed in.

A run script lists every trade term it needs as a setting. Each setting is either

* a value typed into the script, or
* ``from_trade_file("Field_Name")``, which reads that field of the deal.

:func:`resolve_term` turns a setting into its value. This keeps one clear place where the
script says which terms come from the file and under which field name.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class DealField:
    """A marker saying: read this term from a field of the deal.

    Attributes
    ----------
    field : str
        Name of the deal field to read.
    convert : callable, optional
        Function applied to the field's value, for example to turn ``"Buy"`` into ``True``.
    default : object, optional
        Value used when the deal does not have the field. When no default is given a
        missing field is an error.
    """

    field: str
    convert: Callable[[Any], Any] | None = None
    default: Any = None
    has_default: bool = False


def from_trade_file(field: str, convert: Callable[[Any], Any] | None = None, **options) -> DealField:
    """Say that a trade term is read from a field of the deal in the trade file.

    Parameters
    ----------
    field : str
        Name of the deal field.
    convert : callable, optional
        Function applied to the value read.
    default : object, optional
        Keyword only. Value to use when the deal has no such field.
    """
    if "default" in options:
        return DealField(field, convert, options["default"], True)
    return DealField(field, convert)


def resolve_term(setting: Any, deal: dict, setting_name: str = "") -> Any:
    """Return the value of one trade term.

    A typed value is returned as it is. A :class:`DealField` is read from ``deal``.

    Raises
    ------
    KeyError
        When the deal has no such field and the setting gives no default.
    """
    if not isinstance(setting, DealField):
        return setting
    value = deal.get(setting.field)
    if value is None or value == "":
        if setting.has_default:
            return setting.default
        raise KeyError(
            f"Deal {deal.get('Reference')!r} has no field {setting.field!r}. "
            f"Type the value into the setting {setting_name or setting.field} of the run script.")
    return setting.convert(value) if setting.convert else value


def is_buy(value: str) -> bool:
    """``True`` for ``"Buy"``, ``False`` for ``"Sell"``."""
    return str(value).strip().lower() == "buy"


def is_call(value: str) -> bool:
    """``True`` for ``"Call"``, ``False`` for ``"Put"``."""
    return str(value).strip().lower() == "call"
