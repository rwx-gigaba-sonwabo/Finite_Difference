# Trade data

Everything that reads a trade JSON file.

1. `trade_file.py` reads the file and turns its tagged values into plain Python values.
2. `base_market.py` builds the market on the valuation date from the price factors in the file.
3. `deal_terms.py` lets a run script say which trade terms come from the file and which are typed in.
4. `commodity_option_builders.py` turns a commodity option deal into an instrument.

Nothing in this folder prices a trade. See `docs/trade_file_format.md` for the layout of the file.

## Files

| File | What it holds |
|---|---|
| `base_market.py` | The market on the valuation date, built from the price factors of a trade JSON file. |
| `commodity_option_builders.py` | Building commodity option instruments from the deals in a trade JSON file. |
| `deal_terms.py` | Reading trade terms for a run script, either from the deal in the trade file or typed in. |
| `trade_file.py` | Reader for a trade JSON file. |
