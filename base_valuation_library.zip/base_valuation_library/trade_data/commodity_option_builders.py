"""Building commodity option instruments from the deals in a trade JSON file.

Each builder takes one deal, as read by :class:`trade_data.trade_file.TradeFile`, and the
market on the valuation date. It returns the instrument and the ``market_state``
dictionary that instrument prices from.

The builders only translate. Field names of the deal on the left, constructor arguments
of the instrument on the right. All pricing lives in ``instruments/`` and ``models/``.
"""

from __future__ import annotations

import warnings
from datetime import date

from dateutil.relativedelta import relativedelta

from instruments.commodity_barrier_option import CommodityBarrierOption
from instruments.commodity_digital_option import CommodityDigitalOption
from instruments.components.commodity_option_market import CrossCurrencyPayoff
from market_data.risk_factor import RiskFactorSlice
from trade_data.base_market import BaseMarket, date_to_excel_serial, full_factor_name
from trade_data.trade_file import TradeFileError

#: Payout type names used in a deal, mapped onto the names the instruments use.
PAYOFF_TYPE_NAMES = {"Standard": "standard", "Quanto": "quanto", "Compo": "composite"}


def _layer_names(market: BaseMarket, curve_name: str) -> tuple:
    """Full names of a rate curve and each of its spread layers that the file holds."""
    parts = curve_name.split(".")
    names = [full_factor_name("InterestRate", ".".join(parts[:depth]))
             for depth in range(1, len(parts) + 1)]
    return tuple(name for name in names if market.trade_file.has_price_factor(name))


def _fx_vol_name(market: BaseMarket, currency_a: str, currency_b: str) -> str:
    """Full name of the FX volatility surface of a currency pair, in either name order."""
    for name in (f"FXVol.{currency_a}.{currency_b}", f"FXVol.{currency_b}.{currency_a}"):
        if market.trade_file.has_price_factor(name):
            return name
    raise TradeFileError(f"No FX volatility surface for {currency_a} and {currency_b} in the trade file.")


def _commodity_fx_correlation(market: BaseMarket, local_currency: str, payoff_currency: str,
                              reference_name: str) -> float:
    """Correlation between the commodity price and the FX rate, read from the trade file.

    The factor is named ``Correlation.FxRate.<local>.<payoff>/ReferencePrice.<name>.<local>``.
    It is the correlation with the FX rate quoted as payout currency per unit of commodity
    currency. When the file holds no such factor the correlation is taken as zero and a
    warning is raised, so the gap is visible in the run.
    """
    try:
        return market.correlation(
            f"FxRate.{local_currency}.{payoff_currency}",
            f"ReferencePrice.{reference_name}.{local_currency}")
    except TradeFileError:
        warnings.warn(
            f"No correlation between ReferencePrice.{reference_name} and the "
            f"{local_currency} to {payoff_currency} FX rate in the trade file. Zero is used.")
        return 0.0


def _common_inputs(deal: dict, market: BaseMarket, correlation: float | None) -> dict:
    """Resolve the market inputs both commodity options share.

    Returns a dictionary with the names of the curves to read, the volatility surface, the
    cross currency inputs when the payout type needs them, and the list of factors to
    place in ``market_state``.
    """
    reference = market.reference_price(deal["Reference_Type"])
    forward_full = full_factor_name("ForwardPrice", reference.forward_price_name)
    local_currency = market.forward_price_currency(reference.forward_price_name)
    payoff_currency = deal["Currency"]
    report_currency = market.trade_file.reporting_currency or payoff_currency

    discount_short = deal.get("Discount_Rate") or payoff_currency
    discount_layers = _layer_names(market, discount_short)
    if not discount_layers:
        raise TradeFileError(f"Discount curve InterestRate.{discount_short} is not in the trade file.")
    discount_curve = market.zero_rate_curve(discount_short)

    payoff_type = PAYOFF_TYPE_NAMES[deal.get("Payoff_Type") or "Standard"]
    curves = [forward_full, *discount_layers]
    scalars = [f"FxRate.{payoff_currency}", f"FxRate.{report_currency}"]
    cross_currency = None
    if payoff_type != "standard":
        if payoff_currency == local_currency:
            payoff_type = "standard"
        else:
            local_layers = _layer_names(market, market.fx_interest_rate_name(local_currency))
            payoff_layers = _layer_names(market, market.fx_interest_rate_name(payoff_currency))
            if correlation is None:
                correlation = _commodity_fx_correlation(
                    market, local_currency, payoff_currency, reference.name)
            cross_currency = CrossCurrencyPayoff(
                local_fx_name=f"FxRate.{local_currency}",
                payoff_fx_name=f"FxRate.{payoff_currency}",
                local_rate_curve_names=local_layers,
                payoff_rate_curve_names=payoff_layers,
                fx_vol_surface=market.vol_surface(
                    _fx_vol_name(market, local_currency, payoff_currency)),
                correlation=float(correlation))
            curves += [*local_layers, *payoff_layers]
            scalars.append(f"FxRate.{local_currency}")

    rate_curves = [name for name in dict.fromkeys(curves) if name != forward_full]
    return {
        "reference": reference,
        "forward_curve_name": forward_full,
        "discount_curve_names": discount_layers,
        "days_in_year": discount_curve.days_in_year,
        "vol_surface": market.vol_surface(
            full_factor_name("CommodityPriceVol", deal["Reference_Volatility"])),
        "payoff_type": payoff_type,
        "cross_currency": cross_currency,
        "payoff_fx_name": f"FxRate.{payoff_currency}",
        "report_fx_name": f"FxRate.{report_currency}",
        "curve_interpolators": {name: market.curve_interpolator(name) for name in rate_curves},
        "market_state": market.market_state(curves=dict.fromkeys(curves), scalars=dict.fromkeys(scalars)),
    }


def _observed_fixing(deal: dict, on_date: date) -> float | None:
    """The price printed for ``on_date`` in the deal's ``Price_Fixing`` table, if any."""
    for row in deal.get("Price_Fixing") or []:
        if row[0] == on_date and len(row) > 1 and row[1] not in (None, ""):
            return float(row[1])
    return None


def build_commodity_digital_option(
    deal: dict,
    market: BaseMarket,
    relative_digital_spread: float | None = None,
    forward_extrapolation: str = "flat",
    correlation: float | None = None,
) -> tuple[CommodityDigitalOption, dict[str, RiskFactorSlice]]:
    """Build a commodity digital option from a ``CommodityDigitalOption`` deal.

    Deal fields read
    ----------------
    ``Reference``, ``Buy_Sell``, ``Option_Type``, ``Expiry_Date``, ``Settlement_Date``,
    ``Strike_Price``, ``Payoff``, ``Payoff_Style``, ``Payoff_Type``, ``Currency``,
    ``Discount_Rate``, ``Reference_Type``, ``Reference_Volatility``, ``Price_Fixing``.

    Parameters
    ----------
    deal : dict
        The deal's fields.
    market : BaseMarket
        Market on the valuation date.
    relative_digital_spread : float, optional
        Half width of the strike spread as a fraction of the strike. When ``None`` it is
        read from the file's valuation settings for this deal type, and is zero when the
        file does not set it.
    forward_extrapolation : {"flat", "linear"}
        Treatment of delivery dates outside the forward curve's pillars.
    correlation : float, optional
        Commodity to FX correlation for a quanto or composite payout. When ``None`` it is
        read from the file.

    Returns
    -------
    instrument : CommodityDigitalOption
    market_state : dict
    """
    if relative_digital_spread is None:
        relative_digital_spread = float(market.trade_file.valuation_setting(
            "CommodityDigitalOption", "Relative_Digital_Spread", 0.0))
    inputs = _common_inputs(deal, market, correlation)
    expiry_date = deal["Expiry_Date"]
    instrument = CommodityDigitalOption(
        name=deal.get("Reference") or "commodity_digital_option",
        expiry_date=expiry_date,
        strike=float(deal["Strike_Price"]),
        payoff_amount=float(deal["Payoff"]),
        is_call=(deal.get("Option_Type") or "Call") == "Call",
        is_buy=(deal.get("Buy_Sell") or "Buy") == "Buy",
        payoff_style=(deal.get("Payoff_Style") or "Cash").lower(),
        settlement_date=deal.get("Settlement_Date") or None,
        forward_curve_name=inputs["forward_curve_name"],
        delivery_serial=inputs["reference"].delivery_serial(expiry_date),
        discount_curve_names=inputs["discount_curve_names"],
        vol_surface=inputs["vol_surface"],
        relative_digital_spread=relative_digital_spread,
        payoff_type=inputs["payoff_type"],
        cross_currency=inputs["cross_currency"],
        payoff_fx_name=inputs["payoff_fx_name"],
        report_fx_name=inputs["report_fx_name"],
        curve_interpolators=inputs["curve_interpolators"],
        forward_extrapolation=forward_extrapolation,
        days_in_year=inputs["days_in_year"],
        expiry_fixing=_observed_fixing(deal, expiry_date),
    )
    return instrument, inputs["market_state"]


def monitoring_interval_in_years(period: str | None, valuation_date: date) -> float:
    """Turn a monitoring frequency such as ``"1D"``, ``"1W"`` or ``"1M"`` into years.

    The period is added to the valuation date on the calendar. The number of days it
    spans is divided by 365. An empty value or a zero period means the barrier is watched
    all the time and gives 0.
    """
    if not period:
        return 0.0
    amounts = {"Y": 0.0, "M": 0.0, "W": 0.0, "D": 0.0}
    number = ""
    for character in str(period).strip().upper():
        if character.isdigit() or character == ".":
            number += character
        elif character in amounts and number:
            amounts[character] += float(number)
            number = ""
        else:
            raise ValueError(f"Cannot read the monitoring frequency {period!r}")
    end = valuation_date + relativedelta(
        years=int(amounts["Y"]), months=int(amounts["M"]), weeks=int(amounts["W"]),
        days=int(amounts["D"]))
    return (end - valuation_date).days / 365.0


def build_commodity_barrier_option(
    deal: dict,
    market: BaseMarket,
    forward_extrapolation: str = "flat",
    correlation: float | None = None,
    barrier_touched_before: bool = False,
    volatility_moneyness_basis: str = "spot",
) -> tuple[CommodityBarrierOption, dict[str, RiskFactorSlice]]:
    """Build a commodity barrier option from a ``CommodityBarrierOption`` deal.

    Deal fields read
    ----------------
    ``Reference``, ``Buy_Sell``, ``Option_Type``, ``Expiry_Date``, ``Strike_Price``,
    ``Units``, ``Barrier_Type``, ``Barrier_Price``, ``Cash_Rebate``,
    ``Barrier_Monitoring_Frequency``, ``Payoff_Type``, ``Currency``, ``Discount_Rate``,
    ``Reference_Type``, ``Reference_Volatility``.

    ``Barrier_Type`` is one of ``Up_And_In``, ``Up_And_Out``, ``Down_And_In``,
    ``Down_And_Out``.

    Parameters
    ----------
    deal : dict
        The deal's fields.
    market : BaseMarket
        Market on the valuation date.
    forward_extrapolation : {"flat", "linear"}
        Treatment of delivery dates outside the forward curve's pillars.
    correlation : float, optional
        Commodity to FX correlation for a quanto or composite payout. When ``None`` it is
        read from the file.
    barrier_touched_before : bool
        ``True`` when the barrier is known to have been touched before the valuation date.
    volatility_moneyness_basis : {"spot", "forward"}
        Price used with the strike to read the volatility surface.

    Returns
    -------
    instrument : CommodityBarrierOption
    market_state : dict
    """
    inputs = _common_inputs(deal, market, correlation)
    barrier_type = deal["Barrier_Type"]
    expiry_date = deal["Expiry_Date"]
    reference = inputs["reference"]
    instrument = CommodityBarrierOption(
        name=deal.get("Reference") or "commodity_barrier_option",
        expiry_date=expiry_date,
        strike=float(deal["Strike_Price"]),
        barrier=float(deal["Barrier_Price"]),
        units=float(deal["Units"]),
        is_call=(deal.get("Option_Type") or "Call") == "Call",
        is_up="Up" in barrier_type,
        is_knock_in="In" in barrier_type.split("_")[-1],
        is_buy=(deal.get("Buy_Sell") or "Buy") == "Buy",
        cash_rebate=float(deal.get("Cash_Rebate") or 0.0),
        forward_curve_name=inputs["forward_curve_name"],
        fixing_curve=reference.fixing_curve,
        discount_curve_names=inputs["discount_curve_names"],
        vol_surface=inputs["vol_surface"],
        monitoring_interval_years=monitoring_interval_in_years(
            deal.get("Barrier_Monitoring_Frequency"), market.valuation_date),
        payoff_type=inputs["payoff_type"],
        cross_currency=inputs["cross_currency"],
        payoff_fx_name=inputs["payoff_fx_name"],
        report_fx_name=inputs["report_fx_name"],
        curve_interpolators=inputs["curve_interpolators"],
        forward_extrapolation=forward_extrapolation,
        days_in_year=inputs["days_in_year"],
        barrier_touched_before=barrier_touched_before,
        volatility_moneyness_basis=volatility_moneyness_basis,
    )
    return instrument, inputs["market_state"]


def excel_serial(day: date) -> float:
    """Excel serial number of a calendar date. Re-exported for the run scripts."""
    return date_to_excel_serial(day)
