"""Reader for a trade JSON file.

A trade JSON file holds everything one valuation needs in a single document:

* the valuation date and the reporting currency,
* the trades (called deals in the file),
* the market data (called price factors in the file),
* optional valuation settings per deal type.

This module only reads the file. It does not price anything. It turns the tagged values
in the file into plain Python types so the rest of the library never has to know how the
file is laid out.

Layout that is read
-------------------
::

    Calc
      Calculation            valuation date and reporting currency
      Deals > Deals > Children[]   each child holds one deal under Instrument > .Deal
      MergeMarketData > ExplicitMarketData
          Price Factors                 market data, keyed "<Type>.<Name>"
          Valuation Configuration       optional settings per deal type
          Price Factor Interpolation    optional curve interpolation rules

A file that only holds market data, with ``MarketData`` at the top level, is also accepted.

Tagged values
-------------
The file marks typed values with a one key dictionary. The reader converts them like this:

==================  ==========================================  =====================
Tag in the file     Example                                     Python value
==================  ==========================================  =====================
``.Timestamp``      ``{".Timestamp": "2026-01-15"}``            ``datetime.date``
``.Curve``          ``{".Curve": {"meta": [], "data": [...]}}`` ``numpy.ndarray``
``.Percent``        ``{".Percent": 5.0}``                       ``0.05``
``.Basis``          ``{".Basis": 25.0}``                        ``0.0025``
``.DateOffset``     ``{".DateOffset": "3M"}``                   ``"3M"``
``.DateList``       ``{".DateList": [["2026-01-15", 1.0]]}``    list of ``[date, value]``
``.DateEqualList``  same as above with more value columns       list of ``[date, ...]``
``.Deal``           ``{".Deal": {...}}``                        ``dict``
==================  ==========================================  =====================
"""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterator

import numpy as np


class TradeFileError(ValueError):
    """Raised when the trade JSON file does not hold what a valuation needs."""


def _to_date(text: str) -> date:
    """Turn ``"2026-01-15"`` or ``"2026-01-15T09:15:00"`` into a calendar date."""
    return datetime.fromisoformat(str(text)).date()


def decode_value(value: Any) -> Any:
    """Turn one value from the file into a plain Python value.

    Dictionaries and lists are decoded all the way down. A value with no tag is returned
    as it is.
    """
    if isinstance(value, list):
        return [decode_value(item) for item in value]
    if not isinstance(value, dict):
        return value

    if len(value) == 1:
        tag, body = next(iter(value.items()))
        if tag == ".Timestamp":
            return _to_date(body)
        if tag in (".Curve", "Curve") and isinstance(body, dict) and "data" in body:
            return np.asarray(body["data"], dtype=float)
        if tag == ".Percent":
            return float(body) / 100.0
        if tag == ".Basis":
            return float(body) / 10000.0
        if tag == ".DateOffset":
            return str(body)
        if tag in (".DateList", ".DateEqualList"):
            return [[_to_date(row[0])] + [decode_value(x) for x in row[1:]] for row in body]
        if tag == ".Deal":
            return decode_value(body)

    return {key: decode_value(item) for key, item in value.items()}


class TradeFile:
    """One trade JSON file, read once and queried many times.

    Parameters
    ----------
    path : str or Path
        Location of the trade JSON file.

    Attributes
    ----------
    path : Path
        Where the file was read from.
    valuation_date : date
        The date the trades are valued on.
    reporting_currency : str
        The currency every value is reported in.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        if not self.path.is_file():
            raise TradeFileError(f"Trade file not found: {self.path}")
        with open(self.path, encoding="utf-8") as handle:
            self._raw: dict = json.load(handle)

        calc = self._raw.get("Calc", {})
        self._calculation: dict = decode_value(calc.get("Calculation", {}))
        self._market_raw: dict = self._find_market_section()
        self._factor_cache: dict[str, dict] = {}
        self._deals: list[dict] = [decode_value(deal) for deal in self._walk_deals(
            calc.get("Deals", {}).get("Deals", {}).get("Children", []))]

        self.valuation_date: date = self._read_valuation_date()
        self.reporting_currency: str = str(
            self._calculation.get("Currency")
            or self._market_raw.get("System Parameters", {}).get("Base_Currency")
            or "")

    # ------------------------------------------------------------------ set up
    def _find_market_section(self) -> dict:
        """Find the block that holds the price factors."""
        calc = self._raw.get("Calc", {})
        market = calc.get("MergeMarketData", {}).get("ExplicitMarketData")
        if market is None:
            market = self._raw.get("MarketData")
        if market is None:
            raise TradeFileError(
                f"{self.path.name}: no market data block. Expected "
                f"Calc > MergeMarketData > ExplicitMarketData or MarketData.")
        return market

    def _walk_deals(self, children: list) -> Iterator[dict]:
        """Yield every deal in the file, including deals nested inside a netting set."""
        for child in children or []:
            instrument = child.get("Instrument", {})
            deal = instrument.get(".Deal", instrument)
            if deal:
                yield deal
            yield from self._walk_deals(child.get("Children", []))

    def _read_valuation_date(self) -> date:
        value = self._calculation.get("Base_Date")
        if not isinstance(value, date):
            value = decode_value(self._market_raw.get("System Parameters", {}).get("Base_Date"))
        if not isinstance(value, date):
            raise TradeFileError(f"{self.path.name}: no valuation date (Base_Date) in the file.")
        return value

    # ------------------------------------------------------------------- deals
    @property
    def deals(self) -> list[dict]:
        """Every deal in the file as a dictionary of its fields."""
        return list(self._deals)

    def find_deal(self, reference: str | None = None, deal_type: str | None = None) -> dict:
        """Return exactly one deal.

        Parameters
        ----------
        reference : str, optional
            The deal's ``Reference`` field. Use this when the file holds several deals.
        deal_type : str, optional
            The deal's ``Object`` field, for example ``"CommodityDigitalOption"``.

        Raises
        ------
        TradeFileError
            When no deal matches, or when more than one deal matches.
        """
        matches = [
            deal for deal in self._deals
            if (reference is None or deal.get("Reference") == reference)
            and (deal_type is None or deal.get("Object") == deal_type)
        ]
        wanted = f"reference={reference!r}, deal_type={deal_type!r}"
        if not matches:
            found = [(d.get("Reference"), d.get("Object")) for d in self._deals]
            raise TradeFileError(f"{self.path.name}: no deal matches {wanted}. Deals in file: {found}")
        if len(matches) > 1:
            found = [d.get("Reference") for d in matches]
            raise TradeFileError(
                f"{self.path.name}: {len(matches)} deals match {wanted}: {found}. "
                f"Set the deal reference to pick one.")
        return matches[0]

    # ----------------------------------------------------------- price factors
    @property
    def price_factor_names(self) -> list[str]:
        """Names of all price factors in the file, for example ``"InterestRate.USD"``."""
        return sorted(self._market_raw.get("Price Factors", {}))

    def has_price_factor(self, name: str) -> bool:
        """True when the file holds a price factor with this full name."""
        return name in self._market_raw.get("Price Factors", {})

    def price_factor(self, name: str) -> dict:
        """Return one price factor as a dictionary of decoded fields.

        Parameters
        ----------
        name : str
            Full name with its type, for example ``"ForwardPrice.BRENT"``.
        """
        if name not in self._factor_cache:
            factors = self._market_raw.get("Price Factors", {})
            if name not in factors:
                kind = name.split(".")[0]
                similar = [key for key in factors if key.startswith(kind + ".")]
                raise TradeFileError(
                    f"{self.path.name}: price factor {name!r} not found. "
                    f"Factors of type {kind}: {similar}")
            self._factor_cache[name] = decode_value(factors[name])
        return self._factor_cache[name]

    def curve_points(self, name: str, field: str = "Curve") -> np.ndarray:
        """Return the pillars of a curve factor as an array with one row per pillar.

        Column 0 is the pillar position. It is a year fraction for rate curves and an
        Excel serial date for forward price curves. Column 1 is the value at the pillar.
        """
        points = self.price_factor(name).get(field)
        if not isinstance(points, np.ndarray) or points.ndim != 2:
            raise TradeFileError(f"{self.path.name}: {name} has no curve under {field!r}.")
        return points[np.argsort(points[:, 0], kind="stable")]

    # ------------------------------------------------------ valuation settings
    def valuation_setting(self, deal_type: str, setting: str, default: Any = None) -> Any:
        """Return one valuation setting for a deal type, or ``default`` when it is not set.

        Example: ``valuation_setting("CommodityDigitalOption", "Relative_Digital_Spread", 0.0)``.
        """
        block = self._market_raw.get("Valuation Configuration") or {}
        value = (block.get(deal_type) or {}).get(setting)
        return default if value in (None, "") else decode_value(value)

    @property
    def raw(self) -> dict:
        """The file content exactly as loaded, for the few readers that need it."""
        return self._raw

    @property
    def market_section(self) -> dict:
        """The undecoded market data block."""
        return self._market_raw
