"""Reading a trade JSON file and building the market as it stands on the valuation date."""
